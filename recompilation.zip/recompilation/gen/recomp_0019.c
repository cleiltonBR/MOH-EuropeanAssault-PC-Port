/**
 * Medal of Honor: European Assault - Recompiled code chunk 19
 * Functions: 1000 (0x002CBE9A - 0x002CFF00)
 */

#define RECOMP_GENERATED_CODE
#include "recomp_funcs.h"
#include <math.h>

/**
 * sub_002CBE9A
 * Original: 0x002CBE9A - 0x002CBEA2 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBE9A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBE9A: ;
    ecx = ebp + -52;
    g_seh_ebp = ebp; sub_001FEC30(); return; /* tail jmp 0x001FEC30 */

}

/**
 * sub_002CBEA2
 * Original: 0x002CBEA2 - 0x002CBEAC (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBEA2(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBEA2: ;
    eax = 0x352600;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBEB0
 * Original: 0x002CBEB0 - 0x002CBEBB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBEB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBEB0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBEB9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBEB9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBEBB
 * Original: 0x002CBEBB - 0x002CBEC5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBEBB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBEBB: ;
    eax = 0x352624;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBED0
 * Original: 0x002CBED0 - 0x002CBEDB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBED0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBED0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBED9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBED9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBEDB
 * Original: 0x002CBEDB - 0x002CBEE5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBEDB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBEDB: ;
    eax = 0x352648;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBEF0
 * Original: 0x002CBEF0 - 0x002CBEFB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBEF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBEF0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBEF9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBEF9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBEFB
 * Original: 0x002CBEFB - 0x002CBF05 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBEFB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBEFB: ;
    eax = 0x35266C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBF10
 * Original: 0x002CBF10 - 0x002CBF1B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF10: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBF19u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBF19: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBF1B
 * Original: 0x002CBF1B - 0x002CBF25 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF1B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF1B: ;
    eax = 0x352690;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBF30
 * Original: 0x002CBF30 - 0x002CBF3B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF30: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBF39u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBF39: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBF3B
 * Original: 0x002CBF3B - 0x002CBF45 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF3B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF3B: ;
    eax = 0x3526B4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBF50
 * Original: 0x002CBF50 - 0x002CBF58 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF50: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CBF58
 * Original: 0x002CBF58 - 0x002CBF63 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF58(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF58: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x10;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002216D0(); return; /* tail jmp 0x002216D0 */

}

/**
 * sub_002CBF63
 * Original: 0x002CBF63 - 0x002CBF6E (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF63(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF63: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1C;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002216D0(); return; /* tail jmp 0x002216D0 */

}

/**
 * sub_002CBF6E
 * Original: 0x002CBF6E - 0x002CBF79 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF6E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF6E: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x28) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x28;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CBF79
 * Original: 0x002CBF79 - 0x002CBF84 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF79(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF79: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x34) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x34;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CBF84
 * Original: 0x002CBF84 - 0x002CBF8E (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF84(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF84: ;
    eax = 0x3526F8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBF90
 * Original: 0x002CBF90 - 0x002CBF9B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF90: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBF99u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBF99: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBF9B
 * Original: 0x002CBF9B - 0x002CBFA5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBF9B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBF9B: ;
    eax = 0x35271C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBFB0
 * Original: 0x002CBFB0 - 0x002CBFB8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBFB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBFB0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CBFB8
 * Original: 0x002CBFB8 - 0x002CBFC3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBFB8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBFB8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x10;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CBFC3
 * Original: 0x002CBFC3 - 0x002CBFCE (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBFC3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBFC3: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1C;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_001F6550(); return; /* tail jmp 0x001F6550 */

}

/**
 * sub_002CBFCE
 * Original: 0x002CBFCE - 0x002CBFD8 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBFCE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBFCE: ;
    eax = 0x352750;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CBFE0
 * Original: 0x002CBFE0 - 0x002CBFEB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBFE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBFE0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CBFE9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CBFE9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CBFEB
 * Original: 0x002CBFEB - 0x002CBFF5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CBFEB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CBFEB: ;
    eax = 0x352774;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC000
 * Original: 0x002CC000 - 0x002CC008 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC000(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC000: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CC008
 * Original: 0x002CC008 - 0x002CC013 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC008(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC008: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x20;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC013
 * Original: 0x002CC013 - 0x002CC01D (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC013(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC013: ;
    eax = 0x3527A0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC020
 * Original: 0x002CC020 - 0x002CC02B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC020(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC020: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC029u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC029: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC02B
 * Original: 0x002CC02B - 0x002CC035 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC02B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC02B: ;
    eax = 0x3527C4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC040
 * Original: 0x002CC040 - 0x002CC04B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC040(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC040: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC049u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC049: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC04B
 * Original: 0x002CC04B - 0x002CC055 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC04B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC04B: ;
    eax = 0x3527E8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC060
 * Original: 0x002CC060 - 0x002CC068 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC060(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC060: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CC068
 * Original: 0x002CC068 - 0x002CC073 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC068(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC068: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x14;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC073
 * Original: 0x002CC073 - 0x002CC07D (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC073(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC073: ;
    eax = 0x352814;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC080
 * Original: 0x002CC080 - 0x002CC08B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC080(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC080: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC089u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC089: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC08B
 * Original: 0x002CC08B - 0x002CC095 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC08B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC08B: ;
    eax = 0x352838;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC0A0
 * Original: 0x002CC0A0 - 0x002CC0AB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0A0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC0A9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC0A9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC0AB
 * Original: 0x002CC0AB - 0x002CC0B5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0AB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0AB: ;
    eax = 0x35285C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC0C0
 * Original: 0x002CC0C0 - 0x002CC0C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0C0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CC0C8
 * Original: 0x002CC0C8 - 0x002CC0D3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0C8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x10;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC0D3
 * Original: 0x002CC0D3 - 0x002CC0DE (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0D3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0D3: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1C;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC0DE
 * Original: 0x002CC0DE - 0x002CC0E9 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0DE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0DE: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x28) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x28;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC0E9
 * Original: 0x002CC0E9 - 0x002CC0F4 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0E9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0E9: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x34) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x34;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC0F4
 * Original: 0x002CC0F4 - 0x002CC0FF (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0F4(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0F4: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x40) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x40;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC0FF
 * Original: 0x002CC0FF - 0x002CC10A (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC0FF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC0FF: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x4C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x4C;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC10A
 * Original: 0x002CC10A - 0x002CC115 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC10A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC10A: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x58) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x58;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC115
 * Original: 0x002CC115 - 0x002CC120 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC115(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC115: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x68) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x68;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CC120
 * Original: 0x002CC120 - 0x002CC12E (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC120(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC120: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x80) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x80;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00260B60(); return; /* tail jmp 0x00260B60 */

}

/**
 * sub_002CC12E
 * Original: 0x002CC12E - 0x002CC138 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC12E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC12E: ;
    eax = 0x3528C8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC140
 * Original: 0x002CC140 - 0x002CC14B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC140(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC140: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC149u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC149: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC14B
 * Original: 0x002CC14B - 0x002CC155 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC14B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC14B: ;
    eax = 0x3528EC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC160
 * Original: 0x002CC160 - 0x002CC16B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC160(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC160: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC169u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC169: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC16B
 * Original: 0x002CC16B - 0x002CC175 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC16B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC16B: ;
    eax = 0x352910;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC180
 * Original: 0x002CC180 - 0x002CC18B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC180(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC180: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC189u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC189: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC18B
 * Original: 0x002CC18B - 0x002CC195 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC18B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC18B: ;
    eax = 0x352934;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC1A0
 * Original: 0x002CC1A0 - 0x002CC1AB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC1A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC1A0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC1A9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC1A9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC1AB
 * Original: 0x002CC1AB - 0x002CC1B5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC1AB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC1AB: ;
    eax = 0x352958;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC1C0
 * Original: 0x002CC1C0 - 0x002CC1CB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC1C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC1C0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC1C9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC1C9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC1CB
 * Original: 0x002CC1CB - 0x002CC1D5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC1CB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC1CB: ;
    eax = 0x35297C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC1E0
 * Original: 0x002CC1E0 - 0x002CC1EB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC1E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC1E0: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC1E9u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC1E9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC1EB
 * Original: 0x002CC1EB - 0x002CC1F5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC1EB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC1EB: ;
    eax = 0x3529A0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC200
 * Original: 0x002CC200 - 0x002CC20B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC200(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC200: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC209u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC209: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC20B
 * Original: 0x002CC20B - 0x002CC215 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC20B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC20B: ;
    eax = 0x3529C4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC220
 * Original: 0x002CC220 - 0x002CC22B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC220(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC220: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC229u); RECOMP_ABI_CALL(0x00263C60u, sub_00263C60); /* call 0x00263C60 */

loc_002CC229: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC22B
 * Original: 0x002CC22B - 0x002CC235 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC22B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC22B: ;
    eax = 0x3529E8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC240
 * Original: 0x002CC240 - 0x002CC248 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC240(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC240: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC248
 * Original: 0x002CC248 - 0x002CC250 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC248(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC248: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC250
 * Original: 0x002CC250 - 0x002CC258 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC250(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC250: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC258
 * Original: 0x002CC258 - 0x002CC262 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC258(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC258: ;
    eax = 0x352A24;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC270
 * Original: 0x002CC270 - 0x002CC278 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC270(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC270: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC278
 * Original: 0x002CC278 - 0x002CC282 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC278(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC278: ;
    eax = 0x352A48;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC290
 * Original: 0x002CC290 - 0x002CC29F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC290(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC290: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC29Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC29B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC29F
 * Original: 0x002CC29F - 0x002CC2A9 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC29F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC29F: ;
    eax = 0x352A6C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC2B0
 * Original: 0x002CC2B0 - 0x002CC2B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2B0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC2B8
 * Original: 0x002CC2B8 - 0x002CC2C3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2B8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0xC;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC2C3
 * Original: 0x002CC2C3 - 0x002CC2CD (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2C3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2C3: ;
    eax = 0x352A98;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC2D0
 * Original: 0x002CC2D0 - 0x002CC2D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2D0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC2D8
 * Original: 0x002CC2D8 - 0x002CC2E2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2D8: ;
    eax = 0x352ABC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC2F0
 * Original: 0x002CC2F0 - 0x002CC2FF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2F0: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC2FBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CC2FB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC2FF
 * Original: 0x002CC2FF - 0x002CC307 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC2FF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC2FF: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277A10(); return; /* tail jmp 0x00277A10 */

}

/**
 * sub_002CC307
 * Original: 0x002CC307 - 0x002CC316 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC307(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC307: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC312u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CC312: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC316
 * Original: 0x002CC316 - 0x002CC31E (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC316(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC316: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC31E
 * Original: 0x002CC31E - 0x002CC326 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC31E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC31E: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277A10(); return; /* tail jmp 0x00277A10 */

}

/**
 * sub_002CC326
 * Original: 0x002CC326 - 0x002CC330 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC326(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC326: ;
    eax = 0x352B00;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC330
 * Original: 0x002CC330 - 0x002CC338 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC330(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC330: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CC338
 * Original: 0x002CC338 - 0x002CC340 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC338(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC338: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC340
 * Original: 0x002CC340 - 0x002CC34A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC340(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC340: ;
    eax = 0x352B2C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC350
 * Original: 0x002CC350 - 0x002CC358 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC350(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC350: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC358
 * Original: 0x002CC358 - 0x002CC362 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC358(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC358: ;
    eax = 0x352B50;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC370
 * Original: 0x002CC370 - 0x002CC37F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC370(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC370: ;
    PUSH32(esp, 0x64);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC37Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CC37B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC37F
 * Original: 0x002CC37F - 0x002CC389 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC37F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC37F: ;
    eax = 0x352B74;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC390
 * Original: 0x002CC390 - 0x002CC39B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC390(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC390: ;
    ecx = ebp + -152;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC39B
 * Original: 0x002CC39B - 0x002CC3AD (18 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC39B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC39B: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -144);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC3A9u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC3A9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC3AD
 * Original: 0x002CC3AD - 0x002CC3B8 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC3AD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC3AD: ;
    ecx = ebp + -156;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC3B8
 * Original: 0x002CC3B8 - 0x002CC3C2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC3B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC3B8: ;
    eax = 0x352BA8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC3D0
 * Original: 0x002CC3D0 - 0x002CC3D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC3D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC3D0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC3D8
 * Original: 0x002CC3D8 - 0x002CC3E2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC3D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC3D8: ;
    eax = 0x352BCC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC3F0
 * Original: 0x002CC3F0 - 0x002CC3FB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC3F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC3F0: ;
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC3F9u); RECOMP_ABI_CALL(0x00277810u, sub_00277810); /* call 0x00277810 */

loc_002CC3F9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC3FB
 * Original: 0x002CC3FB - 0x002CC406 (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC3FB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC3FB: ;
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC404u); RECOMP_ABI_CALL(0x00277810u, sub_00277810); /* call 0x00277810 */

loc_002CC404: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC406
 * Original: 0x002CC406 - 0x002CC410 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC406(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC406: ;
    eax = 0x352BF8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC410
 * Original: 0x002CC410 - 0x002CC41B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC410(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC410: ;
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC419u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002CC419: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC41B
 * Original: 0x002CC41B - 0x002CC426 (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC41B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC41B: ;
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC424u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002CC424: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CC426
 * Original: 0x002CC426 - 0x002CC430 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC426(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC426: ;
    eax = 0x352C24;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC430
 * Original: 0x002CC430 - 0x002CC438 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC430(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC430: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC438
 * Original: 0x002CC438 - 0x002CC442 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC438(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC438: ;
    eax = 0x352C48;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC450
 * Original: 0x002CC450 - 0x002CC466 (22 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC450(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC450: ;
    PUSH32(esp, 0x170530);
    PUSH32(esp, 2);
    PUSH32(esp, 4);
    eax = MEM32(ebp + -16);
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC465u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CC465: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC466
 * Original: 0x002CC466 - 0x002CC470 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC466(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC466: ;
    eax = 0x352C6C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC470
 * Original: 0x002CC470 - 0x002CC486 (22 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC470(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC470: ;
    PUSH32(esp, 0x277430);
    PUSH32(esp, 2);
    PUSH32(esp, 8);
    eax = MEM32(ebp + -16);
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC485u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CC485: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC486
 * Original: 0x002CC486 - 0x002CC490 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC486(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC486: ;
    eax = 0x352C90;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC490
 * Original: 0x002CC490 - 0x002CC498 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC490(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC490: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC498
 * Original: 0x002CC498 - 0x002CC4A0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC498(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC498: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC4A0
 * Original: 0x002CC4A0 - 0x002CC4AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4A0: ;
    eax = 0x352CBC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC4B0
 * Original: 0x002CC4B0 - 0x002CC4B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4B0: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC4B8
 * Original: 0x002CC4B8 - 0x002CC4C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4B8: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC4C0
 * Original: 0x002CC4C0 - 0x002CC4CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4C0: ;
    eax = 0x352CE8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC4D0
 * Original: 0x002CC4D0 - 0x002CC4D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4D0: ;
    ecx = ebp + -60;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC4D8
 * Original: 0x002CC4D8 - 0x002CC4E2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4D8: ;
    eax = 0x352D0C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC4F0
 * Original: 0x002CC4F0 - 0x002CC506 (22 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC4F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC4F0: ;
    PUSH32(esp, 0x170530);
    PUSH32(esp, 0x60);
    PUSH32(esp, 4);
    eax = ebp + -396;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC505u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CC505: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC506
 * Original: 0x002CC506 - 0x002CC510 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC506(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC506: ;
    eax = 0x352D30;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC510
 * Original: 0x002CC510 - 0x002CC51F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC510(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC510: ;
    PUSH32(esp, 0xC);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC51Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC51B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC51F
 * Original: 0x002CC51F - 0x002CC52E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC51F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC51F: ;
    PUSH32(esp, 0xC);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC52Au); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC52A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC52E
 * Original: 0x002CC52E - 0x002CC53D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC52E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC52E: ;
    PUSH32(esp, 0x18);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC539u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC539: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC53D
 * Original: 0x002CC53D - 0x002CC54C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC53D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC53D: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC548u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC548: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC54C
 * Original: 0x002CC54C - 0x002CC55E (18 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC54C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC54C: ;
    PUSH32(esp, 0x11AC);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC55Au); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC55A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC55E
 * Original: 0x002CC55E - 0x002CC568 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC55E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC55E: ;
    eax = 0x352D74;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC570
 * Original: 0x002CC570 - 0x002CC578 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC570(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC570: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00279D60(); return; /* tail jmp 0x00279D60 */

}

/**
 * sub_002CC578
 * Original: 0x002CC578 - 0x002CC582 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC578(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC578: ;
    eax = 0x352D98;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC590
 * Original: 0x002CC590 - 0x002CC5A3 (19 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC590(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC590: ;
    PUSH32(esp, 0x277430);
    PUSH32(esp, 2);
    PUSH32(esp, 8);
    eax = ebp + -28;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC5A2u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CC5A2: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC5A3
 * Original: 0x002CC5A3 - 0x002CC5AB (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC5A3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC5A3: ;
    ecx = ebp + -36;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC5AB
 * Original: 0x002CC5AB - 0x002CC5B5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC5AB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC5AB: ;
    eax = 0x352DC4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC5C0
 * Original: 0x002CC5C0 - 0x002CC5CB (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC5C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC5C0: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 4;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC5CB
 * Original: 0x002CC5CB - 0x002CC5D5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC5CB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC5CB: ;
    eax = 0x352DE8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC5E0
 * Original: 0x002CC5E0 - 0x002CC5E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC5E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC5E0: ;
    ecx = ebp + -40;
    g_seh_ebp = ebp; sub_00279520(); return; /* tail jmp 0x00279520 */

}

/**
 * sub_002CC5E8
 * Original: 0x002CC5E8 - 0x002CC5F2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC5E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC5E8: ;
    eax = 0x352E0C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC600
 * Original: 0x002CC600 - 0x002CC608 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC600(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC600: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC608
 * Original: 0x002CC608 - 0x002CC612 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC608(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC608: ;
    eax = 0x352E30;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC620
 * Original: 0x002CC620 - 0x002CC628 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC620(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC620: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC628
 * Original: 0x002CC628 - 0x002CC632 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC628(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC628: ;
    eax = 0x352E54;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC640
 * Original: 0x002CC640 - 0x002CC648 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC640(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC640: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC648
 * Original: 0x002CC648 - 0x002CC661 (25 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC648(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC648: ;
    eax = MEM32(ebp + -16);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) goto loc_002CC660; /* je: equal / zero */

loc_002CC654: ;
    MEM32(ebp + -16) = MEM32(ebp + -16) & 0xFFFFFFFEu;
    _fa = (uint32_t)(MEM32(ebp + -16)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = MEM32(ebp + 4);
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

loc_002CC660: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC661
 * Original: 0x002CC661 - 0x002CC66B (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC661(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC661: ;
    eax = 0x352E80;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC670
 * Original: 0x002CC670 - 0x002CC678 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC670(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC670: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC678
 * Original: 0x002CC678 - 0x002CC691 (25 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC678(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC678: ;
    eax = MEM32(ebp + -20);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) goto loc_002CC690; /* je: equal / zero */

loc_002CC684: ;
    MEM32(ebp + -20) = MEM32(ebp + -20) & 0xFFFFFFFEu;
    _fa = (uint32_t)(MEM32(ebp + -20)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = MEM32(ebp + 4);
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

loc_002CC690: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC691
 * Original: 0x002CC691 - 0x002CC699 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC691(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC691: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC699
 * Original: 0x002CC699 - 0x002CC6A3 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC699(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC699: ;
    eax = 0x352EB4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC6B0
 * Original: 0x002CC6B0 - 0x002CC6B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6B0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC6B8
 * Original: 0x002CC6B8 - 0x002CC6C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6B8: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC6C0
 * Original: 0x002CC6C0 - 0x002CC6CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6C0: ;
    eax = 0x352EE0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC6D0
 * Original: 0x002CC6D0 - 0x002CC6D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6D0: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC6D8
 * Original: 0x002CC6D8 - 0x002CC6E0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6D8: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC6E0
 * Original: 0x002CC6E0 - 0x002CC6E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6E0: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC6E8
 * Original: 0x002CC6E8 - 0x002CC6F2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC6E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC6E8: ;
    eax = 0x352F14;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC700
 * Original: 0x002CC700 - 0x002CC713 (19 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC700(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC700: ;
    PUSH32(esp, 0x170530);
    PUSH32(esp, 2);
    PUSH32(esp, 4);
    eax = ebp + -20;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC712u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CC712: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CC713
 * Original: 0x002CC713 - 0x002CC71B (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC713(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC713: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC71B
 * Original: 0x002CC71B - 0x002CC725 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC71B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC71B: ;
    eax = 0x352F40;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC730
 * Original: 0x002CC730 - 0x002CC738 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC730(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC730: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00279390(); return; /* tail jmp 0x00279390 */

}

/**
 * sub_002CC738
 * Original: 0x002CC738 - 0x002CC742 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC738(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC738: ;
    eax = 0x352F64;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC750
 * Original: 0x002CC750 - 0x002CC758 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC750(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC750: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC758
 * Original: 0x002CC758 - 0x002CC760 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC758(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC758: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC760
 * Original: 0x002CC760 - 0x002CC76A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC760(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC760: ;
    eax = 0x352F90;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC770
 * Original: 0x002CC770 - 0x002CC778 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC770(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC770: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC778
 * Original: 0x002CC778 - 0x002CC782 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC778(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC778: ;
    eax = 0x352FB4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC790
 * Original: 0x002CC790 - 0x002CC798 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC790(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC790: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC798
 * Original: 0x002CC798 - 0x002CC7A0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC798(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC798: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC7A0
 * Original: 0x002CC7A0 - 0x002CC7AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7A0: ;
    eax = 0x352FE0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC7B0
 * Original: 0x002CC7B0 - 0x002CC7BB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7B0: ;
    ecx = ebp + -276;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC7BB
 * Original: 0x002CC7BB - 0x002CC7C6 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7BB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7BB: ;
    ecx = ebp + -280;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC7C6
 * Original: 0x002CC7C6 - 0x002CC7D8 (18 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7C6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7C6: ;
    PUSH32(esp, 0x38);
    eax = MEM32(ebp + -288);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC7D4u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC7D4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC7D8
 * Original: 0x002CC7D8 - 0x002CC7E3 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7D8: ;
    ecx = ebp + -308;
    g_seh_ebp = ebp; sub_002794B0(); return; /* tail jmp 0x002794B0 */

}

/**
 * sub_002CC7E3
 * Original: 0x002CC7E3 - 0x002CC7ED (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7E3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7E3: ;
    eax = 0x35301C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC7F0
 * Original: 0x002CC7F0 - 0x002CC7F8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7F0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC7F8
 * Original: 0x002CC7F8 - 0x002CC800 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC7F8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC7F8: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC800
 * Original: 0x002CC800 - 0x002CC808 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC800(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC800: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC808
 * Original: 0x002CC808 - 0x002CC817 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC808(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC808: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -28);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC813u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC813: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC817
 * Original: 0x002CC817 - 0x002CC826 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC817(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC817: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC822u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC822: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC826
 * Original: 0x002CC826 - 0x002CC82E (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC826(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC826: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC82E
 * Original: 0x002CC82E - 0x002CC836 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC82E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC82E: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC836
 * Original: 0x002CC836 - 0x002CC840 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC836(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC836: ;
    eax = 0x353070;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC840
 * Original: 0x002CC840 - 0x002CC848 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC840(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC840: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC848
 * Original: 0x002CC848 - 0x002CC850 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC848(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC848: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC850
 * Original: 0x002CC850 - 0x002CC858 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC850(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC850: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC858
 * Original: 0x002CC858 - 0x002CC860 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC858(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC858: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC860
 * Original: 0x002CC860 - 0x002CC868 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC860(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC860: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC868
 * Original: 0x002CC868 - 0x002CC877 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC868(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC868: ;
    PUSH32(esp, 0x64);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC873u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CC873: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC877
 * Original: 0x002CC877 - 0x002CC886 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC877(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC877: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC882u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC882: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC886
 * Original: 0x002CC886 - 0x002CC88E (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC886(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC886: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC88E
 * Original: 0x002CC88E - 0x002CC89D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC88E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC88E: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC899u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CC899: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC89D
 * Original: 0x002CC89D - 0x002CC8A5 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC89D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC89D: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00278090(); return; /* tail jmp 0x00278090 */

}

/**
 * sub_002CC8A5
 * Original: 0x002CC8A5 - 0x002CC8AF (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8A5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8A5: ;
    eax = 0x3530DC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC8B0
 * Original: 0x002CC8B0 - 0x002CC8B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8B0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC8B8
 * Original: 0x002CC8B8 - 0x002CC8C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8B8: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC8C0
 * Original: 0x002CC8C0 - 0x002CC8C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8C0: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CC8C8
 * Original: 0x002CC8C8 - 0x002CC8D2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8C8: ;
    eax = 0x353110;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC8E0
 * Original: 0x002CC8E0 - 0x002CC8E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8E0: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_0027C590(); return; /* tail jmp 0x0027C590 */

}

/**
 * sub_002CC8E8
 * Original: 0x002CC8E8 - 0x002CC8F2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC8E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC8E8: ;
    eax = 0x353134;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC900
 * Original: 0x002CC900 - 0x002CC908 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC900(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC900: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC908
 * Original: 0x002CC908 - 0x002CC910 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC908(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC908: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC910
 * Original: 0x002CC910 - 0x002CC91A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC910(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC910: ;
    eax = 0x353160;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC920
 * Original: 0x002CC920 - 0x002CC928 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC920(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC920: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC928
 * Original: 0x002CC928 - 0x002CC930 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC928(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC928: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CC930
 * Original: 0x002CC930 - 0x002CC93F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC930(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC930: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + 0x10);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC93Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CC93B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC93F
 * Original: 0x002CC93F - 0x002CC949 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC93F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC93F: ;
    eax = 0x353194;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC950
 * Original: 0x002CC950 - 0x002CC958 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC950(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC950: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC958
 * Original: 0x002CC958 - 0x002CC960 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC958(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC958: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CC960
 * Original: 0x002CC960 - 0x002CC96A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC960(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC960: ;
    eax = 0x3531C0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC970
 * Original: 0x002CC970 - 0x002CC978 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC970(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC970: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC978
 * Original: 0x002CC978 - 0x002CC982 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC978(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC978: ;
    eax = 0x3531E4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC990
 * Original: 0x002CC990 - 0x002CC998 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC990(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC990: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC998
 * Original: 0x002CC998 - 0x002CC9A2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC998(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC998: ;
    eax = 0x353208;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC9B0
 * Original: 0x002CC9B0 - 0x002CC9B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC9B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC9B0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CC9B8
 * Original: 0x002CC9B8 - 0x002CC9C2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC9B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC9B8: ;
    eax = 0x35322C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC9D0
 * Original: 0x002CC9D0 - 0x002CC9DF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC9D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC9D0: ;
    PUSH32(esp, 0x38);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CC9DBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CC9DB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CC9DF
 * Original: 0x002CC9DF - 0x002CC9E9 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC9DF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC9DF: ;
    eax = 0x353250;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CC9F0
 * Original: 0x002CC9F0 - 0x002CC9FB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC9F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC9F0: ;
    ecx = ebp + -168;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CC9FB
 * Original: 0x002CC9FB - 0x002CCA06 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CC9FB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CC9FB: ;
    ecx = ebp + -148;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA06
 * Original: 0x002CCA06 - 0x002CCA11 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA06(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA06: ;
    ecx = ebp + -192;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA11
 * Original: 0x002CCA11 - 0x002CCA1C (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA11(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA11: ;
    ecx = ebp + -152;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA1C
 * Original: 0x002CCA1C - 0x002CCA27 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA1C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA1C: ;
    ecx = ebp + -184;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA27
 * Original: 0x002CCA27 - 0x002CCA32 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA27(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA27: ;
    ecx = ebp + -160;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA32
 * Original: 0x002CCA32 - 0x002CCA3D (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA32(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA32: ;
    ecx = ebp + -176;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA3D
 * Original: 0x002CCA3D - 0x002CCA48 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA3D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA3D: ;
    ecx = ebp + -144;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA48
 * Original: 0x002CCA48 - 0x002CCA53 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA48(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA48: ;
    ecx = ebp + -200;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA53
 * Original: 0x002CCA53 - 0x002CCA5E (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA53(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA53: ;
    ecx = ebp + -196;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA5E
 * Original: 0x002CCA5E - 0x002CCA69 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA5E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA5E: ;
    ecx = ebp + -188;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA69
 * Original: 0x002CCA69 - 0x002CCA74 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA69(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA69: ;
    ecx = ebp + -180;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA74
 * Original: 0x002CCA74 - 0x002CCA7F (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA74(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA74: ;
    ecx = ebp + -172;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA7F
 * Original: 0x002CCA7F - 0x002CCA8A (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA7F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA7F: ;
    ecx = ebp + -164;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA8A
 * Original: 0x002CCA8A - 0x002CCA95 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA8A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA8A: ;
    ecx = ebp + -156;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCA95
 * Original: 0x002CCA95 - 0x002CCAA0 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCA95(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCA95: ;
    ecx = ebp + -204;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCAA0
 * Original: 0x002CCAA0 - 0x002CCAAA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAA0: ;
    eax = 0x3532EC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCAB0
 * Original: 0x002CCAB0 - 0x002CCAB8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAB0: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCAB8
 * Original: 0x002CCAB8 - 0x002CCAD1 (25 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAB8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAB8: ;
    eax = MEM32(ebp + -20);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) goto loc_002CCAD0; /* je: equal / zero */

loc_002CCAC4: ;
    MEM32(ebp + -20) = MEM32(ebp + -20) & 0xFFFFFFFEu;
    _fa = (uint32_t)(MEM32(ebp + -20)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = MEM32(ebp + 4);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

loc_002CCAD0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CCAD1
 * Original: 0x002CCAD1 - 0x002CCAD9 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAD1(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAD1: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCAD9
 * Original: 0x002CCAD9 - 0x002CCAE3 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAD9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAD9: ;
    eax = 0x353320;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCAF0
 * Original: 0x002CCAF0 - 0x002CCAF8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAF0: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCAF8
 * Original: 0x002CCAF8 - 0x002CCB11 (25 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCAF8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCAF8: ;
    eax = MEM32(ebp + -24);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) goto loc_002CCB10; /* je: equal / zero */

loc_002CCB04: ;
    MEM32(ebp + -24) = MEM32(ebp + -24) & 0xFFFFFFFEu;
    _fa = (uint32_t)(MEM32(ebp + -24)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = MEM32(ebp + 4);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

loc_002CCB10: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CCB11
 * Original: 0x002CCB11 - 0x002CCB19 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB11(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB11: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCB19
 * Original: 0x002CCB19 - 0x002CCB21 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB19(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB19: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCB21
 * Original: 0x002CCB21 - 0x002CCB2B (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB21(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB21: ;
    eax = 0x35335C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCB30
 * Original: 0x002CCB30 - 0x002CCB38 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB30: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCB38
 * Original: 0x002CCB38 - 0x002CCB42 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB38(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB38: ;
    eax = 0x353380;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCB50
 * Original: 0x002CCB50 - 0x002CCB58 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB50: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CCB58
 * Original: 0x002CCB58 - 0x002CCB62 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB58(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB58: ;
    eax = 0x3533A4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCB70
 * Original: 0x002CCB70 - 0x002CCB7F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB70: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCB7Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CCB7B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCB7F
 * Original: 0x002CCB7F - 0x002CCB89 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB7F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB7F: ;
    eax = 0x3533C8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCB90
 * Original: 0x002CCB90 - 0x002CCB9F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB90: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCB9Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCB9B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCB9F
 * Original: 0x002CCB9F - 0x002CCBAE (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCB9F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCB9F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCBAAu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCBAA: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCBAE
 * Original: 0x002CCBAE - 0x002CCBBD (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCBAE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCBAE: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCBB9u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCBB9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCBBD
 * Original: 0x002CCBBD - 0x002CCBCC (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCBBD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCBBD: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCBC8u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCBC8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCBCC
 * Original: 0x002CCBCC - 0x002CCBDB (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCBCC(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCBCC: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCBD7u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCBD7: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCBDB
 * Original: 0x002CCBDB - 0x002CCBEA (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCBDB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCBDB: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCBE6u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCBE6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCBEA
 * Original: 0x002CCBEA - 0x002CCBF9 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCBEA(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCBEA: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCBF5u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCBF5: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCBF9
 * Original: 0x002CCBF9 - 0x002CCC08 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCBF9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCBF9: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC04u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC04: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC08
 * Original: 0x002CCC08 - 0x002CCC17 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC08(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC08: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC13u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC13: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC17
 * Original: 0x002CCC17 - 0x002CCC26 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC17(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC17: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC22u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC22: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC26
 * Original: 0x002CCC26 - 0x002CCC35 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC26(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC26: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC31u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC31: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC35
 * Original: 0x002CCC35 - 0x002CCC44 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC35(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC35: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC40u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC40: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC44
 * Original: 0x002CCC44 - 0x002CCC53 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC44(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC44: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC4Fu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC4F: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC53
 * Original: 0x002CCC53 - 0x002CCC62 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC53(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC53: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC5Eu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC5E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC62
 * Original: 0x002CCC62 - 0x002CCC71 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC62(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC62: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC6Du); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC6D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC71
 * Original: 0x002CCC71 - 0x002CCC80 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC71(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC71: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC7Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC7C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC80
 * Original: 0x002CCC80 - 0x002CCC8F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC80: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC8Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC8B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC8F
 * Original: 0x002CCC8F - 0x002CCC9E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC8F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC8F: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCC9Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCC9A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCC9E
 * Original: 0x002CCC9E - 0x002CCCAD (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCC9E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCC9E: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCCA9u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCCA9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCCAD
 * Original: 0x002CCCAD - 0x002CCCBC (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCCAD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCCAD: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCCB8u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCCB8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCCBC
 * Original: 0x002CCCBC - 0x002CCCCB (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCCBC(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCCBC: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCCC7u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCCC7: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCCCB
 * Original: 0x002CCCCB - 0x002CCCDA (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCCCB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCCCB: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCCD6u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCCD6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCCDA
 * Original: 0x002CCCDA - 0x002CCCE9 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCCDA(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCCDA: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCCE5u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCCE5: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCCE9
 * Original: 0x002CCCE9 - 0x002CCCF3 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCCE9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCCE9: ;
    eax = 0x35349C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCD00
 * Original: 0x002CCD00 - 0x002CCD12 (18 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD00: ;
    PUSH32(esp, 0x3C0);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD0Eu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CCD0E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD12
 * Original: 0x002CCD12 - 0x002CCD21 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD12(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD12: ;
    PUSH32(esp, 0x18);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD1Du); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD1D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD21
 * Original: 0x002CCD21 - 0x002CCD30 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD21(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD21: ;
    PUSH32(esp, 0x18);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD2Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD2C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD30
 * Original: 0x002CCD30 - 0x002CCD3F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD30: ;
    PUSH32(esp, 0x18);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD3Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD3B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD3F
 * Original: 0x002CCD3F - 0x002CCD4E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD3F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD3F: ;
    PUSH32(esp, 0x18);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD4Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD4A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD4E
 * Original: 0x002CCD4E - 0x002CCD5D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD4E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD4E: ;
    PUSH32(esp, 0x18);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD59u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD59: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD5D
 * Original: 0x002CCD5D - 0x002CCD6C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD5D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD5D: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD68u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CCD68: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD6C
 * Original: 0x002CCD6C - 0x002CCD7B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD6C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD6C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD77u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD77: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD7B
 * Original: 0x002CCD7B - 0x002CCD8A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD7B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD7B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD86u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD86: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD8A
 * Original: 0x002CCD8A - 0x002CCD99 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD8A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD8A: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCD95u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCD95: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCD99
 * Original: 0x002CCD99 - 0x002CCDA8 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCD99(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCD99: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCDA4u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCDA4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCDA8
 * Original: 0x002CCDA8 - 0x002CCDB7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCDA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCDA8: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCDB3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCDB3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCDB7
 * Original: 0x002CCDB7 - 0x002CCDC6 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCDB7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCDB7: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCDC2u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCDC2: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCDC6
 * Original: 0x002CCDC6 - 0x002CCDD5 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCDC6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCDC6: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCDD1u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CCDD1: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCDD5
 * Original: 0x002CCDD5 - 0x002CCDDF (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCDD5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCDD5: ;
    eax = 0x353528;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCDE0
 * Original: 0x002CCDE0 - 0x002CCDF9 (25 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCDE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCDE0: ;
    eax = MEM32(ebp + -16);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) goto loc_002CCDF8; /* je: equal / zero */

loc_002CCDEC: ;
    MEM32(ebp + -16) = MEM32(ebp + -16) & 0xFFFFFFFEu;
    _fa = (uint32_t)(MEM32(ebp + -16)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = MEM32(ebp + 4);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

loc_002CCDF8: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CCDF9
 * Original: 0x002CCDF9 - 0x002CCE03 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCDF9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCDF9: ;
    eax = 0x35354C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCE10
 * Original: 0x002CCE10 - 0x002CCE29 (25 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE10: ;
    eax = MEM32(ebp + -16);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) goto loc_002CCE28; /* je: equal / zero */

loc_002CCE1C: ;
    MEM32(ebp + -16) = MEM32(ebp + -16) & 0xFFFFFFFEu;
    _fa = (uint32_t)(MEM32(ebp + -16)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = MEM32(ebp + 4);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

loc_002CCE28: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CCE29
 * Original: 0x002CCE29 - 0x002CCE31 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE29(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE29: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCE31
 * Original: 0x002CCE31 - 0x002CCE3B (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE31(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE31: ;
    eax = 0x353578;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCE40
 * Original: 0x002CCE40 - 0x002CCE48 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE40: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCE48
 * Original: 0x002CCE48 - 0x002CCE50 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE48(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE48: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCE50
 * Original: 0x002CCE50 - 0x002CCE5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE50: ;
    eax = 0x3535A4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCE60
 * Original: 0x002CCE60 - 0x002CCE68 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE60: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCE68
 * Original: 0x002CCE68 - 0x002CCE72 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE68(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE68: ;
    eax = 0x3535C8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCE80
 * Original: 0x002CCE80 - 0x002CCE8B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE80: ;
    ecx = ebp + -276;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCE8B
 * Original: 0x002CCE8B - 0x002CCE96 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE8B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE8B: ;
    ecx = ebp + -272;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCE96
 * Original: 0x002CCE96 - 0x002CCEA0 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCE96(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCE96: ;
    eax = 0x3535F4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCEA0
 * Original: 0x002CCEA0 - 0x002CCEA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEA0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCEA8
 * Original: 0x002CCEA8 - 0x002CCEB0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEA8: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCEB0
 * Original: 0x002CCEB0 - 0x002CCEB8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEB0: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCEB8
 * Original: 0x002CCEB8 - 0x002CCEC2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEB8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEB8: ;
    eax = 0x353628;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCED0
 * Original: 0x002CCED0 - 0x002CCED8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCED0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCED0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCED8
 * Original: 0x002CCED8 - 0x002CCEE0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCED8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCED8: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCEE0
 * Original: 0x002CCEE0 - 0x002CCEEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEE0: ;
    eax = 0x353654;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCEF0
 * Original: 0x002CCEF0 - 0x002CCEF8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEF0: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCEF8
 * Original: 0x002CCEF8 - 0x002CCF02 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCEF8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCEF8: ;
    eax = 0x353678;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCF10
 * Original: 0x002CCF10 - 0x002CCF1B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF10: ;
    ecx = MEM32(ebp + -276);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCF1B
 * Original: 0x002CCF1B - 0x002CCF26 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF1B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF1B: ;
    ecx = ebp + -280;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCF26
 * Original: 0x002CCF26 - 0x002CCF31 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF26(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF26: ;
    ecx = MEM32(ebp + -276);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCF31
 * Original: 0x002CCF31 - 0x002CCF3C (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF31(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF31: ;
    ecx = ebp + -284;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCF3C
 * Original: 0x002CCF3C - 0x002CCF46 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF3C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF3C: ;
    eax = 0x3536C4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCF50
 * Original: 0x002CCF50 - 0x002CCF58 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF50: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCF58
 * Original: 0x002CCF58 - 0x002CCF60 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF58(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF58: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCF60
 * Original: 0x002CCF60 - 0x002CCF6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF60: ;
    eax = 0x3536F0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCF70
 * Original: 0x002CCF70 - 0x002CCF78 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF70: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00283F10(); return; /* tail jmp 0x00283F10 */

}

/**
 * sub_002CCF78
 * Original: 0x002CCF78 - 0x002CCF83 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF78(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF78: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0xC;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00283F10(); return; /* tail jmp 0x00283F10 */

}

/**
 * sub_002CCF83
 * Original: 0x002CCF83 - 0x002CCF8E (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF83(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF83: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x18;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00283F10(); return; /* tail jmp 0x00283F10 */

}

/**
 * sub_002CCF8E
 * Original: 0x002CCF8E - 0x002CCF98 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCF8E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCF8E: ;
    eax = 0x353724;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCFA0
 * Original: 0x002CCFA0 - 0x002CCFAB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFA0: ;
    ecx = ebp + -272;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCFAB
 * Original: 0x002CCFAB - 0x002CCFB5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFAB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFAB: ;
    eax = 0x353748;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCFC0
 * Original: 0x002CCFC0 - 0x002CCFCF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFC0: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCFCBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CCFCB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCFCF
 * Original: 0x002CCFCF - 0x002CCFD7 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFCF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFCF: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CCFD7
 * Original: 0x002CCFD7 - 0x002CCFE1 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFD7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFD7: ;
    eax = 0x353774;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CCFF0
 * Original: 0x002CCFF0 - 0x002CCFFF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFF0: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CCFFBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CCFFB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CCFFF
 * Original: 0x002CCFFF - 0x002CD007 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CCFFF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CCFFF: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD007
 * Original: 0x002CD007 - 0x002CD011 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD007(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD007: ;
    eax = 0x3537A0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD020
 * Original: 0x002CD020 - 0x002CD028 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD020(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD020: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD028
 * Original: 0x002CD028 - 0x002CD037 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD028(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD028: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD033u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD033: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD037
 * Original: 0x002CD037 - 0x002CD041 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD037(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD037: ;
    eax = 0x3537CC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD050
 * Original: 0x002CD050 - 0x002CD05F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD050(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD050: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD05Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD05B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD05F
 * Original: 0x002CD05F - 0x002CD067 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD05F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD05F: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD067
 * Original: 0x002CD067 - 0x002CD071 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD067(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD067: ;
    eax = 0x3537F8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD080
 * Original: 0x002CD080 - 0x002CD088 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD080(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD080: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD088
 * Original: 0x002CD088 - 0x002CD097 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD088(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD088: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD093u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD093: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD097
 * Original: 0x002CD097 - 0x002CD09F (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD097(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD097: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD09F
 * Original: 0x002CD09F - 0x002CD0A7 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD09F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD09F: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD0A7
 * Original: 0x002CD0A7 - 0x002CD0B1 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0A7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0A7: ;
    eax = 0x353834;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD0C0
 * Original: 0x002CD0C0 - 0x002CD0C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0C0: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD0C8
 * Original: 0x002CD0C8 - 0x002CD0D7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0C8: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD0D3u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD0D3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD0D7
 * Original: 0x002CD0D7 - 0x002CD0DF (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0D7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0D7: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD0DF
 * Original: 0x002CD0DF - 0x002CD0E9 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0DF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0DF: ;
    eax = 0x353868;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD0F0
 * Original: 0x002CD0F0 - 0x002CD0FF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0F0: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD0FBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD0FB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD0FF
 * Original: 0x002CD0FF - 0x002CD109 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD0FF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD0FF: ;
    eax = 0x35388C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD110
 * Original: 0x002CD110 - 0x002CD11F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD110(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD110: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD11Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD11B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD11F
 * Original: 0x002CD11F - 0x002CD127 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD11F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD11F: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD127
 * Original: 0x002CD127 - 0x002CD136 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD127(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD127: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD132u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD132: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD136
 * Original: 0x002CD136 - 0x002CD140 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD136(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD136: ;
    eax = 0x3538C0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD140
 * Original: 0x002CD140 - 0x002CD148 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD140(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD140: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CD148
 * Original: 0x002CD148 - 0x002CD150 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD148(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD148: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD150
 * Original: 0x002CD150 - 0x002CD15A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD150(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD150: ;
    eax = 0x353944;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD160
 * Original: 0x002CD160 - 0x002CD168 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD160(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD160: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD168
 * Original: 0x002CD168 - 0x002CD170 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD168(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD168: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CD170
 * Original: 0x002CD170 - 0x002CD17A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD170(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD170: ;
    eax = 0x353918;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD180
 * Original: 0x002CD180 - 0x002CD188 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD180(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD180: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD188
 * Original: 0x002CD188 - 0x002CD192 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD188(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD188: ;
    eax = 0x353968;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD1A0
 * Original: 0x002CD1A0 - 0x002CD1A8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1A0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD1A8
 * Original: 0x002CD1A8 - 0x002CD1B0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1A8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1A8: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CD1B0
 * Original: 0x002CD1B0 - 0x002CD1BB (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1B0: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x20;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD1BB
 * Original: 0x002CD1BB - 0x002CD1C5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1BB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1BB: ;
    eax = 0x35399C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD1D0
 * Original: 0x002CD1D0 - 0x002CD1D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1D0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD1D8
 * Original: 0x002CD1D8 - 0x002CD1E0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1D8: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD1E0
 * Original: 0x002CD1E0 - 0x002CD1E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1E0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CD1E8
 * Original: 0x002CD1E8 - 0x002CD1F3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1E8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x20;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD1F3
 * Original: 0x002CD1F3 - 0x002CD1FD (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD1F3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD1F3: ;
    eax = 0x3539D8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD200
 * Original: 0x002CD200 - 0x002CD20F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD200(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD200: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD20Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD20B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD20F
 * Original: 0x002CD20F - 0x002CD21E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD20F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD20F: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD21Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD21A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD21E
 * Original: 0x002CD21E - 0x002CD226 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD21E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD21E: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD226
 * Original: 0x002CD226 - 0x002CD235 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD226(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD226: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 0xC);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD231u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD231: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD235
 * Original: 0x002CD235 - 0x002CD244 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD235(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD235: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD240u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD240: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD244
 * Original: 0x002CD244 - 0x002CD253 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD244(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD244: ;
    PUSH32(esp, 0x64);
    eax = MEM32(ebp + -20);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD24Fu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD24F: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD253
 * Original: 0x002CD253 - 0x002CD262 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD253(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD253: ;
    PUSH32(esp, 0x40);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD25Eu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD25E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD262
 * Original: 0x002CD262 - 0x002CD271 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD262(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD262: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD26Du); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD26D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD271
 * Original: 0x002CD271 - 0x002CD280 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD271(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD271: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD27Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD27C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD280
 * Original: 0x002CD280 - 0x002CD28F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD280(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD280: ;
    PUSH32(esp, 0x20);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD28Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD28B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD28F
 * Original: 0x002CD28F - 0x002CD29E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD28F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD28F: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD29Au); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CD29A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD29E
 * Original: 0x002CD29E - 0x002CD2AD (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD29E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD29E: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD2A9u); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CD2A9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD2AD
 * Original: 0x002CD2AD - 0x002CD2BC (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD2AD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD2AD: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD2B8u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD2B8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD2BC
 * Original: 0x002CD2BC - 0x002CD2C4 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD2BC(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD2BC: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD2C4
 * Original: 0x002CD2C4 - 0x002CD2D3 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD2C4(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD2C4: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD2CFu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD2CF: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD2D3
 * Original: 0x002CD2D3 - 0x002CD2E2 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD2D3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD2D3: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD2DEu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD2DE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD2E2
 * Original: 0x002CD2E2 - 0x002CD2F1 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD2E2(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD2E2: ;
    PUSH32(esp, 0x20);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD2EDu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD2ED: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD2F1
 * Original: 0x002CD2F1 - 0x002CD300 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD2F1(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD2F1: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD2FCu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD2FC: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD300
 * Original: 0x002CD300 - 0x002CD30A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD300(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD300: ;
    eax = 0x353A84;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD310
 * Original: 0x002CD310 - 0x002CD318 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD310(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD310: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD318
 * Original: 0x002CD318 - 0x002CD320 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD318(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD318: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD320
 * Original: 0x002CD320 - 0x002CD32A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD320(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD320: ;
    eax = 0x353AB0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD330
 * Original: 0x002CD330 - 0x002CD338 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD330(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD330: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD338
 * Original: 0x002CD338 - 0x002CD342 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD338(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD338: ;
    eax = 0x353AD4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD350
 * Original: 0x002CD350 - 0x002CD358 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD350(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD350: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD358
 * Original: 0x002CD358 - 0x002CD360 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD358(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD358: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD360
 * Original: 0x002CD360 - 0x002CD36F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD360(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD360: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD36Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD36B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD36F
 * Original: 0x002CD36F - 0x002CD379 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD36F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD36F: ;
    eax = 0x353B08;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD380
 * Original: 0x002CD380 - 0x002CD388 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD380(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD380: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD388
 * Original: 0x002CD388 - 0x002CD390 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD388(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD388: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD390
 * Original: 0x002CD390 - 0x002CD398 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD390(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD390: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD398
 * Original: 0x002CD398 - 0x002CD3A0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD398(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD398: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD3A0
 * Original: 0x002CD3A0 - 0x002CD3AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3A0: ;
    eax = 0x353B44;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD3B0
 * Original: 0x002CD3B0 - 0x002CD3B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3B0: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD3B8
 * Original: 0x002CD3B8 - 0x002CD3C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3B8: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD3C0
 * Original: 0x002CD3C0 - 0x002CD3CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3C0: ;
    eax = 0x353B70;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD3D0
 * Original: 0x002CD3D0 - 0x002CD3D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3D0: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD3D8
 * Original: 0x002CD3D8 - 0x002CD3E0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3D8: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD3E0
 * Original: 0x002CD3E0 - 0x002CD3E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3E0: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD3E8
 * Original: 0x002CD3E8 - 0x002CD3F2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD3E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD3E8: ;
    eax = 0x353BA4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD400
 * Original: 0x002CD400 - 0x002CD408 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD400(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD400: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD408
 * Original: 0x002CD408 - 0x002CD410 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD408(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD408: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD410
 * Original: 0x002CD410 - 0x002CD41A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD410(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD410: ;
    eax = 0x353BD0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD420
 * Original: 0x002CD420 - 0x002CD428 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD420(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD420: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD428
 * Original: 0x002CD428 - 0x002CD432 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD428(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD428: ;
    eax = 0x353BF4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD440
 * Original: 0x002CD440 - 0x002CD44F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD440(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD440: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD44Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD44B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD44F
 * Original: 0x002CD44F - 0x002CD45E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD44F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD44F: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -24);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD45Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD45A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD45E
 * Original: 0x002CD45E - 0x002CD468 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD45E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD45E: ;
    eax = 0x353C20;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD470
 * Original: 0x002CD470 - 0x002CD478 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD470(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD470: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD478
 * Original: 0x002CD478 - 0x002CD487 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD478(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD478: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD483u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD483: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD487
 * Original: 0x002CD487 - 0x002CD491 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD487(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD487: ;
    eax = 0x353C4C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD4A0
 * Original: 0x002CD4A0 - 0x002CD4A8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4A0: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD4A8
 * Original: 0x002CD4A8 - 0x002CD4B2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4A8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4A8: ;
    eax = 0x353C70;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD4C0
 * Original: 0x002CD4C0 - 0x002CD4C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4C0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD4C8
 * Original: 0x002CD4C8 - 0x002CD4D2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4C8: ;
    eax = 0x353C94;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD4E0
 * Original: 0x002CD4E0 - 0x002CD4E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4E0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD4E8
 * Original: 0x002CD4E8 - 0x002CD4F0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4E8: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD4F0
 * Original: 0x002CD4F0 - 0x002CD4FA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD4F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD4F0: ;
    eax = 0x353CC0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD500
 * Original: 0x002CD500 - 0x002CD508 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD500(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD500: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD508
 * Original: 0x002CD508 - 0x002CD517 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD508(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD508: ;
    PUSH32(esp, 0x38);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD513u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD513: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD517
 * Original: 0x002CD517 - 0x002CD51F (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD517(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD517: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD51F
 * Original: 0x002CD51F - 0x002CD529 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD51F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD51F: ;
    eax = 0x353CF4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD530
 * Original: 0x002CD530 - 0x002CD53F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD530(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD530: ;
    PUSH32(esp, 0x38);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD53Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD53B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD53F
 * Original: 0x002CD53F - 0x002CD547 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD53F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD53F: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD547
 * Original: 0x002CD547 - 0x002CD551 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD547(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD547: ;
    eax = 0x353D20;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD560
 * Original: 0x002CD560 - 0x002CD56F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD560(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD560: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD56Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD56B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD56F
 * Original: 0x002CD56F - 0x002CD577 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD56F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD56F: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD577
 * Original: 0x002CD577 - 0x002CD581 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD577(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD577: ;
    eax = 0x3538EC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD590
 * Original: 0x002CD590 - 0x002CD598 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD590(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD590: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD598
 * Original: 0x002CD598 - 0x002CD5A2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD598(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD598: ;
    eax = 0x353D44;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD5B0
 * Original: 0x002CD5B0 - 0x002CD5B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5B0: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD5B8
 * Original: 0x002CD5B8 - 0x002CD5C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5B8: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD5C0
 * Original: 0x002CD5C0 - 0x002CD5CF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5C0: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD5CBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD5CB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD5CF
 * Original: 0x002CD5CF - 0x002CD5D9 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5CF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5CF: ;
    eax = 0x353D78;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD5E0
 * Original: 0x002CD5E0 - 0x002CD5E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5E0: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD5E8
 * Original: 0x002CD5E8 - 0x002CD5F0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5E8: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD5F0
 * Original: 0x002CD5F0 - 0x002CD5F8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5F0: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD5F8
 * Original: 0x002CD5F8 - 0x002CD602 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD5F8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD5F8: ;
    eax = 0x353DAC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD610
 * Original: 0x002CD610 - 0x002CD618 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD610(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD610: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD618
 * Original: 0x002CD618 - 0x002CD622 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD618(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD618: ;
    eax = 0x353DD0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD630
 * Original: 0x002CD630 - 0x002CD63F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD630(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD630: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD63Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD63B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD63F
 * Original: 0x002CD63F - 0x002CD647 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD63F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD63F: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD647
 * Original: 0x002CD647 - 0x002CD651 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD647(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD647: ;
    eax = 0x353DFC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD660
 * Original: 0x002CD660 - 0x002CD66B (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD660(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD660: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x14;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00283F10(); return; /* tail jmp 0x00283F10 */

}

/**
 * sub_002CD66B
 * Original: 0x002CD66B - 0x002CD675 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD66B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD66B: ;
    eax = 0x353E20;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD680
 * Original: 0x002CD680 - 0x002CD688 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD680(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD680: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD688
 * Original: 0x002CD688 - 0x002CD690 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD688(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD688: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CD690
 * Original: 0x002CD690 - 0x002CD69A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD690(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD690: ;
    eax = 0x353E4C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD6A0
 * Original: 0x002CD6A0 - 0x002CD6A8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6A0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CD6A8
 * Original: 0x002CD6A8 - 0x002CD6B2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6A8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6A8: ;
    eax = 0x353E70;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD6C0
 * Original: 0x002CD6C0 - 0x002CD6C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6C0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CD6C8
 * Original: 0x002CD6C8 - 0x002CD6D0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6C8: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_0029AB50(); return; /* tail jmp 0x0029AB50 */

}

/**
 * sub_002CD6D0
 * Original: 0x002CD6D0 - 0x002CD6DB (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6D0: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x34) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x34;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00170530(); return; /* tail jmp 0x00170530 */

}

/**
 * sub_002CD6DB
 * Original: 0x002CD6DB - 0x002CD6E5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6DB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6DB: ;
    eax = 0x353EA4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD6F0
 * Original: 0x002CD6F0 - 0x002CD6F8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6F0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_0029AB50(); return; /* tail jmp 0x0029AB50 */

}

/**
 * sub_002CD6F8
 * Original: 0x002CD6F8 - 0x002CD702 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD6F8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD6F8: ;
    eax = 0x353EC8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD710
 * Original: 0x002CD710 - 0x002CD71B (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD710(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD710: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x14;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_0028FC20(); return; /* tail jmp 0x0028FC20 */

}

/**
 * sub_002CD71B
 * Original: 0x002CD71B - 0x002CD729 (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD71B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD71B: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x820) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x820;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_0028FCC0(); return; /* tail jmp 0x0028FCC0 */

}

/**
 * sub_002CD729
 * Original: 0x002CD729 - 0x002CD737 (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD729(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD729: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x924) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x924;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_0028FC20(); return; /* tail jmp 0x0028FC20 */

}

/**
 * sub_002CD737
 * Original: 0x002CD737 - 0x002CD745 (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD737(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD737: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x1128) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1128;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002A9200(); return; /* tail jmp 0x002A9200 */

}

/**
 * sub_002CD745
 * Original: 0x002CD745 - 0x002CD750 (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD745(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD745: ;
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD74Eu); RECOMP_ABI_CALL(0x00277810u, sub_00277810); /* call 0x00277810 */

loc_002CD74E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CD750
 * Original: 0x002CD750 - 0x002CD75A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD750(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD750: ;
    eax = 0x353F0C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD760
 * Original: 0x002CD760 - 0x002CD76B (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD760(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD760: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x14;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_0028FC20(); return; /* tail jmp 0x0028FC20 */

}

/**
 * sub_002CD76B
 * Original: 0x002CD76B - 0x002CD779 (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD76B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD76B: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x820) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x820;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_0028FCC0(); return; /* tail jmp 0x0028FCC0 */

}

/**
 * sub_002CD779
 * Original: 0x002CD779 - 0x002CD787 (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD779(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD779: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x924) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x924;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_0028FC20(); return; /* tail jmp 0x0028FC20 */

}

/**
 * sub_002CD787
 * Original: 0x002CD787 - 0x002CD795 (14 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD787(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD787: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x1128) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1128;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002A9200(); return; /* tail jmp 0x002A9200 */

}

/**
 * sub_002CD795
 * Original: 0x002CD795 - 0x002CD79F (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD795(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD795: ;
    eax = 0x353F48;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD7A0
 * Original: 0x002CD7A0 - 0x002CD7A8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7A0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD7A8
 * Original: 0x002CD7A8 - 0x002CD7B0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7A8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7A8: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD7B0
 * Original: 0x002CD7B0 - 0x002CD7BA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7B0: ;
    eax = 0x353F74;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD7C0
 * Original: 0x002CD7C0 - 0x002CD7C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7C0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD7C8
 * Original: 0x002CD7C8 - 0x002CD7D2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7C8: ;
    eax = 0x353F98;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD7E0
 * Original: 0x002CD7E0 - 0x002CD7EF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7E0: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD7EBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD7EB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD7EF
 * Original: 0x002CD7EF - 0x002CD7F7 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7EF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7EF: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD7F7
 * Original: 0x002CD7F7 - 0x002CD801 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD7F7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD7F7: ;
    eax = 0x353FC4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD810
 * Original: 0x002CD810 - 0x002CD818 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD810(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD810: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CD818
 * Original: 0x002CD818 - 0x002CD823 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD818(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD818: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x20;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD823
 * Original: 0x002CD823 - 0x002CD82B (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD823(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD823: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD82B
 * Original: 0x002CD82B - 0x002CD835 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD82B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD82B: ;
    eax = 0x353FF8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD840
 * Original: 0x002CD840 - 0x002CD84F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD840(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD840: ;
    PUSH32(esp, 0x20);
    eax = MEM32(ebp + -20);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD84Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD84B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD84F
 * Original: 0x002CD84F - 0x002CD857 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD84F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD84F: ;
    ecx = MEM32(ebp + -20);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CD857
 * Original: 0x002CD857 - 0x002CD85F (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD857(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD857: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD85F
 * Original: 0x002CD85F - 0x002CD867 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD85F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD85F: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD867
 * Original: 0x002CD867 - 0x002CD86F (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD867(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD867: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD86F
 * Original: 0x002CD86F - 0x002CD877 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD86F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD86F: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD877
 * Original: 0x002CD877 - 0x002CD881 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD877(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD877: ;
    eax = 0x354044;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD890
 * Original: 0x002CD890 - 0x002CD898 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD890(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD890: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD898
 * Original: 0x002CD898 - 0x002CD8A2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD898(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD898: ;
    eax = 0x354068;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD8B0
 * Original: 0x002CD8B0 - 0x002CD8B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8B0: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8B8
 * Original: 0x002CD8B8 - 0x002CD8C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8B8: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8C0
 * Original: 0x002CD8C0 - 0x002CD8C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8C0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8C8
 * Original: 0x002CD8C8 - 0x002CD8D0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8C8: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8D0
 * Original: 0x002CD8D0 - 0x002CD8DA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8D0: ;
    eax = 0x3540A4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD8E0
 * Original: 0x002CD8E0 - 0x002CD8E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8E0: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8E8
 * Original: 0x002CD8E8 - 0x002CD8F0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8E8: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8F0
 * Original: 0x002CD8F0 - 0x002CD8F8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8F0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD8F8
 * Original: 0x002CD8F8 - 0x002CD900 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD8F8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD8F8: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CD900
 * Original: 0x002CD900 - 0x002CD90A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD900(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD900: ;
    eax = 0x3540E0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD910
 * Original: 0x002CD910 - 0x002CD91F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD910(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD910: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD91Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD91B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD91F
 * Original: 0x002CD91F - 0x002CD92E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD91F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD91F: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD92Au); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CD92A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD92E
 * Original: 0x002CD92E - 0x002CD93D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD92E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD92E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD939u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD939: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD93D
 * Original: 0x002CD93D - 0x002CD947 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD93D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD93D: ;
    eax = 0x354114;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CD950
 * Original: 0x002CD950 - 0x002CD95F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD950(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD950: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD95Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD95B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD95F
 * Original: 0x002CD95F - 0x002CD96E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD95F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD95F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD96Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD96A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD96E
 * Original: 0x002CD96E - 0x002CD97D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD96E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD96E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD979u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD979: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD97D
 * Original: 0x002CD97D - 0x002CD98C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD97D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD97D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD988u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD988: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD98C
 * Original: 0x002CD98C - 0x002CD99B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD98C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD98C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD997u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD997: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD99B
 * Original: 0x002CD99B - 0x002CD9AA (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD99B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD99B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD9A6u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD9A6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD9AA
 * Original: 0x002CD9AA - 0x002CD9B9 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD9AA(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD9AA: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD9B5u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD9B5: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD9B9
 * Original: 0x002CD9B9 - 0x002CD9C8 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD9B9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD9B9: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD9C4u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD9C4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD9C8
 * Original: 0x002CD9C8 - 0x002CD9D7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD9C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD9C8: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD9D3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD9D3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD9D7
 * Original: 0x002CD9D7 - 0x002CD9E6 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD9D7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD9D7: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD9E2u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD9E2: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD9E6
 * Original: 0x002CD9E6 - 0x002CD9F5 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD9E6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD9E6: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CD9F1u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CD9F1: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CD9F5
 * Original: 0x002CD9F5 - 0x002CDA04 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CD9F5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CD9F5: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA00u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA00: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA04
 * Original: 0x002CDA04 - 0x002CDA13 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA04(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA04: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA0Fu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA0F: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA13
 * Original: 0x002CDA13 - 0x002CDA22 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA13(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA13: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA1Eu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA1E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA22
 * Original: 0x002CDA22 - 0x002CDA31 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA22(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA22: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA2Du); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA2D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA31
 * Original: 0x002CDA31 - 0x002CDA40 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA31(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA31: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA3Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA3C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA40
 * Original: 0x002CDA40 - 0x002CDA4F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA40: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA4Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA4B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA4F
 * Original: 0x002CDA4F - 0x002CDA5E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA4F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA4F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA5Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA5A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA5E
 * Original: 0x002CDA5E - 0x002CDA68 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA5E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA5E: ;
    eax = 0x3541C0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDA70
 * Original: 0x002CDA70 - 0x002CDA7F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA70: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA7Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA7B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA7F
 * Original: 0x002CDA7F - 0x002CDA8E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA7F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA7F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA8Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA8A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA8E
 * Original: 0x002CDA8E - 0x002CDA9D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA8E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA8E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDA99u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDA99: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDA9D
 * Original: 0x002CDA9D - 0x002CDAAC (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDA9D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDA9D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDAA8u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDAA8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDAAC
 * Original: 0x002CDAAC - 0x002CDABB (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDAAC(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDAAC: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDAB7u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDAB7: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDABB
 * Original: 0x002CDABB - 0x002CDACA (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDABB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDABB: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDAC6u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDAC6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDACA
 * Original: 0x002CDACA - 0x002CDAD9 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDACA(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDACA: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDAD5u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDAD5: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDAD9
 * Original: 0x002CDAD9 - 0x002CDAE8 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDAD9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDAD9: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDAE4u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDAE4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDAE8
 * Original: 0x002CDAE8 - 0x002CDAF2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDAE8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDAE8: ;
    eax = 0x35421C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDB00
 * Original: 0x002CDB00 - 0x002CDB0F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB00: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB0Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDB0B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB0F
 * Original: 0x002CDB0F - 0x002CDB1E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB0F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB0F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB1Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDB1A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB1E
 * Original: 0x002CDB1E - 0x002CDB2D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB1E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB1E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB29u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDB29: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB2D
 * Original: 0x002CDB2D - 0x002CDB3C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB2D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB2D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB38u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDB38: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB3C
 * Original: 0x002CDB3C - 0x002CDB4B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB3C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB3C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB47u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDB47: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB4B
 * Original: 0x002CDB4B - 0x002CDB5A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB4B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB4B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB56u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDB56: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB5A
 * Original: 0x002CDB5A - 0x002CDB69 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB5A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB5A: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDB65u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CDB65: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDB69
 * Original: 0x002CDB69 - 0x002CDB73 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB69(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB69: ;
    eax = 0x354270;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDB80
 * Original: 0x002CDB80 - 0x002CDB88 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB80: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CDB88
 * Original: 0x002CDB88 - 0x002CDB92 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDB88(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDB88: ;
    eax = 0x354294;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDBA0
 * Original: 0x002CDBA0 - 0x002CDBA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBA0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDBA8
 * Original: 0x002CDBA8 - 0x002CDBB0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBA8: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDBB0
 * Original: 0x002CDBB0 - 0x002CDBBA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBB0: ;
    eax = 0x3542C0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDBC0
 * Original: 0x002CDBC0 - 0x002CDBC8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBC0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDBC8
 * Original: 0x002CDBC8 - 0x002CDBD2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBC8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBC8: ;
    eax = 0x3542E4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDBE0
 * Original: 0x002CDBE0 - 0x002CDBE8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBE0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDBE8
 * Original: 0x002CDBE8 - 0x002CDBF0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBE8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBE8: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDBF0
 * Original: 0x002CDBF0 - 0x002CDBFA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDBF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDBF0: ;
    eax = 0x354310;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDC00
 * Original: 0x002CDC00 - 0x002CDC08 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC00: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC08
 * Original: 0x002CDC08 - 0x002CDC10 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC08(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC08: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC10
 * Original: 0x002CDC10 - 0x002CDC18 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC10: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC18
 * Original: 0x002CDC18 - 0x002CDC22 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC18(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC18: ;
    eax = 0x354344;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDC30
 * Original: 0x002CDC30 - 0x002CDC3F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC30: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDC3Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDC3B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDC3F
 * Original: 0x002CDC3F - 0x002CDC47 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC3F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC3F: ;
    ecx = ebp + -28;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC47
 * Original: 0x002CDC47 - 0x002CDC4F (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC47(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC47: ;
    ecx = ebp + -36;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC4F
 * Original: 0x002CDC4F - 0x002CDC57 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC4F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC4F: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC57
 * Original: 0x002CDC57 - 0x002CDC5F (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC57(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC57: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC5F
 * Original: 0x002CDC5F - 0x002CDC67 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC5F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC5F: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC67
 * Original: 0x002CDC67 - 0x002CDC71 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC67(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC67: ;
    eax = 0x354390;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDC80
 * Original: 0x002CDC80 - 0x002CDC88 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC80: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC88
 * Original: 0x002CDC88 - 0x002CDC90 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC88(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC88: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDC90
 * Original: 0x002CDC90 - 0x002CDC9A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDC90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDC90: ;
    eax = 0x3543BC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDCA0
 * Original: 0x002CDCA0 - 0x002CDCA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCA0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDCA8
 * Original: 0x002CDCA8 - 0x002CDCB2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCA8: ;
    eax = 0x3543E0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDCC0
 * Original: 0x002CDCC0 - 0x002CDCC8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCC0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDCC8
 * Original: 0x002CDCC8 - 0x002CDCD7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCC8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCC8: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDCD3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDCD3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDCD7
 * Original: 0x002CDCD7 - 0x002CDCE6 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCD7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCD7: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDCE2u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDCE2: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDCE6
 * Original: 0x002CDCE6 - 0x002CDCF5 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCE6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCE6: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDCF1u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDCF1: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDCF5
 * Original: 0x002CDCF5 - 0x002CDD04 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDCF5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDCF5: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD00u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD00: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD04
 * Original: 0x002CDD04 - 0x002CDD13 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD04(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD04: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD0Fu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD0F: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD13
 * Original: 0x002CDD13 - 0x002CDD22 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD13(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD13: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD1Eu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD1E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD22
 * Original: 0x002CDD22 - 0x002CDD31 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD22(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD22: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD2Du); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD2D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD31
 * Original: 0x002CDD31 - 0x002CDD40 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD31(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD31: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD3Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD3C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD40
 * Original: 0x002CDD40 - 0x002CDD4F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD40: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD4Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD4B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD4F
 * Original: 0x002CDD4F - 0x002CDD5E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD4F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD4F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD5Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD5A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD5E
 * Original: 0x002CDD5E - 0x002CDD6D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD5E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD5E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD69u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD69: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD6D
 * Original: 0x002CDD6D - 0x002CDD7C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD6D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD6D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDD78u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDD78: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDD7C
 * Original: 0x002CDD7C - 0x002CDD86 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD7C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD7C: ;
    eax = 0x354464;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDD90
 * Original: 0x002CDD90 - 0x002CDD98 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD90: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDD98
 * Original: 0x002CDD98 - 0x002CDDA0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDD98(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDD98: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDDA0
 * Original: 0x002CDDA0 - 0x002CDDA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDA0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDDA8
 * Original: 0x002CDDA8 - 0x002CDDB2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDA8: ;
    eax = 0x3544A0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDDC0
 * Original: 0x002CDDC0 - 0x002CDDC8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDC0: ;
    ecx = MEM32(ebp + -20);
    g_seh_ebp = ebp; sub_002A91A0(); return; /* tail jmp 0x002A91A0 */

}

/**
 * sub_002CDDC8
 * Original: 0x002CDDC8 - 0x002CDDD3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDC8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDC8: ;
    ecx = MEM32(ebp + -20);
    _fb = (uint32_t)(0x24) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x24;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002A9200(); return; /* tail jmp 0x002A9200 */

}

/**
 * sub_002CDDD3
 * Original: 0x002CDDD3 - 0x002CDDE2 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDD3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDD3: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDDDEu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CDDDE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDDE2
 * Original: 0x002CDDE2 - 0x002CDDEC (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDE2(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDE2: ;
    eax = 0x3544D4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDDF0
 * Original: 0x002CDDF0 - 0x002CDDF8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDF0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_002A91A0(); return; /* tail jmp 0x002A91A0 */

}

/**
 * sub_002CDDF8
 * Original: 0x002CDDF8 - 0x002CDE03 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDDF8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDDF8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x24) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x24;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002A9200(); return; /* tail jmp 0x002A9200 */

}

/**
 * sub_002CDE03
 * Original: 0x002CDE03 - 0x002CDE0D (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE03(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE03: ;
    eax = 0x354500;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDE10
 * Original: 0x002CDE10 - 0x002CDE1F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE10: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDE1Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CDE1B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDE1F
 * Original: 0x002CDE1F - 0x002CDE27 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE1F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE1F: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE27
 * Original: 0x002CDE27 - 0x002CDE31 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE27(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE27: ;
    eax = 0x35452C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDE40
 * Original: 0x002CDE40 - 0x002CDE48 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE40: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE48
 * Original: 0x002CDE48 - 0x002CDE50 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE48(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE48: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE50
 * Original: 0x002CDE50 - 0x002CDE5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE50: ;
    eax = 0x354558;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDE60
 * Original: 0x002CDE60 - 0x002CDE68 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE60: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE68
 * Original: 0x002CDE68 - 0x002CDE70 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE68(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE68: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE70
 * Original: 0x002CDE70 - 0x002CDE7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE70: ;
    eax = 0x354584;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDE80
 * Original: 0x002CDE80 - 0x002CDE88 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE80: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE88
 * Original: 0x002CDE88 - 0x002CDE90 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE88(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE88: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDE90
 * Original: 0x002CDE90 - 0x002CDE9A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDE90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDE90: ;
    eax = 0x3545B0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDEA0
 * Original: 0x002CDEA0 - 0x002CDEA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEA0: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDEA8
 * Original: 0x002CDEA8 - 0x002CDEB2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEA8: ;
    eax = 0x3545D4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDEC0
 * Original: 0x002CDEC0 - 0x002CDEC8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEC0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDEC8
 * Original: 0x002CDEC8 - 0x002CDED2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEC8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEC8: ;
    eax = 0x3545F8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDEE0
 * Original: 0x002CDEE0 - 0x002CDEE8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEE0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDEE8
 * Original: 0x002CDEE8 - 0x002CDEF0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEE8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEE8: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDEF0
 * Original: 0x002CDEF0 - 0x002CDEFF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEF0: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -48);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDEFBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CDEFB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDEFF
 * Original: 0x002CDEFF - 0x002CDF07 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDEFF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDEFF: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDF07
 * Original: 0x002CDF07 - 0x002CDF11 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF07(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF07: ;
    eax = 0x354634;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDF20
 * Original: 0x002CDF20 - 0x002CDF28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF20: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDF28
 * Original: 0x002CDF28 - 0x002CDF32 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF28: ;
    eax = 0x354658;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDF40
 * Original: 0x002CDF40 - 0x002CDF48 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF40: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CDF48
 * Original: 0x002CDF48 - 0x002CDF50 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF48(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF48: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CDF50
 * Original: 0x002CDF50 - 0x002CDF5B (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF50: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x20;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDF5B
 * Original: 0x002CDF5B - 0x002CDF65 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF5B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF5B: ;
    eax = 0x35468C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDF70
 * Original: 0x002CDF70 - 0x002CDF78 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF70: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_002A91A0(); return; /* tail jmp 0x002A91A0 */

}

/**
 * sub_002CDF78
 * Original: 0x002CDF78 - 0x002CDF83 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF78(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF78: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x18;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDF83
 * Original: 0x002CDF83 - 0x002CDF8E (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF83(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF83: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1C;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDF8E
 * Original: 0x002CDF8E - 0x002CDF98 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDF8E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDF8E: ;
    eax = 0x3546C0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDFA0
 * Original: 0x002CDFA0 - 0x002CDFAF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFA0: ;
    PUSH32(esp, 0x20);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDFABu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CDFAB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CDFAF
 * Original: 0x002CDFAF - 0x002CDFB7 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFAF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFAF: ;
    ecx = MEM32(ebp + 8);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CDFB7
 * Original: 0x002CDFB7 - 0x002CDFC1 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFB7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFB7: ;
    eax = 0x3546EC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDFD0
 * Original: 0x002CDFD0 - 0x002CDFD8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFD0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFD0: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CDFD8
 * Original: 0x002CDFD8 - 0x002CDFE2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFD8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFD8: ;
    eax = 0x354710;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CDFF0
 * Original: 0x002CDFF0 - 0x002CDFFB (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFF0: ;
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CDFF9u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002CDFF9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CDFFB
 * Original: 0x002CDFFB - 0x002CE005 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CDFFB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CDFFB: ;
    eax = 0x354734;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE010
 * Original: 0x002CE010 - 0x002CE01B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE010(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE010: ;
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE019u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002CE019: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CE01B
 * Original: 0x002CE01B - 0x002CE02A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE01B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE01B: ;
    PUSH32(esp, 0x40);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE026u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE026: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE02A
 * Original: 0x002CE02A - 0x002CE032 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE02A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE02A: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE032
 * Original: 0x002CE032 - 0x002CE03A (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE032(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE032: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE03A
 * Original: 0x002CE03A - 0x002CE044 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE03A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE03A: ;
    eax = 0x354770;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE050
 * Original: 0x002CE050 - 0x002CE058 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE050(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE050: ;
    ecx = ebp + -44;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE058
 * Original: 0x002CE058 - 0x002CE060 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE058(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE058: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE060
 * Original: 0x002CE060 - 0x002CE06A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE060(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE060: ;
    eax = 0x35479C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE070
 * Original: 0x002CE070 - 0x002CE07F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE070(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE070: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE07Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE07B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE07F
 * Original: 0x002CE07F - 0x002CE08E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE07F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE07F: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE08Au); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE08A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE08E
 * Original: 0x002CE08E - 0x002CE09D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE08E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE08E: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE099u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE099: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE09D
 * Original: 0x002CE09D - 0x002CE0AC (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE09D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE09D: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE0A8u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE0A8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE0AC
 * Original: 0x002CE0AC - 0x002CE0B4 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0AC(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0AC: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE0B4
 * Original: 0x002CE0B4 - 0x002CE0C3 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0B4(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0B4: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -40);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE0BFu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE0BF: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE0C3
 * Original: 0x002CE0C3 - 0x002CE0D2 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0C3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0C3: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE0CEu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE0CE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE0D2
 * Original: 0x002CE0D2 - 0x002CE0E1 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0D2(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0D2: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE0DDu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE0DD: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE0E1
 * Original: 0x002CE0E1 - 0x002CE0F0 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0E1(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0E1: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE0ECu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE0EC: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE0F0
 * Original: 0x002CE0F0 - 0x002CE0FF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0F0: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE0FBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE0FB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE0FF
 * Original: 0x002CE0FF - 0x002CE10E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE0FF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE0FF: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE10Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE10A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE10E
 * Original: 0x002CE10E - 0x002CE11D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE10E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE10E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE119u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE119: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE11D
 * Original: 0x002CE11D - 0x002CE12C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE11D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE11D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE128u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE128: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE12C
 * Original: 0x002CE12C - 0x002CE13B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE12C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE12C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE137u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE137: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE13B
 * Original: 0x002CE13B - 0x002CE14A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE13B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE13B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE146u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE146: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE14A
 * Original: 0x002CE14A - 0x002CE159 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE14A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE14A: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE155u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE155: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE159
 * Original: 0x002CE159 - 0x002CE168 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE159(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE159: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE164u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE164: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE168
 * Original: 0x002CE168 - 0x002CE177 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE168(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE168: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE173u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE173: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE177
 * Original: 0x002CE177 - 0x002CE186 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE177(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE177: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE182u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE182: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE186
 * Original: 0x002CE186 - 0x002CE195 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE186(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE186: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE191u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE191: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE195
 * Original: 0x002CE195 - 0x002CE1A4 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE195(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE195: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1A0u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1A0: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1A4
 * Original: 0x002CE1A4 - 0x002CE1B3 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1A4(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1A4: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1AFu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1AF: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1B3
 * Original: 0x002CE1B3 - 0x002CE1C2 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1B3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1B3: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1BEu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1BE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1C2
 * Original: 0x002CE1C2 - 0x002CE1D1 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1C2(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1C2: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1CDu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1CD: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1D1
 * Original: 0x002CE1D1 - 0x002CE1E0 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1D1(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1D1: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1DCu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1DC: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1E0
 * Original: 0x002CE1E0 - 0x002CE1EF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1E0: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1EBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1EB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1EF
 * Original: 0x002CE1EF - 0x002CE1FE (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1EF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1EF: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE1FAu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE1FA: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE1FE
 * Original: 0x002CE1FE - 0x002CE20D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE1FE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE1FE: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE209u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE209: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE20D
 * Original: 0x002CE20D - 0x002CE21C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE20D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE20D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE218u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE218: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE21C
 * Original: 0x002CE21C - 0x002CE22B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE21C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE21C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE227u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE227: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE22B
 * Original: 0x002CE22B - 0x002CE23A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE22B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE22B: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE236u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE236: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE23A
 * Original: 0x002CE23A - 0x002CE249 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE23A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE23A: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE245u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE245: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE249
 * Original: 0x002CE249 - 0x002CE251 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE249(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE249: ;
    ecx = ebp + -40;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE251
 * Original: 0x002CE251 - 0x002CE260 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE251(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE251: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE25Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE25C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE260
 * Original: 0x002CE260 - 0x002CE26F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE260(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE260: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE26Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE26B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE26F
 * Original: 0x002CE26F - 0x002CE27E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE26F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE26F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE27Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE27A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE27E
 * Original: 0x002CE27E - 0x002CE288 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE27E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE27E: ;
    eax = 0x3548D8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE290
 * Original: 0x002CE290 - 0x002CE298 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE290(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE290: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE298
 * Original: 0x002CE298 - 0x002CE2A0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE298(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE298: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE2A0
 * Original: 0x002CE2A0 - 0x002CE2AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2A0: ;
    eax = 0x354904;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE2B0
 * Original: 0x002CE2B0 - 0x002CE2B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2B0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE2B8
 * Original: 0x002CE2B8 - 0x002CE2C2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2B8: ;
    eax = 0x354928;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE2D0
 * Original: 0x002CE2D0 - 0x002CE2DF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2D0: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE2DBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE2DB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE2DF
 * Original: 0x002CE2DF - 0x002CE2EE (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2DF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2DF: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE2EAu); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE2EA: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE2EE
 * Original: 0x002CE2EE - 0x002CE2FD (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2EE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2EE: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE2F9u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE2F9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE2FD
 * Original: 0x002CE2FD - 0x002CE305 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE2FD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE2FD: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE305
 * Original: 0x002CE305 - 0x002CE314 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE305(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE305: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE310u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE310: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE314
 * Original: 0x002CE314 - 0x002CE323 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE314(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE314: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE31Fu); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE31F: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE323
 * Original: 0x002CE323 - 0x002CE332 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE323(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE323: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE32Eu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE32E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE332
 * Original: 0x002CE332 - 0x002CE341 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE332(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE332: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE33Du); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE33D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE341
 * Original: 0x002CE341 - 0x002CE350 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE341(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE341: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE34Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE34C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE350
 * Original: 0x002CE350 - 0x002CE35F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE350(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE350: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE35Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE35B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE35F
 * Original: 0x002CE35F - 0x002CE36E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE35F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE35F: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE36Au); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE36A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE36E
 * Original: 0x002CE36E - 0x002CE37D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE36E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE36E: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE379u); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE379: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE37D
 * Original: 0x002CE37D - 0x002CE38C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE37D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE37D: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE388u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE388: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE38C
 * Original: 0x002CE38C - 0x002CE39B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE38C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE38C: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE397u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE397: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE39B
 * Original: 0x002CE39B - 0x002CE3AA (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE39B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE39B: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE3A6u); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE3A6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE3AA
 * Original: 0x002CE3AA - 0x002CE3B9 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE3AA(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE3AA: ;
    PUSH32(esp, 0x28);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE3B5u); RECOMP_ABI_CALL(0x00282DE0u, sub_00282DE0); /* call 0x00282DE0 */

loc_002CE3B5: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE3B9
 * Original: 0x002CE3B9 - 0x002CE3C8 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE3B9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE3B9: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE3C4u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE3C4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE3C8
 * Original: 0x002CE3C8 - 0x002CE3D7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE3C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE3C8: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE3D3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE3D3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE3D7
 * Original: 0x002CE3D7 - 0x002CE3E1 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE3D7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE3D7: ;
    eax = 0x3549D4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE3F0
 * Original: 0x002CE3F0 - 0x002CE3F8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE3F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE3F0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_0029FBF0(); return; /* tail jmp 0x0029FBF0 */

}

/**
 * sub_002CE3F8
 * Original: 0x002CE3F8 - 0x002CE402 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE3F8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE3F8: ;
    eax = 0x3549F8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE410
 * Original: 0x002CE410 - 0x002CE418 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE410(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE410: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE418
 * Original: 0x002CE418 - 0x002CE422 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE418(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE418: ;
    eax = 0x354A1C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE430
 * Original: 0x002CE430 - 0x002CE43F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE430(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE430: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE43Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE43B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE43F
 * Original: 0x002CE43F - 0x002CE44E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE43F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE43F: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE44Au); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE44A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE44E
 * Original: 0x002CE44E - 0x002CE45D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE44E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE44E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE459u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE459: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE45D
 * Original: 0x002CE45D - 0x002CE46C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE45D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE45D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE468u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE468: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE46C
 * Original: 0x002CE46C - 0x002CE47B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE46C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE46C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE477u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE477: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE47B
 * Original: 0x002CE47B - 0x002CE48A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE47B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE47B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE486u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE486: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE48A
 * Original: 0x002CE48A - 0x002CE494 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE48A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE48A: ;
    eax = 0x354A68;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE4A0
 * Original: 0x002CE4A0 - 0x002CE4A8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4A0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE4A8
 * Original: 0x002CE4A8 - 0x002CE4B2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4A8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4A8: ;
    eax = 0x354A8C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE4C0
 * Original: 0x002CE4C0 - 0x002CE4C8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4C0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE4C8
 * Original: 0x002CE4C8 - 0x002CE4D0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4C8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4C8: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CE4D0
 * Original: 0x002CE4D0 - 0x002CE4DA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4D0: ;
    eax = 0x354AB8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE4E0
 * Original: 0x002CE4E0 - 0x002CE4EF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4E0: ;
    PUSH32(esp, 0x20);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE4EBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE4EB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE4EF
 * Original: 0x002CE4EF - 0x002CE4F7 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4EF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4EF: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE4F7
 * Original: 0x002CE4F7 - 0x002CE501 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE4F7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE4F7: ;
    eax = 0x354AE4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE510
 * Original: 0x002CE510 - 0x002CE51F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE510(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE510: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE51Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE51B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE51F
 * Original: 0x002CE51F - 0x002CE52E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE51F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE51F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE52Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE52A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE52E
 * Original: 0x002CE52E - 0x002CE53D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE52E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE52E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE539u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE539: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE53D
 * Original: 0x002CE53D - 0x002CE54C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE53D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE53D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE548u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE548: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE54C
 * Original: 0x002CE54C - 0x002CE556 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE54C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE54C: ;
    eax = 0x354B20;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE560
 * Original: 0x002CE560 - 0x002CE568 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE560(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE560: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE568
 * Original: 0x002CE568 - 0x002CE572 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE568(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE568: ;
    eax = 0x354B44;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE580
 * Original: 0x002CE580 - 0x002CE588 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE580(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE580: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE588
 * Original: 0x002CE588 - 0x002CE592 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE588(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE588: ;
    eax = 0x354B68;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE5A0
 * Original: 0x002CE5A0 - 0x002CE5AF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE5A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE5A0: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE5ABu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE5AB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE5AF
 * Original: 0x002CE5AF - 0x002CE5BE (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE5AF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE5AF: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE5BAu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE5BA: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE5BE
 * Original: 0x002CE5BE - 0x002CE5CD (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE5BE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE5BE: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE5C9u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE5C9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE5CD
 * Original: 0x002CE5CD - 0x002CE5D7 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE5CD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE5CD: ;
    eax = 0x354B9C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE5E0
 * Original: 0x002CE5E0 - 0x002CE5E8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE5E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE5E0: ;
    ecx = ebp + -92;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE5E8
 * Original: 0x002CE5E8 - 0x002CE5F2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE5E8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE5E8: ;
    eax = 0x354BC0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE600
 * Original: 0x002CE600 - 0x002CE60F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE600(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE600: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE60Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE60B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE60F
 * Original: 0x002CE60F - 0x002CE617 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE60F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE60F: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE617
 * Original: 0x002CE617 - 0x002CE621 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE617(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE617: ;
    eax = 0x354BEC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE630
 * Original: 0x002CE630 - 0x002CE63F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE630(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE630: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE63Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE63B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE63F
 * Original: 0x002CE63F - 0x002CE64E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE63F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE63F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE64Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE64A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE64E
 * Original: 0x002CE64E - 0x002CE65D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE64E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE64E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE659u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE659: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE65D
 * Original: 0x002CE65D - 0x002CE66C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE65D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE65D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE668u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE668: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE66C
 * Original: 0x002CE66C - 0x002CE67B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE66C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE66C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE677u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE677: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE67B
 * Original: 0x002CE67B - 0x002CE68A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE67B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE67B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE686u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE686: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE68A
 * Original: 0x002CE68A - 0x002CE699 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE68A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE68A: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE695u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE695: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE699
 * Original: 0x002CE699 - 0x002CE6A8 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE699(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE699: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6A4u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6A4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE6A8
 * Original: 0x002CE6A8 - 0x002CE6B7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE6A8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE6A8: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6B3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6B3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE6B7
 * Original: 0x002CE6B7 - 0x002CE6C6 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE6B7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE6B7: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6C2u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6C2: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE6C6
 * Original: 0x002CE6C6 - 0x002CE6D5 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE6C6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE6C6: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6D1u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6D1: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE6D5
 * Original: 0x002CE6D5 - 0x002CE6E4 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE6D5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE6D5: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6E0u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6E0: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE6E4
 * Original: 0x002CE6E4 - 0x002CE6F3 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE6E4(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE6E4: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6EFu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6EF: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE6F3
 * Original: 0x002CE6F3 - 0x002CE702 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE6F3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE6F3: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE6FEu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE6FE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE702
 * Original: 0x002CE702 - 0x002CE711 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE702(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE702: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE70Du); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE70D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE711
 * Original: 0x002CE711 - 0x002CE720 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE711(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE711: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE71Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE71C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE720
 * Original: 0x002CE720 - 0x002CE72F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE720(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE720: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE72Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE72B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE72F
 * Original: 0x002CE72F - 0x002CE73E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE72F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE72F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE73Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE73A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE73E
 * Original: 0x002CE73E - 0x002CE74D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE73E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE73E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE749u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE749: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE74D
 * Original: 0x002CE74D - 0x002CE75C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE74D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE74D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE758u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE758: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE75C
 * Original: 0x002CE75C - 0x002CE76B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE75C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE75C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE767u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE767: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE76B
 * Original: 0x002CE76B - 0x002CE77A (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE76B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE76B: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE776u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE776: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE77A
 * Original: 0x002CE77A - 0x002CE789 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE77A(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE77A: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE785u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE785: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE789
 * Original: 0x002CE789 - 0x002CE798 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE789(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE789: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE794u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE794: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE798
 * Original: 0x002CE798 - 0x002CE7A7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE798(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE798: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7A3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7A3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE7A7
 * Original: 0x002CE7A7 - 0x002CE7B6 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE7A7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE7A7: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7B2u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7B2: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE7B6
 * Original: 0x002CE7B6 - 0x002CE7C5 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE7B6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE7B6: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7C1u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7C1: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE7C5
 * Original: 0x002CE7C5 - 0x002CE7D4 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE7C5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE7C5: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7D0u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7D0: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE7D4
 * Original: 0x002CE7D4 - 0x002CE7E3 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE7D4(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE7D4: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7DFu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7DF: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE7E3
 * Original: 0x002CE7E3 - 0x002CE7F2 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE7E3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE7E3: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7EEu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7EE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE7F2
 * Original: 0x002CE7F2 - 0x002CE801 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE7F2(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE7F2: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE7FDu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE7FD: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE801
 * Original: 0x002CE801 - 0x002CE810 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE801(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE801: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE80Cu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE80C: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE810
 * Original: 0x002CE810 - 0x002CE81F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE810(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE810: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE81Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE81B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE81F
 * Original: 0x002CE81F - 0x002CE82E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE81F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE81F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE82Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE82A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE82E
 * Original: 0x002CE82E - 0x002CE83D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE82E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE82E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE839u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE839: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE83D
 * Original: 0x002CE83D - 0x002CE84C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE83D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE83D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE848u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE848: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE84C
 * Original: 0x002CE84C - 0x002CE85B (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE84C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE84C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE857u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE857: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE85B
 * Original: 0x002CE85B - 0x002CE865 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE85B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE85B: ;
    eax = 0x354D30;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE870
 * Original: 0x002CE870 - 0x002CE878 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE870(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE870: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE878
 * Original: 0x002CE878 - 0x002CE880 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE878(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE878: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE880
 * Original: 0x002CE880 - 0x002CE88A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE880(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE880: ;
    eax = 0x354D5C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE890
 * Original: 0x002CE890 - 0x002CE898 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE890(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE890: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE898
 * Original: 0x002CE898 - 0x002CE8A0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE898(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE898: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE8A0
 * Original: 0x002CE8A0 - 0x002CE8AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8A0: ;
    eax = 0x354D88;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE8B0
 * Original: 0x002CE8B0 - 0x002CE8B8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8B0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277D80(); return; /* tail jmp 0x00277D80 */

}

/**
 * sub_002CE8B8
 * Original: 0x002CE8B8 - 0x002CE8C0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8B8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8B8: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE8C0
 * Original: 0x002CE8C0 - 0x002CE8CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8C0: ;
    eax = 0x354DB4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE8D0
 * Original: 0x002CE8D0 - 0x002CE8D8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8D0: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE8D8
 * Original: 0x002CE8D8 - 0x002CE8E0 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8D8: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CE8E0
 * Original: 0x002CE8E0 - 0x002CE8EF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8E0: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE8EBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CE8EB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE8EF
 * Original: 0x002CE8EF - 0x002CE8F9 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE8EF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE8EF: ;
    eax = 0x354DE8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE900
 * Original: 0x002CE900 - 0x002CE908 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE900(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE900: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CE908
 * Original: 0x002CE908 - 0x002CE912 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE908(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE908: ;
    eax = 0x354E0C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE920
 * Original: 0x002CE920 - 0x002CE92F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE920(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE920: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE92Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE92B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE92F
 * Original: 0x002CE92F - 0x002CE939 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE92F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE92F: ;
    eax = 0x354E30;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE940
 * Original: 0x002CE940 - 0x002CE94F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE940(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE940: ;
    PUSH32(esp, 0x2C);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE94Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE94B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE94F
 * Original: 0x002CE94F - 0x002CE959 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE94F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE94F: ;
    eax = 0x354E54;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CE960
 * Original: 0x002CE960 - 0x002CE96F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE960(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE960: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE96Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE96B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE96F
 * Original: 0x002CE96F - 0x002CE97E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE96F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE96F: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE97Au); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE97A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE97E
 * Original: 0x002CE97E - 0x002CE98D (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE97E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE97E: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE989u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE989: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE98D
 * Original: 0x002CE98D - 0x002CE99C (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE98D(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE98D: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE998u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE998: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE99C
 * Original: 0x002CE99C - 0x002CE9AB (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE99C(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE99C: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE9A7u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE9A7: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE9AB
 * Original: 0x002CE9AB - 0x002CE9BA (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE9AB(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE9AB: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE9B6u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE9B6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE9BA
 * Original: 0x002CE9BA - 0x002CE9C9 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE9BA(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE9BA: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE9C5u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE9C5: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE9C9
 * Original: 0x002CE9C9 - 0x002CE9D8 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE9C9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE9C9: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE9D4u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE9D4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE9D8
 * Original: 0x002CE9D8 - 0x002CE9E7 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE9D8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE9D8: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE9E3u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE9E3: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE9E7
 * Original: 0x002CE9E7 - 0x002CE9F6 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE9E7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE9E7: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CE9F2u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CE9F2: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CE9F6
 * Original: 0x002CE9F6 - 0x002CEA05 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CE9F6(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CE9F6: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEA01u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CEA01: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEA05
 * Original: 0x002CEA05 - 0x002CEA14 (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA05(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA05: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEA10u); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CEA10: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEA14
 * Original: 0x002CEA14 - 0x002CEA1E (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA14(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA14: ;
    eax = 0x354ED0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEA20
 * Original: 0x002CEA20 - 0x002CEA28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA20: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEA28
 * Original: 0x002CEA28 - 0x002CEA32 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA28: ;
    eax = 0x354EF4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEA40
 * Original: 0x002CEA40 - 0x002CEA4F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA40: ;
    PUSH32(esp, 0x64);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEA4Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CEA4B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEA4F
 * Original: 0x002CEA4F - 0x002CEA59 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA4F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA4F: ;
    eax = 0x354F18;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEA60
 * Original: 0x002CEA60 - 0x002CEA6F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA60: ;
    PUSH32(esp, 4);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEA6Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEA6B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEA6F
 * Original: 0x002CEA6F - 0x002CEA79 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA6F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA6F: ;
    eax = 0x354F3C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEA80
 * Original: 0x002CEA80 - 0x002CEA88 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA80: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_002A91A0(); return; /* tail jmp 0x002A91A0 */

}

/**
 * sub_002CEA88
 * Original: 0x002CEA88 - 0x002CEA92 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEA88(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEA88: ;
    eax = 0x354F60;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEAA0
 * Original: 0x002CEAA0 - 0x002CEAAF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEAA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEAA0: ;
    PUSH32(esp, 0x30);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEAABu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEAAB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEAAF
 * Original: 0x002CEAAF - 0x002CEABE (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEAAF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEAAF: ;
    PUSH32(esp, 0x24);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEABAu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEABA: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEABE
 * Original: 0x002CEABE - 0x002CEACD (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEABE(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEABE: ;
    PUSH32(esp, 0x78);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEAC9u); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEAC9: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEACD
 * Original: 0x002CEACD - 0x002CEAD5 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEACD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEACD: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEAD5
 * Original: 0x002CEAD5 - 0x002CEADD (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEAD5(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEAD5: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEADD
 * Original: 0x002CEADD - 0x002CEAE7 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEADD(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEADD: ;
    eax = 0x354FA4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEAF0
 * Original: 0x002CEAF0 - 0x002CEAF8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEAF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEAF0: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEAF8
 * Original: 0x002CEAF8 - 0x002CEB00 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEAF8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEAF8: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB00
 * Original: 0x002CEB00 - 0x002CEB08 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB00: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB08
 * Original: 0x002CEB08 - 0x002CEB10 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB08(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB08: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB10
 * Original: 0x002CEB10 - 0x002CEB1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB10: ;
    eax = 0x354FE0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEB20
 * Original: 0x002CEB20 - 0x002CEB28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB20: ;
    ecx = ebp + -16;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB28
 * Original: 0x002CEB28 - 0x002CEB30 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB28: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB30
 * Original: 0x002CEB30 - 0x002CEB3A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB30: ;
    eax = 0x35500C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEB40
 * Original: 0x002CEB40 - 0x002CEB4F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB40: ;
    PUSH32(esp, 0x14);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEB4Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEB4B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEB4F
 * Original: 0x002CEB4F - 0x002CEB59 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB4F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB4F: ;
    eax = 0x355030;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEB60
 * Original: 0x002CEB60 - 0x002CEB68 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB60: ;
    ecx = ebp + 0xC;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB68
 * Original: 0x002CEB68 - 0x002CEB70 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB68(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB68: ;
    ecx = ebp + -72;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEB70
 * Original: 0x002CEB70 - 0x002CEB7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB70: ;
    eax = 0x35505C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEB80
 * Original: 0x002CEB80 - 0x002CEB8F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB80: ;
    PUSH32(esp, 0x48);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEB8Bu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CEB8B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEB8F
 * Original: 0x002CEB8F - 0x002CEB99 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEB8F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEB8F: ;
    eax = 0x355080;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEBA0
 * Original: 0x002CEBA0 - 0x002CEBA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBA0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CEBA8
 * Original: 0x002CEBA8 - 0x002CEBB3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBA8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0xC;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEBB3
 * Original: 0x002CEBB3 - 0x002CEBBD (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBB3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBB3: ;
    eax = 0x3550AC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEBC0
 * Original: 0x002CEBC0 - 0x002CEBCF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBC0: ;
    PUSH32(esp, 8);
    eax = MEM32(ebp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEBCBu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEBCB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEBCF
 * Original: 0x002CEBCF - 0x002CEBD9 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBCF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBCF: ;
    eax = 0x3550D0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEBE0
 * Original: 0x002CEBE0 - 0x002CEBEF (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBE0: ;
    PUSH32(esp, 0x1C);
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEBEBu); RECOMP_ABI_CALL(0x00277940u, sub_00277940); /* call 0x00277940 */

loc_002CEBEB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEBEF
 * Original: 0x002CEBEF - 0x002CEBF7 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBEF(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBEF: ;
    ecx = ebp + -24;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEBF7
 * Original: 0x002CEBF7 - 0x002CEC01 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEBF7(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEBF7: ;
    eax = 0x3550FC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEC10
 * Original: 0x002CEC10 - 0x002CEC18 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC10: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEC18
 * Original: 0x002CEC18 - 0x002CEC20 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC18(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC18: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEC20
 * Original: 0x002CEC20 - 0x002CEC28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC20: ;
    ecx = ebp + 4;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEC28
 * Original: 0x002CEC28 - 0x002CEC30 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC28: ;
    ecx = ebp + 8;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEC30
 * Original: 0x002CEC30 - 0x002CEC3A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC30: ;
    eax = 0x355138;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEC40
 * Original: 0x002CEC40 - 0x002CEC4F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC40: ;
    PUSH32(esp, 0x14);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEC4Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEC4B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEC4F
 * Original: 0x002CEC4F - 0x002CEC5E (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC4F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC4F: ;
    PUSH32(esp, 0x14);
    eax = MEM32(ebp + 8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEC5Au); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEC5A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEC5E
 * Original: 0x002CEC5E - 0x002CEC68 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC5E(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC5E: ;
    eax = 0x355164;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEC70
 * Original: 0x002CEC70 - 0x002CEC7F (15 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC70: ;
    PUSH32(esp, 0x10);
    eax = MEM32(ebp + -20);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEC7Bu); RECOMP_ABI_CALL(0x002A8320u, sub_002A8320); /* call 0x002A8320 */

loc_002CEC7B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CEC7F
 * Original: 0x002CEC7F - 0x002CEC87 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC7F(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC7F: ;
    ecx = ebp + -20;
    g_seh_ebp = ebp; sub_00277430(); return; /* tail jmp 0x00277430 */

}

/**
 * sub_002CEC87
 * Original: 0x002CEC87 - 0x002CEC91 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEC87(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEC87: ;
    eax = 0x355190;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CECA0
 * Original: 0x002CECA0 - 0x002CECA8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CECA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CECA0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00277970(); return; /* tail jmp 0x00277970 */

}

/**
 * sub_002CECA8
 * Original: 0x002CECA8 - 0x002CECB2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CECA8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CECA8: ;
    eax = 0x3551B4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CECC0
 * Original: 0x002CECC0 - 0x002CECC8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CECC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CECC0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CECC8
 * Original: 0x002CECC8 - 0x002CECD2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CECC8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CECC8: ;
    eax = 0x3551D8;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CECE0
 * Original: 0x002CECE0 - 0x002CECE8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CECE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CECE0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_001FF100(); return; /* tail jmp 0x001FF100 */

}

/**
 * sub_002CECE8
 * Original: 0x002CECE8 - 0x002CECF2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CECE8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CECE8: ;
    eax = 0x3551FC;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CED00
 * Original: 0x002CED00 - 0x002CED08 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED00: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_002B42C0(); return; /* tail jmp 0x002B42C0 */

}

/**
 * sub_002CED08
 * Original: 0x002CED08 - 0x002CED12 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED08(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED08: ;
    eax = 0x355220;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CED20
 * Original: 0x002CED20 - 0x002CED28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED20: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_002216D0(); return; /* tail jmp 0x002216D0 */

}

/**
 * sub_002CED28
 * Original: 0x002CED28 - 0x002CED32 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED28: ;
    eax = 0x355244;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CED40
 * Original: 0x002CED40 - 0x002CED48 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED40: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_001F6550(); return; /* tail jmp 0x001F6550 */

}

/**
 * sub_002CED48
 * Original: 0x002CED48 - 0x002CED52 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED48(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED48: ;
    eax = 0x355268;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CED60
 * Original: 0x002CED60 - 0x002CED68 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED60: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00224500(); return; /* tail jmp 0x00224500 */

}

/**
 * sub_002CED68
 * Original: 0x002CED68 - 0x002CED72 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED68(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED68: ;
    eax = 0x35528C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CED80
 * Original: 0x002CED80 - 0x002CED88 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED80: ;
    ecx = MEM32(ebp + -52);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CED88
 * Original: 0x002CED88 - 0x002CED93 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED88(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED88: ;
    ecx = MEM32(ebp + -52);
    _fb = (uint32_t)(0x40) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x40;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002216D0(); return; /* tail jmp 0x002216D0 */

}

/**
 * sub_002CED93
 * Original: 0x002CED93 - 0x002CEDA9 (22 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CED93(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CED93: ;
    PUSH32(esp, 0x224500);
    PUSH32(esp, 3);
    PUSH32(esp, 0xC);
    eax = MEM32(ebp + -52);
    _fb = (uint32_t)(0x4C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x4C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEDA8u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CEDA8: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CEDA9
 * Original: 0x002CEDA9 - 0x002CEDB3 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEDA9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEDA9: ;
    eax = 0x3552C0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEDC0
 * Original: 0x002CEDC0 - 0x002CEDC8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEDC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEDC0: ;
    ecx = ebp + -80;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEDC8
 * Original: 0x002CEDC8 - 0x002CEDD2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEDC8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEDC8: ;
    eax = 0x3552E4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEDE0
 * Original: 0x002CEDE0 - 0x002CEDE8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEDE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEDE0: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEDE8
 * Original: 0x002CEDE8 - 0x002CEDF2 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEDE8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEDE8: ;
    eax = 0x355308;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEE00
 * Original: 0x002CEE00 - 0x002CEE08 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE00: ;
    ecx = ebp + -36;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEE08
 * Original: 0x002CEE08 - 0x002CEE12 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE08(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE08: ;
    eax = 0x35532C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEE20
 * Original: 0x002CEE20 - 0x002CEE28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE20: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_002B4620(); return; /* tail jmp 0x002B4620 */

}

/**
 * sub_002CEE28
 * Original: 0x002CEE28 - 0x002CEE30 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE28: ;
    ecx = ebp + -72;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEE30
 * Original: 0x002CEE30 - 0x002CEE38 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE30: ;
    ecx = ebp + -52;
    g_seh_ebp = ebp; sub_002246F0(); return; /* tail jmp 0x002246F0 */

}

/**
 * sub_002CEE38
 * Original: 0x002CEE38 - 0x002CEE42 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE38(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE38: ;
    eax = 0x355360;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEE50
 * Original: 0x002CEE50 - 0x002CEE58 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE50: ;
    ecx = ebp + -112;
    g_seh_ebp = ebp; sub_002B47F0(); return; /* tail jmp 0x002B47F0 */

}

/**
 * sub_002CEE58
 * Original: 0x002CEE58 - 0x002CEE63 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE58(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE58: ;
    ecx = ebp + -156;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEE63
 * Original: 0x002CEE63 - 0x002CEE6D (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE63(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE63: ;
    eax = 0x35538C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEE70
 * Original: 0x002CEE70 - 0x002CEE78 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE70: ;
    ecx = ebp + -100;
    g_seh_ebp = ebp; sub_002B47F0(); return; /* tail jmp 0x002B47F0 */

}

/**
 * sub_002CEE78
 * Original: 0x002CEE78 - 0x002CEE82 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE78(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE78: ;
    eax = 0x3553B0;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEE90
 * Original: 0x002CEE90 - 0x002CEE9B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE90: ;
    eax = MEM32(ebp + 0xC);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEE99u); RECOMP_ABI_CALL(0x002B29C0u, sub_002B29C0); /* call 0x002B29C0 */

loc_002CEE99: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CEE9B
 * Original: 0x002CEE9B - 0x002CEEA5 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEE9B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEE9B: ;
    eax = 0x3553D4;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEEB0
 * Original: 0x002CEEB0 - 0x002CEEB8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEEB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEEB0: ;
    ecx = MEM32(ebp + -16);
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002CEEB8
 * Original: 0x002CEEB8 - 0x002CEEC3 (11 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEEB8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEEB8: ;
    ecx = MEM32(ebp + -16);
    _fb = (uint32_t)(0x40) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x40;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002216D0(); return; /* tail jmp 0x002216D0 */

}

/**
 * sub_002CEEC3
 * Original: 0x002CEEC3 - 0x002CEED9 (22 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEEC3(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEEC3: ;
    PUSH32(esp, 0x224500);
    PUSH32(esp, 3);
    PUSH32(esp, 0xC);
    eax = MEM32(ebp + -16);
    _fb = (uint32_t)(0x4C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x4C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEED8u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002CEED8: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CEED9
 * Original: 0x002CEED9 - 0x002CEEE3 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEED9(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEED9: ;
    eax = 0x355408;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEEF0
 * Original: 0x002CEEF0 - 0x002CEEF8 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEEF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEEF0: ;
    ecx = ebp + -112;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEEF8
 * Original: 0x002CEEF8 - 0x002CEF02 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEEF8(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEEF8: ;
    eax = 0x35542C;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEF10
 * Original: 0x002CEF10 - 0x002CEF18 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF10: ;
    ecx = ebp + -92;
    g_seh_ebp = ebp; sub_002B43A0(); return; /* tail jmp 0x002B43A0 */

}

/**
 * sub_002CEF18
 * Original: 0x002CEF18 - 0x002CEF20 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF18(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF18: ;
    ecx = ebp + -32;
    g_seh_ebp = ebp; sub_002B44E0(); return; /* tail jmp 0x002B44E0 */

}

/**
 * sub_002CEF20
 * Original: 0x002CEF20 - 0x002CEF28 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF20: ;
    ecx = ebp + -52;
    g_seh_ebp = ebp; sub_002B44E0(); return; /* tail jmp 0x002B44E0 */

}

/**
 * sub_002CEF28
 * Original: 0x002CEF28 - 0x002CEF30 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF28(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF28: ;
    ecx = ebp + -72;
    g_seh_ebp = ebp; sub_002B44E0(); return; /* tail jmp 0x002B44E0 */

}

/**
 * sub_002CEF30
 * Original: 0x002CEF30 - 0x002CEF38 (8 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF30: ;
    ecx = ebp + -112;
    g_seh_ebp = ebp; sub_002B44E0(); return; /* tail jmp 0x002B44E0 */

}

/**
 * sub_002CEF38
 * Original: 0x002CEF38 - 0x002CEF42 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF38(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF38: ;
    eax = 0x355470;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEF50
 * Original: 0x002CEF50 - 0x002CEF5B (11 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF50: ;
    eax = MEM32(ebp + -16);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CEF59u); RECOMP_ABI_CALL(0x002BDA60u, sub_002BDA60); /* call 0x002BDA60 */

loc_002CEF59: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CEF5B
 * Original: 0x002CEF5B - 0x002CEF65 (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF5B(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CEF5B: ;
    eax = 0x355494;
    g_seh_ebp = ebp; sub_002BFE18(); return; /* tail jmp 0x002BFE18 */

}

/**
 * sub_002CEF70
 * Original: 0x002CEF70 - 0x002CEF86 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEF70(void)
{

loc_002CEF70: ;
    ecx = 0x3864D8;
    PUSH32(esp, 0x002CEF7Au); RECOMP_ABI_CALL(0x0007B390u, sub_0007B390); /* call 0x0007B390 */

loc_002CEF7A: ;
    PUSH32(esp, 0x2D5FA0);
    PUSH32(esp, 0x002CEF84u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CEF84: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CEF90
 * Original: 0x002CEF90 - 0x002CEFB1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CEF90(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CEF90: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3887C8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CEFC0
 * Original: 0x002CEFC0 - 0x002CEFD6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEFC0(void)
{

loc_002CEFC0: ;
    ecx = 0x3887D0;
    PUSH32(esp, 0x002CEFCAu); RECOMP_ABI_CALL(0x0015C580u, sub_0015C580); /* call 0x0015C580 */

loc_002CEFCA: ;
    PUSH32(esp, 0x2D5F60);
    PUSH32(esp, 0x002CEFD4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CEFD4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CEFE0
 * Original: 0x002CEFE0 - 0x002CEFF6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CEFE0(void)
{

loc_002CEFE0: ;
    ecx = 0x3888C0;
    PUSH32(esp, 0x002CEFEAu); RECOMP_ABI_CALL(0x0007B5B0u, sub_0007B5B0); /* call 0x0007B5B0 */

loc_002CEFEA: ;
    PUSH32(esp, 0x2D5F90);
    PUSH32(esp, 0x002CEFF4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CEFF4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF000
 * Original: 0x002CF000 - 0x002CF016 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF000(void)
{

loc_002CF000: ;
    ecx = 0x389F60;
    PUSH32(esp, 0x002CF00Au); RECOMP_ABI_CALL(0x001373B0u, sub_001373B0); /* call 0x001373B0 */

loc_002CF00A: ;
    PUSH32(esp, 0x2D5F70);
    PUSH32(esp, 0x002CF014u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF014: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF020
 * Original: 0x002CF020 - 0x002CF03F (31 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF020(void)
{

loc_002CF020: ;
    PUSH32(esp, 1);
    PUSH32(esp, 2);
    PUSH32(esp, 0x280);
    ecx = 0x389FD0;
    PUSH32(esp, 0x002CF033u); RECOMP_ABI_CALL(0x00014020u, sub_00014020); /* call 0x00014020 */

loc_002CF033: ;
    PUSH32(esp, 0x2D5F80);
    PUSH32(esp, 0x002CF03Du); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF03D: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF040
 * Original: 0x002CF040 - 0x002CF061 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF040(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF040: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x38DCC4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF070
 * Original: 0x002CF070 - 0x002CF07C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF070(void)
{

loc_002CF070: ;
    PUSH32(esp, 0x2D5FF0);
    PUSH32(esp, 0x002CF07Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF07A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF080
 * Original: 0x002CF080 - 0x002CF0BC (60 bytes, 25 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF080(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CF080: ;
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x38DD4D;
    ebp = 0x5FF;
    ebx = 0; /* xor self */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */

loc_002CF090: ;
    edi = esi + -45;
    ecx = edi;
    PUSH32(esp, 0x002CF09Au); RECOMP_ABI_CALL(0x000172F0u, sub_000172F0); /* call 0x000172F0 */

loc_002CF09A: ;
    MEM32(esi + -37) = ebx;
    MEM8(esi) = LO8(ebx);
    MEM8(esi + -1) = LO8(ebx);
    _fb = (uint32_t)(0x30) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 0x30;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ebp--;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(edi) = ebx;
    if ((_fa != 0)) goto loc_002CF090; /* jne: not equal / not zero */

loc_002CF0AA: ;
    PUSH32(esp, 0x2D6000);
    PUSH32(esp, 0x002CF0B4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF0B4: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF0C0
 * Original: 0x002CF0C0 - 0x002CF0E1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF0C0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF0C0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A00F8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF0F0
 * Original: 0x002CF0F0 - 0x002CF107 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF0F0(void)
{

loc_002CF0F0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x1CD80);
    PUSH32(esp, 0xAF9854F);
    ecx = 0x3A00FC;
    PUSH32(esp, 0x002CF106u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002CF106: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF110
 * Original: 0x002CF110 - 0x002CF131 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF110(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF110: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A010C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF140
 * Original: 0x002CF140 - 0x002CF161 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF140(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF140: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A0110) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF170
 * Original: 0x002CF170 - 0x002CF187 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF170(void)
{

loc_002CF170: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x1D3E0);
    PUSH32(esp, 0x1C4F382F);
    ecx = 0x3A0114;
    PUSH32(esp, 0x002CF186u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002CF186: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF190
 * Original: 0x002CF190 - 0x002CF1B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF190(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF190: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A0128) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF1C0
 * Original: 0x002CF1C0 - 0x002CF1D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF1C0(void)
{

loc_002CF1C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x1E300);
    PUSH32(esp, 0x507D0D05);
    ecx = 0x3A012C;
    PUSH32(esp, 0x002CF1D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002CF1D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF1E0
 * Original: 0x002CF1E0 - 0x002CF201 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF1E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF1E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A013C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF210
 * Original: 0x002CF210 - 0x002CF231 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF210(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF210: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A0144) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF240
 * Original: 0x002CF240 - 0x002CF261 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF240(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF240: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A0148) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF270
 * Original: 0x002CF270 - 0x002CF284 (20 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF270(void)
{

loc_002CF270: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0);
    PUSH32(esp, 0xE11D0E3);
    ecx = 0x3A014C;
    PUSH32(esp, 0x002CF283u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002CF283: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF290
 * Original: 0x002CF290 - 0x002CF2B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF290(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF290: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A015C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF2C0
 * Original: 0x002CF2C0 - 0x002CF2E1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF2C0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF2C0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A0180) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF2F0
 * Original: 0x002CF2F0 - 0x002CF306 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF2F0(void)
{

loc_002CF2F0: ;
    ecx = 0x3A0190;
    PUSH32(esp, 0x002CF2FAu); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002CF2FA: ;
    PUSH32(esp, 0x2D6060);
    PUSH32(esp, 0x002CF304u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF304: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF310
 * Original: 0x002CF310 - 0x002CF325 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF310(void)
{

loc_002CF310: ;
    PUSH32(esp, 0x256A0);
    PUSH32(esp, 0x300640);
    ecx = 0x3A01C0;
    PUSH32(esp, 0x002CF324u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002CF324: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF330
 * Original: 0x002CF330 - 0x002CF351 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF330(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF330: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A01D0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF360
 * Original: 0x002CF360 - 0x002CF381 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF360(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF360: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A01D4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF390
 * Original: 0x002CF390 - 0x002CF3B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF390(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF390: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A020C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF3C0
 * Original: 0x002CF3C0 - 0x002CF3E1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF3C0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF3C0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A022C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF3F0
 * Original: 0x002CF3F0 - 0x002CF3FC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF3F0(void)
{

loc_002CF3F0: ;
    PUSH32(esp, 0x2D60B0);
    PUSH32(esp, 0x002CF3FAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF3FA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF400
 * Original: 0x002CF400 - 0x002CF421 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF400(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF400: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A024C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF430
 * Original: 0x002CF430 - 0x002CF451 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF430(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF430: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A0258) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF460
 * Original: 0x002CF460 - 0x002CF477 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF460(void)
{

loc_002CF460: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x328C0);
    PUSH32(esp, 0xB6862049u);
    ecx = 0x3A0260;
    PUSH32(esp, 0x002CF476u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002CF476: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF480
 * Original: 0x002CF480 - 0x002CF497 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF480(void)
{

loc_002CF480: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x32BC0);
    PUSH32(esp, 0xD3204AAFu);
    ecx = 0x3A0270;
    PUSH32(esp, 0x002CF496u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002CF496: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF4A0
 * Original: 0x002CF4A0 - 0x002CF4C1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF4A0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF4A0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A02A0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF4D0
 * Original: 0x002CF4D0 - 0x002CF4DC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF4D0(void)
{

loc_002CF4D0: ;
    PUSH32(esp, 0x2D60D0);
    PUSH32(esp, 0x002CF4DAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF4DA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF4E0
 * Original: 0x002CF4E0 - 0x002CF51C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF4E0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF4E0: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CF4E7u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF4E7: ;
    MEM32(0x3A02E0) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A02E4) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A02E0);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A02E0);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A02E0);
    PUSH32(esp, 0x2D60E0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF518u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF518: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF520
 * Original: 0x002CF520 - 0x002CF55C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF520(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF520: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CF527u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF527: ;
    MEM32(0x3A0304) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A0308) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A0304);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A0304);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A0304);
    PUSH32(esp, 0x2D6160);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF558u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF558: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF560
 * Original: 0x002CF560 - 0x002CF59C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF560(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF560: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CF567u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF567: ;
    MEM32(0x3A0310) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A0314) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A0310);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A0310);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A0310);
    PUSH32(esp, 0x2D61C0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF598u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF598: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF5A0
 * Original: 0x002CF5A0 - 0x002CF5AC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF5A0(void)
{

loc_002CF5A0: ;
    PUSH32(esp, 0x2D6140);
    PUSH32(esp, 0x002CF5AAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF5AA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF5B0
 * Original: 0x002CF5B0 - 0x002CF5D1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF5B0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF5B0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A04D0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF5E0
 * Original: 0x002CF5E0 - 0x002CF5EC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF5E0(void)
{

loc_002CF5E0: ;
    PUSH32(esp, 0x2D6220);
    PUSH32(esp, 0x002CF5EAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF5EA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF5F0
 * Original: 0x002CF5F0 - 0x002CF5FC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF5F0(void)
{

loc_002CF5F0: ;
    PUSH32(esp, 0x2D6230);
    PUSH32(esp, 0x002CF5FAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF5FA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF600
 * Original: 0x002CF600 - 0x002CF60C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF600(void)
{

loc_002CF600: ;
    PUSH32(esp, 0x2D6240);
    PUSH32(esp, 0x002CF60Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF60A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF610
 * Original: 0x002CF610 - 0x002CF631 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF610(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF610: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A6568) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF640
 * Original: 0x002CF640 - 0x002CF64C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF640(void)
{

loc_002CF640: ;
    PUSH32(esp, 0x2D6260);
    PUSH32(esp, 0x002CF64Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF64A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF650
 * Original: 0x002CF650 - 0x002CF68C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF650(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF650: ;
    PUSH32(esp, 0x14);
    PUSH32(esp, 0x002CF657u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF657: ;
    MEM32(0x3A657C) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A6580) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A657C);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A657C);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A657C);
    PUSH32(esp, 0x2D62E0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF688u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF688: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF690
 * Original: 0x002CF690 - 0x002CF6CC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF690(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF690: ;
    PUSH32(esp, 0x14);
    PUSH32(esp, 0x002CF697u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF697: ;
    MEM32(0x3A6588) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A658C) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A6588);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A6588);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A6588);
    PUSH32(esp, 0x2D6280);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF6C8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF6C8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF6D0
 * Original: 0x002CF6D0 - 0x002CF6DC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF6D0(void)
{

loc_002CF6D0: ;
    PUSH32(esp, 0x2D6350);
    PUSH32(esp, 0x002CF6DAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF6DA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF6E0
 * Original: 0x002CF6E0 - 0x002CF704 (36 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF6E0(void)
{

loc_002CF6E0: ;
    PUSH32(esp, 0x28);
    PUSH32(esp, 6);
    ecx = 0x3A65A8;
    PUSH32(esp, 0x002CF6EEu); RECOMP_ABI_CALL(0x001567B0u, sub_001567B0); /* call 0x001567B0 */

loc_002CF6EE: ;
    PUSH32(esp, 0x2D6340);
    MEM32(0x3A65A8) = 0x3082A4;
    PUSH32(esp, 0x002CF702u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF702: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF710
 * Original: 0x002CF710 - 0x002CF725 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF710(void)
{

loc_002CF710: ;
    PUSH32(esp, 0x3D460);
    PUSH32(esp, 0x30294C);
    ecx = 0x3A65C4;
    PUSH32(esp, 0x002CF724u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002CF724: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF730
 * Original: 0x002CF730 - 0x002CF751 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002CF730(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002CF730: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3A65D4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002CF760
 * Original: 0x002CF760 - 0x002CF775 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF760(void)
{

loc_002CF760: ;
    PUSH32(esp, 0x3E100);
    PUSH32(esp, 0x30365C);
    ecx = 0x3A65D8;
    PUSH32(esp, 0x002CF774u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002CF774: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002CF780
 * Original: 0x002CF780 - 0x002CF7A0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF780(void)
{

loc_002CF780: ;
    PUSH32(esp, 0x4970);
    PUSH32(esp, 0x3037FC);
    ecx = 0x3A6670;
    PUSH32(esp, 0x002CF794u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF794: ;
    PUSH32(esp, 0x2D6370);
    PUSH32(esp, 0x002CF79Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF79E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF7A0
 * Original: 0x002CF7A0 - 0x002CF7C0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF7A0(void)
{

loc_002CF7A0: ;
    PUSH32(esp, 0xBC0);
    PUSH32(esp, 0x3038B8);
    ecx = 0x3A6694;
    PUSH32(esp, 0x002CF7B4u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF7B4: ;
    PUSH32(esp, 0x2D6380);
    PUSH32(esp, 0x002CF7BEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF7BE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF7C0
 * Original: 0x002CF7C0 - 0x002CF7E0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF7C0(void)
{

loc_002CF7C0: ;
    PUSH32(esp, 0xC80);
    PUSH32(esp, 0x3039F0);
    ecx = 0x3A66B8;
    PUSH32(esp, 0x002CF7D4u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF7D4: ;
    PUSH32(esp, 0x2D6390);
    PUSH32(esp, 0x002CF7DEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF7DE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF7E0
 * Original: 0x002CF7E0 - 0x002CF800 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF7E0(void)
{

loc_002CF7E0: ;
    PUSH32(esp, 0x4FB0);
    PUSH32(esp, 0x303A48);
    ecx = 0x3A66DC;
    PUSH32(esp, 0x002CF7F4u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF7F4: ;
    PUSH32(esp, 0x2D63A0);
    PUSH32(esp, 0x002CF7FEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF7FE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF800
 * Original: 0x002CF800 - 0x002CF849 (73 bytes, 19 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF800(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF800: ;
    _fb = (uint32_t)(0x24) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x24;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 0x14) = eax;
    MEM32(esp + 0x18) = eax;
    MEM32(esp + 0x1C) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372E70);
    ecx = esp + 4;
    MEM32(esp + 0x24) = eax;
    MEM32(esp + 4) = 0x303AE8;
    { uint32_t _icall_target = MEM32(0x303AF0); PUSH32(esp, 0x002CF83Fu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CF839u); } /* indirect call */
    }

loc_002CF83F: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CF845u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CF845: ;
    _fb = (uint32_t)(0x2C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x2C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF850
 * Original: 0x002CF850 - 0x002CF870 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF850(void)
{

loc_002CF850: ;
    PUSH32(esp, 0xABE0);
    PUSH32(esp, 0x303B30);
    ecx = 0x3A6700;
    PUSH32(esp, 0x002CF864u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF864: ;
    PUSH32(esp, 0x2D63B0);
    PUSH32(esp, 0x002CF86Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF86E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF870
 * Original: 0x002CF870 - 0x002CF890 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF870(void)
{

loc_002CF870: ;
    PUSH32(esp, 0x168);
    PUSH32(esp, 0x303BA8);
    ecx = 0x3A6738;
    PUSH32(esp, 0x002CF884u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF884: ;
    PUSH32(esp, 0x2D63C0);
    PUSH32(esp, 0x002CF88Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF88E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF890
 * Original: 0x002CF890 - 0x002CF8D0 (64 bytes, 20 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF890(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF890: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CF897u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF897: ;
    MEM32(0x3A675C) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A6760) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A675C);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A675C);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A675C);
    PUSH32(esp, 0x2D63D0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF8C8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF8C8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF8D0
 * Original: 0x002CF8D0 - 0x002CF8F0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF8D0(void)
{

loc_002CF8D0: ;
    PUSH32(esp, 0x5200);
    PUSH32(esp, 0x303E00);
    ecx = 0x3A75BC;
    PUSH32(esp, 0x002CF8E4u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF8E4: ;
    PUSH32(esp, 0x2D6430);
    PUSH32(esp, 0x002CF8EEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF8EE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF8F0
 * Original: 0x002CF8F0 - 0x002CF930 (64 bytes, 20 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF8F0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CF8F0: ;
    PUSH32(esp, 0x20);
    PUSH32(esp, 0x002CF8F7u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CF8F7: ;
    MEM32(0x3A75E8) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A75EC) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A75E8);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A75E8);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A75E8);
    PUSH32(esp, 0x2D6440);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CF928u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF928: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CF930
 * Original: 0x002CF930 - 0x002CF946 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF930(void)
{

loc_002CF930: ;
    ecx = 0x3A75FC;
    PUSH32(esp, 0x002CF93Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002CF93A: ;
    PUSH32(esp, 0x2D64A0);
    PUSH32(esp, 0x002CF944u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF944: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF950
 * Original: 0x002CF950 - 0x002CF966 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF950(void)
{

loc_002CF950: ;
    ecx = 0x3A7628;
    PUSH32(esp, 0x002CF95Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002CF95A: ;
    PUSH32(esp, 0x2D64B0);
    PUSH32(esp, 0x002CF964u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF964: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF970
 * Original: 0x002CF970 - 0x002CF986 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF970(void)
{

loc_002CF970: ;
    ecx = 0x3A7654;
    PUSH32(esp, 0x002CF97Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002CF97A: ;
    PUSH32(esp, 0x2D64C0);
    PUSH32(esp, 0x002CF984u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF984: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF990
 * Original: 0x002CF990 - 0x002CF9A6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF990(void)
{

loc_002CF990: ;
    ecx = 0x3A7680;
    PUSH32(esp, 0x002CF99Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002CF99A: ;
    PUSH32(esp, 0x2D64D0);
    PUSH32(esp, 0x002CF9A4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF9A4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF9B0
 * Original: 0x002CF9B0 - 0x002CF9C6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF9B0(void)
{

loc_002CF9B0: ;
    ecx = 0x3A76AC;
    PUSH32(esp, 0x002CF9BAu); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002CF9BA: ;
    PUSH32(esp, 0x2D64E0);
    PUSH32(esp, 0x002CF9C4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF9C4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF9D0
 * Original: 0x002CF9D0 - 0x002CF9F0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF9D0(void)
{

loc_002CF9D0: ;
    PUSH32(esp, 0x708);
    PUSH32(esp, 0x305508);
    ecx = 0x3A7828;
    PUSH32(esp, 0x002CF9E4u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CF9E4: ;
    PUSH32(esp, 0x2D6520);
    PUSH32(esp, 0x002CF9EEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CF9EE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CF9F0
 * Original: 0x002CF9F0 - 0x002CFA20 (48 bytes, 24 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CF9F0(void)
{

loc_002CF9F0: ;
    eax = MEM32(0x372FB8);
    PUSH32(esp, eax);
    PUSH32(esp, 0x305514);
    ecx = 0x3A784C;
    PUSH32(esp, 0x002CFA05u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CFA05: ;
    PUSH32(esp, 0x2D6530);
    PUSH32(esp, 0x002CFA0Fu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFA0F: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CFA20
 * Original: 0x002CFA20 - 0x002CFA40 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFA20(void)
{

loc_002CFA20: ;
    PUSH32(esp, 0x9D80);
    PUSH32(esp, 0x3055CC);
    ecx = 0x3A7878;
    PUSH32(esp, 0x002CFA34u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CFA34: ;
    PUSH32(esp, 0x2D6540);
    PUSH32(esp, 0x002CFA3Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFA3E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CFA40
 * Original: 0x002CFA40 - 0x002CFA60 (32 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFA40(void)
{

loc_002CFA40: ;
    xmm0 = XMM_SCALAR(MEMF(0x372FC0)); /* movss */
    MEMF(0x3A789C) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFA60
 * Original: 0x002CFA60 - 0x002CFAA5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFA60(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFA60: ;
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x20;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 0x14) = eax;
    MEM32(esp + 0x18) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FC4);
    ecx = esp + 4;
    MEM32(esp + 0x20) = eax;
    MEM32(esp + 4) = 0x3055E8;
    { uint32_t _icall_target = MEM32(0x3055F0); PUSH32(esp, 0x002CFA9Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFA95u); } /* indirect call */
    }

loc_002CFA9B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFAA1u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFAA1: ;
    _fb = (uint32_t)(0x28) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x28;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFAB0
 * Original: 0x002CFAB0 - 0x002CFADD (45 bytes, 12 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFAB0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFAB0: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FC8);
    ecx = esp + 4;
    MEM32(esp + 8) = eax;
    MEM32(esp + 4) = 0x305620;
    { uint32_t _icall_target = MEM32(0x305628); PUSH32(esp, 0x002CFAD3u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFACDu); } /* indirect call */
    }

loc_002CFAD3: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFAD9u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFAD9: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFAE0
 * Original: 0x002CFAE0 - 0x002CFB11 (49 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFAE0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFAE0: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FCC);
    ecx = esp + 4;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 4) = 0x305658;
    { uint32_t _icall_target = MEM32(0x305660); PUSH32(esp, 0x002CFB07u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFB01u); } /* indirect call */
    }

loc_002CFB07: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFB0Du); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFB0D: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFB20
 * Original: 0x002CFB20 - 0x002CFB5C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFB20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFB20: ;
    PUSH32(esp, 0x14);
    PUSH32(esp, 0x002CFB27u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CFB27: ;
    MEM32(0x3A78C4) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A78C8) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A78C4);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A78C4);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A78C4);
    PUSH32(esp, 0x2D6590);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CFB58u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFB58: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFB60
 * Original: 0x002CFB60 - 0x002CFB80 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFB60(void)
{

loc_002CFB60: ;
    PUSH32(esp, 0xB00);
    PUSH32(esp, 0x30569C);
    ecx = 0x3A78D0;
    PUSH32(esp, 0x002CFB74u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CFB74: ;
    PUSH32(esp, 0x2D65F0);
    PUSH32(esp, 0x002CFB7Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFB7E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CFB80
 * Original: 0x002CFB80 - 0x002CFBB0 (48 bytes, 23 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFB80(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFB80: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, ecx);
    PUSH32(esp, 0x372FD8);
    ecx = esp + 4;
    MEM32(esp + 4) = 0x305734;
    { uint32_t _icall_target = MEM32(0x30573C); PUSH32(esp, 0x002CFB98u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFB92u); } /* indirect call */
    }

loc_002CFB98: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFB9Eu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFB9E: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFBB0
 * Original: 0x002CFBB0 - 0x002CFBE5 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFBB0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFBB0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FDC);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x305774;
    { uint32_t _icall_target = MEM32(0x30577C); PUSH32(esp, 0x002CFBDBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFBD5u); } /* indirect call */
    }

loc_002CFBDB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFBE1u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFBE1: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFBF0
 * Original: 0x002CFBF0 - 0x002CFC12 (34 bytes, 9 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFBF0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFBF0: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, ecx);
    PUSH32(esp, 0x372FE0);
    ecx = esp + 4;
    MEM32(esp + 4) = 0x3057B4;
    { uint32_t _icall_target = MEM32(0x3057BC); PUSH32(esp, 0x002CFC08u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFC02u); } /* indirect call */
    }

loc_002CFC08: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFC0Eu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFC0E: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFC20
 * Original: 0x002CFC20 - 0x002CFC42 (34 bytes, 9 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFC20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFC20: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, ecx);
    PUSH32(esp, 0x372FE4);
    ecx = esp + 4;
    MEM32(esp + 4) = 0x3057F0;
    { uint32_t _icall_target = MEM32(0x3057F8); PUSH32(esp, 0x002CFC38u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFC32u); } /* indirect call */
    }

loc_002CFC38: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFC3Eu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFC3E: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFC50
 * Original: 0x002CFC50 - 0x002CFC91 (65 bytes, 17 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFC50(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFC50: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 0x10) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FE8);
    ecx = esp + 4;
    MEM32(esp + 0x18) = eax;
    MEM32(esp + 4) = 0x305A28;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_target = MEM32(0x305A30); PUSH32(esp, 0x002CFC87u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFC81u); } /* indirect call */
    }

loc_002CFC87: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFC8Du); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFC8D: ;
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x20;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFCA0
 * Original: 0x002CFCA0 - 0x002CFCDE (62 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFCA0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFCA0: ;
    _fb = (uint32_t)(0x3C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x3C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, edi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ecx = 0xF;
    edi = esp + 4;
    { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4); for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = eax; edi += ecx * _st; }
    ecx = 0; /* rep stosd */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FEC);
    ecx = esp + 8;
    MEM32(esp + 8) = 0x305828;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 0x20) = eax;
    { uint32_t _icall_target = MEM32(0x305830); PUSH32(esp, 0x002CFCD0u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFCCAu); } /* indirect call */
    }

loc_002CFCD0: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFCD6u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFCD6: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    _fb = (uint32_t)(0x3C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x3C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFCE0
 * Original: 0x002CFCE0 - 0x002CFCEA (10 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFCE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CFCE0: ;
    ecx = 0x3A78F4;
    g_seh_ebp = ebp; sub_00065000(); return; /* tail jmp 0x00065000 */

}

/**
 * sub_002CFCF0
 * Original: 0x002CFCF0 - 0x002CFD32 (66 bytes, 19 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFCF0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFCF0: ;
    _fb = (uint32_t)(0x4C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x4C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, edi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ecx = 0x13;
    edi = esp + 4;
    { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4); for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = eax; edi += ecx * _st; }
    ecx = 0; /* rep stosd */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FF0);
    ecx = esp + 8;
    MEM32(esp + 8) = 0x3058A8;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 0x20) = eax;
    MEM32(esp + 0x34) = eax;
    { uint32_t _icall_target = MEM32(0x3058B0); PUSH32(esp, 0x002CFD24u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFD1Eu); } /* indirect call */
    }

loc_002CFD24: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFD2Au); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFD2A: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    _fb = (uint32_t)(0x4C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x4C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFD40
 * Original: 0x002CFD40 - 0x002CFD4A (10 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFD40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002CFD40: ;
    ecx = 0x3A78F8;
    g_seh_ebp = ebp; sub_000650A0(); return; /* tail jmp 0x000650A0 */

}

/**
 * sub_002CFD50
 * Original: 0x002CFD50 - 0x002CFD7D (45 bytes, 12 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFD50(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFD50: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FF4);
    ecx = esp + 4;
    MEM32(esp + 8) = eax;
    MEM32(esp + 4) = 0x305934;
    { uint32_t _icall_target = MEM32(0x30593C); PUSH32(esp, 0x002CFD73u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFD6Du); } /* indirect call */
    }

loc_002CFD73: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFD79u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFD79: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFD80
 * Original: 0x002CFD80 - 0x002CFDB1 (49 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFD80(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFD80: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FF8);
    ecx = esp + 4;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 4) = 0x305974;
    { uint32_t _icall_target = MEM32(0x30597C); PUSH32(esp, 0x002CFDA7u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFDA1u); } /* indirect call */
    }

loc_002CFDA7: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFDADu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFDAD: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFDC0
 * Original: 0x002CFDC0 - 0x002CFDF5 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFDC0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFDC0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x372FFC);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x3059B8;
    { uint32_t _icall_target = MEM32(0x3059C0); PUSH32(esp, 0x002CFDEBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFDE5u); } /* indirect call */
    }

loc_002CFDEB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFDF1u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFDF1: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFE00
 * Original: 0x002CFE00 - 0x002CFE3C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFE00(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFE00: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CFE07u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CFE07: ;
    MEM32(0x3A9C34) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A9C38) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A9C34);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A9C34);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A9C34);
    PUSH32(esp, 0x2D6610);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CFE38u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFE38: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFE40
 * Original: 0x002CFE40 - 0x002CFE7C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFE40(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFE40: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CFE47u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CFE47: ;
    MEM32(0x3A9C40) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A9C44) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A9C40);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A9C40);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A9C40);
    PUSH32(esp, 0x2D66D0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CFE78u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFE78: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFE80
 * Original: 0x002CFE80 - 0x002CFEBC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFE80(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFE80: ;
    PUSH32(esp, 0x20);
    PUSH32(esp, 0x002CFE87u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CFE87: ;
    MEM32(0x3A9C4C) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A9C50) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A9C4C);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A9C4C);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A9C4C);
    PUSH32(esp, 0x2D6730);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CFEB8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFEB8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFE9B
 * Original: 0x002CFE9B - 0x002CFEBC (33 bytes, 9 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFE9B(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFE9B: ;
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A9C4C);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A9C4C);
    PUSH32(esp, 0x2D6730);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CFEB8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFEB8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFEC0
 * Original: 0x002CFEC0 - 0x002CFEFC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFEC0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFEC0: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002CFEC7u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002CFEC7: ;
    MEM32(0x3A9C58) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3A9C5C) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3A9C58);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3A9C58);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3A9C58);
    PUSH32(esp, 0x2D6670);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002CFEF8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFEF8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFF00
 * Original: 0x002CFF00 - 0x002CFF20 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFF00(void)
{

loc_002CFF00: ;
    PUSH32(esp, 0x2D0);
    PUSH32(esp, 0x305CB0);
    ecx = 0x3BC890;
    PUSH32(esp, 0x002CFF14u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CFF14: ;
    PUSH32(esp, 0x2D6790);
    PUSH32(esp, 0x002CFF1Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFF1E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}
