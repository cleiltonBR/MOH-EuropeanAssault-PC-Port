/**
 * Xbox Static Recompilation - Runtime Type Definitions
 *
 * Type definitions and helper macros used by mechanically translated
 * x86 -> C code. Each original x86 function is translated to a C
 * function that uses these types and macros.
 *
 * This is a reusable template for ANY Xbox game. Game-specific
 * customization should go in separate headers.
 *
 * Memory model:
 *   Xbox data sections are mapped to their original VAs via
 *   CreateFileMapping + MapViewOfFileEx (see xbox_memory.h).
 *   Recompiled code accesses globals via pointer casts, e.g.:
 *     *(uint32_t*)0x003B2360
 *
 * Register model:
 *   Volatile registers (eax, ecx, edx, esp) are global variables,
 *   matching real x86 behavior where these registers are shared
 *   across all code. This enables correct argument passing via the
 *   simulated stack and return value communication via eax.
 *
 *   Callee-saved registers (ebx, esi, edi) are also global because
 *   callers pass implicit parameters through them (e.g. 'this' via
 *   esi in thiscall). The callee-save contract is enforced by
 *   PUSH32/POP32 instructions in the generated code, not by C local
 *   variable scoping.
 *
 *   ebp is NOT global - it stays local in each function because many
 *   FPO (Frame Pointer Omission) functions use it as scratch without
 *   save/restore. For SEH functions, g_seh_ebp bridges the gap.
 *
 * Calling convention:
 *   All translated functions are void(void). Arguments are passed
 *   on the simulated Xbox stack (via push instructions before call).
 *   Return values are communicated through g_eax.
 *   The call instruction pushes the real guest return address (the VA of
 *   the instruction after the call); ret discards it with esp += 4.
 *   The value is never used to transfer control -- control flow is C
 *   call/return -- but it must be correct because guest code reads it
 *   (__SEH_prolog's scope table, _alloca probes, "mov eax, [esp]").
 */

#ifndef RECOMP_TYPES_H
#define RECOMP_TYPES_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>
/* math.h is load-bearing, and its absence was invisible.
 *
 * The lifter emits sqrt() and fabs() for fsqrt/fabs -- 146 of them in one of
 * Halo's nine chunks alone -- and now sin/cos/tan/atan2/log2/exp2/fmod for the
 * x87 transcendentals. With no declaration in scope, C89 implicit declaration
 * makes every one of them return `int`: the caller reads EAX instead of XMM0 and
 * gets garbage, then converts that garbage to double. Vector normalisation is
 * 1/sqrt(x), so this corrupts every matrix the title builds.
 *
 * Nothing reported it because generated code is compiled with /w (see the game
 * CMakeLists) -- MSVC's C4013 was emitted and discarded. Same failure as the
 * missing stdlib.h in kernel_bridge.c, in a hotter path. */
#include <math.h>
#if defined(_M_IX86) || defined(_M_X64) || defined(__i386__) || defined(__x86_64__)
#include <xmmintrin.h>
#include <emmintrin.h>
#endif

/* MSVC's __forceinline -> gcc/clang equivalent on POSIX. */
#if !defined(_MSC_VER) && !defined(__forceinline)
#define __forceinline inline __attribute__((always_inline))
#endif

/* Guest debug output: INT 2D, the Xbox kernel debug trap.
 *
 * eax selects the service, ecx carries its argument. Service 1 prints the
 * ANSI_STRING ecx points at -- what OutputDebugStringA compiles to. The int3
 * that always follows is the slide byte the kernel steps over, so the lifter
 * emits nothing for it; lifting it to __debugbreak() terminated the process
 * with STATUS_BREAKPOINT the first time a title tried to print. */
void recomp_debug_service(uint32_t service, uint32_t arg_va);

/* MSVC's __debugbreak() intrinsic -> gcc/clang equivalent.
 * The auto-generated code emits __debugbreak for x86 INT 3 instructions.
 * !defined(__debugbreak) is not enough on its own: MinGW declares __debugbreak
 * as a function, not a macro, so that test passes and the macro is defined
 * anyway. Any windows.h reaching this TU afterwards then fails to declare it.
 * Excluding _WIN32 outright leaves the SDK's own int3 intrinsic in place. */
#if !defined(_MSC_VER) && !defined(_WIN32) && !defined(__debugbreak)
#define __debugbreak() __builtin_trap()
#endif

/* ================================================================
 * Memory offset
 * ================================================================ */

/**
 * Memory offset from Xbox VA to actual mapped address.
 * When Xbox memory is mapped at the original address (0x00010000),
 * this is 0 and the MEM macros are simple identity casts.
 * When mapped elsewhere, this adjusts all memory accesses.
 *
 * Set once during memory initialization, then read-only.
 */
extern ptrdiff_t g_xbox_mem_offset;

/* Bounds of the title's executable sections, filled in by
 * xbox_MemoryLayoutInit from the XBE's own section table. Zero means "not
 * loaded yet", which RECOMP_ICALL_IS_CODE treats as allow.
 *
 * These replace a hardcoded 0x00400000 cutoff that was only ever right for one
 * title -- see the comment where they are defined in xbox_memory_layout.c. */
/* --force-return: read once at startup, so the check at each forced ret is a
 * load rather than a getenv. Zero unless RECOMP_FORCE_RETURN is set, which is
 * what lets a build carrying forced functions behave normally by default. */
extern int g_force_return;

extern uint32_t g_xbox_code_lo;
extern uint32_t g_xbox_code_hi;

/* Is this indirect-call target plausibly code?
 *
 * Synthetic kernel thunks live at 0xFE0000xx and are dispatched by
 * recomp_lookup_kernel, so they are always allowed. Everything else has to lie
 * inside an executable section of the loaded title. A target that fails this is
 * a garbage pointer that reached a call site, and calling it would be worse
 * than dropping it. */
#define RECOMP_ICALL_IS_CODE(_va) \
    ((_va) >= 0xFE000000u || g_xbox_code_hi == 0u || \
     ((_va) >= g_xbox_code_lo && (_va) < g_xbox_code_hi))

/* ================================================================
 * Global registers
 * ================================================================ */

/**
 * Volatile x86 registers (caller-saved):
 *   eax - return values, general accumulator
 *   ecx - 'this' pointer for thiscall, loop counter
 *   edx - high dword of multiply/divide, general
 *   esp - stack pointer (initialized to top of Xbox stack)
 *
 * Callee-saved x86 registers (also global):
 *   ebx, esi, edi - global because callers pass implicit parameters
 *   through them. The callee-save contract is enforced by generated
 *   PUSH32/POP32 instructions.
 *
 * NOT global: ebp - stays local in each function because FPO
 * functions use it as scratch. For SEH, g_seh_ebp bridges the gap.
 */
/* Per-thread register state.
 *
 * These started as plain globals, which works exactly as long as one thread
 * runs recompiled code. Halo is the first title to create real workers (its
 * cache/file loader), and the runtime papered over that by running every worker
 * synchronously inside PsCreateSystemThreadEx -- so a worker that blocks
 * waiting for work never returns and startup deadlocks.
 *
 * On hardware each thread has its own register set, so model it that way.
 * Thread-local costs an indirection per access; a deadlock costs the title. */
#if defined(_MSC_VER)
#  define RECOMP_TLS __declspec(thread)
#elif defined(__GNUC__) || defined(__clang__)
#  define RECOMP_TLS __thread
#else
#  define RECOMP_TLS _Thread_local
#endif

extern RECOMP_TLS uint32_t g_eax, g_ecx, g_edx, g_esp;
extern RECOMP_TLS uint32_t g_ebx, g_esi, g_edi;

/* x87 stack. Per-thread for the same reason the integer registers are:
 * arguments are passed in st(0)/st(1) across call boundaries. */
extern RECOMP_TLS double g_fp_stack[8];
extern RECOMP_TLS int g_fp_top;

/**
 * SEH frame pointer bridge.
 *
 * __SEH_prolog sets up ebp for the caller, but since ebp is a local
 * variable in each function, the caller can't see the prolog's change.
 * The prolog writes g_seh_ebp, and the caller reads it after the call.
 * Similarly, __SEH_epilog reads g_seh_ebp at entry and writes it at exit.
 */
/* Linear base of the fs segment: where the fake TIB lives. Generated code
 * adds this to every fs-relative address, so page zero stays unmapped and a
 * null dereference faults instead of hitting the TIB. Must match
 * XBOX_FS_BASE in src/kernel/xbox_memory_layout.h.
 *
 * Per-thread, because a TIB is. fs:[0] is the SEH chain head and fs:[4]
 * reaches the CRT's per-thread data, so a single shared base makes every
 * guest thread the same thread as far as the CRT is concerned. */
extern RECOMP_TLS uint32_t g_fs_base;
#define XBOX_FS_BASE g_fs_base

extern RECOMP_TLS uint32_t g_seh_ebp;

/* ---- non-local jumps (setjmp / longjmp) --------------------------------
 *
 * A recompiled function is a real C function, so restoring the guest esp is
 * only half of a longjmp: the abandoned frames are still on the native stack,
 * and control returns into them once the resume point finishes. Pairing each
 * guest jmp_buf with a native one -- taken at the setjmp call site, the only
 * place a native setjmp is valid -- makes the guest jump a native jump, so the
 * frames actually unwind.
 *
 * recomp_setjmp_slot() returns the native buffer for a guest jmp_buf address,
 * allocating one on first use. recomp_guest_longjmp() restores the guest
 * registers the CRT's longjmp would and jumps; it returns 0, without jumping,
 * for a buffer that has no native counterpart, leaving the caller to fall back
 * to the guest's own longjmp.
 */
/* Atomic read-modify-write, for the lock-prefixed instructions.
 *
 * "lock xadd" and "lock cmpxchg" are what InterlockedIncrement and
 * InterlockedCompareExchange compile to, so they carry a title's reference
 * counts and its lock-free lists. They used to lift to a TODO comment, which
 * meant a refcount that never moved and a compare-and-swap that never swapped
 * -- harmless while every guest thread ran synchronously, and not once the
 * runtime began spawning real ones.
 *
 * Genuinely atomic, not merely correct in isolation: the guest's own threads
 * now run on real host threads, so a read-modify-write that races is exactly
 * the bug these instructions exist to prevent.
 */
#if defined(_MSC_VER)
#include <intrin.h>
#define RECOMP_ATOMIC_ADD32(p, v)     ((uint32_t)_InterlockedExchangeAdd((volatile long *)(p), (long)(v)))
#define RECOMP_ATOMIC_CAS32(p, cmp, val)     ((uint32_t)_InterlockedCompareExchange((volatile long *)(p),                                            (long)(val), (long)(cmp)))
#else
#define RECOMP_ATOMIC_ADD32(p, v)     ((uint32_t)__sync_fetch_and_add((volatile uint32_t *)(p), (uint32_t)(v)))
#define RECOMP_ATOMIC_CAS32(p, cmp, val)     ((uint32_t)__sync_val_compare_and_swap((volatile uint32_t *)(p),                                            (uint32_t)(cmp), (uint32_t)(val)))
#endif

#include <setjmp.h>
jmp_buf *recomp_setjmp_slot(uint32_t buf_va);
int recomp_guest_longjmp(uint32_t buf_va, uint32_t value);
extern RECOMP_TLS uint32_t g_ebp;

/* EFLAGS.DF, and the signed step the string instructions take because of it.
 *
 * `cld`/`std` used to lift to a comment and every string instruction stepped
 * forwards regardless. That is right almost everywhere -- DF is 0 by ABI and
 * the compiler restores it -- but MSVC's strrchr is `std; repne scasb` from
 * the terminator backwards, so it scanned forwards off the end of the string
 * and returned a pointer into whatever followed. The Xbox Dashboard uses it to
 * split "y:\default.xip" into a mount path; with strrchr wrong the archive
 * registered itself under its own full filename, no resource in it could ever
 * be found by name, and the dashboard rebooted rather than showing a UI.
 * memmove's overlapping case is the same instruction and the same bug.
 */
extern RECOMP_TLS int g_df;
extern RECOMP_TLS uint32_t g_eflags; /* EFLAGS image: pushfd, popfd */
#define RECOMP_DF_STEP(n) (g_df ? -(int32_t)(n) : (int32_t)(n))

/* EFLAGS as pushfd and popfd see it.
 *
 * The arithmetic flags are lazy: a jcc rebuilds them from the instruction
 * that set them, and the lifter writes them into g_eflags only right before
 * a pushfd (publish_flags in lifter.py), so code without one pays nothing.
 * The rest of the word lives in g_eflags too: popfd loads it, masked to the
 * bits a P3 lets ring 0 write (CF PF AF ZF SF TF IF DF OF IOPL NT AC ID),
 * with bit 1 always set. The ID bit (21) round-trips, which is how code
 * learns the CPU has cpuid; a jcc right after popfd reads its flags from
 * here.
 *
 * recomp_pushfd builds the pushed word from g_eflags, with DF from g_df,
 * which std/cld keep. cli and sti do not update IF (they have no lift that
 * touches it), so a pushfd after them reports the IF of the last popfd image:
 * set, unless the guest popped it clear. */
#define RECOMP_EFL_WRITABLE 0x00247FD5u
static inline uint32_t recomp_pushfd(void) {
    return (g_eflags & ~0x400u) | 0x2u | (g_df ? 0x400u : 0u);
}
static inline void recomp_popfd(uint32_t v) {
    g_eflags = (v & RECOMP_EFL_WRITABLE) | 0x2u;
    g_df = (int)((v >> 10) & 1u);
}

/* cpuid: out[0..3] = eax, ebx, ecx, edx for leaf `leaf` (subleaf unused).
 * The runtime answers as the Xbox's Coppermine-class Pentium III. */
void xbox_Cpuid(uint32_t leaf, uint32_t subleaf, uint32_t out[4]);

/* x87 control and status. Thread-local for the same reason the x87 stack
   above is: one guest routine can lift to several C functions, so a compare
   and the FNSTSW that reads it can land in different bodies, and the control
   word has to survive a call. (g_fp_stack/g_fp_top are declared above.) */
extern RECOMP_TLS uint16_t g_fp_control_word;
extern RECOMP_TLS int g_fp_cmp;
extern RECOMP_TLS uint16_t g_fp_cc;
/* SSE control and status (MXCSR), reset value 0x1F80: every exception
 * masked, rounding to nearest. Like the x87 control word it is guest state
 * that STMXCSR stores and LDMXCSR loads; the host's MXCSR is never changed.
 * The rounding-control bits (13-14) steer CVTSS2SI/CVTSD2SI. The exception
 * flags (bits 0-5) are not modelled and read as clear, as the x87 status
 * word's exception byte is not. */
extern RECOMP_TLS uint32_t g_mxcsr;
/* x87 precision control (control word bits 8-9). The stack is double-backed,
 * which matches PC=53 and is close enough for PC=64, but PC=24 -- what the
 * Xbox runs with -- rounds every arithmetic result to float. A title that
 * compares a freshly computed value against the same value stored as a float
 * relies on that: Burnout 3's sorted draw list re-inserts a node by walking
 * while `v > next` / `v < prev`, and with v left at double precision it sits
 * between its own stored copy and a neighbour and walks back and forth
 * forever, which froze every race at the start line.
 *
 * PC narrows the significand only; the exponent keeps the register's range.
 * So a plain (float) cast is right only inside float's range -- outside it,
 * it would turn a large intermediate into inf (and inf*0 into NaN) or flush a
 * tiny one to 0, where the x87 carries on. Those go the long way. */
static inline double recomp_fp_round24(double x) {
    double ax = fabs(x);
    int e;
    if ((ax <= 3.4028234663852886e38 && ax >= 1.1754943508222875e-38) || ax == 0.0
        || x != x || ax == INFINITY)
        return (double)(float)x;
    x = frexp(x, &e);                      /* |x| in [0.5, 1): float-exact range */
    return ldexp((double)(float)x, e);
}
#define RECOMP_FP_PC(x) ((g_fp_control_word & 0x300u) ? (double)(x) : recomp_fp_round24(x))
#define RECOMP_FCMP_CC(c) ((uint16_t)((c)==2 ? 0x4500u : (c)<0 ? 0x0100u : (c)>0 ? 0u : 0x4000u))
/* Values in the existing double-backed stack are all representable as normal
 * x87 extended values, including binary64 subnormals. Empty stack tags and
 * unsupported extended encodings are not represented by this stack model. */
static inline uint16_t recomp_fxam(double value) {
    return (uint16_t)((signbit(value) ? 0x0200u : 0u) |
        (isnan(value) ? 0x0100u : isinf(value) ? 0x0500u :
         value == 0.0 ? 0x4000u : 0x0400u));
}

/* Result of an x87 compare, in the shape the status word wants:
 *   -1 less, 0 equal, 1 greater, 2 unordered (either operand is NaN).
 * The unordered case is not a curiosity: `fucompp` of a value with itself
 * followed by `test ah, 0x44; jp` is how this era's CRT asks "is this a NaN",
 * and collapsing it to "equal" answers no every time. */
#define RECOMP_FCMP(a, b)     (((a) != (a) || (b) != (b)) ? 2 : (a) < (b) ? -1 : (a) > (b) ? 1 : 0)
/* x87 rounding to an integral value under the guest RC bits (control word
 * bits 10-11: 0 nearest-even, 1 down, 2 up, 3 toward zero). FRNDINT rounds
 * this way, and so does FIST before its store; neither may follow the HOST's
 * rounding mode, which the guest's fldcw never reaches. MSVC's CRT floor() and
 * ceil() are `fldcw RC=down/up` (via _ctrlfp) around _frnd, a bare frndint,
 * so a frndint lifted as rint() made both of them round to nearest.
 * NaN, the infinities and values already integral come back unchanged, and a
 * zero result keeps the operand's sign, as FRNDINT's does. */
static inline double recomp_frndint(double value, uint16_t control) {
    double rounded;
    if (!isfinite(value)) return value;
    switch((control>>10)&3) {
    case 1: rounded=floor(value); break;
    case 2: rounded=ceil(value); break;
    case 3: rounded=trunc(value); break;
    default: {
        double lo=floor(value), fraction=value-lo;
        rounded=lo;
        if(fraction>0.5 || (fraction==0.5 && fmod(lo,2.0)!=0.0)) rounded=lo+1.0;
        break;
    }
    }
    return rounded == 0.0 ? copysign(0.0, value) : rounded;
}
/* x87 integer stores use the guest RC bits, independently of host rounding.
 * Masked invalid conversions store the signed integer-indefinite value. */
static inline int64_t recomp_fist(double value, uint16_t control, unsigned bits) {
    double rounded = recomp_frndint(value, control);
    double limit=ldexp(1.0,(int)bits-1);
    if(!isfinite(rounded) || rounded < -limit || rounded >= limit)
        return bits==64?INT64_MIN:-(INT64_C(1)<<(bits-1));
    return (int64_t)rounded;
}

/* fld/fstp tbyte: 64-bit significand with an explicit integer bit, 15-bit
 * exponent biased by 16383, sign on top. The stack is double, so a load
 * rounds to 53 bits and a store is exact. */
static inline double recomp_f80_load(uint64_t mant, uint16_t se) {
    int e = se & 0x7fff;
    double v = e == 0x7fff ? ((mant << 1) ? NAN : INFINITY)
                           : ldexp((double)mant, e - 16383 - 63);
    return (se & 0x8000u) ? -v : v;
}
static inline uint16_t recomp_f80_store(double v, uint64_t *mant) {
    union { double d; uint64_t u; } bits;
    uint16_t sign = signbit(v) ? 0x8000u : 0u;
    int e;
    bits.d = v;
    if (v != v) { *mant = 0x8000000000000000ull | (bits.u << 11); return sign | 0x7fffu; }
    if (isinf(v)) { *mant = 0x8000000000000000ull; return sign | 0x7fffu; }
    if (v == 0.0) { *mant = 0; return sign; }
    v = frexp(fabs(v), &e);
    *mant = (uint64_t)(int64_t)ldexp(v, 63) << 1;
    return (uint16_t)(sign | (e + 16382));
}

/* Trig range failure leaves both value and stack depth unchanged. */
static inline int recomp_fp_trig_in_range(double value) {
    if (isfinite(value) && fabs(value) >= 0x1p63) {
        g_fp_cc |= 0x0400u;
        return 0;
    }
    g_fp_cc &= (uint16_t)~0x0400u;
    return 1;
}

/* x87 FSIN, FCOS, FSINCOS and FPTAN values, for an operand that
 * recomp_fp_trig_in_range has let through.
 *
 * The x87 reduces the operand modulo pi/4 with a 66-bit pi,
 * 0xC90FDAA22168C234C * 2^-66, not the true pi libm reduces with. The
 * reduced argument is off by k * (pi - pi66) / 4 for k eighth-turns removed,
 * so the hardware returns f(x * (1 + D)), D = (pi - pi66) / pi66, where libm
 * returns f(x). At x = 1e10 the two cosines differ in the 11th digit, and the
 * x87's fsin(pi) is 1.2246063538223773e-16, not 1.2246467991473532e-16. A
 * title that runs sin() on an accumulated, never-wrapped angle drifts from
 * libm that way on a Pentium III, so the recompiled one has to drift too.
 *
 * 1 + D rounds to 1, so the shift is applied as a correction to libm's s and
 * c by angle addition, in the versine form (v = 1 - cos e = 2 sin^2(e/2)):
 * the correction stays small next to s and the sum rounds once, which keeps a
 * result near a zero of the function accurate. Below |e| = 2^-26 (|x| under
 * about 1.16e13) sin e is e and v is below half an ulp, so that costs no
 * libm call beyond the other one of the pair. tests/x87_trig/model.py derives
 * the vectors and the error budget (a third of the conformance tolerance).
 * tan = sin/cos loses relative accuracy as cos(x * (1 + D)) nears 0, as the
 * hardware's own tan does there; the budget sweep leaves out |cos| < 1e-2.
 *
 * For |x| <= pi/4 the hardware does no reduction and libm's value is
 * returned as it is. No precision-control rounding: PC only narrows FADD,
 * FSUB, FMUL, FDIV and FSQRT, and the transcendentals always deliver 64 bits.
 * Inf and NaN give NaN (invalid is masked), as libm's do. */
#define RECOMP_X87_PI66_D 1.2874146789751208e-21 /* 0x1.8518e2da2e893p-70 */
static inline int recomp_x87_reduces(double x) {
    return isfinite(x) && fabs(x) > 0.78539816339744830962;
}
static inline void recomp_x87_sincos_pi66(double x, double *s, double *c) {
    double e = x * RECOMP_X87_PI66_D, se, v, sx = sin(x), cx = cos(x);
    if (fabs(e) < 1.4901161193847656e-08) { /* 2^-26 */
        se = e; v = 0.0;
    } else {
        double h = sin(0.5 * e);
        se = sin(e); v = 2.0 * h * h;
    }
    *s = sx + (cx * se - sx * v);
    *c = cx - (sx * se + cx * v);
}
static inline double recomp_x87_sin(double x) {
    double s, c;
    if (!recomp_x87_reduces(x)) return sin(x);
    recomp_x87_sincos_pi66(x, &s, &c);
    return s;
}
static inline double recomp_x87_cos(double x) {
    double s, c;
    if (!recomp_x87_reduces(x)) return cos(x);
    recomp_x87_sincos_pi66(x, &s, &c);
    return c;
}
/* Returns the sine; *c is the cosine FSINCOS then pushes. */
static inline double recomp_x87_sincos(double x, double *c) {
    double s;
    if (!recomp_x87_reduces(x)) { *c = cos(x); return sin(x); }
    recomp_x87_sincos_pi66(x, &s, c);
    return s;
}
static inline double recomp_x87_tan(double x) {
    double s, c;
    if (!recomp_x87_reduces(x)) return tan(x);
    recomp_x87_sincos_pi66(x, &s, &c);
    return s / c;
}

static inline double recomp_fscale(double value, double scale) {
    if (isnan(value) || isnan(scale)) return value + scale;
    if (scale == INFINITY)
        return value == 0.0 ? NAN : copysign(INFINITY, value);
    if (scale == -INFINITY)
        return isinf(value) ? NAN : copysign(0.0, value);
    /* Finite exponents beyond this clamp already overflow/underflow double.
     * Avoid an undefined float-to-int cast for the much larger x87 inputs. */
    return scalbn(value, scale > 4096 ? 4096 : scale < -4096 ? -4096 : (int)scale);
}

static inline double recomp_fprem(double a, double b, int nearest) {
    int quotient = 0, ea = 0, eb = 0;
    unsigned q;
    double result;
    if (isfinite(a) && isfinite(b) && a != 0.0 && b != 0.0) {
        frexp(a, &ea); frexp(b, &eb);
        if (ea - eb >= 64) {
            /* Intel permits 32..63 bits of quotient per partial reduction.
             * Keep C2 set; the guest repeats until a complete reduction. */
            g_fp_cc |= 0x0400u;
            return fmod(a, scalbn(b, ea - eb - 32));
        }
    }
    result = remquo(a, b, &quotient);
    /* remquo's quotient is round-to-nearest; FPREM chops. Step back one in
     * magnitude, on the low bits remquo returns, before reading C0/C3/C1. */
    q = (unsigned)(quotient < 0 ? -quotient : quotient);
    if (!nearest && result != 0.0 && isfinite(result) && signbit(result) != signbit(a)) {
        result += copysign(fabs(b), a);
        q -= 1u;
    }
    /* C0/C3/C1 contain quotient bits 2/1/0; C2 says complete. */
    g_fp_cc = (uint16_t)(((q & 4u) << 6) | ((q & 2u) << 13) | ((q & 1u) << 9));
    return result;
}

/* CVTSS2SI/CVTSD2SI (and the truncating CVTT forms) to a 32-bit integer.
 * The non-truncating forms round under MXCSR.RC (bits 13-14), which uses the
 * x87 RC encoding, so recomp_frndint does the rounding. A C cast would always
 * truncate, and is undefined out of range; the hardware answers NaN, the
 * infinities and out-of-range values with the integer indefinite. */
static inline int32_t recomp_cvt_si32(double value, uint32_t mxcsr, int truncate) {
    double rounded = truncate ? (isfinite(value) ? trunc(value) : value)
                              : recomp_frndint(value, (uint16_t)(((mxcsr >> 13) & 3u) << 10));
    if (!(rounded >= -2147483648.0 && rounded <= 2147483647.0))
        return (int32_t)0x80000000u;
    return (int32_t)rounded;
}

/* ================================================================
 * ICALL trace ring buffer (for debugging indirect calls)
 * ================================================================ */

/** Size of the ring buffer (must be power of 2). */
#define ICALL_TRACE_SIZE 16

/** Ring buffer of recent indirect call target VAs. */
extern volatile uint32_t g_icall_trace[ICALL_TRACE_SIZE];

/** Current write index into the ring buffer. */
extern volatile uint32_t g_icall_trace_idx;

/** Total count of indirect calls executed. */
extern volatile uint64_t g_icall_count;

/**
 * Called when an indirect call target cannot be resolved.
 * Implement this in your game-specific code to log diagnostics.
 * The va parameter is the Xbox VA that failed to resolve.
 */
void recomp_icall_fail_log(uint32_t va);

/* Report an indirect call whose target is not code (a null or wild
 * function pointer). Rate-limited per address by the implementation,
 * because these usually arrive inside a loop -- which is exactly why
 * they must be reported: silently skipping one turns a diagnosable null
 * vtable call into an unexplained hang. */
void recomp_icall_not_code_log(uint32_t va);

/* Indirect-branch target feedback. The ring buffer above is crash forensics --
 * 16 entries, overwritten constantly. This is a durable, deduplicated record of
 * every target the title ever reached, for feeding back into the next codegen
 * run (tools/recomp/icall_feedback.py).
 *
 * The header is pulled in only when the feature is on, so a default build needs
 * neither the file nor src/kernel on its include path. Disabled,
 * RECOMP_ICALL_OBSERVE discards its arguments without expanding them, so the
 * RECOMP_ICALL_SEEN_* constants need not exist either. */
#ifdef RECOMP_ICALL_FEEDBACK
#include "recomp_icall_feedback.h"
#else
#define RECOMP_ICALL_OBSERVE(va, flags) ((void)0)
#define RECOMP_ICALL_OBSERVE_SITE(site, va) ((void)0)
#endif

/**
 * Function entry trace, emitted only for addresses passed to
 * tools.recomp --trace-functions. Bring-up is largely "which of these
 * init calls does it not come back from", and answering that by
 * overriding a function loses the body you were trying to observe.
 */
/* The guest's time source.
 *
 * Xbox's QueryPerformanceCounter is a bare rdtsc and its
 * QueryPerformanceFrequency returns the CPU clock as a constant, so the guest
 * divides this by 733,333,333 to get seconds. Returning the host TSC would
 * make that division wrong by the ratio of the two clocks; the runtime scales
 * to the console's rate instead. */
uint64_t xbox_ReadTimeStampCounter(void);

/* x86 port I/O (`in`/`out`). width is 1, 2 or 4 bytes. The runtime models
 * the ports titles are known to read (the field pin at 0x80C0) and logs the
 * first access to any other. */
uint32_t xbox_PortIn(uint32_t port, int width);
void     xbox_PortOut(uint32_t port, uint32_t value, int width);

void recomp_trace_enter(const char *name, uint32_t va);
#define RECOMP_TRACE_ENTER(name, va) recomp_trace_enter((name), (va))
void recomp_trace_exit(const char *name, uint32_t va);
#define RECOMP_TRACE_EXIT(name, va) recomp_trace_exit((name), (va))
void recomp_trace_esp(const char *name, const char *tag);
#define RECOMP_TRACE_ESP(name, tag) recomp_trace_esp((name), (tag))


/* ================================================================
 * Memory access helpers
 * ================================================================ */

/**
 * Translate an Xbox VA to an actual pointer.
 * Mask to 32-bit first: Xbox addresses are 32-bit and arithmetic
 * in the recompiled code can overflow. Without the mask, a 64-bit
 * uintptr_t cast preserves the overflow bits, landing us 4GB+ past
 * our mapping and causing access violations.
 */
#define XBOX_PTR(addr) ((uintptr_t)(uint32_t)(addr) + g_xbox_mem_offset)

/** Read/write N bytes at a flat Xbox memory address. */
#define MEM8(addr)   (*(volatile uint8_t  *)XBOX_PTR(addr))
#define MEM16(addr)  (*(volatile uint16_t *)XBOX_PTR(addr))
#define MEM32(addr)  (*(volatile uint32_t *)XBOX_PTR(addr))

/** Signed memory reads. */
#define SMEM8(addr)  (*(volatile int8_t   *)XBOX_PTR(addr))
#define SMEM16(addr) (*(volatile int16_t  *)XBOX_PTR(addr))
#define SMEM32(addr) (*(volatile int32_t  *)XBOX_PTR(addr))
#define SMEM64(addr) (*(volatile int64_t  *)XBOX_PTR(addr))

/** Float/double memory access. */
#define MEMF(addr)   (*(volatile float    *)XBOX_PTR(addr))
#define MEMD(addr)   (*(volatile double   *)XBOX_PTR(addr))

/* ================================================================
 * SSE / XMM register state
 *
 * XMM is 128 bits of architectural state, not a scalar float. Modelling
 * it as a `float` made movaps/movups transfer 4 of 16 bytes and silently
 * drop the upper three lanes, and left the packed arithmetic with no
 * representation at all.
 *
 * The registers are global for the same reason the volatile GPRs are:
 * one guest routine can lift to several C functions, so a value produced
 * in one body and read in the next has to outlive the body that wrote it.
 * A function-local declaration would also shadow these, and the local
 * starts zeroed -- a returned float would silently read as 0.0.
 *
 * The helpers are lane-wise C rather than host intrinsics: the guest
 * semantics stay explicit (MINPS returning src on unordered, CMPNEQPS
 * being the unordered form) and the header stays portable.
 * ================================================================ */

#ifndef RECOMP_XMM_DEFINED
#define RECOMP_XMM_DEFINED
#define XMM_INTRIN 1
typedef union RecompXmm {
    float    f[4];
    double   d[2];
    uint32_t u[4];
    int32_t  i[4];
    uint64_t q[2];
    __m128   m;
} RecompXmm;
#endif

extern RECOMP_TLS RecompXmm g_xmm0, g_xmm1, g_xmm2, g_xmm3;
extern RECOMP_TLS RecompXmm g_xmm4, g_xmm5, g_xmm6, g_xmm7;

/* -- construction -- */

static inline RecompXmm XMM_ZERO(void) {
    RecompXmm r; r.q[0] = 0; r.q[1] = 0; return r;
}

/** movss from memory: lane 0 set, upper lanes zeroed. */
static inline RecompXmm XMM_SCALAR(float v) {
    RecompXmm r = XMM_ZERO(); r.f[0] = v; return r;
}

/** movsd from memory: low double set, high double zeroed. */
static inline RecompXmm XMM_SCALAR_DOUBLE(double v) {
    RecompXmm r = XMM_ZERO(); r.d[0] = v; return r;
}

/** movd: 32 raw bits into lane 0, upper lanes zeroed. */
static inline RecompXmm XMM_SCALAR_BITS(uint32_t bits) {
    RecompXmm r = XMM_ZERO(); r.u[0] = bits; return r;
}

/* -- guest memory --
 * Addresses are guest VAs, so they go through MEM32 like every other
 * access. Done lane-wise, which is also unaligned-safe for movups. */

static inline RecompXmm XMM_MEM(uint32_t addr) {
    RecompXmm r;
    _ReadWriteBarrier();      /* guest memory is volatile: keep this load in program order with its neighbours */
    r.m = _mm_loadu_ps((const float *)XBOX_PTR(addr));
    _ReadWriteBarrier();
    return r;
}

static inline void XMM_STORE(uint32_t addr, RecompXmm v) {
    _ReadWriteBarrier();
    _mm_storeu_ps((float *)XBOX_PTR(addr), v.m);
    _ReadWriteBarrier();
}

/* movlps/movhps move 8 bytes into or out of one half, leaving the
 * other half alone. */
#define XMM_LOAD_LOW(dst, addr)   recomp_xmm_load_half(&(dst), (addr), 0)
#define XMM_LOAD_HIGH(dst, addr)  recomp_xmm_load_half(&(dst), (addr), 1)
#define XMM_STORE_LOW(addr, src)  recomp_xmm_store_half((addr), (src), 0)
#define XMM_STORE_HIGH(addr, src) recomp_xmm_store_half((addr), (src), 1)

static inline void recomp_xmm_load_half(RecompXmm *dst, uint32_t addr,
                                        int high) {
    dst->u[high * 2]     = MEM32(addr);
    dst->u[high * 2 + 1] = MEM32(addr + 4);
}

static inline void recomp_xmm_store_half(uint32_t addr, RecompXmm src,
                                         int high) {
    MEM32(addr)     = src.u[high * 2];
    MEM32(addr + 4) = src.u[high * 2 + 1];
}

/** movlhps: dst high = src low. */
static inline RecompXmm XMM_MOVE_LOW_TO_HIGH(RecompXmm a, RecompXmm b) {
    RecompXmm r; r.m = _mm_movelh_ps(a.m, b.m); return r;
}

/** movhlps: dst low = src high. */
static inline RecompXmm XMM_MOVE_HIGH_TO_LOW(RecompXmm a, RecompXmm b) {
    RecompXmm r; r.m = _mm_movehl_ps(a.m, b.m); return r;
}

/* -- packed arithmetic -- */

/* Packed arithmetic, logic and compares are the SSE instructions themselves: ADD/SUB/MUL/DIV are exactly
 * the per-lane IEEE operations; MIN/MAX return the second operand on unordered or equal lanes, which is
 * what MINPS/MAXPS do; ANDN is ~a & b; EQ/LT/LE are the ordered compares and NEQ the unordered one. */
#define RECOMP_XMM_BIN(name, intrin)                                      \
    static inline RecompXmm name(RecompXmm a, RecompXmm b) {              \
        RecompXmm r; r.m = intrin(a.m, b.m); return r;                    \
    }

RECOMP_XMM_BIN(XMM_ADD, _mm_add_ps)
RECOMP_XMM_BIN(XMM_SUB, _mm_sub_ps)
RECOMP_XMM_BIN(XMM_MUL, _mm_mul_ps)
RECOMP_XMM_BIN(XMM_DIV, _mm_div_ps)
RECOMP_XMM_BIN(XMM_MIN, _mm_min_ps)
RECOMP_XMM_BIN(XMM_MAX, _mm_max_ps)
RECOMP_XMM_BIN(XMM_AND,  _mm_and_ps)
RECOMP_XMM_BIN(XMM_OR,   _mm_or_ps)
RECOMP_XMM_BIN(XMM_XOR,  _mm_xor_ps)
RECOMP_XMM_BIN(XMM_ANDN, _mm_andnot_ps)
RECOMP_XMM_BIN(XMM_CMP_EQ,  _mm_cmpeq_ps)
RECOMP_XMM_BIN(XMM_CMP_LT,  _mm_cmplt_ps)
RECOMP_XMM_BIN(XMM_CMP_LE,  _mm_cmple_ps)
RECOMP_XMM_BIN(XMM_CMP_NEQ, _mm_cmpneq_ps)

/* The full SSE compare predicate set, by CMPPS/CMPSS immediate:
 * 0 EQ, 1 LT, 2 LE, 3 UNORD, 4 NEQ, 5 NLT, 6 NLE, 7 ORD. */
static inline int recomp_cmp_pred(float a, float b, int p) {
    switch (p & 7) {
    case 0:  return a == b;
    case 1:  return a < b;
    case 2:  return a <= b;
    case 3:  return a != a || b != b;
    case 4:  return !(a == b);
    case 5:  return !(a < b);
    case 6:  return !(a <= b);
    default: return !(a != a || b != b);
    }
}
static inline RecompXmm XMM_CMP_PRED(RecompXmm a, RecompXmm b, int p) {
    RecompXmm r;
    switch (p & 7) {
    case 0:  r.m = _mm_cmpeq_ps(a.m, b.m); break;
    case 1:  r.m = _mm_cmplt_ps(a.m, b.m); break;
    case 2:  r.m = _mm_cmple_ps(a.m, b.m); break;
    case 3:  r.m = _mm_cmpunord_ps(a.m, b.m); break;
    case 4:  r.m = _mm_cmpneq_ps(a.m, b.m); break;
    case 5:  r.m = _mm_cmpnlt_ps(a.m, b.m); break;
    case 6:  r.m = _mm_cmpnle_ps(a.m, b.m); break;
    default: r.m = _mm_cmpord_ps(a.m, b.m); break;
    }
    return r;
}
/* Packed unary ops; the first argument is unused, as for the binary forms. */
static inline RecompXmm XMM_SQRT(RecompXmm a, RecompXmm b) {
    RecompXmm r; (void)a; r.m = _mm_sqrt_ps(b.m); return r;
}
/* These instructions deliberately approximate and treat denormals as zero.
 * Exact division changes Newton refinement and zero-mask idioms. */
static inline float recomp_rcpss(float x) {
#if defined(_M_IX86) || defined(_M_X64) || defined(__i386__) || defined(__x86_64__)
    return _mm_cvtss_f32(_mm_rcp_ss(_mm_set_ss(x)));
#else
    return 1.0f / (fpclassify(x) == FP_SUBNORMAL ? copysignf(0.0f, x) : x);
#endif
}
static inline float recomp_rsqrtss(float x) {
#if defined(_M_IX86) || defined(_M_X64) || defined(__i386__) || defined(__x86_64__)
    return _mm_cvtss_f32(_mm_rsqrt_ss(_mm_set_ss(x)));
#else
    return 1.0f / sqrtf(fpclassify(x) == FP_SUBNORMAL ? copysignf(0.0f, x) : x);
#endif
}
static inline RecompXmm XMM_RSQRT(RecompXmm a, RecompXmm b) {
    RecompXmm r; (void)a; r.m = _mm_rsqrt_ps(b.m); return r;
}
static inline RecompXmm XMM_RCP(RecompXmm a, RecompXmm b) {
    RecompXmm r; (void)a; r.m = _mm_rcp_ps(b.m); return r;
}

/** movmskps: the four lane sign bits, packed into the low nibble. */
static inline uint32_t XMM_MOVEMASK(RecompXmm a) {
    return (uint32_t)_mm_movemask_ps(a.m);
}

static inline RecompXmm recomp_xmm_wrap(__m128 v) {
    RecompXmm r; r.m = v; return r;
}

/** shufps: lanes 0-1 selected out of `a`, lanes 2-3 out of `b`. The immediate is always a literal in the
 * generated code, which the intrinsic needs. */
#define XMM_SHUFFLE(a, b, imm) recomp_xmm_wrap(_mm_shuffle_ps((a).m, (b).m, (imm)))

/** unpcklps / unpckhps: interleave the low or high halves. */
static inline RecompXmm XMM_UNPACK_LOW(RecompXmm a, RecompXmm b) {
    RecompXmm r; r.m = _mm_unpacklo_ps(a.m, b.m); return r;
}

static inline RecompXmm XMM_UNPACK_HIGH(RecompXmm a, RecompXmm b) {
    RecompXmm r; r.m = _mm_unpackhi_ps(a.m, b.m); return r;
}

/* ================================================================
 * Flag computation helpers
 *
 * These macros compute x86 flags for conditional branches.
 * Used by the lifter's pattern-matching output:
 *   cmp a, b; jcc target  ->  if (COND(a, b)) goto target;
 * ================================================================ */

/* Unsigned comparison conditions (from CMP a, b -> a - b) */
#define CMP_EQ(a, b)  ((uint32_t)(a) == (uint32_t)(b))
#define CMP_NE(a, b)  ((uint32_t)(a) != (uint32_t)(b))
#define CMP_B(a, b)   ((uint32_t)(a) <  (uint32_t)(b))   /* below (CF=1) */
#define CMP_AE(a, b)  ((uint32_t)(a) >= (uint32_t)(b))   /* above or equal */
#define CMP_BE(a, b)  ((uint32_t)(a) <= (uint32_t)(b))   /* below or equal */
#define CMP_A(a, b)   ((uint32_t)(a) >  (uint32_t)(b))   /* above */

/* Signed comparison conditions */
/* x86 evaluates the signed conditions at the operand width, not at 32 bits.
   The generated code passes LO8/HI8/LO16 sub-register reads straight in, and
   those zero-extend, so recover the width and sign-extend before comparing. */
#define RECOMP_FLAG_WIDTH(a, b) (sizeof(a) < sizeof(b) ? sizeof(a) : sizeof(b))
#define RECOMP_SIGNED(value, width) \
    ((width) == 1u ? (int32_t)(int8_t)(uint8_t)(uint32_t)(value) \
     : (width) == 2u ? (int32_t)(int16_t)(uint16_t)(uint32_t)(value) \
     : (int32_t)(uint32_t)(value))
#define CMP_L(a, b)   (RECOMP_SIGNED(a, RECOMP_FLAG_WIDTH(a, b)) <  \
                       RECOMP_SIGNED(b, RECOMP_FLAG_WIDTH(a, b)))  /* less */
#define CMP_GE(a, b)  (RECOMP_SIGNED(a, RECOMP_FLAG_WIDTH(a, b)) >= \
                       RECOMP_SIGNED(b, RECOMP_FLAG_WIDTH(a, b)))  /* >= */
#define CMP_LE(a, b)  (RECOMP_SIGNED(a, RECOMP_FLAG_WIDTH(a, b)) <= \
                       RECOMP_SIGNED(b, RECOMP_FLAG_WIDTH(a, b)))  /* <= */
#define CMP_G(a, b)   (RECOMP_SIGNED(a, RECOMP_FLAG_WIDTH(a, b)) >  \
                       RECOMP_SIGNED(b, RECOMP_FLAG_WIDTH(a, b)))  /* > */

/* TEST-based conditions (AND without storing result) */
#define TEST_Z(a, b)  (((uint32_t)(a) & (uint32_t)(b)) == 0)  /* ZF=1 */
#define TEST_NZ(a, b) (((uint32_t)(a) & (uint32_t)(b)) != 0)  /* ZF=0 */
#define TEST_S(a, b)  (RECOMP_SIGNED((uint32_t)(a) & (uint32_t)(b), \
                                     RECOMP_FLAG_WIDTH(a, b)) < 0)  /* SF=1 */

/* ================================================================
 * Arithmetic with carry/overflow detection
 * ================================================================ */

/** Add with carry flag. Returns result, sets *cf. */
static inline uint32_t ADD32_CF(uint32_t a, uint32_t b, int *cf) {
    uint32_t r = a + b;
    *cf = (r < a);
    return r;
}

/** Sub with carry (borrow) flag. Returns result, sets *cf. */
static inline uint32_t SUB32_CF(uint32_t a, uint32_t b, int *cf) {
    *cf = (a < b);
    return a - b;
}

/* ================================================================
 * Rotation / shift helpers
 * ================================================================ */

/* x86 masks the rotate count to 5 bits, and THEN the rotate is modulo the
 * operand's own width -- so `rol al, 16` is a rotate by zero and `rol ax, 31`
 * is a rotate by 15. A narrow rotate performed at 32 bits is not a rotate at
 * all: the bits that should wrap around at bit 7 or 15 land above the operand
 * and are discarded by the store, which turns `ror al, 2` on 0x01 into 0x00
 * where x86 gives 0x40.
 *
 * The zero case is separated out because `val >> (32 - 0)` is a shift of a
 * uint32_t by 32, which is undefined behaviour -- it happened to survive
 * because x86 masks shift counts to 5 bits and gives back `val`, but the
 * compiler is under no obligation to agree, least of all at -O2. */
static inline uint32_t ROL32(uint32_t val, int n) {
    n &= 31;
    return n ? ((val << n) | (val >> (32 - n))) : val;
}

static inline uint32_t ROR32(uint32_t val, int n) {
    n &= 31;
    return n ? ((val >> n) | (val << (32 - n))) : val;
}

/* rcl/rcr: rotate through the carry flag.
 *
 * The carry is a bit sitting one place above the operand's top bit, so the
 * rotation is over width+1 bits. That is also why a count is reduced modulo
 * width+1 for the 8- and 16-bit forms rather than modulo the width: a byte
 * rotates through nine positions, not eight. The 32-bit form takes the count
 * masked to five bits and no further, which is already inside 33.
 *
 * `cf` carries in and out.
 */
static inline uint32_t RC_ROT(uint32_t val, unsigned n, int *cf,
                              unsigned width, int left) {
    unsigned mod = width + 1u;
    uint64_t mask = (width >= 32u) ? 0xFFFFFFFFull
                                   : ((((uint64_t)1 << width) - 1u));
    uint64_t x = (((uint64_t)(*cf & 1)) << width) | ((uint64_t)val & mask);

    n &= 31u;
    if (width < 32u)
        n %= mod;
    if (n) {
        uint64_t full = (((uint64_t)1 << mod) - 1u);
        x = left ? ((x << n) | (x >> (mod - n)))
                 : ((x >> n) | (x << (mod - n)));
        x &= full;
    }
    *cf = (int)((x >> width) & 1);
    return (uint32_t)(x & mask);
}

static inline uint8_t ROL8(uint8_t val, int n) {
    n = (n & 31) % 8;
    return n ? (uint8_t)((val << n) | (val >> (8 - n))) : val;
}

static inline uint8_t ROR8(uint8_t val, int n) {
    n = (n & 31) % 8;
    return n ? (uint8_t)((val >> n) | (val << (8 - n))) : val;
}

static inline uint16_t ROL16(uint16_t val, int n) {
    n = (n & 31) % 16;
    return n ? (uint16_t)((val << n) | (val >> (16 - n))) : val;
}

static inline uint16_t ROR16(uint16_t val, int n) {
    n = (n & 31) % 16;
    return n ? (uint16_t)((val >> n) | (val << (16 - n))) : val;
}

/* ================================================================
 * Sign/zero extension
 * ================================================================ */

#define ZX8(v)   ((uint32_t)(uint8_t)(v))
#define ZX16(v)  ((uint32_t)(uint16_t)(v))
#define SX8(v)   ((uint32_t)(int32_t)(int8_t)(v))
#define SX16(v)  ((uint32_t)(int32_t)(int16_t)(v))

/* ================================================================
 * Byte/word register access
 *
 * These macros extract or set partial registers, matching x86
 * behavior where writing AL doesn't affect bits 8-31 of EAX.
 * ================================================================ */

/** Extract low byte (al, bl, cl, dl). */
#define LO8(r)  ((uint8_t)((r) & 0xFF))
/** Extract high byte of low word (ah, bh, ch, dh). */
#define HI8(r)  ((uint8_t)(((r) >> 8) & 0xFF))
/** Extract low word (ax, bx, cx, dx). */
#define LO16(r) ((uint16_t)((r) & 0xFFFF))

/** Set low byte, preserving upper 24 bits. */
#define SET_LO8(r, v)  ((r) = ((r) & 0xFFFFFF00u) | ((uint32_t)(uint8_t)(v)))
/** Set high byte of low word, preserving other bits. */
#define SET_HI8(r, v)  ((r) = ((r) & 0xFFFF00FFu) | (((uint32_t)(uint8_t)(v)) << 8))
/** Set low word, preserving upper 16 bits. */
#define SET_LO16(r, v) ((r) = ((r) & 0xFFFF0000u) | ((uint32_t)(uint16_t)(v)))

/* ================================================================
 * Stack simulation
 *
 * For push/pop heavy prologues in the generated code.
 * ================================================================ */

/**
 * Push a 32-bit value onto the simulated stack.
 * Evaluates val BEFORE decrementing sp, matching x86 semantics
 * where push [esp+N] reads the operand before adjusting ESP.
 */
#define PUSH32(sp, val) do { \
    uint32_t _pv = (uint32_t)(val); \
    (sp) -= 4; \
    MEM32(sp) = _pv; \
} while(0)

/**
 * x86 parity flag: 1 when the low byte of the result has an EVEN number of set
 * bits (that is what PF means). Used by the x87 float-compare idiom
 * `fnstsw ax; test ah, mask; jp/jnp`, which is how all pre-SSE code branches on
 * a float comparison. Without a real parity here the branch was hardcoded and
 * every such comparison went one fixed direction.
 */
static inline int recomp_parity8(uint32_t x) {
    x &= 0xFFu; x ^= x >> 4; x ^= x >> 2; x ^= x >> 1;
    return (int)(~x & 1u);   /* 1 = even parity (PF set) */
}
#define RECOMP_PARITY8(x) recomp_parity8((uint32_t)(x))

/**
 * Pop a 32-bit value from the simulated stack.
 * Writes dst AFTER incrementing sp: for `pop esp` (dst == sp) x86 leaves ESP
 * equal to the popped value, not popped value + 4 (Intel SDM, POP). The old
 * read-then-increment order left every lifted `pop esp` 4 bytes high, so the
 * round-to-int idiom `push esp; push eax; ...; pop eax; pop esp` drifted the
 * stack and later pops read the wrong slots.
 */
#define POP32(sp, dst) do { \
    uint32_t _pv = MEM32(sp); \
    (sp) += 4; \
    (dst) = _pv; \
} while(0)

/* ================================================================
 * Byte swap (for endian conversion if needed)
 *
 * Xbox is little-endian like x86, so these are rarely needed,
 * but some games use bswap for network byte order or data parsing.
 * ================================================================ */

static inline uint32_t BSWAP32(uint32_t v) {
    return ((v >> 24) & 0xFF) | ((v >> 8) & 0xFF00) |
           ((v << 8) & 0xFF0000) | ((v << 24) & 0xFF000000u);
}

static inline uint16_t BSWAP16(uint16_t v) {
    return (uint16_t)((v >> 8) | (v << 8));
}

/* ================================================================
 * Indirect call dispatch
 *
 * The dispatch system resolves Xbox virtual addresses to native
 * function pointers at runtime. Three lookup sources are checked:
 *   1. Manual overrides (hand-written reimplementations)
 *   2. Generated dispatch table (auto-recompiled functions)
 *   3. Kernel thunk bridge (Xbox kernel function replacements)
 * ================================================================ */

/**
 * Generic function pointer type for all recompiled functions.
 * All translated functions are void(void) - arguments and return
 * values are passed through global registers and the simulated stack.
 */
#ifndef RECOMP_DISPATCH_H  /* avoid conflict with recomp_dispatch.h */
typedef void (*recomp_func_t)(void);

/**
 * Look up a recompiled function by its Xbox VA.
 * Returns NULL if the VA is not in the generated dispatch table.
 */
recomp_func_t recomp_lookup(uint32_t xbox_va);

/**
 * Build the flat, directly-indexed dispatch table.
 *
 * Turns recomp_lookup from a binary search over every translated function into
 * a bounds check and one indexed load -- the C form of Microsoft's
 * `jmp [table + guest_eip*8]`. Call it once at startup, before any recompiled
 * code runs.
 *
 * Entirely optional: if it is never called, or returns 0 because the allocation
 * failed, recomp_lookup keeps using the binary search and everything still
 * works. Costs 8 bytes per byte of guest code span (see
 * recomp_dispatch_flat_bytes), allocated with calloc so the untouched middle
 * stays uncommitted.
 *
 * Returns 1 if the flat table is in use, 0 if the search is.
 */
int recomp_dispatch_init(void);

/** Bytes held by the flat table, or 0 if it was never built. */
size_t recomp_dispatch_flat_bytes(void);

/**
 * Look up a kernel thunk function by its synthetic VA.
 * Kernel thunks live at 0xFE000000+ (synthetic addresses assigned
 * during kernel bridge initialization).
 * Returns NULL if the VA is not a kernel thunk.
 */
recomp_func_t recomp_lookup_kernel(uint32_t xbox_va);

/**
 * Look up a manually overridden function by its Xbox VA.
 * Manual overrides take priority over generated code.
 * Returns NULL if no manual override exists for this VA.
 */
recomp_func_t recomp_lookup_manual(uint32_t xbox_va);
#endif

/**
 * RECOMP_ABI_CALL - call a resolved target, optionally checking the ABI.
 *
 * ebx, esi and edi are callee-saved on x86, and the recompiler keeps them in
 * globals rather than on the host's stack. So a lifted function that never
 * reaches its own epilogue -- the usual cause is a decode that lost sync on
 * embedded data -- does not merely lose its own state, it silently corrupts
 * every caller's.
 *
 * That failure is invisible at the crash site: the caller carries on with a
 * wrong loop cursor and simply does less work. Half-Life 2's C++ static
 * initialiser walks 5,305 constructors with esi as the cursor and edi as the
 * limit; a single callee returning with those changed ended the walk early and
 * left Source with no registered interfaces, with no error anywhere.
 *
 * Build with -DRECOMP_ABI_CHECK to have every indirect call verify them and
 * name the first offenders. esp is deliberately not checked: the convention
 * decides whether the callee pops arguments, so there is no single correct
 * value -- but there is one invariant that holds under every convention:
 * the callee at least pops its own return address, so esp must come back
 * at least 4 higher than it went in. Coming back lower means the epilogue
 * never ran, which is the failure this exists to catch.
 *
 * Covers direct calls as well as indirect: tools/recomp emits every direct
 * call through this macro, which expands to a plain call when the flag is
 * off. That matters because CRT and static-initialiser paths -- where these
 * clobbers actually bite -- are almost entirely direct calls.
 * Generated code emits a direct call as a plain C call to the symbol, with no
 * macro to hook, so a direct callee that clobbers these registers is invisible
 * here. That matters more than it sounds -- CRT and static-initialiser paths
 * are almost entirely direct calls, so this found nothing at all on Half-Life
 * 2's static init, where the clobber demonstrably exists. It is the right tool
 * for vtable-dispatch-heavy code and the wrong one for early boot.
 */
#ifdef RECOMP_ABI_CHECK
void recomp_abi_violation_log(uint32_t va, uint32_t ebx0, uint32_t esi0,
                              uint32_t edi0, uint32_t esp0);
#define RECOMP_ABI_CALL(va, fn) do { \
    uint32_t _ab = g_ebx, _as = g_esi, _ad = g_edi, _ap = g_esp; \
    (fn)(); \
    if (g_ebx != _ab || g_esi != _as || g_edi != _ad || g_esp < _ap + 4) \
        recomp_abi_violation_log((va), _ab, _as, _ad, _ap); \
} while(0)
#elif defined(RECOMP_CALL_PROFILE)
/* Opt-in profiling: every direct call reports its target to the project, which
 * keeps the counts (a project defines recomp_call_profile_hit). Diffing the counts
 * of two situations shows which functions one of them runs and the other does not. */
void recomp_call_profile_hit(uint32_t va);
#define RECOMP_ABI_CALL(va, fn) do { recomp_call_profile_hit(va); (fn)(); } while(0)
#else
#define RECOMP_ABI_CALL(va, fn) (fn)()
#endif

/* A guarded arm of an indirect call. When a recorded run saw a call site
 * reach only a few translated functions, the lifter compares the target
 * against each and calls the match directly (RECOMP_ABI_CALL), falling back
 * to RECOMP_ICALL_SAFE_AT for anything else -- so an unseen target is slow,
 * never wrong. Under RECOMP_ICALL_FEEDBACK the arms are counted, so a run
 * can say how often the guards held; otherwise they cost nothing. */
#ifdef RECOMP_ICALL_FEEDBACK
extern volatile uint64_t g_icall_guard_hits;
extern volatile uint64_t g_icall_guard_misses;
#define RECOMP_ICALL_GUARD_HIT()  ((void)g_icall_guard_hits++)
#define RECOMP_ICALL_GUARD_MISS() ((void)g_icall_guard_misses++)
#else
#define RECOMP_ICALL_GUARD_HIT()  ((void)0)
#define RECOMP_ICALL_GUARD_MISS() ((void)0)
#endif

/* Every loop back edge in code lifted with --back-edge-yield (tools.recomp;
 * off by default, so a title lifted without it has none): the guest CPU's
 * quantum check. A guest thread that has waited its quantum for the CPU
 * (RECOMP_GUEST_LOCK) sets the flag, and the holder hands over at its next
 * back edge, as the console's timer tick preempted it wherever it was; a
 * kernel call checks the quantum too, but a frame of lifted code can go
 * without one. With the lock off the flag is never set: one relaxed atomic
 * load and a branch not taken per back edge. */
#if defined(_MSC_VER)
#include <intrin.h>
#define RECOMP_LOAD_RELAXED32(p) \
    ((int32_t)__iso_volatile_load32((const volatile __int32 *)(p)))
#else
#define RECOMP_LOAD_RELAXED32(p) __atomic_load_n((p), __ATOMIC_RELAXED)
#endif
extern int32_t g_xbox_guest_cpu_preempt;
void xbox_GuestCpuPreempt(uint32_t va);
#define RECOMP_BACK_EDGE(va) \
    do { if (RECOMP_LOAD_RELAXED32(&g_xbox_guest_cpu_preempt)) \
             xbox_GuestCpuPreempt(va); } while (0)

/**
 * RECOMP_ICALL - Indirect call through the dispatch table.
 *
 * Looks up the Xbox VA and calls the translated function.
 * Falls back to kernel bridge for kernel thunk synthetic VAs.
 * The caller must PUSH32 the guest return address before this macro.
 * If not found, pops it back off to keep the stack balanced.
 *
 * RECOMP_ICALL_IS_CODE skips garbage VAs that come from uninitialized vtable
 * pointers. Kernel thunks at 0xFE000000+ are never blocked.
 *
 * Nothing to customize: the range comes from g_xbox_code_lo/g_xbox_code_hi,
 * which the memory layout fills in from the sections it actually mapped. This
 * used to say "change the VA range check to match your game's code range",
 * left over from a hardcoded 0x00400000 cutoff that was only ever right for
 * one title. Editing this header per project is no longer a thing.
 */
#define RECOMP_ICALL(xbox_va) do { \
    uint32_t _va = (uint32_t)(xbox_va); \
    g_icall_trace[g_icall_trace_idx & (ICALL_TRACE_SIZE-1)] = _va; \
    g_icall_trace_idx++; \
    g_icall_count++; \
    /* Skip garbage VAs outside code section + kernel thunk range */ \
    if (!RECOMP_ICALL_IS_CODE(_va)) { \
        recomp_icall_not_code_log(_va); \
        g_esp += 4; eax = 0; break; \
    } \
    recomp_func_t _fn = recomp_lookup_manual(_va); \
    if (!_fn) _fn = recomp_lookup(_va); \
    if (!_fn) _fn = recomp_lookup_kernel(_va); \
    if (_fn) { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_RESOLVED); \
               RECOMP_ABI_CALL(_va, _fn); } \
    else { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_UNRESOLVED); \
           recomp_icall_fail_log(_va); g_esp += 4; eax = 0; } \
} while(0)

/**
 * RECOMP_ICALL_SAFE - Stack-safe indirect call.
 *
 * Restores g_esp to saved_esp (pre-argument value) on lookup failure,
 * preventing stdcall argument leaks on failed vtable calls.
 * Use this when the caller pushes arguments that the callee would
 * normally clean up (stdcall convention).
 */
#define RECOMP_ICALL_SAFE(xbox_va, saved_esp) do { \
    uint32_t _va = (uint32_t)(xbox_va); \
    g_icall_trace[g_icall_trace_idx & (ICALL_TRACE_SIZE-1)] = _va; \
    g_icall_trace_idx++; \
    g_icall_count++; \
    if (!RECOMP_ICALL_IS_CODE(_va)) { \
        recomp_icall_not_code_log(_va); \
        g_esp = (saved_esp); eax = 0; break; \
    } \
    recomp_func_t _fn = recomp_lookup_manual(_va); \
    if (!_fn) _fn = recomp_lookup(_va); \
    if (!_fn) _fn = recomp_lookup_kernel(_va); \
    if (_fn) { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_RESOLVED); \
               RECOMP_ABI_CALL(_va, _fn); } \
    else { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_UNRESOLVED); \
           recomp_icall_fail_log(_va); g_esp = (saved_esp); eax = 0; } \
} while(0)

/* Caller cleanup: a failed call pops only its return address. */
#define RECOMP_ICALL_SAFE_CC(xbox_va, saved_esp) do { \
    (void)(saved_esp); \
    uint32_t _va = (uint32_t)(xbox_va); \
    g_icall_trace[g_icall_trace_idx & (ICALL_TRACE_SIZE-1)] = _va; \
    g_icall_trace_idx++; \
    g_icall_count++; \
    if (!RECOMP_ICALL_IS_CODE(_va)) { \
        recomp_icall_not_code_log(_va); \
        g_esp += 4; eax = 0; break; \
    } \
    recomp_func_t _fn = recomp_lookup_manual(_va); \
    if (!_fn) _fn = recomp_lookup(_va); \
    if (!_fn) _fn = recomp_lookup_kernel(_va); \
    if (_fn) { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_RESOLVED); \
               RECOMP_ABI_CALL(_va, _fn); } \
    else { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_UNRESOLVED); \
           recomp_icall_fail_log(_va); g_esp += 4; eax = 0; } \
} while(0)

/**
 * RECOMP_ICALL_SAFE_AT - RECOMP_ICALL_SAFE that also names the call SITE.
 *
 * `site` is the guest address of the `call` instruction. Under
 * RECOMP_ICALL_FEEDBACK the runtime records which targets each site reaches
 * (icall_sites.dump), which is what lets the lifter guard a site with direct
 * calls on the next generation. Everything else is RECOMP_ICALL_SAFE.
 */
#define RECOMP_ICALL_SAFE_AT(xbox_va, saved_esp, site) do { \
    uint32_t _va = (uint32_t)(xbox_va); \
    g_icall_trace[g_icall_trace_idx & (ICALL_TRACE_SIZE-1)] = _va; \
    g_icall_trace_idx++; \
    g_icall_count++; \
    if (!RECOMP_ICALL_IS_CODE(_va)) { \
        recomp_icall_not_code_log(_va); \
        g_esp = (saved_esp); eax = 0; break; \
    } \
    RECOMP_ICALL_OBSERVE_SITE((site), _va); \
    recomp_func_t _fn = recomp_lookup_manual(_va); \
    if (!_fn) _fn = recomp_lookup(_va); \
    if (!_fn) _fn = recomp_lookup_kernel(_va); \
    if (_fn) { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_RESOLVED); \
               RECOMP_ABI_CALL(_va, _fn); } \
    else { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_UNRESOLVED); \
           recomp_icall_fail_log(_va); g_esp = (saved_esp); eax = 0; } \
} while(0)

/* Caller cleanup: a failed call pops only its return address. */
#define RECOMP_ICALL_SAFE_AT_CC(xbox_va, saved_esp, site) do { \
    (void)(saved_esp); \
    uint32_t _va = (uint32_t)(xbox_va); \
    g_icall_trace[g_icall_trace_idx & (ICALL_TRACE_SIZE-1)] = _va; \
    g_icall_trace_idx++; \
    g_icall_count++; \
    if (!RECOMP_ICALL_IS_CODE(_va)) { \
        recomp_icall_not_code_log(_va); \
        g_esp += 4; eax = 0; break; \
    } \
    RECOMP_ICALL_OBSERVE_SITE((site), _va); \
    recomp_func_t _fn = recomp_lookup_manual(_va); \
    if (!_fn) _fn = recomp_lookup(_va); \
    if (!_fn) _fn = recomp_lookup_kernel(_va); \
    if (_fn) { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_RESOLVED); \
               RECOMP_ABI_CALL(_va, _fn); } \
    else { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_UNRESOLVED); \
           recomp_icall_fail_log(_va); g_esp += 4; eax = 0; } \
} while(0)

/**
 * RECOMP_ITAIL - Indirect tail call (jmp through function pointer).
 *
 * No return address is pushed - reuses the current frame's return addr.
 * Used for tail-call optimization where the original code uses
 * jmp [reg] instead of call [reg].
 */
#define RECOMP_ITAIL(xbox_va) do { \
    uint32_t _va = (uint32_t)(xbox_va); \
    recomp_func_t _fn = recomp_lookup_manual(_va); \
    if (!_fn) _fn = recomp_lookup(_va); \
    if (!_fn) _fn = recomp_lookup_kernel(_va); \
    if (_fn) { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_RESOLVED); \
               RECOMP_ABI_CALL(_va, _fn); } \
    else { RECOMP_ICALL_OBSERVE(_va, RECOMP_ICALL_SEEN_UNRESOLVED); \
           recomp_icall_fail_log(_va); g_esp += 4; g_eax = 0; } \
} while(0)

/* ================================================================
 * Register name aliases for generated code
 *
 * Map x86 volatile register names to global variables.
 * These #defines allow the generated code to use natural register
 * names (eax, ecx, edx, esp) which the preprocessor maps to the
 * corresponding globals (g_eax, g_ecx, g_edx, g_esp).
 *
 * Only active when RECOMP_GENERATED_CODE is defined (in generated
 * .c files) to avoid polluting hand-written code.
 * ================================================================ */

#ifdef RECOMP_GENERATED_CODE
#define eax g_eax
#define ecx g_ecx
#define edx g_edx
#define esp g_esp
#define ebx g_ebx
#define esi g_esi
#define edi g_edi

/* ================================================================
 * MMX register file
 *
 * The Xbox is a Pentium III and every XDK codec leans on MMX: the WMV
 * decoder's IDCT and motion compensation are almost nothing else. Modelled the
 * same way as RecompXmm -- a union of lane views over one 64-bit register --
 * because that is what the instructions are: the same bits read as bytes,
 * words or dwords.
 *
 * mm0..mm7 alias the x87 stack on real hardware. Nothing here does, and
 * nothing needs to: a title that interleaves the two calls emms between, and
 * emms is a no-op for us. Modelling the aliasing would mean giving up the
 * separate x87 model that the FPU work depends on, to reproduce a hazard the
 * hardware exists to let software avoid.
 * ================================================================ */

#ifndef RECOMP_MMX_DEFINED
#define RECOMP_MMX_DEFINED
typedef union RecompMmx {
    int8_t   b[8];
    uint8_t  ub[8];
    int16_t  w[4];
    uint16_t uw[4];
    int32_t  d[2];
    uint32_t ud[2];
    uint64_t q;
} RecompMmx;
#endif

extern RECOMP_TLS RecompMmx g_mm0, g_mm1, g_mm2, g_mm3;
extern RECOMP_TLS RecompMmx g_mm4, g_mm5, g_mm6, g_mm7;

static inline RecompMmx MMX_ZERO(void) { RecompMmx r; r.q = 0; return r; }

/* CVTPS2PI follows MXCSR; CVTTPS2PI truncates regardless of its rounding mode.
 * Use SSE scalar conversions to avoid touching the host x87/MMX register file.
 * Non-x86 hosts use their floating-point environment for rounding instead. */
static inline int32_t MMX_CVT_F2I(float v, int truncate)
{
#if defined(_M_IX86) || defined(_M_X64) || defined(__i386__) || defined(__x86_64__)
    return truncate ? _mm_cvttss_si32(_mm_set_ss(v))
                    : _mm_cvtss_si32(_mm_set_ss(v));
#else
    double rounded = truncate ? trunc((double)v) : nearbyint((double)v);
    if (!(rounded >= -2147483648.0 && rounded <= 2147483647.0))
        return (int32_t)0x80000000u;       /* integer indefinite */
    return (int32_t)rounded;
#endif
}

static inline RecompMmx MMX_FROM_PS(float lo, float hi, int truncate)
{
    RecompMmx r;
    r.d[0] = MMX_CVT_F2I(lo, truncate);
    r.d[1] = MMX_CVT_F2I(hi, truncate);
    return r;
}

static inline int32_t recomp_sse_d2i(double v, int truncate) {
#if defined(_M_IX86) || defined(_M_X64) || defined(__i386__) || defined(__x86_64__)
    return truncate ? _mm_cvttsd_si32(_mm_set_sd(v))
                    : _mm_cvtsd_si32(_mm_set_sd(v));
#else
    double rounded = truncate ? trunc(v) : nearbyint(v);
    return rounded >= -2147483648.0 && rounded < 2147483648.0
        ? (int32_t)rounded : INT32_MIN;
#endif
}
static inline RecompXmm XMM_CVT_PS2DQ(RecompXmm v, int truncate) {
    RecompXmm r; int i;
    for (i = 0; i < 4; ++i) r.i[i] = MMX_CVT_F2I(v.f[i], truncate);
    return r;
}

/** cvtpi2ps: two signed dwords in, two singles out, into the LOW half of the
 * destination -- lanes 2 and 3 keep whatever they held. That detail is the
 * whole instruction: code that builds a float4 from two of these relies on
 * the first one surviving the second. */
static inline RecompXmm XMM_FROM_PI(RecompXmm dst, RecompMmx src)
{
    dst.f[0] = (float)src.d[0];
    dst.f[1] = (float)src.d[1];
    return dst;
}

static inline RecompMmx MMX_MEM(uint32_t addr) {
    RecompMmx r;
    memcpy(&r, (const void *)XBOX_PTR(addr), 8);
    return r;
}

static inline void MMX_STORE(uint32_t addr, RecompMmx v) {
    memcpy((void *)XBOX_PTR(addr), &v, 8);
}

static inline RecompMmx MMX_FROM32(uint32_t v) {
    RecompMmx r; r.q = 0; r.ud[0] = v; return r;
}

/* -- saturation helpers ---------------------------------------- */
static inline int16_t recomp_sat_i16(int32_t v) {
    return (int16_t)(v > 32767 ? 32767 : (v < -32768 ? -32768 : v));
}
static inline int8_t recomp_sat_i8(int32_t v) {
    return (int8_t)(v > 127 ? 127 : (v < -128 ? -128 : v));
}
static inline uint8_t recomp_sat_u8(int32_t v) {
    return (uint8_t)(v > 255 ? 255 : (v < 0 ? 0 : v));
}

static inline uint16_t recomp_sat_u16(int32_t v) {
    return (uint16_t)(v > 65535 ? 65535 : (v < 0 ? 0 : v));
}

/* -- integer arithmetic, lane-wise, wrapping -------------------- */
#define RECOMP_MMX_BINOP(NAME, LANES, FIELD, EXPR)                      \
    static inline RecompMmx NAME(RecompMmx a, RecompMmx b) {            \
        RecompMmx r; int i;                                             \
        for (i = 0; i < (LANES); i++) { (void)b; r.FIELD[i] = (EXPR); } \
        return r;                                                       \
    }

RECOMP_MMX_BINOP(MMX_PADDB, 8, b, (int8_t)((uint8_t)a.b[i] + (uint8_t)b.b[i]))
RECOMP_MMX_BINOP(MMX_PADDW, 4, w, (int16_t)((uint16_t)a.w[i] + (uint16_t)b.w[i]))
RECOMP_MMX_BINOP(MMX_PADDD, 2, d, (int32_t)((uint32_t)a.d[i] + (uint32_t)b.d[i]))
RECOMP_MMX_BINOP(MMX_PSUBB, 8, b, (int8_t)((uint8_t)a.b[i] - (uint8_t)b.b[i]))
RECOMP_MMX_BINOP(MMX_PSUBW, 4, w, (int16_t)((uint16_t)a.w[i] - (uint16_t)b.w[i]))
RECOMP_MMX_BINOP(MMX_PSUBD, 2, d, (int32_t)((uint32_t)a.d[i] - (uint32_t)b.d[i]))
RECOMP_MMX_BINOP(MMX_PADDSB, 8, b, recomp_sat_i8((int32_t)a.b[i] + b.b[i]))
RECOMP_MMX_BINOP(MMX_PADDSW, 4, w, recomp_sat_i16((int32_t)a.w[i] + b.w[i]))
RECOMP_MMX_BINOP(MMX_PSUBSB, 8, b, recomp_sat_i8((int32_t)a.b[i] - b.b[i]))
RECOMP_MMX_BINOP(MMX_PSUBSW, 4, w, recomp_sat_i16((int32_t)a.w[i] - b.w[i]))
RECOMP_MMX_BINOP(MMX_PADDUSB, 8, ub,
                 recomp_sat_u8((int32_t)a.ub[i] + b.ub[i]))
RECOMP_MMX_BINOP(MMX_PSUBUSB, 8, ub,
                 recomp_sat_u8((int32_t)a.ub[i] - b.ub[i]))
RECOMP_MMX_BINOP(MMX_PADDUSW, 4, uw,
                 recomp_sat_u16((int32_t)a.uw[i] + b.uw[i]))
RECOMP_MMX_BINOP(MMX_PSUBUSW, 4, uw,
                 recomp_sat_u16((int32_t)a.uw[i] - b.uw[i]))
RECOMP_MMX_BINOP(MMX_PMULLW, 4, w, (int16_t)((int32_t)a.w[i] * b.w[i]))
RECOMP_MMX_BINOP(MMX_PMULHW, 4, w, (int16_t)(((int32_t)a.w[i] * b.w[i]) >> 16))
RECOMP_MMX_BINOP(MMX_PAVGB, 8, ub, (uint8_t)(((int32_t)a.ub[i] + b.ub[i] + 1) >> 1))
RECOMP_MMX_BINOP(MMX_PAVGW, 4, uw, (uint16_t)(((int32_t)a.uw[i] + b.uw[i] + 1) >> 1))
RECOMP_MMX_BINOP(MMX_PMINSW, 4, w, (a.w[i] < b.w[i] ? a.w[i] : b.w[i]))
RECOMP_MMX_BINOP(MMX_PMAXSW, 4, w, (a.w[i] > b.w[i] ? a.w[i] : b.w[i]))
RECOMP_MMX_BINOP(MMX_PCMPEQB, 8, b, (int8_t)(a.b[i] == b.b[i] ? -1 : 0))
RECOMP_MMX_BINOP(MMX_PCMPEQW, 4, w, (int16_t)(a.w[i] == b.w[i] ? -1 : 0))
RECOMP_MMX_BINOP(MMX_PCMPEQD, 2, d, (int32_t)(a.d[i] == b.d[i] ? -1 : 0))
RECOMP_MMX_BINOP(MMX_PCMPGTB, 8, b, (int8_t)(a.b[i] > b.b[i] ? -1 : 0))
RECOMP_MMX_BINOP(MMX_PCMPGTW, 4, w, (int16_t)(a.w[i] > b.w[i] ? -1 : 0))
RECOMP_MMX_BINOP(MMX_PCMPGTD, 2, d, (int32_t)(a.d[i] > b.d[i] ? -1 : 0))

/* pmaddwd: multiply signed words, add adjacent pairs into dwords. */
static inline RecompMmx MMX_PMADDWD(RecompMmx a, RecompMmx b) {
    RecompMmx r;
    r.d[0] = (int32_t)a.w[0] * b.w[0] + (int32_t)a.w[1] * b.w[1];
    r.d[1] = (int32_t)a.w[2] * b.w[2] + (int32_t)a.w[3] * b.w[3];
    return r;
}

/* -- bitwise ---------------------------------------------------- */
static inline RecompMmx MMX_PAND(RecompMmx a, RecompMmx b)  { RecompMmx r; r.q = a.q & b.q; return r; }
static inline RecompMmx MMX_PANDN(RecompMmx a, RecompMmx b) { RecompMmx r; r.q = ~a.q & b.q; return r; }
static inline RecompMmx MMX_POR(RecompMmx a, RecompMmx b)   { RecompMmx r; r.q = a.q | b.q; return r; }
static inline RecompMmx MMX_PXOR(RecompMmx a, RecompMmx b)  { RecompMmx r; r.q = a.q ^ b.q; return r; }

/* -- shifts -----------------------------------------------------
 * A count at or past the lane width gives zero for the logical shifts and a
 * full sign fill for the arithmetic ones. The count is the whole 64-bit
 * register, not one lane, and it is unsigned -- a negative-looking count is a
 * huge one, which saturates the same way.
 */
#define RECOMP_MMX_SHIFT(NAME, LANES, FIELD, WIDTH, OP)                 \
    static inline RecompMmx NAME(RecompMmx a, uint64_t cnt) {           \
        RecompMmx r; int i;                                             \
        for (i = 0; i < (LANES); i++)                                   \
            r.FIELD[i] = (cnt >= (WIDTH)) ? 0 : (OP);                   \
        return r;                                                       \
    }
RECOMP_MMX_SHIFT(MMX_PSLLW, 4, uw, 16, (uint16_t)(a.uw[i] << cnt))
RECOMP_MMX_SHIFT(MMX_PSRLW, 4, uw, 16, (uint16_t)(a.uw[i] >> cnt))
RECOMP_MMX_SHIFT(MMX_PSLLD, 2, ud, 32, (uint32_t)(a.ud[i] << cnt))
RECOMP_MMX_SHIFT(MMX_PSRLD, 2, ud, 32, (uint32_t)(a.ud[i] >> cnt))

static inline RecompMmx MMX_PSLLQ(RecompMmx a, uint64_t cnt) {
    RecompMmx r; r.q = (cnt >= 64) ? 0 : (a.q << cnt); return r;
}
static inline RecompMmx MMX_PSRLQ(RecompMmx a, uint64_t cnt) {
    RecompMmx r; r.q = (cnt >= 64) ? 0 : (a.q >> cnt); return r;
}
static inline RecompMmx MMX_PSRAW(RecompMmx a, uint64_t cnt) {
    RecompMmx r; int i; uint64_t c = (cnt >= 16) ? 15 : cnt;
    for (i = 0; i < 4; i++) r.w[i] = (int16_t)(a.w[i] >> c);
    return r;
}
static inline RecompMmx MMX_PSRAD(RecompMmx a, uint64_t cnt) {
    RecompMmx r; int i; uint64_t c = (cnt >= 32) ? 31 : cnt;
    for (i = 0; i < 2; i++) r.d[i] = (int32_t)(a.d[i] >> c);
    return r;
}

/* -- unpack / pack ---------------------------------------------- */
static inline RecompMmx MMX_PUNPCKLBW(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 4; i++) { r.ub[i*2] = a.ub[i]; r.ub[i*2+1] = b.ub[i]; }
    return r;
}
static inline RecompMmx MMX_PUNPCKHBW(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 4; i++) { r.ub[i*2] = a.ub[i+4]; r.ub[i*2+1] = b.ub[i+4]; }
    return r;
}
static inline RecompMmx MMX_PUNPCKLWD(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 2; i++) { r.uw[i*2] = a.uw[i]; r.uw[i*2+1] = b.uw[i]; }
    return r;
}
static inline RecompMmx MMX_PUNPCKHWD(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 2; i++) { r.uw[i*2] = a.uw[i+2]; r.uw[i*2+1] = b.uw[i+2]; }
    return r;
}
static inline RecompMmx MMX_PUNPCKLDQ(RecompMmx a, RecompMmx b) {
    RecompMmx r; r.ud[0] = a.ud[0]; r.ud[1] = b.ud[0]; return r;
}
static inline RecompMmx MMX_PUNPCKHDQ(RecompMmx a, RecompMmx b) {
    RecompMmx r; r.ud[0] = a.ud[1]; r.ud[1] = b.ud[1]; return r;
}
static inline RecompMmx MMX_PACKSSWB(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 4; i++) r.b[i]     = recomp_sat_i8(a.w[i]);
    for (i = 0; i < 4; i++) r.b[i + 4] = recomp_sat_i8(b.w[i]);
    return r;
}
static inline RecompMmx MMX_PACKUSWB(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 4; i++) r.ub[i]     = recomp_sat_u8(a.w[i]);
    for (i = 0; i < 4; i++) r.ub[i + 4] = recomp_sat_u8(b.w[i]);
    return r;
}
static inline RecompMmx MMX_PACKSSDW(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i;
    for (i = 0; i < 2; i++) r.w[i]     = recomp_sat_i16(a.d[i]);
    for (i = 0; i < 2; i++) r.w[i + 2] = recomp_sat_i16(b.d[i]);
    return r;
}

/* -- word insert / extract / shuffle ----------------------------- */
static inline RecompMmx MMX_PSHUFW(RecompMmx a, uint32_t imm) {
    RecompMmx r; int i;
    for (i = 0; i < 4; i++) r.uw[i] = a.uw[(imm >> (i * 2)) & 3];
    return r;
}
static inline RecompMmx MMX_PINSRW(RecompMmx a, uint32_t v, uint32_t imm) {
    RecompMmx r = a; r.uw[imm & 3] = (uint16_t)v; return r;
}
static inline uint32_t MMX_PEXTRW(RecompMmx a, uint32_t imm) {
    return (uint32_t)a.uw[imm & 3];
}
static inline uint32_t MMX_PMOVMSKB(RecompMmx a) {
    uint32_t m = 0; int i;
    for (i = 0; i < 8; i++) if (a.ub[i] & 0x80) m |= (1u << i);
    return m;
}
static inline RecompMmx MMX_PSADBW(RecompMmx a, RecompMmx b) {
    RecompMmx r; int i; uint32_t s = 0;
    for (i = 0; i < 8; i++)
        s += (uint32_t)(a.ub[i] > b.ub[i] ? a.ub[i] - b.ub[i] : b.ub[i] - a.ub[i]);
    r.q = 0; r.uw[0] = (uint16_t)s;
    return r;
}

#define xmm0 g_xmm0
#define xmm1 g_xmm1
#define xmm2 g_xmm2
#define xmm3 g_xmm3
#define xmm4 g_xmm4
#define xmm5 g_xmm5
#define xmm6 g_xmm6
#define xmm7 g_xmm7
#define mm0 g_mm0
#define mm1 g_mm1
#define mm2 g_mm2
#define mm3 g_mm3
#define mm4 g_mm4
#define mm5 g_mm5
#define mm6 g_mm6
#define mm7 g_mm7
/* ebp is NOT global - it's local in each function.
 * For __SEH_prolog/epilog, use g_seh_ebp to bridge. */
#endif

/* ================================================================
 * Forward declarations for translated functions
 *
 * These are generated by the recompiler and included per-file.
 * The recomp_funcs.h header (generated) declares all translated
 * function prototypes.
 * ================================================================ */

/* An instruction the lifter has no translation for.
 *
 * The lifter used to emit a bare "TODO: mnemonic" C comment at such a site,
 * and a comment is a no-op: the instruction vanished, the guest carried
 * on, and nothing at runtime could say the site had been reached. Wreckless
 * died inside RtlAllocateHeap because `bsf` was a comment; Half-Life 2 painted
 * its intro red because `cvtpi2ps` was. Each was found by working backwards
 * from a subsystem failure that had nothing to do with the cause.
 *
 * Now the site calls this, with the instruction text and its guest address.
 * The instruction is STILL a no-op -- this changes no behaviour -- but the run
 * says which untranslated sites it reached, how often, and with what register
 * state, and with RECOMP_UNIMPL_TRAP=1 it stops at the first one. The lifter
 * keeps the comment beside the call so `grep TODO:` over a gen tree still
 * enumerates every site whether or not it is ever reached. */
void recomp_unimpl(const char *text, uint32_t va);
#define RECOMP_UNIMPL(_text, _va) recomp_unimpl((_text), (_va))

/* ---- cached register-file addresses (generated function files only: RECOMP_REGS_CACHE) -------------------
 * g_eax & co. are thread-local, and because every guest memory access is volatile the compiler reloaded the
 * thread-local base (gs:[58h], then the block) before almost every one of them. Each generated function now
 * starts with RC_REGS_PROLOGUE, which takes the addresses once (and g_xbox_mem_offset, which never changes
 * after start-up); the names below then go through those locals. A function never changes host thread while
 * it runs, so nothing changes meaning. Everything else keeps using the thread-local variables directly. */
#ifdef RECOMP_REGS_CACHE
static __forceinline uint32_t *rc_a_eax(void) { return &g_eax; }
static __forceinline uint32_t *rc_a_ecx(void) { return &g_ecx; }
static __forceinline uint32_t *rc_a_edx(void) { return &g_edx; }
static __forceinline uint32_t *rc_a_esp(void) { return &g_esp; }
static __forceinline uint32_t *rc_a_ebx(void) { return &g_ebx; }
static __forceinline uint32_t *rc_a_esi(void) { return &g_esi; }
static __forceinline uint32_t *rc_a_edi(void) { return &g_edi; }
static __forceinline uint32_t *rc_a_ebp(void) { return &g_ebp; }
static __forceinline uint32_t *rc_a_seh_ebp(void) { return &g_seh_ebp; }
static __forceinline uint32_t *rc_a_fs_base(void) { return &g_fs_base; }
static __forceinline int *rc_a_fp_top(void) { return &g_fp_top; }
static __forceinline double *rc_a_fp_stack(void) { return g_fp_stack; }
static __forceinline RecompXmm *rc_a_xmm0(void) { return &g_xmm0; }
static __forceinline RecompXmm *rc_a_xmm1(void) { return &g_xmm1; }
static __forceinline RecompXmm *rc_a_xmm2(void) { return &g_xmm2; }
static __forceinline RecompXmm *rc_a_xmm3(void) { return &g_xmm3; }
#define RC_REGS_PROLOGUE1 uint32_t *const _p_eax = rc_a_eax(), *const _p_ecx = rc_a_ecx(), *const _p_edx = rc_a_edx();
#define RC_REGS_PROLOGUE2 uint32_t *const _p_esp = rc_a_esp(), *const _p_ebx = rc_a_ebx(), *const _p_esi = rc_a_esi();
#define RC_REGS_PROLOGUE3 uint32_t *const _p_edi = rc_a_edi(), *const _p_ebp = rc_a_ebp(), *const _p_seh_ebp = rc_a_seh_ebp();
#define RC_REGS_PROLOGUE4 uint32_t *const _p_fs_base = rc_a_fs_base(); int *const _p_fp_top = rc_a_fp_top(); double *const _p_fp_stack = rc_a_fp_stack();
#define RC_REGS_PROLOGUE5 RecompXmm *const _p_xmm0 = rc_a_xmm0(), *const _p_xmm1 = rc_a_xmm1(), *const _p_xmm2 = rc_a_xmm2(), *const _p_xmm3 = rc_a_xmm3();
#define RC_REGS_PROLOGUE6 const ptrdiff_t _mo = g_xbox_mem_offset;
#define RC_REGS_PROLOGUE RC_REGS_PROLOGUE1 RC_REGS_PROLOGUE2 RC_REGS_PROLOGUE3 RC_REGS_PROLOGUE4 RC_REGS_PROLOGUE5 RC_REGS_PROLOGUE6
#define g_eax (*_p_eax)
#define g_ecx (*_p_ecx)
#define g_edx (*_p_edx)
#define g_esp (*_p_esp)
#define g_ebx (*_p_ebx)
#define g_esi (*_p_esi)
#define g_edi (*_p_edi)
#define g_ebp (*_p_ebp)
#define g_seh_ebp (*_p_seh_ebp)
#define g_fs_base (*_p_fs_base)
#define g_fp_top (*_p_fp_top)
#define g_fp_stack _p_fp_stack
#define g_xmm0 (*_p_xmm0)
#define g_xmm1 (*_p_xmm1)
#define g_xmm2 (*_p_xmm2)
#define g_xmm3 (*_p_xmm3)
#undef XBOX_PTR
#define XBOX_PTR(addr) ((uintptr_t)(uint32_t)(addr) + _mo)
#else
#define RC_REGS_PROLOGUE
#endif

#endif /* RECOMP_TYPES_H */
