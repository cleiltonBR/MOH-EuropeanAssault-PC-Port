/**
 * Medal of Honor: European Assault - Recompiled code chunk 20
 * Functions: 1000 (0x002CFF1E - 0x002DE6B0)
 */

#define RECOMP_GENERATED_CODE
#include "recomp_funcs.h"
#include <math.h>

/**
 * sub_002CFF1E
 * Original: 0x002CFF1E - 0x002CFF20 (2 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFF1E(void)
{

loc_002CFF1E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CFF20
 * Original: 0x002CFF20 - 0x002CFF40 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFF20(void)
{

loc_002CFF20: ;
    PUSH32(esp, 0x1A00);
    PUSH32(esp, 0x305D20);
    ecx = 0x3BC8B4;
    PUSH32(esp, 0x002CFF34u); RECOMP_ABI_CALL(0x00065970u, sub_00065970); /* call 0x00065970 */

loc_002CFF34: ;
    PUSH32(esp, 0x2D67A0);
    PUSH32(esp, 0x002CFF3Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002CFF3E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002CFF40
 * Original: 0x002CFF40 - 0x002CFF71 (49 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFF40(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFF40: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373020);
    ecx = esp + 4;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 4) = 0x305E38;
    { uint32_t _icall_target = MEM32(0x305E40); PUSH32(esp, 0x002CFF67u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFF61u); } /* indirect call */
    }

loc_002CFF67: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFF6Du); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFF6D: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFF80
 * Original: 0x002CFF80 - 0x002CFFAD (45 bytes, 12 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFF80(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFF80: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373024);
    ecx = esp + 4;
    MEM32(esp + 8) = eax;
    MEM32(esp + 4) = 0x305E7C;
    { uint32_t _icall_target = MEM32(0x305E84); PUSH32(esp, 0x002CFFA3u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002CFF9Du); } /* indirect call */
    }

loc_002CFFA3: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002CFFA9u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002CFFA9: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFFB0
 * Original: 0x002CFFB0 - 0x002CFFC9 (25 bytes, 4 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFFB0(void)
{

loc_002CFFB0: ;
    xmm0 = XMM_SCALAR(MEMF(0x37303C)); /* movss */
    xmm0.f[0] = xmm0.f[0] * MEMF(0x2FEFB4); /* mulss */
    MEMF(0x3BC900) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFFD0
 * Original: 0x002CFFD0 - 0x002CFFE9 (25 bytes, 4 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFFD0(void)
{

loc_002CFFD0: ;
    xmm0 = XMM_SCALAR(MEMF(0x37303C)); /* movss */
    xmm0.f[0] = xmm0.f[0] * MEMF(0x2FEFB4); /* mulss */
    MEMF(0x3BC914) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002CFFF0
 * Original: 0x002CFFF0 - 0x002D0029 (57 bytes, 15 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002CFFF0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002CFFF0: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    MEM32(esp + 0xC) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373028);
    ecx = esp + 4;
    MEM32(esp + 0x14) = eax;
    MEM32(esp + 4) = 0x305EC0;
    { uint32_t _icall_target = MEM32(0x305EC8); PUSH32(esp, 0x002D001Fu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0019u); } /* indirect call */
    }

loc_002D001F: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0025u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0025: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x1C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0000
 * Original: 0x002D0000 - 0x002D0029 (41 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0000(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0000: ;
    MEM32(esp + 0xC) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373028);
    ecx = esp + 4;
    MEM32(esp + 0x14) = eax;
    MEM32(esp + 4) = 0x305EC0;
    { uint32_t _icall_target = MEM32(0x305EC8); PUSH32(esp, 0x002D001Fu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0019u); } /* indirect call */
    }

loc_002D001F: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0025u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0025: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x1C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0004
 * Original: 0x002D0004 - 0x002D0029 (37 bytes, 9 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0004(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0004: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373028);
    ecx = esp + 4;
    MEM32(esp + 0x14) = eax;
    MEM32(esp + 4) = 0x305EC0;
    { uint32_t _icall_target = MEM32(0x305EC8); PUSH32(esp, 0x002D001Fu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0019u); } /* indirect call */
    }

loc_002D001F: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0025u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0025: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x1C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0030
 * Original: 0x002D0030 - 0x002D0049 (25 bytes, 4 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0030(void)
{

loc_002D0030: ;
    xmm0 = XMM_SCALAR(MEMF(0x37303C)); /* movss */
    xmm0.f[0] = xmm0.f[0] * MEMF(0x2FEFB4); /* mulss */
    MEMF(0x3BC928) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0050
 * Original: 0x002D0050 - 0x002D0081 (49 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0050(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0050: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x37302C);
    ecx = esp + 4;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 4) = 0x305F04;
    { uint32_t _icall_target = MEM32(0x305F0C); PUSH32(esp, 0x002D0077u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0071u); } /* indirect call */
    }

loc_002D0077: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D007Du); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D007D: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0090
 * Original: 0x002D0090 - 0x002D00C5 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0090(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0090: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373030);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x305F50;
    { uint32_t _icall_target = MEM32(0x305F58); PUSH32(esp, 0x002D00BBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D00B5u); } /* indirect call */
    }

loc_002D00BB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D00C1u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D00C1: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D00D0
 * Original: 0x002D00D0 - 0x002D00E9 (25 bytes, 4 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D00D0(void)
{

loc_002D00D0: ;
    xmm0 = XMM_SCALAR(MEMF(0x37303C)); /* movss */
    xmm0.f[0] = xmm0.f[0] * MEMF(0x2FEFB4); /* mulss */
    MEMF(0x3BC93C) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D00F0
 * Original: 0x002D00F0 - 0x002D0125 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D00F0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D00F0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373034);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x305FA4;
    { uint32_t _icall_target = MEM32(0x305FAC); PUSH32(esp, 0x002D011Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0115u); } /* indirect call */
    }

loc_002D011B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0121u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0121: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0130
 * Original: 0x002D0130 - 0x002D0149 (25 bytes, 4 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0130(void)
{

loc_002D0130: ;
    xmm0 = XMM_SCALAR(MEMF(0x37303C)); /* movss */
    xmm0.f[0] = xmm0.f[0] * MEMF(0x2FEFB4); /* mulss */
    MEMF(0x3BC950) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0150
 * Original: 0x002D0150 - 0x002D0185 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0150(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0150: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373038);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x305FEC;
    { uint32_t _icall_target = MEM32(0x305FF4); PUSH32(esp, 0x002D017Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0175u); } /* indirect call */
    }

loc_002D017B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0181u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0181: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0190
 * Original: 0x002D0190 - 0x002D01C5 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0190(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0190: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373044);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x306030;
    { uint32_t _icall_target = MEM32(0x306038); PUSH32(esp, 0x002D01BBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D01B5u); } /* indirect call */
    }

loc_002D01BB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D01C1u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D01C1: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D01D0
 * Original: 0x002D01D0 - 0x002D0205 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D01D0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D01D0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x37304C);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x306080;
    { uint32_t _icall_target = MEM32(0x306088); PUSH32(esp, 0x002D01FBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D01F5u); } /* indirect call */
    }

loc_002D01FB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0201u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0201: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0210
 * Original: 0x002D0210 - 0x002D0241 (49 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0210(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0210: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373054);
    ecx = esp + 4;
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 4) = 0x3060C4;
    { uint32_t _icall_target = MEM32(0x3060CC); PUSH32(esp, 0x002D0237u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0231u); } /* indirect call */
    }

loc_002D0237: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D023Du); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D023D: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0250
 * Original: 0x002D0250 - 0x002D0285 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0250(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0250: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x37305C);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x306110;
    { uint32_t _icall_target = MEM32(0x306118); PUSH32(esp, 0x002D027Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0275u); } /* indirect call */
    }

loc_002D027B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0281u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0281: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0290
 * Original: 0x002D0290 - 0x002D02C9 (57 bytes, 15 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0290(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0290: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    MEM32(esp + 0xC) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373064);
    ecx = esp + 4;
    MEM32(esp + 0x14) = eax;
    MEM32(esp + 4) = 0x306168;
    { uint32_t _icall_target = MEM32(0x306170); PUSH32(esp, 0x002D02BFu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D02B9u); } /* indirect call */
    }

loc_002D02BF: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D02C5u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D02C5: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x1C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D02D0
 * Original: 0x002D02D0 - 0x002D0305 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D02D0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D02D0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x37306C);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x3061C8;
    { uint32_t _icall_target = MEM32(0x3061D0); PUSH32(esp, 0x002D02FBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D02F5u); } /* indirect call */
    }

loc_002D02FB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0301u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0301: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0310
 * Original: 0x002D0310 - 0x002D0345 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0310(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0310: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373074);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x306224;
    { uint32_t _icall_target = MEM32(0x30622C); PUSH32(esp, 0x002D033Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0335u); } /* indirect call */
    }

loc_002D033B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0341u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0341: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0313
 * Original: 0x002D0313 - 0x002D0345 (50 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0313(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0313: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373074);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x306224;
    { uint32_t _icall_target = MEM32(0x30622C); PUSH32(esp, 0x002D033Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0335u); } /* indirect call */
    }

loc_002D033B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0341u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0341: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0350
 * Original: 0x002D0350 - 0x002D0385 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0350(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0350: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x37307C);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x306278;
    { uint32_t _icall_target = MEM32(0x306280); PUSH32(esp, 0x002D037Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0375u); } /* indirect call */
    }

loc_002D037B: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D0381u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D0381: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0390
 * Original: 0x002D0390 - 0x002D03C5 (53 bytes, 14 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0390(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0390: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(esp) = eax;
    MEM32(esp + 4) = eax;
    MEM32(esp + 8) = eax;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x373084);
    ecx = esp + 4;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 4) = 0x3062CC;
    { uint32_t _icall_target = MEM32(0x3062D4); PUSH32(esp, 0x002D03BBu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D03B5u); } /* indirect call */
    }

loc_002D03BB: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D03C1u); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D03C1: ;
    _fb = (uint32_t)(0x18) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x18;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D03D0
 * Original: 0x002D03D0 - 0x002D03DC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D03D0(void)
{

loc_002D03D0: ;
    PUSH32(esp, 0x2D69B0);
    PUSH32(esp, 0x002D03DAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D03DA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D03E0
 * Original: 0x002D03E0 - 0x002D03EC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D03E0(void)
{

loc_002D03E0: ;
    PUSH32(esp, 0x2D69C0);
    PUSH32(esp, 0x002D03EAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D03EA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D03F0
 * Original: 0x002D03F0 - 0x002D0406 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D03F0(void)
{

loc_002D03F0: ;
    ecx = 0x3BE9A0;
    PUSH32(esp, 0x002D03FAu); RECOMP_ABI_CALL(0x000740E0u, sub_000740E0); /* call 0x000740E0 */

loc_002D03FA: ;
    PUSH32(esp, 0x2D69D0);
    PUSH32(esp, 0x002D0404u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D0404: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D0410
 * Original: 0x002D0410 - 0x002D0446 (54 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0410(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0410: ;
    _fb = (uint32_t)(0x48) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x48;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, edi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ecx = 0x12;
    edi = esp + 4;
    { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4); for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = eax; edi += ecx * _st; }
    ecx = 0; /* rep stosd */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x3731D4);
    ecx = esp + 8;
    MEM32(esp + 8) = 0x306350;
    { uint32_t _icall_target = MEM32(0x306358); PUSH32(esp, 0x002D0438u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0432u); } /* indirect call */
    }

loc_002D0438: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D043Eu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D043E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    _fb = (uint32_t)(0x48) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x48;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0450
 * Original: 0x002D0450 - 0x002D0486 (54 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0450(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0450: ;
    _fb = (uint32_t)(0x50) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x50;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, edi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ecx = 0x14;
    edi = esp + 4;
    { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4); for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = eax; edi += ecx * _st; }
    ecx = 0; /* rep stosd */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x3731D8);
    ecx = esp + 8;
    MEM32(esp + 8) = 0x306370;
    { uint32_t _icall_target = MEM32(0x306378); PUSH32(esp, 0x002D0478u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D0472u); } /* indirect call */
    }

loc_002D0478: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D047Eu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D047E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    _fb = (uint32_t)(0x50) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x50;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0490
 * Original: 0x002D0490 - 0x002D04C6 (54 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0490(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0490: ;
    _fb = (uint32_t)(0x50) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x50;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, edi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ecx = 0x14;
    edi = esp + 4;
    { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4); for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = eax; edi += ecx * _st; }
    ecx = 0; /* rep stosd */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x3731DC);
    ecx = esp + 8;
    MEM32(esp + 8) = 0x30638C;
    { uint32_t _icall_target = MEM32(0x306394); PUSH32(esp, 0x002D04B8u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D04B2u); } /* indirect call */
    }

loc_002D04B8: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D04BEu); RECOMP_ABI_CALL(0x001531E0u, sub_001531E0); /* call 0x001531E0 */

loc_002D04BE: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    _fb = (uint32_t)(0x50) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x50;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D04D0
 * Original: 0x002D04D0 - 0x002D0505 (53 bytes, 17 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D04D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D04D0: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x3BECE0;
    edi = 0x1A;
    /* nop */

loc_002D04E0: ;
    PUSH32(esp, 0xE8840);
    PUSH32(esp, 0x10);
    PUSH32(esp, 0x20);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002D04EFu); RECOMP_ABI_CALL(0x00012790u, sub_00012790); /* call 0x00012790 */

loc_002D04EF: ;
    MEM32(esi + 0x200) = 0;
    _fb = (uint32_t)(0x220) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 0x220;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D04E0; /* jne: not equal / not zero */

loc_002D0502: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D0510
 * Original: 0x002D0510 - 0x002D0531 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0510(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0510: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C2420) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0540
 * Original: 0x002D0540 - 0x002D0561 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0540(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0540: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C2424) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0570
 * Original: 0x002D0570 - 0x002D0591 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0570(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0570: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C2428) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D05A0
 * Original: 0x002D05A0 - 0x002D05AC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D05A0(void)
{

loc_002D05A0: ;
    PUSH32(esp, 0x2D69E0);
    PUSH32(esp, 0x002D05AAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D05AA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D05B0
 * Original: 0x002D05B0 - 0x002D05C6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D05B0(void)
{

loc_002D05B0: ;
    ecx = 0x3C2470;
    PUSH32(esp, 0x002D05BAu); RECOMP_ABI_CALL(0x000779E0u, sub_000779E0); /* call 0x000779E0 */

loc_002D05BA: ;
    PUSH32(esp, 0x2D69F0);
    PUSH32(esp, 0x002D05C4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D05C4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D05D0
 * Original: 0x002D05D0 - 0x002D05F1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D05D0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D05D0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C2E34) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0600
 * Original: 0x002D0600 - 0x002D0621 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0600(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0600: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C2E38) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0630
 * Original: 0x002D0630 - 0x002D0640 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0630(void)
{

loc_002D0630: ;
    PUSH32(esp, 0x307498);
    ecx = 0x3C2E48;
    PUSH32(esp, 0x002D063Fu); RECOMP_ABI_CALL(0x002643D0u, sub_002643D0); /* call 0x002643D0 */

loc_002D063F: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0640
 * Original: 0x002D0640 - 0x002D0650 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0640(void)
{

loc_002D0640: ;
    PUSH32(esp, 0x3074B0);
    ecx = 0x3C2E4C;
    PUSH32(esp, 0x002D064Fu); RECOMP_ABI_CALL(0x002643D0u, sub_002643D0); /* call 0x002643D0 */

loc_002D064F: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0650
 * Original: 0x002D0650 - 0x002D0660 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0650(void)
{

loc_002D0650: ;
    PUSH32(esp, 0x3074C0);
    ecx = 0x3C2E50;
    PUSH32(esp, 0x002D065Fu); RECOMP_ABI_CALL(0x002643D0u, sub_002643D0); /* call 0x002643D0 */

loc_002D065F: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0660
 * Original: 0x002D0660 - 0x002D0690 (48 bytes, 24 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0660(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0660: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C2F30) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0690
 * Original: 0x002D0690 - 0x002D06A6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0690(void)
{

loc_002D0690: ;
    ecx = 0x3C2F40;
    PUSH32(esp, 0x002D069Au); RECOMP_ABI_CALL(0x00181DD0u, sub_00181DD0); /* call 0x00181DD0 */

loc_002D069A: ;
    PUSH32(esp, 0x2D6A10);
    PUSH32(esp, 0x002D06A4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D06A4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D06B0
 * Original: 0x002D06B0 - 0x002D06D0 (32 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D06B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D06B0: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x3C2FD0;
    edi = 0xC;
    /* nop */

loc_002D06C0: ;
    ecx = esi;
    PUSH32(esp, 0x002D06C7u); RECOMP_ABI_CALL(0x00194D10u, sub_00194D10); /* call 0x00194D10 */

loc_002D06C7: ;
    _fb = (uint32_t)(0x70) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 0x70;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D06C0; /* jne: not equal / not zero */

loc_002D06CD: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D06D0
 * Original: 0x002D06D0 - 0x002D06E0 (16 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D06D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D06D0: ;
    ecx = 0x3C3510;
    g_seh_ebp = ebp; sub_00194D10(); return; /* tail jmp 0x00194D10 */

    /* int3: debug-trap slide byte, stepped over */
    /* int3: debug-trap slide byte, stepped over */
    /* int3: debug-trap slide byte, stepped over */
    /* int3: debug-trap slide byte, stepped over */
    /* int3: debug-trap slide byte, stepped over */
    /* int3: debug-trap slide byte, stepped over */

}

/**
 * sub_002D06E0
 * Original: 0x002D06E0 - 0x002D06EB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D06E0(void)
{

loc_002D06E0: ;
    MEM32(0x3C3580) = 0x3C3510;
    esp += 4; return; /* ret */

}

/**
 * sub_002D06F0
 * Original: 0x002D06F0 - 0x002D0711 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D06F0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D06F0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C35A4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0720
 * Original: 0x002D0720 - 0x002D074A (42 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0720(void)
{

loc_002D0720: ;
    ecx = 0x3C35B0;
    PUSH32(esp, 0x002D072Au); RECOMP_ABI_CALL(0x00014260u, sub_00014260); /* call 0x00014260 */

loc_002D072A: ;
    PUSH32(esp, 0x2D6A20);
    MEM32(0x3C35B0) = 0x307AF8;
    MEM32(0x3C35B8) = 0x307AEC;
    PUSH32(esp, 0x002D0748u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D0748: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D0750
 * Original: 0x002D0750 - 0x002D0771 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0750(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0750: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3680) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0780
 * Original: 0x002D0780 - 0x002D0795 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0780(void)
{

loc_002D0780: ;
    PUSH32(esp, 0x83900);
    PUSH32(esp, 0x307CAC);
    ecx = 0x3C3690;
    PUSH32(esp, 0x002D0794u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D0794: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D07A0
 * Original: 0x002D07A0 - 0x002D07C1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D07A0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D07A0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C36A4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D07D0
 * Original: 0x002D07D0 - 0x002D07E5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D07D0(void)
{

loc_002D07D0: ;
    PUSH32(esp, 0x83C90);
    PUSH32(esp, 0x307E14);
    ecx = 0x3C36A8;
    PUSH32(esp, 0x002D07E4u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D07E4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D07F0
 * Original: 0x002D07F0 - 0x002D0811 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D07F0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D07F0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C36B8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0820
 * Original: 0x002D0820 - 0x002D0837 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0820(void)
{

loc_002D0820: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x84DE0);
    PUSH32(esp, 0x842442CDu);
    ecx = 0x3C36CC;
    PUSH32(esp, 0x002D0836u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0836: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0840
 * Original: 0x002D0840 - 0x002D0861 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0840(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0840: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C36DC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0870
 * Original: 0x002D0870 - 0x002D0887 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0870(void)
{

loc_002D0870: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x851C0);
    PUSH32(esp, 0x1F529134);
    ecx = 0x3C36E0;
    PUSH32(esp, 0x002D0886u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0886: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0890
 * Original: 0x002D0890 - 0x002D08B7 (39 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0890(void)
{

loc_002D0890: ;
    PUSH32(esp, 0xE0);
    PUSH32(esp, 2);
    ecx = 0x3C36F0;
    PUSH32(esp, 0x002D08A1u); RECOMP_ABI_CALL(0x001567B0u, sub_001567B0); /* call 0x001567B0 */

loc_002D08A1: ;
    PUSH32(esp, 0x2D6A40);
    MEM32(0x3C36F0) = 0x3082A4;
    PUSH32(esp, 0x002D08B5u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D08B5: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D08C0
 * Original: 0x002D08C0 - 0x002D08D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D08C0(void)
{

loc_002D08C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x85B50);
    PUSH32(esp, 0x31FC0A5A);
    ecx = 0x3C370C;
    PUSH32(esp, 0x002D08D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D08D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D08E0
 * Original: 0x002D08E0 - 0x002D08F7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D08E0(void)
{

loc_002D08E0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x85D60);
    PUSH32(esp, 0x17D0180E);
    ecx = 0x3C371C;
    PUSH32(esp, 0x002D08F6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D08F6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0900
 * Original: 0x002D0900 - 0x002D0921 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0900(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0900: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C372C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0930
 * Original: 0x002D0930 - 0x002D0947 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0930(void)
{

loc_002D0930: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x86530);
    PUSH32(esp, 0xE236819Du);
    ecx = 0x3C3730;
    PUSH32(esp, 0x002D0946u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0946: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0950
 * Original: 0x002D0950 - 0x002D0967 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0950(void)
{

loc_002D0950: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x86A70);
    PUSH32(esp, 0xED7FCEBEu);
    ecx = 0x3C374C;
    PUSH32(esp, 0x002D0966u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0966: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0970
 * Original: 0x002D0970 - 0x002D0987 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0970(void)
{

loc_002D0970: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x87140);
    PUSH32(esp, 0xCDB7E17Bu);
    ecx = 0x3C375C;
    PUSH32(esp, 0x002D0986u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0986: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0990
 * Original: 0x002D0990 - 0x002D09B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0990(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0990: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3770) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D09C0
 * Original: 0x002D09C0 - 0x002D09D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D09C0(void)
{

loc_002D09C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x876F0);
    PUSH32(esp, 0x5794B35);
    ecx = 0x3C3774;
    PUSH32(esp, 0x002D09D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D09D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D09E0
 * Original: 0x002D09E0 - 0x002D09F7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D09E0(void)
{

loc_002D09E0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x87BE0);
    PUSH32(esp, 0x5D21A6A2);
    ecx = 0x3C3784;
    PUSH32(esp, 0x002D09F6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D09F6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0A00
 * Original: 0x002D0A00 - 0x002D0A21 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0A00(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0A00: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C37A0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0A30
 * Original: 0x002D0A30 - 0x002D0A47 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0A30(void)
{

loc_002D0A30: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x87FC0);
    PUSH32(esp, 0x32830CF4);
    ecx = 0x3C37A4;
    PUSH32(esp, 0x002D0A46u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0A46: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0A50
 * Original: 0x002D0A50 - 0x002D0A71 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0A50(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0A50: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C37BC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0A80
 * Original: 0x002D0A80 - 0x002D0ABC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0A80(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D0A80: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D0A87u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D0A87: ;
    MEM32(0x3C37C0) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3C37C4) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3C37C0);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3C37C0);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3C37C0);
    PUSH32(esp, 0x2D6A70);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D0AB8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D0AB8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D0AC0
 * Original: 0x002D0AC0 - 0x002D0AD7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0AC0(void)
{

loc_002D0AC0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8A7E0);
    PUSH32(esp, 0x5301FB45);
    ecx = 0x3C37CC;
    PUSH32(esp, 0x002D0AD6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0AD6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0AE0
 * Original: 0x002D0AE0 - 0x002D0AF7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0AE0(void)
{

loc_002D0AE0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8ACF0);
    PUSH32(esp, 0x358EC95D);
    ecx = 0x3C37E4;
    PUSH32(esp, 0x002D0AF6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0AF6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0B00
 * Original: 0x002D0B00 - 0x002D0B17 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0B00(void)
{

loc_002D0B00: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8B0D0);
    PUSH32(esp, 0x1EEA0D80);
    ecx = 0x3C37F4;
    PUSH32(esp, 0x002D0B16u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0B16: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0B20
 * Original: 0x002D0B20 - 0x002D0B41 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0B20(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0B20: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3804) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0B50
 * Original: 0x002D0B50 - 0x002D0B67 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0B50(void)
{

loc_002D0B50: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8BAA0);
    PUSH32(esp, 0x8BE28683u);
    ecx = 0x3C3808;
    PUSH32(esp, 0x002D0B66u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0B66: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0B70
 * Original: 0x002D0B70 - 0x002D0B87 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0B70(void)
{

loc_002D0B70: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8BD60);
    PUSH32(esp, 0x2F157A14);
    ecx = 0x3C3818;
    PUSH32(esp, 0x002D0B86u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0B86: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0B90
 * Original: 0x002D0B90 - 0x002D0BB1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0B90(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0B90: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3828) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0BC0
 * Original: 0x002D0BC0 - 0x002D0BD7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0BC0(void)
{

loc_002D0BC0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8CA70);
    PUSH32(esp, 0x4A72A63F);
    ecx = 0x3C382C;
    PUSH32(esp, 0x002D0BD6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0BD6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0BE0
 * Original: 0x002D0BE0 - 0x002D0BF7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0BE0(void)
{

loc_002D0BE0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8D0B0);
    PUSH32(esp, 0xE9FADE4);
    ecx = 0x3C3848;
    PUSH32(esp, 0x002D0BF6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0BF6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0C00
 * Original: 0x002D0C00 - 0x002D0C21 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0C00(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0C00: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3864) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0C30
 * Original: 0x002D0C30 - 0x002D0C47 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0C30(void)
{

loc_002D0C30: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8D550);
    PUSH32(esp, 0x705582AA);
    ecx = 0x3C3868;
    PUSH32(esp, 0x002D0C46u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0C46: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0C50
 * Original: 0x002D0C50 - 0x002D0C71 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0C50(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0C50: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3878) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0C80
 * Original: 0x002D0C80 - 0x002D0C97 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0C80(void)
{

loc_002D0C80: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8D8C0);
    PUSH32(esp, 0x6F4899C8);
    ecx = 0x3C387C;
    PUSH32(esp, 0x002D0C96u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0C96: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0CA0
 * Original: 0x002D0CA0 - 0x002D0CC1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0CA0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0CA0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3898) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0CD0
 * Original: 0x002D0CD0 - 0x002D0CE7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0CD0(void)
{

loc_002D0CD0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8DE30);
    PUSH32(esp, 0x2F6CEE63);
    ecx = 0x3C389C;
    PUSH32(esp, 0x002D0CE6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0CE6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0CF0
 * Original: 0x002D0CF0 - 0x002D0D11 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0CF0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0CF0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C38AC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0D20
 * Original: 0x002D0D20 - 0x002D0D37 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0D20(void)
{

loc_002D0D20: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8F000);
    PUSH32(esp, 0xB73A8280u);
    ecx = 0x3C38B0;
    PUSH32(esp, 0x002D0D36u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0D36: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0D40
 * Original: 0x002D0D40 - 0x002D0D61 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0D40(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0D40: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C38C8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0D70
 * Original: 0x002D0D70 - 0x002D0D87 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0D70(void)
{

loc_002D0D70: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8F430);
    PUSH32(esp, 0xB1A521DFu);
    ecx = 0x3C38CC;
    PUSH32(esp, 0x002D0D86u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0D86: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0D90
 * Original: 0x002D0D90 - 0x002D0DA7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0D90(void)
{

loc_002D0D90: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x8FC20);
    PUSH32(esp, 0x4C80697C);
    ecx = 0x3C38DC;
    PUSH32(esp, 0x002D0DA6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0DA6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0DB0
 * Original: 0x002D0DB0 - 0x002D0DC7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0DB0(void)
{

loc_002D0DB0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x900B0);
    PUSH32(esp, 0x65A22CE4);
    ecx = 0x3C38EC;
    PUSH32(esp, 0x002D0DC6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0DC6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0DD0
 * Original: 0x002D0DD0 - 0x002D0DF1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0DD0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0DD0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3908) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0E00
 * Original: 0x002D0E00 - 0x002D0E17 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0E00(void)
{

loc_002D0E00: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x90430);
    PUSH32(esp, 0x91140104u);
    ecx = 0x3C390C;
    PUSH32(esp, 0x002D0E16u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0E16: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0E20
 * Original: 0x002D0E20 - 0x002D0E37 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0E20(void)
{

loc_002D0E20: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x90590);
    PUSH32(esp, 0x8226D723u);
    ecx = 0x3C391C;
    PUSH32(esp, 0x002D0E36u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0E36: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0E40
 * Original: 0x002D0E40 - 0x002D0E61 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0E40(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0E40: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3938) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0E70
 * Original: 0x002D0E70 - 0x002D0E87 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0E70(void)
{

loc_002D0E70: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x90970);
    PUSH32(esp, 0x42FA126F);
    ecx = 0x3C393C;
    PUSH32(esp, 0x002D0E86u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0E86: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0E90
 * Original: 0x002D0E90 - 0x002D0EA7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0E90(void)
{

loc_002D0E90: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x90BF0);
    PUSH32(esp, 0x616011F9);
    ecx = 0x3C394C;
    PUSH32(esp, 0x002D0EA6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0EA6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0EB0
 * Original: 0x002D0EB0 - 0x002D0EC7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0EB0(void)
{

loc_002D0EB0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x91190);
    PUSH32(esp, 0x4660A155);
    ecx = 0x3C395C;
    PUSH32(esp, 0x002D0EC6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0EC6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0ED0
 * Original: 0x002D0ED0 - 0x002D0EF1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0ED0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0ED0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3970) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0F00
 * Original: 0x002D0F00 - 0x002D0F17 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0F00(void)
{

loc_002D0F00: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x920C0);
    PUSH32(esp, 0x858EBBE8u);
    ecx = 0x3C3974;
    PUSH32(esp, 0x002D0F16u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0F16: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0F20
 * Original: 0x002D0F20 - 0x002D0F37 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0F20(void)
{

loc_002D0F20: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x923D0);
    PUSH32(esp, 0x79305CDC);
    ecx = 0x3C3984;
    PUSH32(esp, 0x002D0F36u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0F36: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0F40
 * Original: 0x002D0F40 - 0x002D0F61 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0F40(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0F40: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3994) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D0F70
 * Original: 0x002D0F70 - 0x002D0F87 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0F70(void)
{

loc_002D0F70: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x92A70);
    PUSH32(esp, 0xC54CFB0Eu);
    ecx = 0x3C3998;
    PUSH32(esp, 0x002D0F86u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0F86: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0F90
 * Original: 0x002D0F90 - 0x002D0FA7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0F90(void)
{

loc_002D0F90: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x92CD0);
    PUSH32(esp, 0x40B70819);
    ecx = 0x3C39D0;
    PUSH32(esp, 0x002D0FA6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D0FA6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0FB0
 * Original: 0x002D0FB0 - 0x002D0FC5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D0FB0(void)
{

loc_002D0FB0: ;
    PUSH32(esp, 0x92BD0);
    PUSH32(esp, 0x30B61C);
    ecx = 0x3C39E0;
    PUSH32(esp, 0x002D0FC4u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D0FC4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D0FD0
 * Original: 0x002D0FD0 - 0x002D0FF1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D0FD0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D0FD0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C39F0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1000
 * Original: 0x002D1000 - 0x002D1017 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1000(void)
{

loc_002D1000: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x93420);
    PUSH32(esp, 0x9312A35Fu);
    ecx = 0x3C39F4;
    PUSH32(esp, 0x002D1016u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1016: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1020
 * Original: 0x002D1020 - 0x002D1037 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1020(void)
{

loc_002D1020: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x93F90);
    PUSH32(esp, 0xACEA45FDu);
    ecx = 0x3C3A04;
    PUSH32(esp, 0x002D1036u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1036: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1040
 * Original: 0x002D1040 - 0x002D1061 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1040(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1040: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3A18) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1070
 * Original: 0x002D1070 - 0x002D1087 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1070(void)
{

loc_002D1070: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x94E60);
    PUSH32(esp, 0xA644C06);
    ecx = 0x3C3A1C;
    PUSH32(esp, 0x002D1086u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1086: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1090
 * Original: 0x002D1090 - 0x002D10B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1090(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1090: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3A9C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D10C0
 * Original: 0x002D10C0 - 0x002D10D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D10C0(void)
{

loc_002D10C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x95860);
    PUSH32(esp, 0x500F4F9A);
    ecx = 0x3C3AA0;
    PUSH32(esp, 0x002D10D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D10D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D10E0
 * Original: 0x002D10E0 - 0x002D1101 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D10E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D10E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3AB0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1110
 * Original: 0x002D1110 - 0x002D1127 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1110(void)
{

loc_002D1110: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x95B30);
    PUSH32(esp, 0xEAACEE9Bu);
    ecx = 0x3C3AB4;
    PUSH32(esp, 0x002D1126u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1126: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1130
 * Original: 0x002D1130 - 0x002D1151 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1130(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1130: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3AD0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1160
 * Original: 0x002D1160 - 0x002D1177 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1160(void)
{

loc_002D1160: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x95EC0);
    PUSH32(esp, 0x4D25CE32);
    ecx = 0x3C3AD4;
    PUSH32(esp, 0x002D1176u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1176: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1180
 * Original: 0x002D1180 - 0x002D11A1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1180(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1180: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3AE4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D11B0
 * Original: 0x002D11B0 - 0x002D11C7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D11B0(void)
{

loc_002D11B0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x96880);
    PUSH32(esp, 0xB407C1F);
    ecx = 0x3C3AE8;
    PUSH32(esp, 0x002D11C6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D11C6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D11D0
 * Original: 0x002D11D0 - 0x002D11E7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D11D0(void)
{

loc_002D11D0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x97390);
    PUSH32(esp, 0x421EAA05);
    ecx = 0x3C3AFC;
    PUSH32(esp, 0x002D11E6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D11E6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D11F0
 * Original: 0x002D11F0 - 0x002D1211 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D11F0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D11F0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3B10) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1220
 * Original: 0x002D1220 - 0x002D1237 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1220(void)
{

loc_002D1220: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x974E0);
    PUSH32(esp, 0xFE0B6C49u);
    ecx = 0x3C3B14;
    PUSH32(esp, 0x002D1236u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1236: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1240
 * Original: 0x002D1240 - 0x002D1261 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1240(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1240: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3B24) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1270
 * Original: 0x002D1270 - 0x002D1287 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1270(void)
{

loc_002D1270: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x97950);
    PUSH32(esp, 0x61972555);
    ecx = 0x3C3B28;
    PUSH32(esp, 0x002D1286u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1286: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1290
 * Original: 0x002D1290 - 0x002D12B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1290(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1290: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3B3C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D12C0
 * Original: 0x002D12C0 - 0x002D12D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D12C0(void)
{

loc_002D12C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x983A0);
    PUSH32(esp, 0xC1CDC185u);
    ecx = 0x3C3B40;
    PUSH32(esp, 0x002D12D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D12D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D12E0
 * Original: 0x002D12E0 - 0x002D1301 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D12E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D12E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3B50) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1310
 * Original: 0x002D1310 - 0x002D1327 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1310(void)
{

loc_002D1310: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x98CD0);
    PUSH32(esp, 0x2A5E9D83);
    ecx = 0x3C3B54;
    PUSH32(esp, 0x002D1326u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1326: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1330
 * Original: 0x002D1330 - 0x002D1351 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1330(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1330: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3B68) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1360
 * Original: 0x002D1360 - 0x002D1377 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1360(void)
{

loc_002D1360: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x99140);
    PUSH32(esp, 0x8B1139CCu);
    ecx = 0x3C3B6C;
    PUSH32(esp, 0x002D1376u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1376: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1380
 * Original: 0x002D1380 - 0x002D13A1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1380(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1380: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3B88) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D13B0
 * Original: 0x002D13B0 - 0x002D13C7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D13B0(void)
{

loc_002D13B0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x99710);
    PUSH32(esp, 0x22055F28);
    ecx = 0x3C3B8C;
    PUSH32(esp, 0x002D13C6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D13C6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D13D0
 * Original: 0x002D13D0 - 0x002D13E7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D13D0(void)
{

loc_002D13D0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9AAC0);
    PUSH32(esp, 0x9FCC457Au);
    ecx = 0x3C3BA0;
    PUSH32(esp, 0x002D13E6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D13E6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D13F0
 * Original: 0x002D13F0 - 0x002D1411 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D13F0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D13F0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3BB0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1420
 * Original: 0x002D1420 - 0x002D1437 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1420(void)
{

loc_002D1420: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9B2D0);
    PUSH32(esp, 0x9A2588ECu);
    ecx = 0x3C3BB4;
    PUSH32(esp, 0x002D1436u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1436: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1440
 * Original: 0x002D1440 - 0x002D1461 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1440(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1440: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3BC4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1470
 * Original: 0x002D1470 - 0x002D1487 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1470(void)
{

loc_002D1470: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9B9A0);
    PUSH32(esp, 0x634BE2E9);
    ecx = 0x3C3BC8;
    PUSH32(esp, 0x002D1486u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1486: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1490
 * Original: 0x002D1490 - 0x002D14B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1490(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1490: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3BD8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D14C0
 * Original: 0x002D14C0 - 0x002D14D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D14C0(void)
{

loc_002D14C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9C3D0);
    PUSH32(esp, 0xF6AC2D55u);
    ecx = 0x3C3BDC;
    PUSH32(esp, 0x002D14D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D14D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D14E0
 * Original: 0x002D14E0 - 0x002D1501 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D14E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D14E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3BEC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1510
 * Original: 0x002D1510 - 0x002D1527 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1510(void)
{

loc_002D1510: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9C740);
    PUSH32(esp, 0xE10BBE11u);
    ecx = 0x3C3BF0;
    PUSH32(esp, 0x002D1526u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1526: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1530
 * Original: 0x002D1530 - 0x002D1551 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1530(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1530: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3C28) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1560
 * Original: 0x002D1560 - 0x002D1580 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1560(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D1560: ;
    eax = 0x9C9D0;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3733F8) = eax;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3733FC) = ecx;
    MEM32(0x373408) = eax;
    MEM32(0x37340C) = ecx;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1580
 * Original: 0x002D1580 - 0x002D15A0 (32 bytes, 15 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1580(void)
{

loc_002D1580: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9CF60);
    PUSH32(esp, 0x5E8CF10F);
    ecx = 0x3C3C2C;
    PUSH32(esp, 0x002D1596u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1596: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D15A0
 * Original: 0x002D15A0 - 0x002D15B7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D15A0(void)
{

loc_002D15A0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9D560);
    PUSH32(esp, 0x52C72FB8);
    ecx = 0x3C3C3C;
    PUSH32(esp, 0x002D15B6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D15B6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D15C0
 * Original: 0x002D15C0 - 0x002D15D7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D15C0(void)
{

loc_002D15C0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9E350);
    PUSH32(esp, 0x653075A2);
    ecx = 0x3C3C90;
    PUSH32(esp, 0x002D15D6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D15D6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D15E0
 * Original: 0x002D15E0 - 0x002D1601 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D15E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D15E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3CC4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1610
 * Original: 0x002D1610 - 0x002D1627 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1610(void)
{

loc_002D1610: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9F880);
    PUSH32(esp, 0x57414B37);
    ecx = 0x3C3CC8;
    PUSH32(esp, 0x002D1626u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1626: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1630
 * Original: 0x002D1630 - 0x002D1647 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1630(void)
{

loc_002D1630: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9FB20);
    PUSH32(esp, 0xC4A31B5Du);
    ecx = 0x3C3CD8;
    PUSH32(esp, 0x002D1646u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1646: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1650
 * Original: 0x002D1650 - 0x002D1667 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1650(void)
{

loc_002D1650: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x9FEE0);
    PUSH32(esp, 0x5ED50D83);
    ecx = 0x3C3CE8;
    PUSH32(esp, 0x002D1666u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1666: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1670
 * Original: 0x002D1670 - 0x002D1687 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1670(void)
{

loc_002D1670: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA02C0);
    PUSH32(esp, 0xCB5000FAu);
    ecx = 0x3C3CF8;
    PUSH32(esp, 0x002D1686u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1686: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1690
 * Original: 0x002D1690 - 0x002D16A7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1690(void)
{

loc_002D1690: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA0700);
    PUSH32(esp, 0x1C7BD67);
    ecx = 0x3C3D14;
    PUSH32(esp, 0x002D16A6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D16A6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D16B0
 * Original: 0x002D16B0 - 0x002D16C7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D16B0(void)
{

loc_002D16B0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA0A30);
    PUSH32(esp, 0x133913F);
    ecx = 0x3C3D24;
    PUSH32(esp, 0x002D16C6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D16C6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D16D0
 * Original: 0x002D16D0 - 0x002D16E7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D16D0(void)
{

loc_002D16D0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA0C20);
    PUSH32(esp, 0xC664E021u);
    ecx = 0x3C3D34;
    PUSH32(esp, 0x002D16E6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D16E6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D16F0
 * Original: 0x002D16F0 - 0x002D1711 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D16F0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D16F0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3D44) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1720
 * Original: 0x002D1720 - 0x002D1737 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1720(void)
{

loc_002D1720: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA0DF0);
    PUSH32(esp, 0x54FC2A07);
    ecx = 0x3C3D48;
    PUSH32(esp, 0x002D1736u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1736: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1740
 * Original: 0x002D1740 - 0x002D1757 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1740(void)
{

loc_002D1740: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA1410);
    PUSH32(esp, 0x2E780B72);
    ecx = 0x3C3D60;
    PUSH32(esp, 0x002D1756u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1756: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1760
 * Original: 0x002D1760 - 0x002D1781 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1760(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1760: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3D7C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1790
 * Original: 0x002D1790 - 0x002D17A7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1790(void)
{

loc_002D1790: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA19E0);
    PUSH32(esp, 0xB29C5383u);
    ecx = 0x3C3D80;
    PUSH32(esp, 0x002D17A6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D17A6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D17B0
 * Original: 0x002D17B0 - 0x002D17C7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D17B0(void)
{

loc_002D17B0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA1CE0);
    PUSH32(esp, 0xA774BE4Cu);
    ecx = 0x3C3DB8;
    PUSH32(esp, 0x002D17C6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D17C6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D17D0
 * Original: 0x002D17D0 - 0x002D17F1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D17D0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D17D0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3DC8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1800
 * Original: 0x002D1800 - 0x002D1817 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1800(void)
{

loc_002D1800: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA21A0);
    PUSH32(esp, 0x89B5775Eu);
    ecx = 0x3C3DCC;
    PUSH32(esp, 0x002D1816u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1816: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1820
 * Original: 0x002D1820 - 0x002D1841 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1820(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1820: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3DDC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1850
 * Original: 0x002D1850 - 0x002D1867 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1850(void)
{

loc_002D1850: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA2630);
    PUSH32(esp, 0xAEDF2ABBu);
    ecx = 0x3C3DE0;
    PUSH32(esp, 0x002D1866u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1866: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1870
 * Original: 0x002D1870 - 0x002D1887 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1870(void)
{

loc_002D1870: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA2890);
    PUSH32(esp, 0xC1627F57u);
    ecx = 0x3C3DF0;
    PUSH32(esp, 0x002D1886u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1886: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1890
 * Original: 0x002D1890 - 0x002D18A5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1890(void)
{

loc_002D1890: ;
    PUSH32(esp, 0xA2960);
    PUSH32(esp, 0x30F210);
    ecx = 0x3C3E00;
    PUSH32(esp, 0x002D18A4u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D18A4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D18B0
 * Original: 0x002D18B0 - 0x002D18C5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D18B0(void)
{

loc_002D18B0: ;
    PUSH32(esp, 0xA29A0);
    PUSH32(esp, 0x30F21C);
    ecx = 0x3C3E10;
    PUSH32(esp, 0x002D18C4u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D18C4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D18D0
 * Original: 0x002D18D0 - 0x002D18E5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D18D0(void)
{

loc_002D18D0: ;
    PUSH32(esp, 0xA29E0);
    PUSH32(esp, 0x30F22C);
    ecx = 0x3C3E20;
    PUSH32(esp, 0x002D18E4u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D18E4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D18F0
 * Original: 0x002D18F0 - 0x002D1907 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D18F0(void)
{

loc_002D18F0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA2D90);
    PUSH32(esp, 0x22917348);
    ecx = 0x3C3E30;
    PUSH32(esp, 0x002D1906u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1906: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1910
 * Original: 0x002D1910 - 0x002D1931 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1910(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1910: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3E40) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1940
 * Original: 0x002D1940 - 0x002D1957 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1940(void)
{

loc_002D1940: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA4040);
    PUSH32(esp, 0xA49E450Du);
    ecx = 0x3C3E44;
    PUSH32(esp, 0x002D1956u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1956: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1960
 * Original: 0x002D1960 - 0x002D1981 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1960(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1960: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3E54) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1990
 * Original: 0x002D1990 - 0x002D19A7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1990(void)
{

loc_002D1990: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA4630);
    PUSH32(esp, 0xF0CEB521u);
    ecx = 0x3C3E58;
    PUSH32(esp, 0x002D19A6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D19A6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D19B0
 * Original: 0x002D19B0 - 0x002D19D1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D19B0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D19B0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C3E68) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D19E0
 * Original: 0x002D19E0 - 0x002D19F7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D19E0(void)
{

loc_002D19E0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xA4910);
    PUSH32(esp, 0x2B4B6B1F);
    ecx = 0x3C3E6C;
    PUSH32(esp, 0x002D19F6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D19F6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1A00
 * Original: 0x002D1A00 - 0x002D1A3C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1A00(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D1A00: ;
    PUSH32(esp, 0x1C);
    PUSH32(esp, 0x002D1A07u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D1A07: ;
    MEM32(0x3C3E80) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3C3E84) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3C3E80);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3C3E80);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3C3E80);
    PUSH32(esp, 0x2D6B90);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D1A38u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1A38: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D1A40
 * Original: 0x002D1A40 - 0x002D1A62 (34 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1A40(void)
{

loc_002D1A40: ;
    PUSH32(esp, 0x18);
    ecx = 0x373508;
    PUSH32(esp, 0x002D1A4Cu); RECOMP_ABI_CALL(0x001565D0u, sub_001565D0); /* call 0x001565D0 */

loc_002D1A4C: ;
    PUSH32(esp, 0x2D6BF0);
    MEM32(0x373508) = 0x30FE98;
    PUSH32(esp, 0x002D1A60u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1A60: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1A70
 * Original: 0x002D1A70 - 0x002D1A85 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1A70(void)
{

loc_002D1A70: ;
    PUSH32(esp, 0xA68F0);
    PUSH32(esp, 0x30FF70);
    ecx = 0x3C3EA4;
    PUSH32(esp, 0x002D1A84u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D1A84: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1A90
 * Original: 0x002D1A90 - 0x002D1AA7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1A90(void)
{

loc_002D1A90: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xAF030);
    PUSH32(esp, 0x55215F92);
    ecx = 0x3C5FF4;
    PUSH32(esp, 0x002D1AA6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1AA6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1AB0
 * Original: 0x002D1AB0 - 0x002D1ABC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1AB0(void)
{

loc_002D1AB0: ;
    PUSH32(esp, 0x2D6C10);
    PUSH32(esp, 0x002D1ABAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1ABA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1AC0
 * Original: 0x002D1AC0 - 0x002D1AE1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1AC0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1AC0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3C6080) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1AF0
 * Original: 0x002D1AF0 - 0x002D1B06 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1AF0(void)
{

loc_002D1AF0: ;
    ecx = 0x3C6088;
    PUSH32(esp, 0x002D1AFAu); RECOMP_ABI_CALL(0x001D0810u, sub_001D0810); /* call 0x001D0810 */

loc_002D1AFA: ;
    PUSH32(esp, 0x2D6C20);
    PUSH32(esp, 0x002D1B04u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1B04: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1B10
 * Original: 0x002D1B10 - 0x002D1B35 (37 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1B10(void)
{

loc_002D1B10: ;
    PUSH32(esp, 0x230);
    ecx = 0x3735B4;
    PUSH32(esp, 0x002D1B1Fu); RECOMP_ABI_CALL(0x001565D0u, sub_001565D0); /* call 0x001565D0 */

loc_002D1B1F: ;
    PUSH32(esp, 0x2D6C30);
    MEM32(0x3735B4) = 0x30FE98;
    PUSH32(esp, 0x002D1B33u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1B33: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1B40
 * Original: 0x002D1B40 - 0x002D1B64 (36 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1B40(void)
{

loc_002D1B40: ;
    PUSH32(esp, 0x1C);
    PUSH32(esp, 8);
    ecx = 0x3C6184;
    PUSH32(esp, 0x002D1B4Eu); RECOMP_ABI_CALL(0x001567B0u, sub_001567B0); /* call 0x001567B0 */

loc_002D1B4E: ;
    PUSH32(esp, 0x2D6C50);
    MEM32(0x3C6184) = 0x3082A4;
    PUSH32(esp, 0x002D1B62u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1B62: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1B70
 * Original: 0x002D1B70 - 0x002D1B97 (39 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1B70(void)
{

loc_002D1B70: ;
    PUSH32(esp, 0x100);
    PUSH32(esp, 2);
    ecx = 0x3C61A0;
    PUSH32(esp, 0x002D1B81u); RECOMP_ABI_CALL(0x001567B0u, sub_001567B0); /* call 0x001567B0 */

loc_002D1B81: ;
    PUSH32(esp, 0x2D6C60);
    MEM32(0x3C61A0) = 0x3082A4;
    PUSH32(esp, 0x002D1B95u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1B95: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1BA0
 * Original: 0x002D1BA0 - 0x002D1BB7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1BA0(void)
{

loc_002D1BA0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xBC490);
    PUSH32(esp, 0xBC2DE55Eu);
    ecx = 0x3C61BC;
    PUSH32(esp, 0x002D1BB6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D1BB6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1BC0
 * Original: 0x002D1BC0 - 0x002D1BD6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1BC0(void)
{

loc_002D1BC0: ;
    ecx = 0x3C6230;
    PUSH32(esp, 0x002D1BCAu); RECOMP_ABI_CALL(0x001CD4C0u, sub_001CD4C0); /* call 0x001CD4C0 */

loc_002D1BCA: ;
    PUSH32(esp, 0x2D6C70);
    PUSH32(esp, 0x002D1BD4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1BD4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1BE0
 * Original: 0x002D1BE0 - 0x002D1CDB (251 bytes, 51 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1BE0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D1BE0: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, esi);
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, esi);
    PUSH32(esp, 0x34);
    { uint32_t _icall_target = MEM32(0x37DB68); PUSH32(esp, 0x002D1BECu); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002D1BE6u); } /* indirect call */
    }

loc_002D1BEC: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D1C06; /* je: equal / zero */

loc_002D1BF3: ;
    PUSH32(esp, 0x529C80);
    ecx = eax;
    PUSH32(esp, 0x002D1BFFu); RECOMP_ABI_CALL(0x001D2B00u, sub_001D2B00); /* call 0x001D2B00 */

loc_002D1BFF: ;
    MEM32(0x3C62B8) = eax;
    goto loc_002D1C0C;

loc_002D1C06: ;
    MEM32(0x3C62B8) = esi;

loc_002D1C0C: ;
    PUSH32(esp, 0x2D6C80);
    MEM32(0x3C62C0) = esi;
    MEM32(0x3C62BC) = esi;
    MEM32(0x3C62C8) = esi;
    MEM32(0x3C62C4) = esi;
    MEM32(0x3C62D0) = esi;
    MEM32(0x3C62CC) = esi;
    MEM32(0x3C62D8) = esi;
    MEM32(0x3C62D4) = esi;
    MEM32(0x3C62E0) = esi;
    MEM32(0x3C62DC) = esi;
    MEM32(0x3C62E8) = esi;
    MEM32(0x3C62E4) = esi;
    MEM32(0x3C62F0) = esi;
    MEM32(0x3C62EC) = esi;
    MEM32(0x3C62F8) = esi;
    MEM32(0x3C62F4) = esi;
    MEM32(0x3C6300) = esi;
    MEM32(0x3C62FC) = esi;
    MEM32(0x3C6308) = esi;
    MEM32(0x3C6304) = esi;
    MEM32(0x3C6310) = esi;
    MEM32(0x3C630C) = esi;
    MEM32(0x3C6318) = esi;
    MEM32(0x3C6314) = esi;
    MEM32(0x3C6320) = esi;
    MEM32(0x3C631C) = esi;
    MEM32(0x3C6328) = esi;
    MEM32(0x3C6324) = esi;
    MEM32(0x3C6330) = esi;
    MEM32(0x3C632C) = esi;
    MEM32(0x3C6338) = esi;
    MEM32(0x3C6334) = esi;
    PUSH32(esp, 0x002D1CD6u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1CD6: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1CE0
 * Original: 0x002D1CE0 - 0x002D1CF8 (24 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1CE0(void)
{

loc_002D1CE0: ;
    xmm0 = XMM_SCALAR(MEMF(0x373674)); /* movss */
    xmm1 = xmm0; /* movaps */
    xmm1.f[0] = xmm1.f[0] * xmm0.f[0]; /* mulss */
    MEMF(0x3C6350) = xmm1.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D1D00
 * Original: 0x002D1D00 - 0x002D1D20 (32 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1D00(void)
{

loc_002D1D00: ;
    xmm0 = XMM_SCALAR(MEMF(0x373674)); /* movss */
    xmm0.f[0] = xmm0.f[0] - MEMF(0x373678); /* subss */
    xmm1 = xmm0; /* movaps */
    xmm1.f[0] = xmm1.f[0] * xmm0.f[0]; /* mulss */
    MEMF(0x3C6354) = xmm1.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D1D20
 * Original: 0x002D1D20 - 0x002D1D50 (48 bytes, 17 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1D20(void)
{

loc_002D1D20: ;
    xmm0 = XMM_SCALAR(MEMF(0x3C6350)); /* movss */
    xmm0.f[0] = xmm0.f[0] - MEMF(0x3C6354); /* subss */
    xmm1 = XMM_SCALAR(MEMF(0x2FE99C)); /* movss */
    xmm1.f[0] = xmm1.f[0] / xmm0.f[0]; /* divss */
    MEMF(0x3C6358) = xmm1.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D1D50
 * Original: 0x002D1D50 - 0x002D1D65 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1D50(void)
{

loc_002D1D50: ;
    PUSH32(esp, 0xC24C0);
    PUSH32(esp, 0x311D80);
    ecx = 0x3C6450;
    PUSH32(esp, 0x002D1D64u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D1D64: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D1D70
 * Original: 0x002D1D70 - 0x002D1D86 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1D70(void)
{

loc_002D1D70: ;
    ecx = 0x3C64F8;
    PUSH32(esp, 0x002D1D7Au); RECOMP_ABI_CALL(0x001CD4C0u, sub_001CD4C0); /* call 0x001CD4C0 */

loc_002D1D7A: ;
    PUSH32(esp, 0x2D6D00);
    PUSH32(esp, 0x002D1D84u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1D84: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1D90
 * Original: 0x002D1D90 - 0x002D1DA6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1D90(void)
{

loc_002D1D90: ;
    ecx = 0x3C6570;
    PUSH32(esp, 0x002D1D9Au); RECOMP_ABI_CALL(0x001CD4C0u, sub_001CD4C0); /* call 0x001CD4C0 */

loc_002D1D9A: ;
    PUSH32(esp, 0x2D6D10);
    PUSH32(esp, 0x002D1DA4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1DA4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1DB0
 * Original: 0x002D1DB0 - 0x002D1DC6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1DB0(void)
{

loc_002D1DB0: ;
    ecx = 0x3C6600;
    PUSH32(esp, 0x002D1DBAu); RECOMP_ABI_CALL(0x000C71B0u, sub_000C71B0); /* call 0x000C71B0 */

loc_002D1DBA: ;
    PUSH32(esp, 0x2D6D20);
    PUSH32(esp, 0x002D1DC4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1DC4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1DD0
 * Original: 0x002D1DD0 - 0x002D1DF1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1DD0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1DD0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DA494) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1E00
 * Original: 0x002D1E00 - 0x002D1E0A (10 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1E00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D1E00: ;
    ecx = 0x3DA4E0;
    g_seh_ebp = ebp; sub_00106490(); return; /* tail jmp 0x00106490 */

}

/**
 * sub_002D1E10
 * Original: 0x002D1E10 - 0x002D1E1A (10 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1E10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D1E10: ;
    ecx = 0x3DAA20;
    g_seh_ebp = ebp; sub_000FF2D0(); return; /* tail jmp 0x000FF2D0 */

}

/**
 * sub_002D1E20
 * Original: 0x002D1E20 - 0x002D1E41 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1E20(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1E20: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DAF58) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1E50
 * Original: 0x002D1E50 - 0x002D1E71 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1E50(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1E50: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DAF60) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1E80
 * Original: 0x002D1E80 - 0x002D1EA1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1E80(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1E80: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DAF6C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1EB0
 * Original: 0x002D1EB0 - 0x002D1ED1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D1EB0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D1EB0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DAF74) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D1EE0
 * Original: 0x002D1EE0 - 0x002D1EF6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1EE0(void)
{

loc_002D1EE0: ;
    ecx = 0x3DAF78;
    PUSH32(esp, 0x002D1EEAu); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002D1EEA: ;
    PUSH32(esp, 0x2D6D40);
    PUSH32(esp, 0x002D1EF4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1EF4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1F00
 * Original: 0x002D1F00 - 0x002D1F16 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1F00(void)
{

loc_002D1F00: ;
    ecx = 0x3DAFA4;
    PUSH32(esp, 0x002D1F0Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002D1F0A: ;
    PUSH32(esp, 0x2D6D50);
    PUSH32(esp, 0x002D1F14u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D1F14: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D1F20
 * Original: 0x002D1F20 - 0x002D201F (255 bytes, 37 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D1F20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D1F20: ;
    xmm2 = XMM_SCALAR(MEMF(0x315CD0)); /* movss */
    xmm0 = XMM_SCALAR(MEMF(0x301058)); /* movss */
    xmm1 = XMM_SCALAR(MEMF(0x30039C)); /* movss */
    MEMF(0x375E08) = xmm2.f[0]; /* movss */
    xmm2 = XMM_SCALAR(MEMF(0x315CCC)); /* movss */
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEMF(0x375DE0) = xmm0.f[0]; /* movss */
    MEMF(0x375DE4) = xmm1.f[0]; /* movss */
    MEMF(0x375DE8) = xmm0.f[0]; /* movss */
    xmm0 = XMM_SCALAR(MEMF(0x315CC8)); /* movss */
    MEMF(0x375E00) = xmm1.f[0]; /* movss */
    xmm1 = XMM_SCALAR(MEMF(0x3003A0)); /* movss */
    MEMF(0x375E0C) = xmm2.f[0]; /* movss */
    xmm2 = XMM_ZERO(); /* xorps self = zero */
    ecx = 2;
    MEMF(0x375DEC) = xmm0.f[0]; /* movss */
    xmm0 = XMM_SCALAR(MEMF(0x2FE99C)); /* movss */
    MEMF(0x375E04) = xmm1.f[0]; /* movss */
    MEMF(0x375E1C) = xmm2.f[0]; /* movss */
    xmm2 = XMM_SCALAR(MEMF(0x315CC4)); /* movss */
    MEMF(0x375E20) = xmm1.f[0]; /* movss */
    xmm1 = XMM_SCALAR(MEMF(0x301050)); /* movss */
    MEM32(0x375DF0) = eax;
    MEM32(0x375DF4) = ecx;
    MEM8(0x375DF8) = LO8(eax);
    MEMF(0x375DFC) = xmm0.f[0]; /* movss */
    MEM32(0x375E10) = eax;
    MEM32(0x375E14) = 1;
    MEM8(0x375E18) = LO8(eax);
    MEMF(0x375E24) = xmm1.f[0]; /* movss */
    MEMF(0x375E28) = xmm2.f[0]; /* movss */
    MEMF(0x375E2C) = xmm1.f[0]; /* movss */
    MEM32(0x375E30) = eax;
    MEM32(0x375E34) = ecx;
    MEM8(0x375E38) = LO8(eax);
    MEMF(0x375E3C) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2020
 * Original: 0x002D2020 - 0x002D2041 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2020(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2020: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DAFD0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2050
 * Original: 0x002D2050 - 0x002D2071 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2050(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2050: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DAFDC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2080
 * Original: 0x002D2080 - 0x002D20BC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2080(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2080: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D2087u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D2087: ;
    MEM32(0x3DAFF4) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3DAFF8) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3DAFF4);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3DAFF4);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3DAFF4);
    PUSH32(esp, 0x2D6D60);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D20B8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D20B8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D20C0
 * Original: 0x002D20C0 - 0x002D20F1 (49 bytes, 15 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D20C0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D20C0: ;
    eax = 0x3DB004;
    ecx = 0x50;
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    /* nop */

loc_002D20D0: ;
    MEM32(eax) = edx;
    MEM32(eax + 4) = edx;
    MEM32(eax + 8) = edx;
    MEM32(eax + -4) = 0x307680;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x10;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D20D0; /* jne: not equal / not zero */

loc_002D20E5: ;
    PUSH32(esp, 0x2D6DC0);
    PUSH32(esp, 0x002D20EFu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D20EF: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2100
 * Original: 0x002D2100 - 0x002D2122 (34 bytes, 10 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2100(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2100: ;
    xmm0 = XMM_ZERO(); /* xorps self = zero */
    eax = 0x3DB500;
    ecx = 0x20;
    /* nop */

loc_002D2110: ;
    MEM32(eax) = 0xFFFFFFFFu;
    MEMF(eax + 4) = xmm0.f[0]; /* movss */
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D2110; /* jne: not equal / not zero */

loc_002D2121: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2130
 * Original: 0x002D2130 - 0x002D2151 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2130(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2130: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DB618) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2160
 * Original: 0x002D2160 - 0x002D2181 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2160(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2160: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DB620) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2190
 * Original: 0x002D2190 - 0x002D21A6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2190(void)
{

loc_002D2190: ;
    ecx = 0x3DB624;
    PUSH32(esp, 0x002D219Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002D219A: ;
    PUSH32(esp, 0x2D6E00);
    PUSH32(esp, 0x002D21A4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D21A4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D21B0
 * Original: 0x002D21B0 - 0x002D21D1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D21B0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D21B0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DB658) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D21E0
 * Original: 0x002D21E0 - 0x002D21F6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D21E0(void)
{

loc_002D21E0: ;
    ecx = 0x3DB65C;
    PUSH32(esp, 0x002D21EAu); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002D21EA: ;
    PUSH32(esp, 0x2D6E10);
    PUSH32(esp, 0x002D21F4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D21F4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2200
 * Original: 0x002D2200 - 0x002D2216 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2200(void)
{

loc_002D2200: ;
    ecx = 0x3DB688;
    PUSH32(esp, 0x002D220Au); RECOMP_ABI_CALL(0x000658C0u, sub_000658C0); /* call 0x000658C0 */

loc_002D220A: ;
    PUSH32(esp, 0x2D6E20);
    PUSH32(esp, 0x002D2214u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2214: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2220
 * Original: 0x002D2220 - 0x002D2241 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2220(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2220: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DB8D4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2250
 * Original: 0x002D2250 - 0x002D225C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2250(void)
{

loc_002D2250: ;
    PUSH32(esp, 0x2D6E30);
    PUSH32(esp, 0x002D225Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D225A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2260
 * Original: 0x002D2260 - 0x002D229C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2260(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2260: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D2267u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D2267: ;
    MEM32(0x3DB8D8) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3DB8DC) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3DB8D8);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3DB8D8);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3DB8D8);
    PUSH32(esp, 0x2D6E40);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D2298u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2298: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D22A0
 * Original: 0x002D22A0 - 0x002D22B5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D22A0(void)
{

loc_002D22A0: ;
    PUSH32(esp, 0x375E70);
    PUSH32(esp, 0xE95B93D);
    ecx = 0x3DB8E4;
    PUSH32(esp, 0x002D22B4u); RECOMP_ABI_CALL(0x001335E0u, sub_001335E0); /* call 0x001335E0 */

loc_002D22B4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D22C0
 * Original: 0x002D22C0 - 0x002D22D6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D22C0(void)
{

loc_002D22C0: ;
    ecx = 0x3DB900;
    PUSH32(esp, 0x002D22CAu); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D22CA: ;
    PUSH32(esp, 0x2D6EA0);
    PUSH32(esp, 0x002D22D4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D22D4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D22E0
 * Original: 0x002D22E0 - 0x002D22F6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D22E0(void)
{

loc_002D22E0: ;
    ecx = 0x3DB930;
    PUSH32(esp, 0x002D22EAu); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D22EA: ;
    PUSH32(esp, 0x2D6EB0);
    PUSH32(esp, 0x002D22F4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D22F4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2300
 * Original: 0x002D2300 - 0x002D2316 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2300(void)
{

loc_002D2300: ;
    ecx = 0x3DB960;
    PUSH32(esp, 0x002D230Au); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D230A: ;
    PUSH32(esp, 0x2D6EC0);
    PUSH32(esp, 0x002D2314u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2314: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2320
 * Original: 0x002D2320 - 0x002D2341 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2320(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2320: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DB9A4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2350
 * Original: 0x002D2350 - 0x002D2371 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2350(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2350: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DB9AC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2380
 * Original: 0x002D2380 - 0x002D2396 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2380(void)
{

loc_002D2380: ;
    ecx = 0x3DB9E0;
    PUSH32(esp, 0x002D238Au); RECOMP_ABI_CALL(0x00105C60u, sub_00105C60); /* call 0x00105C60 */

loc_002D238A: ;
    PUSH32(esp, 0x2D6EF0);
    PUSH32(esp, 0x002D2394u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2394: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D23A0
 * Original: 0x002D23A0 - 0x002D23B6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D23A0(void)
{

loc_002D23A0: ;
    ecx = 0x3DC480;
    PUSH32(esp, 0x002D23AAu); RECOMP_ABI_CALL(0x00105D00u, sub_00105D00); /* call 0x00105D00 */

loc_002D23AA: ;
    PUSH32(esp, 0x2D6F10);
    PUSH32(esp, 0x002D23B4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D23B4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D23C0
 * Original: 0x002D23C0 - 0x002D23D6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D23C0(void)
{

loc_002D23C0: ;
    ecx = 0x3DD8E0;
    PUSH32(esp, 0x002D23CAu); RECOMP_ABI_CALL(0x00105D80u, sub_00105D80); /* call 0x00105D80 */

loc_002D23CA: ;
    PUSH32(esp, 0x2D6F30);
    PUSH32(esp, 0x002D23D4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D23D4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D23E0
 * Original: 0x002D23E0 - 0x002D23F6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D23E0(void)
{

loc_002D23E0: ;
    ecx = 0x3DD940;
    PUSH32(esp, 0x002D23EAu); RECOMP_ABI_CALL(0x00105DD0u, sub_00105DD0); /* call 0x00105DD0 */

loc_002D23EA: ;
    PUSH32(esp, 0x2D6F50);
    PUSH32(esp, 0x002D23F4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D23F4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2400
 * Original: 0x002D2400 - 0x002D2416 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2400(void)
{

loc_002D2400: ;
    ecx = 0x3DE7E0;
    PUSH32(esp, 0x002D240Au); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D240A: ;
    PUSH32(esp, 0x2D6ED0);
    PUSH32(esp, 0x002D2414u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2414: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2420
 * Original: 0x002D2420 - 0x002D2436 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2420(void)
{

loc_002D2420: ;
    ecx = 0x3DE810;
    PUSH32(esp, 0x002D242Au); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D242A: ;
    PUSH32(esp, 0x2D6EE0);
    PUSH32(esp, 0x002D2434u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2434: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2440
 * Original: 0x002D2440 - 0x002D2455 (21 bytes, 5 insns)
 * Category: game_vehicle
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2440(void)
{

loc_002D2440: ;
    PUSH32(esp, 0x105E70);
    PUSH32(esp, 0x317FB8);
    ecx = 0x3DE840;
    PUSH32(esp, 0x002D2454u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D2454: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2460
 * Original: 0x002D2460 - 0x002D2475 (21 bytes, 5 insns)
 * Category: game_vehicle
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2460(void)
{

loc_002D2460: ;
    PUSH32(esp, 0x106330);
    PUSH32(esp, 0x317FC8);
    ecx = 0x3DE850;
    PUSH32(esp, 0x002D2474u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D2474: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2480
 * Original: 0x002D2480 - 0x002D2493 (19 bytes, 5 insns)
 * Category: game_vehicle
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2480(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2480: ;
    PUSH32(esp, 0x317F2C);
    PUSH32(esp, 0x002D248Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D248A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE860) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D24A0
 * Original: 0x002D24A0 - 0x002D24B3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D24A0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D24A0: ;
    PUSH32(esp, 0x317FD8);
    PUSH32(esp, 0x002D24AAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D24AA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE864) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D24C0
 * Original: 0x002D24C0 - 0x002D24D3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D24C0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D24C0: ;
    PUSH32(esp, 0x317FDC);
    PUSH32(esp, 0x002D24CAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D24CA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE868) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D24E0
 * Original: 0x002D24E0 - 0x002D24F3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D24E0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D24E0: ;
    PUSH32(esp, 0x317FE8);
    PUSH32(esp, 0x002D24EAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D24EA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE86C) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2500
 * Original: 0x002D2500 - 0x002D2513 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2500(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2500: ;
    PUSH32(esp, 0x317FF0);
    PUSH32(esp, 0x002D250Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D250A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE870) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2520
 * Original: 0x002D2520 - 0x002D2533 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2520(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2520: ;
    PUSH32(esp, 0x318004);
    PUSH32(esp, 0x002D252Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D252A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE874) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2540
 * Original: 0x002D2540 - 0x002D2553 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2540(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2540: ;
    PUSH32(esp, 0x318018);
    PUSH32(esp, 0x002D254Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D254A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE878) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2560
 * Original: 0x002D2560 - 0x002D2573 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2560(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2560: ;
    PUSH32(esp, 0x31802C);
    PUSH32(esp, 0x002D256Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D256A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE87C) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2580
 * Original: 0x002D2580 - 0x002D2593 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2580(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2580: ;
    PUSH32(esp, 0x318040);
    PUSH32(esp, 0x002D258Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D258A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE880) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D25A0
 * Original: 0x002D25A0 - 0x002D25B3 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D25A0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D25A0: ;
    PUSH32(esp, 0x318054);
    PUSH32(esp, 0x002D25AAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D25AA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE884) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D25C0
 * Original: 0x002D25C0 - 0x002D25D3 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D25C0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D25C0: ;
    PUSH32(esp, 0x318068);
    PUSH32(esp, 0x002D25CAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D25CA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE888) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D25E0
 * Original: 0x002D25E0 - 0x002D25F3 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D25E0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D25E0: ;
    PUSH32(esp, 0x31807C);
    PUSH32(esp, 0x002D25EAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D25EA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE88C) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2600
 * Original: 0x002D2600 - 0x002D2613 (19 bytes, 5 insns)
 * Category: game_physics
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2600(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2600: ;
    PUSH32(esp, 0x318090);
    PUSH32(esp, 0x002D260Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D260A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE890) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2620
 * Original: 0x002D2620 - 0x002D2633 (19 bytes, 5 insns)
 * Category: game_vehicle
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2620(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2620: ;
    PUSH32(esp, 0x3180A4);
    PUSH32(esp, 0x002D262Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D262A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE894) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2640
 * Original: 0x002D2640 - 0x002D2653 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2640(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2640: ;
    PUSH32(esp, 0x3180B8);
    PUSH32(esp, 0x002D264Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D264A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE898) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2660
 * Original: 0x002D2660 - 0x002D2673 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2660(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2660: ;
    PUSH32(esp, 0x3180C4);
    PUSH32(esp, 0x002D266Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D266A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE89C) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2680
 * Original: 0x002D2680 - 0x002D2693 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2680(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2680: ;
    PUSH32(esp, 0x3180D4);
    PUSH32(esp, 0x002D268Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D268A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8A0) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D26A0
 * Original: 0x002D26A0 - 0x002D26B3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D26A0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D26A0: ;
    PUSH32(esp, 0x3180E0);
    PUSH32(esp, 0x002D26AAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D26AA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8A4) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D26C0
 * Original: 0x002D26C0 - 0x002D26D3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D26C0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D26C0: ;
    PUSH32(esp, 0x3180EC);
    PUSH32(esp, 0x002D26CAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D26CA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8A8) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D26E0
 * Original: 0x002D26E0 - 0x002D26F3 (19 bytes, 5 insns)
 * Category: game_vehicle
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D26E0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D26E0: ;
    PUSH32(esp, 0x3180F8);
    PUSH32(esp, 0x002D26EAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D26EA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8AC) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2700
 * Original: 0x002D2700 - 0x002D2713 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2700(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2700: ;
    PUSH32(esp, 0x318108);
    PUSH32(esp, 0x002D270Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D270A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8B0) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2720
 * Original: 0x002D2720 - 0x002D2733 (19 bytes, 5 insns)
 * Category: game_audio
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2720(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2720: ;
    PUSH32(esp, 0x318114);
    PUSH32(esp, 0x002D272Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D272A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8B4) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2740
 * Original: 0x002D2740 - 0x002D2753 (19 bytes, 5 insns)
 * Category: game_audio
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2740(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2740: ;
    PUSH32(esp, 0x318128);
    PUSH32(esp, 0x002D274Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D274A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8B8) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2760
 * Original: 0x002D2760 - 0x002D2773 (19 bytes, 5 insns)
 * Category: game_vehicle
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2760(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2760: ;
    PUSH32(esp, 0x31813C);
    PUSH32(esp, 0x002D276Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D276A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x3DE8BC) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2780
 * Original: 0x002D2780 - 0x002D27A1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2780(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2780: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DE8C4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D27B0
 * Original: 0x002D27B0 - 0x002D27D1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D27B0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D27B0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DE8E4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D27E0
 * Original: 0x002D27E0 - 0x002D2801 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D27E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D27E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEA00) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2810
 * Original: 0x002D2810 - 0x002D281C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2810(void)
{

loc_002D2810: ;
    PUSH32(esp, 0x2D6F70);
    PUSH32(esp, 0x002D281Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D281A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2820
 * Original: 0x002D2820 - 0x002D282C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2820(void)
{

loc_002D2820: ;
    PUSH32(esp, 0x2D6F80);
    PUSH32(esp, 0x002D282Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D282A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2830
 * Original: 0x002D2830 - 0x002D283C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2830(void)
{

loc_002D2830: ;
    PUSH32(esp, 0x2D6F90);
    PUSH32(esp, 0x002D283Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D283A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2840
 * Original: 0x002D2840 - 0x002D284B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2840(void)
{

loc_002D2840: ;
    MEM32(0x3DEA04) = 0x375E88;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2850
 * Original: 0x002D2850 - 0x002D285B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2850(void)
{

loc_002D2850: ;
    MEM32(0x3DEA08) = 0x375E8C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2860
 * Original: 0x002D2860 - 0x002D286B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2860(void)
{

loc_002D2860: ;
    MEM32(0x3DEA0C) = 0x375E90;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2870
 * Original: 0x002D2870 - 0x002D2891 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2870(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2870: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEA10) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D28A0
 * Original: 0x002D28A0 - 0x002D28AF (15 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D28A0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D28A0: ;
    fp_push(MEMD(0x318C48)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) fp_top() = recomp_x87_cos(fp_top()); /* fcos */
    MEMF(0x3DEA14) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D28B0
 * Original: 0x002D28B0 - 0x002D28C7 (23 bytes, 7 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D28B0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D28B0: ;
    PUSH32(esp, 0x110180);
    PUSH32(esp, 8);
    PUSH32(esp, 0x1D);
    PUSH32(esp, 0x375E98);
    PUSH32(esp, 0x002D28C3u); RECOMP_ABI_CALL(0x002BEF20u, sub_002BEF20); /* call 0x002BEF20 */

loc_002D28C3: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D28D0
 * Original: 0x002D28D0 - 0x002D28F1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D28D0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D28D0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEA24) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2900
 * Original: 0x002D2900 - 0x002D2921 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2900(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2900: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEA54) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2930
 * Original: 0x002D2930 - 0x002D2951 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2930(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2930: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEA58) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2960
 * Original: 0x002D2960 - 0x002D2981 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2960(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2960: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEA5C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2990
 * Original: 0x002D2990 - 0x002D29A9 (25 bytes, 4 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2990(void)
{

loc_002D2990: ;
    xmm0 = XMM_SCALAR(MEMF(0x3727C4)); /* movss */
    xmm0.f[0] = xmm0.f[0] * MEMF(0x2FF504); /* mulss */
    MEMF(0x3DEA60) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D29B0
 * Original: 0x002D29B0 - 0x002D29D1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D29B0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D29B0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEE44) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D29E0
 * Original: 0x002D29E0 - 0x002D2A01 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D29E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D29E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEE48) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2A10
 * Original: 0x002D2A10 - 0x002D2A1C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2A10(void)
{

loc_002D2A10: ;
    PUSH32(esp, 0x2D6FB0);
    PUSH32(esp, 0x002D2A1Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2A1A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2A20
 * Original: 0x002D2A20 - 0x002D2A41 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2A20(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2A20: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEEA4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2A50
 * Original: 0x002D2A50 - 0x002D2A67 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2A50(void)
{

loc_002D2A50: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x1260A0);
    PUSH32(esp, 0x1BF15200);
    ecx = 0x3DEEA8;
    PUSH32(esp, 0x002D2A66u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D2A66: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2A70
 * Original: 0x002D2A70 - 0x002D2A7C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2A70(void)
{

loc_002D2A70: ;
    PUSH32(esp, 0x2D6FC0);
    PUSH32(esp, 0x002D2A7Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2A7A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2A80
 * Original: 0x002D2A80 - 0x002D2A95 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2A80(void)
{

loc_002D2A80: ;
    PUSH32(esp, 0x1265F0);
    PUSH32(esp, 0x31A124);
    ecx = 0x3DEEB8;
    PUSH32(esp, 0x002D2A94u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D2A94: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2AA0
 * Original: 0x002D2AA0 - 0x002D2AC1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2AA0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2AA0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEEC8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2AD0
 * Original: 0x002D2AD0 - 0x002D2AF1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2AD0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2AD0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEECC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2B00
 * Original: 0x002D2B00 - 0x002D2B21 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2B00(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2B00: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3DEED0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2B30
 * Original: 0x002D2B30 - 0x002D2B3C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2B30(void)
{

loc_002D2B30: ;
    PUSH32(esp, 0x2D6FE0);
    PUSH32(esp, 0x002D2B3Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2B3A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2B40
 * Original: 0x002D2B40 - 0x002D2B4C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2B40(void)
{

loc_002D2B40: ;
    PUSH32(esp, 0x2D7010);
    PUSH32(esp, 0x002D2B4Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2B4A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2B50
 * Original: 0x002D2B50 - 0x002D2B5C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2B50(void)
{

loc_002D2B50: ;
    PUSH32(esp, 0x2D7000);
    PUSH32(esp, 0x002D2B5Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2B5A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2B60
 * Original: 0x002D2B60 - 0x002D2B76 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2B60(void)
{

loc_002D2B60: ;
    ecx = 0x3E8B60;
    PUSH32(esp, 0x002D2B6Au); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D2B6A: ;
    PUSH32(esp, 0x2D7030);
    PUSH32(esp, 0x002D2B74u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2B74: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2B80
 * Original: 0x002D2B80 - 0x002D2B96 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2B80(void)
{

loc_002D2B80: ;
    ecx = 0x3E8B90;
    PUSH32(esp, 0x002D2B8Au); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D2B8A: ;
    PUSH32(esp, 0x2D7040);
    PUSH32(esp, 0x002D2B94u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2B94: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2BA0
 * Original: 0x002D2BA0 - 0x002D2BB6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2BA0(void)
{

loc_002D2BA0: ;
    ecx = 0x3E8BC0;
    PUSH32(esp, 0x002D2BAAu); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D2BAA: ;
    PUSH32(esp, 0x2D7050);
    PUSH32(esp, 0x002D2BB4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2BB4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2BC0
 * Original: 0x002D2BC0 - 0x002D2BD6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2BC0(void)
{

loc_002D2BC0: ;
    ecx = 0x3E8BF0;
    PUSH32(esp, 0x002D2BCAu); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D2BCA: ;
    PUSH32(esp, 0x2D7060);
    PUSH32(esp, 0x002D2BD4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2BD4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2BE0
 * Original: 0x002D2BE0 - 0x002D2C01 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2BE0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2BE0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3E8C24) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2C10
 * Original: 0x002D2C10 - 0x002D2C31 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2C10(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2C10: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3E8C38) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2C40
 * Original: 0x002D2C40 - 0x002D2C56 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2C40(void)
{

loc_002D2C40: ;
    ecx = 0x3E8C40;
    PUSH32(esp, 0x002D2C4Au); RECOMP_ABI_CALL(0x00132060u, sub_00132060); /* call 0x00132060 */

loc_002D2C4A: ;
    PUSH32(esp, 0x2D7070);
    PUSH32(esp, 0x002D2C54u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2C54: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2C60
 * Original: 0x002D2C60 - 0x002D2C81 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2C60(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2C60: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3F2D98) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2C90
 * Original: 0x002D2C90 - 0x002D2CB1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2C90(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2C90: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3F2DD4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2CC0
 * Original: 0x002D2CC0 - 0x002D2CD6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2CC0(void)
{

loc_002D2CC0: ;
    ecx = 0x376D40;
    PUSH32(esp, 0x002D2CCAu); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D2CCA: ;
    PUSH32(esp, 0x2D7080);
    PUSH32(esp, 0x002D2CD4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2CD4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2CE0
 * Original: 0x002D2CE0 - 0x002D2CF5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2CE0(void)
{

loc_002D2CE0: ;
    PUSH32(esp, 0x376D30);
    PUSH32(esp, 0xD4B7D42);
    ecx = 0x3F2DE4;
    PUSH32(esp, 0x002D2CF4u); RECOMP_ABI_CALL(0x001335E0u, sub_001335E0); /* call 0x001335E0 */

loc_002D2CF4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2D00
 * Original: 0x002D2D00 - 0x002D2D3C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2D00(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2D00: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D2D07u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D2D07: ;
    MEM32(0x3F2DF8) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x3F2DFC) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x3F2DF8);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x3F2DF8);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x3F2DF8);
    PUSH32(esp, 0x2D70A0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D2D38u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2D38: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2D40
 * Original: 0x002D2D40 - 0x002D2D55 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2D40(void)
{

loc_002D2D40: ;
    PUSH32(esp, 0x13BB40);
    PUSH32(esp, 0x31BF18);
    ecx = 0x3F2E04;
    PUSH32(esp, 0x002D2D54u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D2D54: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D2D60
 * Original: 0x002D2D60 - 0x002D2D81 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D2D60(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D2D60: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3F2E1C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D2D90
 * Original: 0x002D2D90 - 0x002D2D9C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2D90(void)
{

loc_002D2D90: ;
    PUSH32(esp, 0x2D72E0);
    PUSH32(esp, 0x002D2D9Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2D9A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2DA0
 * Original: 0x002D2DA0 - 0x002D2DAC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2DA0(void)
{

loc_002D2DA0: ;
    PUSH32(esp, 0x2D7300);
    PUSH32(esp, 0x002D2DAAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2DAA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2DB0
 * Original: 0x002D2DB0 - 0x002D2DBC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2DB0(void)
{

loc_002D2DB0: ;
    PUSH32(esp, 0x2D7320);
    PUSH32(esp, 0x002D2DBAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2DBA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2DC0
 * Original: 0x002D2DC0 - 0x002D2DCC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2DC0(void)
{

loc_002D2DC0: ;
    PUSH32(esp, 0x2D7340);
    PUSH32(esp, 0x002D2DCAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2DCA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2DD0
 * Original: 0x002D2DD0 - 0x002D2DDC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2DD0(void)
{

loc_002D2DD0: ;
    PUSH32(esp, 0x2D7360);
    PUSH32(esp, 0x002D2DDAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2DDA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D2DE0
 * Original: 0x002D2DE0 - 0x002D2E27 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2DE0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2DE0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x9844332Bu;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2E06u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2E06: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376DDC;
    PUSH32(esp, 0x2D7100);
    MEM32(0x376DDC) = 0x31C0FC;
    PUSH32(esp, 0x002D2E23u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2E23: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2E30
 * Original: 0x002D2E30 - 0x002D2E77 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2E30(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2E30: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x5746C3BD;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2E56u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2E56: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376DE4;
    PUSH32(esp, 0x2D7110);
    MEM32(0x376DE4) = 0x31C10C;
    PUSH32(esp, 0x002D2E73u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2E73: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2E80
 * Original: 0x002D2E80 - 0x002D2EC7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2E80(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2E80: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xB22AC053u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2EA6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2EA6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376DEC;
    PUSH32(esp, 0x2D7120);
    MEM32(0x376DEC) = 0x31C11C;
    PUSH32(esp, 0x002D2EC3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2EC3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2ED0
 * Original: 0x002D2ED0 - 0x002D2F17 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2ED0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2ED0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x1B0EFA7;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2EF6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2EF6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376DF4;
    PUSH32(esp, 0x2D7130);
    MEM32(0x376DF4) = 0x31C174;
    PUSH32(esp, 0x002D2F13u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2F13: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2F20
 * Original: 0x002D2F20 - 0x002D2F67 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2F20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2F20: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x148EF289;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2F46u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2F46: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376DFC;
    PUSH32(esp, 0x2D7140);
    MEM32(0x376DFC) = 0x31C184;
    PUSH32(esp, 0x002D2F63u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2F63: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2F70
 * Original: 0x002D2F70 - 0x002D2FB7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2F70(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2F70: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xC7DDC27;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2F96u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2F96: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E04;
    PUSH32(esp, 0x2D7150);
    MEM32(0x376E04) = 0x31C1D0;
    PUSH32(esp, 0x002D2FB3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D2FB3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D2FC0
 * Original: 0x002D2FC0 - 0x002D3007 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D2FC0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D2FC0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x29589DDE;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D2FE6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D2FE6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E0C;
    PUSH32(esp, 0x2D7160);
    MEM32(0x376E0C) = 0x31C1E0;
    PUSH32(esp, 0x002D3003u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3003: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3010
 * Original: 0x002D3010 - 0x002D3057 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3010(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3010: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xD3DEE924u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3036u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3036: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E14;
    PUSH32(esp, 0x2D7170);
    MEM32(0x376E14) = 0x31C1F0;
    PUSH32(esp, 0x002D3053u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3053: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3060
 * Original: 0x002D3060 - 0x002D30A7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3060(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3060: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xC05EDEE4u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3086u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3086: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E1C;
    PUSH32(esp, 0x2D7180);
    MEM32(0x376E1C) = 0x31C200;
    PUSH32(esp, 0x002D30A3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D30A3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D30B0
 * Original: 0x002D30B0 - 0x002D30F7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D30B0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D30B0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xD78B3B1Cu;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D30D6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D30D6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E24;
    PUSH32(esp, 0x2D7190);
    MEM32(0x376E24) = 0x31C210;
    PUSH32(esp, 0x002D30F3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D30F3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3100
 * Original: 0x002D3100 - 0x002D3147 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3100(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3100: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xE218D7AEu;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3126u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3126: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E2C;
    PUSH32(esp, 0x2D71A0);
    MEM32(0x376E2C) = 0x31C220;
    PUSH32(esp, 0x002D3143u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3143: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3150
 * Original: 0x002D3150 - 0x002D3197 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3150(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3150: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x15C3BBB5;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3176u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3176: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E34;
    PUSH32(esp, 0x2D71B0);
    MEM32(0x376E34) = 0x31C230;
    PUSH32(esp, 0x002D3193u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3193: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D31A0
 * Original: 0x002D31A0 - 0x002D31E7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D31A0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D31A0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x147FF6F5;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D31C6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D31C6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E3C;
    PUSH32(esp, 0x2D71C0);
    MEM32(0x376E3C) = 0x31C240;
    PUSH32(esp, 0x002D31E3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D31E3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D31F0
 * Original: 0x002D31F0 - 0x002D3237 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D31F0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D31F0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x403A6D9A;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3216u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3216: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E44;
    PUSH32(esp, 0x2D71D0);
    MEM32(0x376E44) = 0x31C290;
    PUSH32(esp, 0x002D3233u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3233: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3240
 * Original: 0x002D3240 - 0x002D3287 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3240(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3240: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x4CDE679F;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3266u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3266: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E4C;
    PUSH32(esp, 0x2D71E0);
    MEM32(0x376E4C) = 0x31C2A0;
    PUSH32(esp, 0x002D3283u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3283: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3290
 * Original: 0x002D3290 - 0x002D32D7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3290(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3290: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x189BFCF0;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D32B6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D32B6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E54;
    PUSH32(esp, 0x2D71F0);
    MEM32(0x376E54) = 0x31C2F0;
    PUSH32(esp, 0x002D32D3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D32D3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D32E0
 * Original: 0x002D32E0 - 0x002D3327 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D32E0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D32E0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xA798873Du;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3306u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3306: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E5C;
    PUSH32(esp, 0x2D7200);
    MEM32(0x376E5C) = 0x31C300;
    PUSH32(esp, 0x002D3323u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3323: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3330
 * Original: 0x002D3330 - 0x002D3377 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3330(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3330: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xF16AEF75u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3356u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3356: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E64;
    PUSH32(esp, 0x2D7210);
    MEM32(0x376E64) = 0x31C310;
    PUSH32(esp, 0x002D3373u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3373: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3380
 * Original: 0x002D3380 - 0x002D33C7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3380(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3380: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x64DADE25;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D33A6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D33A6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E6C;
    PUSH32(esp, 0x2D7220);
    MEM32(0x376E6C) = 0x31C320;
    PUSH32(esp, 0x002D33C3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D33C3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D33D0
 * Original: 0x002D33D0 - 0x002D3417 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D33D0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D33D0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xABFEE30Fu;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D33F6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D33F6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E74;
    PUSH32(esp, 0x2D7230);
    MEM32(0x376E74) = 0x31C330;
    PUSH32(esp, 0x002D3413u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3413: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3420
 * Original: 0x002D3420 - 0x002D3467 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3420(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3420: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xAD46921Bu;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3446u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3446: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E7C;
    PUSH32(esp, 0x2D7240);
    MEM32(0x376E7C) = 0x31C340;
    PUSH32(esp, 0x002D3463u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3463: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3470
 * Original: 0x002D3470 - 0x002D34B7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3470(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3470: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xCB253575u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3496u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3496: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E84;
    PUSH32(esp, 0x2D7250);
    MEM32(0x376E84) = 0x31C350;
    PUSH32(esp, 0x002D34B3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D34B3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D34C0
 * Original: 0x002D34C0 - 0x002D3507 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D34C0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D34C0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x4483E964;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D34E6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D34E6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E8C;
    PUSH32(esp, 0x2D7260);
    MEM32(0x376E8C) = 0x31C360;
    PUSH32(esp, 0x002D3503u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3503: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3510
 * Original: 0x002D3510 - 0x002D3557 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3510(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3510: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x71683B71;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3536u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3536: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E94;
    PUSH32(esp, 0x2D7270);
    MEM32(0x376E94) = 0x31C370;
    PUSH32(esp, 0x002D3553u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3553: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3560
 * Original: 0x002D3560 - 0x002D35A7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3560(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3560: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xBE1B2D9;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3586u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3586: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376E9C;
    PUSH32(esp, 0x2D7280);
    MEM32(0x376E9C) = 0x31C380;
    PUSH32(esp, 0x002D35A3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D35A3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D35B0
 * Original: 0x002D35B0 - 0x002D35F7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D35B0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D35B0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xC640D987u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D35D6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D35D6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376EA4;
    PUSH32(esp, 0x2D7290);
    MEM32(0x376EA4) = 0x31C390;
    PUSH32(esp, 0x002D35F3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D35F3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3600
 * Original: 0x002D3600 - 0x002D3647 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3600(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3600: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0xDCC82547u;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3626u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3626: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376EAC;
    PUSH32(esp, 0x2D72A0);
    MEM32(0x376EAC) = 0x31C3A0;
    PUSH32(esp, 0x002D3643u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3643: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3650
 * Original: 0x002D3650 - 0x002D3697 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3650(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3650: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x61CFB4DE;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3676u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3676: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376EB4;
    PUSH32(esp, 0x2D72B0);
    MEM32(0x376EB4) = 0x31C3B0;
    PUSH32(esp, 0x002D3693u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3693: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D36A0
 * Original: 0x002D36A0 - 0x002D36E7 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D36A0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D36A0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x5DABF71C;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D36C6u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D36C6: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376EBC;
    PUSH32(esp, 0x2D72C0);
    MEM32(0x376EBC) = 0x31C3C0;
    PUSH32(esp, 0x002D36E3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D36E3: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D36F0
 * Original: 0x002D36F0 - 0x002D3737 (71 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D36F0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D36F0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = esp;
    PUSH32(esp, eax);
    ecx = esp + 0xC;
    PUSH32(esp, ecx);
    ecx = 0x3F2E20;
    MEM32(esp + 8) = 0x7392B093;
    MEM32(esp + 0xC) = 0;
    PUSH32(esp, 0x002D3716u); RECOMP_ABI_CALL(0x0003DBD0u, sub_0003DBD0); /* call 0x0003DBD0 */

loc_002D3716: ;
    edx = MEM32(eax);
    MEM32(edx + 4) = 0x376EC4;
    PUSH32(esp, 0x2D72D0);
    MEM32(0x376EC4) = 0x31C3D0;
    PUSH32(esp, 0x002D3733u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3733: ;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x14;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3740
 * Original: 0x002D3740 - 0x002D3757 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3740(void)
{

loc_002D3740: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x140390);
    PUSH32(esp, 0xD4B7D42);
    ecx = 0x3F2E7C;
    PUSH32(esp, 0x002D3756u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D3756: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D3760
 * Original: 0x002D3760 - 0x002D3781 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3760(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3760: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x3F2E98) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3790
 * Original: 0x002D3790 - 0x002D37A7 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3790(void)
{

loc_002D3790: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x1415D0);
    PUSH32(esp, 0xAE0ACDE);
    ecx = 0x3F2E9C;
    PUSH32(esp, 0x002D37A6u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D37A6: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D37B0
 * Original: 0x002D37B0 - 0x002D37C6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D37B0(void)
{

loc_002D37B0: ;
    ecx = 0x3F3178;
    PUSH32(esp, 0x002D37BAu); RECOMP_ABI_CALL(0x00145150u, sub_00145150); /* call 0x00145150 */

loc_002D37BA: ;
    PUSH32(esp, 0x2D76B0);
    PUSH32(esp, 0x002D37C4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D37C4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D37D0
 * Original: 0x002D37D0 - 0x002D37E6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D37D0(void)
{

loc_002D37D0: ;
    ecx = 0x3F31F0;
    PUSH32(esp, 0x002D37DAu); RECOMP_ABI_CALL(0x00146FD0u, sub_00146FD0); /* call 0x00146FD0 */

loc_002D37DA: ;
    PUSH32(esp, 0x2D76C0);
    PUSH32(esp, 0x002D37E4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D37E4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D37F0
 * Original: 0x002D37F0 - 0x002D3806 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D37F0(void)
{

loc_002D37F0: ;
    ecx = 0x3F32B8;
    PUSH32(esp, 0x002D37FAu); RECOMP_ABI_CALL(0x001AE6E0u, sub_001AE6E0); /* call 0x001AE6E0 */

loc_002D37FA: ;
    PUSH32(esp, 0x2D7390);
    PUSH32(esp, 0x002D3804u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3804: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3810
 * Original: 0x002D3810 - 0x002D381C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3810(void)
{

loc_002D3810: ;
    PUSH32(esp, 0x2D73D0);
    PUSH32(esp, 0x002D381Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D381A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3820
 * Original: 0x002D3820 - 0x002D3847 (39 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3820(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3820: ;
    eax = 0x3F4730;
    ecx = 0x20;
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    /* nop */

loc_002D3830: ;
    MEM32(eax) = edx;
    MEM32(eax + 4) = edx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D3830; /* jne: not equal / not zero */

loc_002D383B: ;
    PUSH32(esp, 0x2D73A0);
    PUSH32(esp, 0x002D3845u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3845: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3850
 * Original: 0x002D3850 - 0x002D385C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3850(void)
{

loc_002D3850: ;
    PUSH32(esp, 0x2D7440);
    PUSH32(esp, 0x002D385Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D385A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3860
 * Original: 0x002D3860 - 0x002D386C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3860(void)
{

loc_002D3860: ;
    PUSH32(esp, 0x2D74B0);
    PUSH32(esp, 0x002D386Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D386A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3870
 * Original: 0x002D3870 - 0x002D3886 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3870(void)
{

loc_002D3870: ;
    ecx = 0x3F4830;
    PUSH32(esp, 0x002D387Au); RECOMP_ABI_CALL(0x00146610u, sub_00146610); /* call 0x00146610 */

loc_002D387A: ;
    PUSH32(esp, 0x2D7670);
    PUSH32(esp, 0x002D3884u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3884: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3890
 * Original: 0x002D3890 - 0x002D3920 (144 bytes, 45 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3890(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D3890: ;
    xmm0 = XMM_ZERO(); /* xorps self = zero */
    xmm1 = XMM_SCALAR(MEMF(0x2FE99C)); /* movss */
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    eax = 0x3F48B8;
    edx = 3;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    esi = 1;
    /* nop */

loc_002D38B0: ;
    MEM32(eax + -16) = ecx;
    MEM32(eax + -12) = ecx;
    MEM32(eax + -4) = ecx;
    MEM32(eax) = ecx;
    MEM32(eax + 0x14) = ecx;
    ebx = 0; /* xor self */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ebp = eax + 8;
    MEM32(ebp) = ebx;
    MEM32(ebp + 4) = ebx;
    MEM32(ebp + 8) = ebx;
    MEMF(eax + 4) = xmm0.f[0]; /* movss */
    MEM32(eax + 0x18) = ecx;
    MEMF(eax + 0x1C) = xmm0.f[0]; /* movss */
    MEM32(eax + 0x20) = esi;
    MEM32(eax + 0x24) = ecx;
    MEMF(eax + 0x28) = xmm1.f[0]; /* movss */
    MEM32(eax + 0x2C) = esi;
    MEMF(eax + 0x30) = xmm1.f[0]; /* movss */
    MEM32(eax + -8) = 0x31D51C;
    MEM32(eax + 0x34) = ecx;
    MEM32(eax + 0x38) = ecx;
    MEM32(eax + 0x3C) = ecx;
    MEMF(eax + 0x40) = xmm0.f[0]; /* movss */
    MEM32(eax + 0x44) = ecx;
    MEMF(eax + 0x48) = xmm0.f[0]; /* movss */
    _fb = (uint32_t)(0x60) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x60;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edx--;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D38B0; /* jne: not equal / not zero */

loc_002D390F: ;
    PUSH32(esp, 0x2D73B0);
    PUSH32(esp, 0x002D3919u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3919: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3920
 * Original: 0x002D3920 - 0x002D3930 (16 bytes, 8 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3920(void)
{

loc_002D3920: ;
    PUSH32(esp, 0x2D7520);
    PUSH32(esp, 0x002D392Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D392A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3930
 * Original: 0x002D3930 - 0x002D393C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3930(void)
{

loc_002D3930: ;
    PUSH32(esp, 0x2D7590);
    PUSH32(esp, 0x002D393Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D393A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3940
 * Original: 0x002D3940 - 0x002D394C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3940(void)
{

loc_002D3940: ;
    PUSH32(esp, 0x2D7600);
    PUSH32(esp, 0x002D394Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D394A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3950
 * Original: 0x002D3950 - 0x002D3971 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3950(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3950: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x4F4EA0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3980
 * Original: 0x002D3980 - 0x002D398C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3980(void)
{

loc_002D3980: ;
    PUSH32(esp, 0x2D76F0);
    PUSH32(esp, 0x002D398Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D398A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3990
 * Original: 0x002D3990 - 0x002D39B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3990(void)
{

loc_002D3990: ;
    eax = MEM32(0x4F4E68);
    PUSH32(esp, 0xC800);
    PUSH32(esp, eax);
    ecx = 0x4F4EA8;
    PUSH32(esp, 0x002D39A5u); RECOMP_ABI_CALL(0x00140740u, sub_00140740); /* call 0x00140740 */

loc_002D39A5: ;
    PUSH32(esp, 0x2D76D0);
    PUSH32(esp, 0x002D39AFu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D39AF: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D39C0
 * Original: 0x002D39C0 - 0x002D39D6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D39C0(void)
{

loc_002D39C0: ;
    ecx = 0x4F52D0;
    PUSH32(esp, 0x002D39CAu); RECOMP_ABI_CALL(0x0014ADC0u, sub_0014ADC0); /* call 0x0014ADC0 */

loc_002D39CA: ;
    PUSH32(esp, 0x2D76E0);
    PUSH32(esp, 0x002D39D4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D39D4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D39E0
 * Original: 0x002D39E0 - 0x002D39EC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D39E0(void)
{

loc_002D39E0: ;
    PUSH32(esp, 0x2D7700);
    PUSH32(esp, 0x002D39EAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D39EA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D39F0
 * Original: 0x002D39F0 - 0x002D3A01 (17 bytes, 3 insns)
 * Category: data_init
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D39F0(void)
{

loc_002D39F0: ;
    xmm0 = XMM_SCALAR(MEMF(0x31D894)); /* movss */
    MEMF(0x4F5B48) = xmm0.f[0]; /* movss */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3A10
 * Original: 0x002D3A10 - 0x002D3A26 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3A10(void)
{

loc_002D3A10: ;
    ecx = 0x4F5DD8;
    PUSH32(esp, 0x002D3A1Au); RECOMP_ABI_CALL(0x001AE6E0u, sub_001AE6E0); /* call 0x001AE6E0 */

loc_002D3A1A: ;
    PUSH32(esp, 0x2D7710);
    PUSH32(esp, 0x002D3A24u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3A24: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3A30
 * Original: 0x002D3A30 - 0x002D3A51 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3A30(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3A30: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x4F7250) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3A60
 * Original: 0x002D3A60 - 0x002D3A77 (23 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3A60(void)
{

loc_002D3A60: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0x14AA10);
    PUSH32(esp, 0xA9D1BA99u);
    ecx = 0x4F7254;
    PUSH32(esp, 0x002D3A76u); RECOMP_ABI_CALL(0x00035780u, sub_00035780); /* call 0x00035780 */

loc_002D3A76: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D3A80
 * Original: 0x002D3A80 - 0x002D3A8C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3A80(void)
{

loc_002D3A80: ;
    PUSH32(esp, 0x2D7720);
    PUSH32(esp, 0x002D3A8Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3A8A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3A90
 * Original: 0x002D3A90 - 0x002D3ACC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3A90(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3A90: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D3A97u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D3A97: ;
    MEM32(0x4F7284) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x4F7288) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x4F7284);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x4F7284);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x4F7284);
    PUSH32(esp, 0x2D7730);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D3AC8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3AC8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3AD0
 * Original: 0x002D3AD0 - 0x002D3B0C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3AD0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3AD0: ;
    PUSH32(esp, 0x20);
    PUSH32(esp, 0x002D3AD7u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D3AD7: ;
    MEM32(0x4F72B4) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x4F72B8) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x4F72B4);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x4F72B4);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x4F72B4);
    PUSH32(esp, 0x2D77A0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D3B08u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3B08: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3B10
 * Original: 0x002D3B10 - 0x002D3B1C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3B10(void)
{

loc_002D3B10: ;
    PUSH32(esp, 0x2D7790);
    PUSH32(esp, 0x002D3B1Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3B1A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3B20
 * Original: 0x002D3B20 - 0x002D3B5C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3B20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3B20: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D3B27u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D3B27: ;
    MEM32(0x4F73F4) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x4F73F8) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x4F73F4);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x4F73F4);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x4F73F4);
    PUSH32(esp, 0x2D7800);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D3B58u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3B58: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3B60
 * Original: 0x002D3B60 - 0x002D3B6C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3B60(void)
{

loc_002D3B60: ;
    PUSH32(esp, 0x2D7860);
    PUSH32(esp, 0x002D3B6Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3B6A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3B70
 * Original: 0x002D3B70 - 0x002D3BAC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3B70(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3B70: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D3B77u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D3B77: ;
    MEM32(0x4F742C) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x4F7430) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x4F742C);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x4F742C);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x4F742C);
    PUSH32(esp, 0x2D7870);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D3BA8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3BA8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3BB0
 * Original: 0x002D3BB0 - 0x002D3BEC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3BB0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3BB0: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D3BB7u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D3BB7: ;
    MEM32(0x4F7438) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x4F743C) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x4F7438);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x4F7438);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x4F7438);
    PUSH32(esp, 0x2D78D0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D3BE8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3BE8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3BF0
 * Original: 0x002D3BF0 - 0x002D3C01 (17 bytes, 5 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3BF0(void)
{

loc_002D3BF0: ;
    PUSH32(esp, 0x002D3BF5u); RECOMP_ABI_CALL(0x00152160u, sub_00152160); /* call 0x00152160 */

loc_002D3BF5: ;
    PUSH32(esp, 0x2D7930);
    PUSH32(esp, 0x002D3BFFu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3BFF: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3C10
 * Original: 0x002D3C10 - 0x002D3C3D (45 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3C10(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3C10: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x4F7450;
    edi = 5;
    /* nop */

loc_002D3C20: ;
    ecx = esi;
    PUSH32(esp, 0x002D3C27u); RECOMP_ABI_CALL(0x001553B0u, sub_001553B0); /* call 0x001553B0 */

loc_002D3C27: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 0x1C;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D3C20; /* jne: not equal / not zero */

loc_002D3C2D: ;
    PUSH32(esp, 0x2D7940);
    PUSH32(esp, 0x002D3C37u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3C37: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3C40
 * Original: 0x002D3C40 - 0x002D3C4C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3C40(void)
{

loc_002D3C40: ;
    PUSH32(esp, 0x2D79C0);
    PUSH32(esp, 0x002D3C4Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3C4A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3C50
 * Original: 0x002D3C50 - 0x002D3CF3 (163 bytes, 34 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3C50(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3C50: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x51D2B8) = eax;
    MEM32(0x51D2BC) = eax;
    MEM32(0x51D2C0) = eax;
    MEM32(0x51D2C4) = eax;
    MEM32(0x51D2C8) = eax;
    MEM32(0x51D2CC) = eax;
    MEM32(0x51D2D0) = eax;
    MEM32(0x51D2D4) = eax;
    MEM32(0x51D2D8) = eax;
    MEM32(0x51D2DC) = eax;
    MEM32(0x51D2E0) = eax;
    MEM32(0x51D2E4) = eax;
    MEM32(0x51D2E8) = eax;
    MEM32(0x51D2EC) = eax;
    MEM32(0x51D2F0) = eax;
    MEM32(0x51D2F4) = eax;
    MEM32(0x51D2F8) = eax;
    MEM32(0x51D2FC) = eax;
    MEM32(0x51D300) = eax;
    MEM32(0x51D304) = eax;
    MEM32(0x51D308) = eax;
    MEM32(0x51D30C) = eax;
    MEM32(0x51D310) = eax;
    MEM32(0x51D314) = eax;
    MEM32(0x51D318) = eax;
    MEM32(0x51D31C) = eax;
    MEM32(0x51D320) = eax;
    MEM32(0x51D324) = eax;
    MEM32(0x51D328) = eax;
    MEM32(0x51D32C) = eax;
    MEM32(0x51D330) = eax;
    MEM32(0x51D334) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D3D00
 * Original: 0x002D3D00 - 0x002D3D15 (21 bytes, 5 insns)
 * Category: game_camera
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3D00(void)
{

loc_002D3D00: ;
    PUSH32(esp, 0x156A80);
    PUSH32(esp, 0x31EB2C);
    ecx = 0x51D338;
    PUSH32(esp, 0x002D3D14u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D3D14: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D3D20
 * Original: 0x002D3D20 - 0x002D3D41 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3D20(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3D20: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D668) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3D50
 * Original: 0x002D3D50 - 0x002D3D8C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3D50(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3D50: ;
    PUSH32(esp, 0x28);
    PUSH32(esp, 0x002D3D57u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D3D57: ;
    MEM32(0x51D66C) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x51D670) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x51D66C);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x51D66C);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x51D66C);
    PUSH32(esp, 0x2D79D0);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D3D88u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3D88: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3D90
 * Original: 0x002D3D90 - 0x002D3DB1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3D90(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3D90: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D678) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3DC0
 * Original: 0x002D3DC0 - 0x002D3DE1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3DC0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3DC0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D67C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3DF0
 * Original: 0x002D3DF0 - 0x002D3E11 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3DF0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3DF0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D6C8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3E20
 * Original: 0x002D3E20 - 0x002D3E41 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3E20(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3E20: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D6CC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3E50
 * Original: 0x002D3E50 - 0x002D3E8B (59 bytes, 19 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3E50(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D3E50: ;
    _fb = (uint32_t)(0x44) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x44;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, esi);
    SET_LO8(eax, 0); /* xor self */
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fas = (int32_t)(int8_t)(_fa); /* xor result */
    PUSH32(esp, edi);
    MEM8(esp + 0xC) = LO8(eax);
    MEM8(esp + 0xD) = LO8(eax);
    MEM8(esp + 0xE) = LO8(eax);
    ecx = 0x11;
    esi = esp + 8;
    edi = 0x3785E0;
    MEM8(esp + 0xF) = 0xFF;
    PUSH32(esp, 0x2D7A40);
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    PUSH32(esp, 0x002D3E82u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3E82: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    POP32(esp, esi);
    _fb = (uint32_t)(0x44) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x44;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D3E90
 * Original: 0x002D3E90 - 0x002D3EB1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3E90(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3E90: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D84C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3EC0
 * Original: 0x002D3EC0 - 0x002D3EE1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3EC0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3EC0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D870) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3EF0
 * Original: 0x002D3EF0 - 0x002D3EFC (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3EF0(void)
{

loc_002D3EF0: ;
    PUSH32(esp, 0x2D7AB0);
    PUSH32(esp, 0x002D3EFAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3EFA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F00
 * Original: 0x002D3F00 - 0x002D3F0C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F00(void)
{

loc_002D3F00: ;
    PUSH32(esp, 0x2D7AC0);
    PUSH32(esp, 0x002D3F0Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F0A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F10
 * Original: 0x002D3F10 - 0x002D3F1C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F10(void)
{

loc_002D3F10: ;
    PUSH32(esp, 0x2D7AD0);
    PUSH32(esp, 0x002D3F1Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F1A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F20
 * Original: 0x002D3F20 - 0x002D3F2C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F20(void)
{

loc_002D3F20: ;
    PUSH32(esp, 0x2D7AE0);
    PUSH32(esp, 0x002D3F2Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F2A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F30
 * Original: 0x002D3F30 - 0x002D3F3C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F30(void)
{

loc_002D3F30: ;
    PUSH32(esp, 0x2D7AF0);
    PUSH32(esp, 0x002D3F3Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F3A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F40
 * Original: 0x002D3F40 - 0x002D3F4C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F40(void)
{

loc_002D3F40: ;
    PUSH32(esp, 0x2D7B00);
    PUSH32(esp, 0x002D3F4Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F4A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F50
 * Original: 0x002D3F50 - 0x002D3F5C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F50(void)
{

loc_002D3F50: ;
    PUSH32(esp, 0x2D7B10);
    PUSH32(esp, 0x002D3F5Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F5A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F60
 * Original: 0x002D3F60 - 0x002D3F6C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D3F60(void)
{

loc_002D3F60: ;
    PUSH32(esp, 0x2D7B20);
    PUSH32(esp, 0x002D3F6Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D3F6A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D3F70
 * Original: 0x002D3F70 - 0x002D3F91 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3F70(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3F70: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D874) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3FA0
 * Original: 0x002D3FA0 - 0x002D3FC1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3FA0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3FA0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D878) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D3FD0
 * Original: 0x002D3FD0 - 0x002D3FF1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D3FD0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D3FD0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8B0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4000
 * Original: 0x002D4000 - 0x002D4021 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4000(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4000: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8B4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4030
 * Original: 0x002D4030 - 0x002D4051 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4030(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4030: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8B8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4060
 * Original: 0x002D4060 - 0x002D4081 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4060(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4060: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8BC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4090
 * Original: 0x002D4090 - 0x002D40B1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4090(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4090: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8C0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D40C0
 * Original: 0x002D40C0 - 0x002D40E1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D40C0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D40C0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8E4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D40F0
 * Original: 0x002D40F0 - 0x002D4111 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D40F0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D40F0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8E8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4120
 * Original: 0x002D4120 - 0x002D4141 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4120(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4120: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8EC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4150
 * Original: 0x002D4150 - 0x002D4171 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4150(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4150: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8F0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4180
 * Original: 0x002D4180 - 0x002D41A1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4180(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4180: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8F4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D41B0
 * Original: 0x002D41B0 - 0x002D41D1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D41B0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D41B0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8F8) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D41E0
 * Original: 0x002D41E0 - 0x002D4201 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D41E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D41E0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D8FC) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4210
 * Original: 0x002D4210 - 0x002D4231 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4210(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4210: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51D900) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4240
 * Original: 0x002D4240 - 0x002D427C (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4240(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4240: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D4247u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D4247: ;
    MEM32(0x51FAC0) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x51FAC4) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x51FAC0);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x51FAC0);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x51FAC0);
    PUSH32(esp, 0x2D7B30);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D4278u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4278: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D4280
 * Original: 0x002D4280 - 0x002D42BC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4280(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4280: ;
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x002D4287u); RECOMP_ABI_CALL(0x00155270u, sub_00155270); /* call 0x00155270 */

loc_002D4287: ;
    MEM32(0x51FACC) = eax;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x51FAD0) = ecx;
    MEM8(eax) = LO8(ecx);
    eax = MEM32(0x51FACC);
    MEM32(eax + 4) = ecx;
    eax = MEM32(0x51FACC);
    MEM32(eax + 8) = eax;
    eax = MEM32(0x51FACC);
    PUSH32(esp, 0x2D7B90);
    MEM32(eax + 0xC) = eax;
    PUSH32(esp, 0x002D42B8u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D42B8: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D42C0
 * Original: 0x002D42C0 - 0x002D42E1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D42C0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D42C0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x51FB64) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D42F0
 * Original: 0x002D42F0 - 0x002D4303 (19 bytes, 5 insns)
 * Category: game_ui
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D42F0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D42F0: ;
    PUSH32(esp, 0x321980);
    PUSH32(esp, 0x002D42FAu); RECOMP_ABI_CALL(0x00194DB0u, sub_00194DB0); /* call 0x00194DB0 */

loc_002D42FA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x51FB68) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4310
 * Original: 0x002D4310 - 0x002D4323 (19 bytes, 5 insns)
 * Category: game_io
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4310(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4310: ;
    PUSH32(esp, 0x3214B0);
    PUSH32(esp, 0x002D431Au); RECOMP_ABI_CALL(0x00194DB0u, sub_00194DB0); /* call 0x00194DB0 */

loc_002D431A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x51FB6C) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4330
 * Original: 0x002D4330 - 0x002D4373 (67 bytes, 13 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4330(void)
{

loc_002D4330: ;
    ecx = 0x378968;
    PUSH32(esp, 0x002D433Au); RECOMP_ABI_CALL(0x00109D60u, sub_00109D60); /* call 0x00109D60 */

loc_002D433A: ;
    eax = MEM32(0x51FB74);
    MEM32(0x51FB78) = eax;
    eax = 2;
    PUSH32(esp, 0x2D7BF0);
    MEM32(0x378974) = 0;
    MEM32(0x378978) = 0xFFFFFFFFu;
    MEM32(0x51FB7C) = eax;
    MEM32(0x51FB74) = eax;
    PUSH32(esp, 0x002D4371u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4371: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4380
 * Original: 0x002D4380 - 0x002D43A0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4380(void)
{

loc_002D4380: ;
    PUSH32(esp, 0x51FBC0);
    PUSH32(esp, 0x12C);
    ecx = 0x523400;
    PUSH32(esp, 0x002D4394u); RECOMP_ABI_CALL(0x0017FDA0u, sub_0017FDA0); /* call 0x0017FDA0 */

loc_002D4394: ;
    PUSH32(esp, 0x2D7C00);
    PUSH32(esp, 0x002D439Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D439E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D43A0
 * Original: 0x002D43A0 - 0x002D43D0 (48 bytes, 24 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D43A0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D43A0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x523414) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D43D0
 * Original: 0x002D43D0 - 0x002D43F1 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D43D0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D43D0: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x52342C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4400
 * Original: 0x002D4400 - 0x002D4416 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4400(void)
{

loc_002D4400: ;
    ecx = 0x523430;
    PUSH32(esp, 0x002D440Au); RECOMP_ABI_CALL(0x001D0810u, sub_001D0810); /* call 0x001D0810 */

loc_002D440A: ;
    PUSH32(esp, 0x2D7C40);
    PUSH32(esp, 0x002D4414u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4414: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4420
 * Original: 0x002D4420 - 0x002D4441 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4420(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4420: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x5234E4) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4450
 * Original: 0x002D4450 - 0x002D445C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4450(void)
{

loc_002D4450: ;
    PUSH32(esp, 0x2D7C50);
    PUSH32(esp, 0x002D445Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D445A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4460
 * Original: 0x002D4460 - 0x002D4481 (33 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D4460(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D4460: ;
    fp_push(MEMD(0x2FEB08)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) { double _a = fp_top(); fp_top() = recomp_x87_tan(_a); fp_push(isfinite(_a) ? 1.0 : _a - _a); } /* fptan */
    fp_pop(); /* fstp st(0) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEB00)); /* fmul dword ptr [0x2feb00] */
    fp_push(1.0); /* fld1 */
    { fp_st1() = atan2(fp_st1(), fp_top()); fp_pop(); } /* fpatan */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FEAFC)); /* fmul dword ptr [0x2feafc] */
    MEMF(0x5234F0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D4490
 * Original: 0x002D4490 - 0x002D44A3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4490(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4490: ;
    PUSH32(esp, 0x324008);
    PUSH32(esp, 0x002D449Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D449A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x5234F4) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D44B0
 * Original: 0x002D44B0 - 0x002D44C3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D44B0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D44B0: ;
    PUSH32(esp, 0x324010);
    PUSH32(esp, 0x002D44BAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D44BA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x5234F8) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D44D0
 * Original: 0x002D44D0 - 0x002D44E3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D44D0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D44D0: ;
    PUSH32(esp, 0x324028);
    PUSH32(esp, 0x002D44DAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D44DA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x5234FC) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D44F0
 * Original: 0x002D44F0 - 0x002D4503 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D44F0(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D44F0: ;
    PUSH32(esp, 0x32403C);
    PUSH32(esp, 0x002D44FAu); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D44FA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x523500) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4510
 * Original: 0x002D4510 - 0x002D4523 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4510(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4510: ;
    PUSH32(esp, 0x32404C);
    PUSH32(esp, 0x002D451Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D451A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x523504) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4530
 * Original: 0x002D4530 - 0x002D4543 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4530(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4530: ;
    PUSH32(esp, 0x32405C);
    PUSH32(esp, 0x002D453Au); RECOMP_ABI_CALL(0x002642E0u, sub_002642E0); /* call 0x002642E0 */

loc_002D453A: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x523508) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4550
 * Original: 0x002D4550 - 0x002D4566 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4550(void)
{

loc_002D4550: ;
    ecx = 0x523520;
    PUSH32(esp, 0x002D455Au); RECOMP_ABI_CALL(0x000EEFF0u, sub_000EEFF0); /* call 0x000EEFF0 */

loc_002D455A: ;
    PUSH32(esp, 0x2D7C60);
    PUSH32(esp, 0x002D4564u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4564: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4570
 * Original: 0x002D4570 - 0x002D4586 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4570(void)
{

loc_002D4570: ;
    ecx = 0x5235D8;
    PUSH32(esp, 0x002D457Au); RECOMP_ABI_CALL(0x001CD4C0u, sub_001CD4C0); /* call 0x001CD4C0 */

loc_002D457A: ;
    PUSH32(esp, 0x2D7C70);
    PUSH32(esp, 0x002D4584u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4584: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4590
 * Original: 0x002D4590 - 0x002D461B (139 bytes, 35 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4590(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4590: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, ecx);
    PUSH32(esp, esi);
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, esi);
    PUSH32(esp, 0x34);
    { uint32_t _icall_target = MEM32(0x37DB68); PUSH32(esp, 0x002D459Du); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002D4597u); } /* indirect call */
    }

loc_002D459D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D45B7; /* je: equal / zero */

loc_002D45A4: ;
    PUSH32(esp, 0x529D1C);
    ecx = eax;
    PUSH32(esp, 0x002D45B0u); RECOMP_ABI_CALL(0x001D2B00u, sub_001D2B00); /* call 0x001D2B00 */

loc_002D45B0: ;
    MEM32(0x523624) = eax;
    goto loc_002D45BD;

loc_002D45B7: ;
    MEM32(0x523624) = esi;

loc_002D45BD: ;
    eax = esp + 7;
    PUSH32(esp, eax);
    PUSH32(esp, 0x324104);
    MEM32(0x52362C) = esi;
    MEM32(0x523628) = esi;
    MEM32(0x523634) = esi;
    MEM32(0x523630) = esi;
    PUSH32(esp, 0x002D45E4u); RECOMP_ABI_CALL(0x001C56A0u, sub_001C56A0); /* call 0x001C56A0 */

loc_002D45E4: ;
    PUSH32(esp, 0x2D7CA0);
    MEM32(0x52363C) = eax;
    MEM32(0x523638) = 1;
    MEM32(0x523644) = esi;
    MEM32(0x523640) = esi;
    MEM32(0x52364C) = esi;
    MEM32(0x523648) = esi;
    PUSH32(esp, 0x002D4615u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4615: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, esi);
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4620
 * Original: 0x002D4620 - 0x002D4636 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4620(void)
{

loc_002D4620: ;
    ecx = 0x523650;
    PUSH32(esp, 0x002D462Au); RECOMP_ABI_CALL(0x001CF930u, sub_001CF930); /* call 0x001CF930 */

loc_002D462A: ;
    PUSH32(esp, 0x2D7C80);
    PUSH32(esp, 0x002D4634u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4634: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4640
 * Original: 0x002D4640 - 0x002D4656 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4640(void)
{

loc_002D4640: ;
    ecx = 0x5236A0;
    PUSH32(esp, 0x002D464Au); RECOMP_ABI_CALL(0x001D0230u, sub_001D0230); /* call 0x001D0230 */

loc_002D464A: ;
    PUSH32(esp, 0x2D7C90);
    PUSH32(esp, 0x002D4654u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4654: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4660
 * Original: 0x002D4660 - 0x002D466C (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4660(void)
{

loc_002D4660: ;
    PUSH32(esp, 0x2D7CC0);
    PUSH32(esp, 0x002D466Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D466A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4670
 * Original: 0x002D4670 - 0x002D467A (10 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4670(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D4670: ;
    ecx = 0x5237B0;
    g_seh_ebp = ebp; sub_001D3D30(); return; /* tail jmp 0x001D3D30 */

}

/**
 * sub_002D4680
 * Original: 0x002D4680 - 0x002D4695 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4680(void)
{

loc_002D4680: ;
    PUSH32(esp, 0x190330);
    PUSH32(esp, 0x3245FC);
    ecx = 0x523850;
    PUSH32(esp, 0x002D4694u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D4694: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D46A0
 * Original: 0x002D46A0 - 0x002D46B5 (21 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D46A0(void)
{

loc_002D46A0: ;
    PUSH32(esp, 0x1907F0);
    PUSH32(esp, 0x32460C);
    ecx = 0x523860;
    PUSH32(esp, 0x002D46B4u); RECOMP_ABI_CALL(0x0003AB80u, sub_0003AB80); /* call 0x0003AB80 */

loc_002D46B4: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D46B5
 * Original: 0x002D46B5 - 0x002D46C0 (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D46B5(void)
{

loc_002D46B5: ;
    MEM32(0x524274) = 1;
    esp += 4; return; /* ret */

}

/**
 * sub_002D46C0
 * Original: 0x002D46C0 - 0x002D46D6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D46C0(void)
{

loc_002D46C0: ;
    ecx = 0x525140;
    PUSH32(esp, 0x002D46CAu); RECOMP_ABI_CALL(0x001BB1AEu, sub_001BB1AE); /* call 0x001BB1AE */

loc_002D46CA: ;
    PUSH32(esp, 0x2D7CE3);
    PUSH32(esp, 0x002D46D4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D46D4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D46D6
 * Original: 0x002D46D6 - 0x002D46E2 (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D46D6(void)
{

loc_002D46D6: ;
    PUSH32(esp, 0x2D7CC1);
    PUSH32(esp, 0x002D46E0u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D46E0: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D46E2
 * Original: 0x002D46E2 - 0x002D46F8 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D46E2(void)
{

loc_002D46E2: ;
    ecx = 0x5250B8;
    PUSH32(esp, 0x002D46ECu); RECOMP_ABI_CALL(0x001BF83Fu, sub_001BF83F); /* call 0x001BF83F */

loc_002D46EC: ;
    PUSH32(esp, 0x2D7CC2);
    PUSH32(esp, 0x002D46F6u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D46F6: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D46F8
 * Original: 0x002D46F8 - 0x002D4708 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D46F8(void)
{

loc_002D46F8: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524FB0;
    PUSH32(esp, 0x002D4707u); RECOMP_ABI_CALL(0x001BAEEDu, sub_001BAEED); /* call 0x001BAEED */

loc_002D4707: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4708
 * Original: 0x002D4708 - 0x002D4718 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4708(void)
{

loc_002D4708: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x5249A0;
    PUSH32(esp, 0x002D4717u); RECOMP_ABI_CALL(0x001BAF16u, sub_001BAF16); /* call 0x001BAF16 */

loc_002D4717: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4718
 * Original: 0x002D4718 - 0x002D4728 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4718(void)
{

loc_002D4718: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x525348;
    PUSH32(esp, 0x002D4727u); RECOMP_ABI_CALL(0x001BAF37u, sub_001BAF37); /* call 0x001BAF37 */

loc_002D4727: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4728
 * Original: 0x002D4728 - 0x002D4738 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4728(void)
{

loc_002D4728: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x525400;
    PUSH32(esp, 0x002D4737u); RECOMP_ABI_CALL(0x001BAF9Cu, sub_001BAF9C); /* call 0x001BAF9C */

loc_002D4737: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4738
 * Original: 0x002D4738 - 0x002D4748 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4738(void)
{

loc_002D4738: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524AA8;
    PUSH32(esp, 0x002D4747u); RECOMP_ABI_CALL(0x001BAF68u, sub_001BAF68); /* call 0x001BAF68 */

loc_002D4747: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4748
 * Original: 0x002D4748 - 0x002D4758 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4748(void)
{

loc_002D4748: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x5252B8;
    PUSH32(esp, 0x002D4757u); RECOMP_ABI_CALL(0x001BAFD0u, sub_001BAFD0); /* call 0x001BAFD0 */

loc_002D4757: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4758
 * Original: 0x002D4758 - 0x002D4768 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4758(void)
{

loc_002D4758: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524C50;
    PUSH32(esp, 0x002D4767u); RECOMP_ABI_CALL(0x001BB004u, sub_001BB004); /* call 0x001BB004 */

loc_002D4767: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4768
 * Original: 0x002D4768 - 0x002D4778 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4768(void)
{

loc_002D4768: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524D78;
    PUSH32(esp, 0x002D4777u); RECOMP_ABI_CALL(0x001BB038u, sub_001BB038); /* call 0x001BB038 */

loc_002D4777: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4778
 * Original: 0x002D4778 - 0x002D47AE (54 bytes, 9 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4778(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4778: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 8);
    ecx = 0x524B30;
    PUSH32(esp, 0x002D4789u); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D4789: ;
    MEM16(0x524B46) = MEM16(0x524B46) & 0;
    _fa = (uint32_t)(MEM16(0x524B46)) & 0xFFFFu; _fas = (int32_t)(int16_t)(_fa); /* and result */
    MEM16(0x524B44) = MEM16(0x524B44) & 0;
    _fa = (uint32_t)(MEM16(0x524B44)) & 0xFFFFu; _fas = (int32_t)(int16_t)(_fa); /* and result */
    MEM32(0x524B30) = 0x33560C;
    MEM32(0x524B54) = 2;
    esp += 4; return; /* ret */

}

/**
 * sub_002D47AE
 * Original: 0x002D47AE - 0x002D47CA (28 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D47AE(void)
{

loc_002D47AE: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 9);
    ecx = 0x5250DC;
    PUSH32(esp, 0x002D47BFu); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D47BF: ;
    MEM32(0x5250DC) = 0x33560C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D47CA
 * Original: 0x002D47CA - 0x002D47FC (50 bytes, 11 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D47CA(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D47CA: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0x13);
    ecx = 0x524F54;
    PUSH32(esp, 0x002D47DBu); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D47DB: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x524F54) = 0x33560C;
    MEM32(0x524F78) = eax;
    MEM32(0x524F7C) = eax;
    MEM32(0x524F80) = eax;
    MEM32(0x524F84) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D47FC
 * Original: 0x002D47FC - 0x002D4829 (45 bytes, 10 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D47FC(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D47FC: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0x11);
    ecx = 0x52504C;
    PUSH32(esp, 0x002D480Du); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D480D: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x52504C) = 0x33560C;
    MEM32(0x525070) = eax;
    MEM32(0x525074) = eax;
    MEM32(0x525078) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4829
 * Original: 0x002D4829 - 0x002D485B (50 bytes, 11 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4829(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D4829: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0x12);
    ecx = 0x525498;
    PUSH32(esp, 0x002D483Au); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D483A: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(0x525498) = 0x33560C;
    MEM32(0x5254BC) = eax;
    MEM32(0x5254C0) = eax;
    MEM32(0x5254C4) = eax;
    MEM32(0x5254C8) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D485B
 * Original: 0x002D485B - 0x002D486B (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D485B(void)
{

loc_002D485B: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524CE0;
    PUSH32(esp, 0x002D486Au); RECOMP_ABI_CALL(0x001BB06Cu, sub_001BB06C); /* call 0x001BB06C */

loc_002D486A: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D486B
 * Original: 0x002D486B - 0x002D4887 (28 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D486B(void)
{

loc_002D486B: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0xA);
    ecx = 0x5253D8;
    PUSH32(esp, 0x002D487Cu); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D487C: ;
    MEM32(0x5253D8) = 0x33560C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4887
 * Original: 0x002D4887 - 0x002D48A3 (28 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4887(void)
{

loc_002D4887: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0xB);
    ecx = 0x52511C;
    PUSH32(esp, 0x002D4898u); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D4898: ;
    MEM32(0x52511C) = 0x33560C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D48A3
 * Original: 0x002D48A3 - 0x002D48B3 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D48A3(void)
{

loc_002D48A3: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524930;
    PUSH32(esp, 0x002D48B2u); RECOMP_ABI_CALL(0x001BB0A6u, sub_001BB0A6); /* call 0x001BB0A6 */

loc_002D48B2: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D48B3
 * Original: 0x002D48B3 - 0x002D48C3 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D48B3(void)
{

loc_002D48B3: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524B68;
    PUSH32(esp, 0x002D48C2u); RECOMP_ABI_CALL(0x001BB0CCu, sub_001BB0CC); /* call 0x001BB0CC */

loc_002D48C2: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D48C3
 * Original: 0x002D48C3 - 0x002D48D3 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D48C3(void)
{

loc_002D48C3: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x52507C;
    PUSH32(esp, 0x002D48D2u); RECOMP_ABI_CALL(0x001BB0F2u, sub_001BB0F2); /* call 0x001BB0F2 */

loc_002D48D2: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D48D3
 * Original: 0x002D48D3 - 0x002D48F6 (35 bytes, 7 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D48D3(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D48D3: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0xF);
    ecx = 0x524E98;
    PUSH32(esp, 0x002D48E4u); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D48E4: ;
    MEM32(0x524EBC) = MEM32(0x524EBC) & 0;
    _fa = (uint32_t)(MEM32(0x524EBC)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(0x524E98) = 0x33560C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D48F6
 * Original: 0x002D48F6 - 0x002D4919 (35 bytes, 7 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D48F6(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D48F6: ;
    PUSH32(esp, 0x37D7B0);
    PUSH32(esp, 0x14);
    ecx = 0x524F88;
    PUSH32(esp, 0x002D4907u); RECOMP_ABI_CALL(0x001BAE70u, sub_001BAE70); /* call 0x001BAE70 */

loc_002D4907: ;
    MEM32(0x524FAC) = MEM32(0x524FAC) & 0;
    _fa = (uint32_t)(MEM32(0x524FAC)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(0x524F88) = 0x33560C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4919
 * Original: 0x002D4919 - 0x002D4929 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4919(void)
{

loc_002D4919: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524A18;
    PUSH32(esp, 0x002D4928u); RECOMP_ABI_CALL(0x001BB12Du, sub_001BB12D); /* call 0x001BB12D */

loc_002D4928: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4929
 * Original: 0x002D4929 - 0x002D4939 (16 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4929(void)
{

loc_002D4929: ;
    PUSH32(esp, 0x37D7B0);
    ecx = 0x524EC0;
    PUSH32(esp, 0x002D4938u); RECOMP_ABI_CALL(0x001BB15Bu, sub_001BB15B); /* call 0x001BB15B */

loc_002D4938: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4939
 * Original: 0x002D4939 - 0x002D4950 (23 bytes, 7 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4939(void)
{

loc_002D4939: ;
    ecx = 0x524BD8;
    PUSH32(esp, 0x002D4943u); RECOMP_ABI_CALL(0x001BB1AEu, sub_001BB1AE); /* call 0x001BB1AE */

loc_002D4943: ;
    PUSH32(esp, 0x2D7CCD);
    PUSH32(esp, 0x002D494Du); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D494D: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4950
 * Original: 0x002D4950 - 0x002D4966 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4950(void)
{

loc_002D4950: ;
    ecx = 0x5286AC;
    PUSH32(esp, 0x002D495Au); RECOMP_ABI_CALL(0x001C10A0u, sub_001C10A0); /* call 0x001C10A0 */

loc_002D495A: ;
    PUSH32(esp, 0x2D7CF0);
    PUSH32(esp, 0x002D4964u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4964: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4970
 * Original: 0x002D4970 - 0x002D4990 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4970(void)
{

loc_002D4970: ;
    ecx = 0x5286E8;
    PUSH32(esp, 0x002D497Au); RECOMP_ABI_CALL(0x001C10A0u, sub_001C10A0); /* call 0x001C10A0 */

loc_002D497A: ;
    ecx = 0x5286FC;
    PUSH32(esp, 0x002D4984u); RECOMP_ABI_CALL(0x001C10A0u, sub_001C10A0); /* call 0x001C10A0 */

loc_002D4984: ;
    PUSH32(esp, 0x2D7D00);
    PUSH32(esp, 0x002D498Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D498E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4990
 * Original: 0x002D4990 - 0x002D49B0 (32 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4990(void)
{

loc_002D4990: ;
    ecx = 0x5286C0;
    PUSH32(esp, 0x002D499Au); RECOMP_ABI_CALL(0x001C10A0u, sub_001C10A0); /* call 0x001C10A0 */

loc_002D499A: ;
    ecx = 0x5286D4;
    PUSH32(esp, 0x002D49A4u); RECOMP_ABI_CALL(0x001C10A0u, sub_001C10A0); /* call 0x001C10A0 */

loc_002D49A4: ;
    PUSH32(esp, 0x2D7D10);
    PUSH32(esp, 0x002D49AEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D49AE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D49B0
 * Original: 0x002D49B0 - 0x002D49D0 (32 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D49B0(void)
{

loc_002D49B0: ;
    ecx = 0x528A68;
    PUSH32(esp, 0x002D49BAu); RECOMP_ABI_CALL(0x001CF930u, sub_001CF930); /* call 0x001CF930 */

loc_002D49BA: ;
    PUSH32(esp, 0x2D7D20);
    PUSH32(esp, 0x002D49C4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D49C4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D49D0
 * Original: 0x002D49D0 - 0x002D49F0 (32 bytes, 8 insns)
 * Category: game_ui
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D49D0(void)
{

loc_002D49D0: ;
    PUSH32(esp, 0xFF00AAAAu);
    PUSH32(esp, 0x3384E0);
    ecx = 0x528DA0;
    PUSH32(esp, 0x002D49E4u); RECOMP_ABI_CALL(0x001D5270u, sub_001D5270); /* call 0x001D5270 */

loc_002D49E4: ;
    PUSH32(esp, 0x2D7D90);
    PUSH32(esp, 0x002D49EEu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D49EE: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D49F0
 * Original: 0x002D49F0 - 0x002D4A10 (32 bytes, 8 insns)
 * Category: game_ui
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D49F0(void)
{

loc_002D49F0: ;
    PUSH32(esp, 0xFFFFFF50u);
    PUSH32(esp, 0x3384EC);
    ecx = 0x528EE0;
    PUSH32(esp, 0x002D4A04u); RECOMP_ABI_CALL(0x001D5270u, sub_001D5270); /* call 0x001D5270 */

loc_002D4A04: ;
    PUSH32(esp, 0x2D7DA0);
    PUSH32(esp, 0x002D4A0Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4A0E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4A10
 * Original: 0x002D4A10 - 0x002D4A30 (32 bytes, 7 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4A10(void)
{

loc_002D4A10: ;
    ecx = 0x528EC8;
    MEM32(0x528EC8) = 0x528EE0;
    PUSH32(esp, 0x002D4A24u); RECOMP_ABI_CALL(0x001D5DF0u, sub_001D5DF0); /* call 0x001D5DF0 */

loc_002D4A24: ;
    PUSH32(esp, 0x2D7D30);
    PUSH32(esp, 0x002D4A2Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4A2E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4A30
 * Original: 0x002D4A30 - 0x002D4A70 (64 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4A30(void)
{

loc_002D4A30: ;
    PUSH32(esp, 0x338E58);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37F4E8);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37F3B4);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37F3B0);
    PUSH32(esp, 0x37F4CC);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37F3B8);
    ecx = 0x529C80;
    PUSH32(esp, 0x002D4A60u); RECOMP_ABI_CALL(0x001D2860u, sub_001D2860); /* call 0x001D2860 */

loc_002D4A60: ;
    PUSH32(esp, 0x2D7DB0);
    PUSH32(esp, 0x002D4A6Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4A6A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4A70
 * Original: 0x002D4A70 - 0x002D4AAC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4A70(void)
{

loc_002D4A70: ;
    PUSH32(esp, 0x338EF4);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37F760);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37F664);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37F660);
    PUSH32(esp, 0x37F74C);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37F668);
    ecx = 0x529CB4;
    PUSH32(esp, 0x002D4AA0u); RECOMP_ABI_CALL(0x001D2860u, sub_001D2860); /* call 0x001D2860 */

loc_002D4AA0: ;
    PUSH32(esp, 0x2D7DC0);
    PUSH32(esp, 0x002D4AAAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4AAA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4AB0
 * Original: 0x002D4AB0 - 0x002D4AEC (60 bytes, 16 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4AB0(void)
{

loc_002D4AB0: ;
    PUSH32(esp, 0x338F8C);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37F998);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37F8CC);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37F8C8);
    PUSH32(esp, 0x37F984);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37F8D0);
    ecx = 0x529CE8;
    PUSH32(esp, 0x002D4AE0u); RECOMP_ABI_CALL(0x001D2860u, sub_001D2860); /* call 0x001D2860 */

loc_002D4AE0: ;
    PUSH32(esp, 0x2D7DD0);
    PUSH32(esp, 0x002D4AEAu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4AEA: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4AF0
 * Original: 0x002D4AF0 - 0x002D4B2C (60 bytes, 16 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4AF0(void)
{

loc_002D4AF0: ;
    PUSH32(esp, 0x338FEC);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37FBD0);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37FB4C);
    PUSH32(esp, 0);
    PUSH32(esp, 0x37FB48);
    PUSH32(esp, 0x37FBBC);
    PUSH32(esp, 1);
    PUSH32(esp, 0x37FB50);
    ecx = 0x529D1C;
    PUSH32(esp, 0x002D4B20u); RECOMP_ABI_CALL(0x001D2860u, sub_001D2860); /* call 0x001D2860 */

loc_002D4B20: ;
    PUSH32(esp, 0x2D7DE0);
    PUSH32(esp, 0x002D4B2Au); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4B2A: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4B2C
 * Original: 0x002D4B2C - 0x002D4B38 (12 bytes, 4 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4B2C(void)
{

loc_002D4B2C: ;
    PUSH32(esp, 0x2D7DEA);
    PUSH32(esp, 0x002D4B36u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4B36: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4B38
 * Original: 0x002D4B38 - 0x002D4B50 (24 bytes, 16 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4B38(void)
{

loc_002D4B38: ;
    PUSH32(esp, 0x2D7DF5);
    PUSH32(esp, 0x002D4B42u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4B42: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4B50
 * Original: 0x002D4B50 - 0x002D4B80 (48 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4B50(void)
{

loc_002D4B50: ;
    eax = MEM32(0x382E28);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x530EBC;
    PUSH32(esp, 0x002D4B74u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4B74: ;
    PUSH32(esp, 0x2D7E00);
    PUSH32(esp, 0x002D4B7Eu); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4B7E: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4B80
 * Original: 0x002D4B80 - 0x002D4BA0 (32 bytes, 15 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4B80(void)
{

loc_002D4B80: ;
    eax = MEM32(0x530F08);
    MEM32(0x382E30) = eax;
    MEM32(0x530F08) = 0x382E2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4BA0
 * Original: 0x002D4BA0 - 0x002D4BB5 (21 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4BA0(void)
{

loc_002D4BA0: ;
    eax = MEM32(0x530F08);
    MEM32(0x382E44) = eax;
    MEM32(0x530F08) = 0x382E40;
    esp += 4; return; /* ret */

}

/**
 * sub_002D4BC0
 * Original: 0x002D4BC0 - 0x002D4C05 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4BC0(void)
{

loc_002D4BC0: ;
    eax = MEM32(0x382EA0);
    PUSH32(esp, 0);
    PUSH32(esp, 0xB);
    PUSH32(esp, 0x33D200);
    PUSH32(esp, 0x2C);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1F7010);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1F7000);
    PUSH32(esp, 0x1F7070);
    PUSH32(esp, eax);
    ecx = 0x530F18;
    PUSH32(esp, 0x002D4BF9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4BF9: ;
    PUSH32(esp, 0x2D7E10);
    PUSH32(esp, 0x002D4C03u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4C03: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4C10
 * Original: 0x002D4C10 - 0x002D4C43 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4C10(void)
{

loc_002D4C10: ;
    eax = MEM32(0x382EA4);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x530F4C;
    PUSH32(esp, 0x002D4C37u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4C37: ;
    PUSH32(esp, 0x2D7E20);
    PUSH32(esp, 0x002D4C41u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4C41: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4C50
 * Original: 0x002D4C50 - 0x002D4C86 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4C50(void)
{

loc_002D4C50: ;
    eax = MEM32(0x382EA8);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33D41C);
    PUSH32(esp, 4);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x530F80;
    PUSH32(esp, 0x002D4C7Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4C7A: ;
    PUSH32(esp, 0x2D7E30);
    PUSH32(esp, 0x002D4C84u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4C84: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4C90
 * Original: 0x002D4C90 - 0x002D4CD5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4C90(void)
{

loc_002D4C90: ;
    eax = MEM32(0x382EAC);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33D43C);
    PUSH32(esp, 8);
    PUSH32(esp, 0x530F80);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1F8080);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1F8050);
    PUSH32(esp, 0x1F80A0);
    PUSH32(esp, eax);
    ecx = 0x530FB4;
    PUSH32(esp, 0x002D4CC9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4CC9: ;
    PUSH32(esp, 0x2D7E40);
    PUSH32(esp, 0x002D4CD3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4CD3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4CE0
 * Original: 0x002D4CE0 - 0x002D4D13 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4CE0(void)
{

loc_002D4CE0: ;
    eax = MEM32(0x382EB8);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 4);
    PUSH32(esp, 0x530F80);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x530FE8;
    PUSH32(esp, 0x002D4D07u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4D07: ;
    PUSH32(esp, 0x2D7E50);
    PUSH32(esp, 0x002D4D11u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4D11: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4D20
 * Original: 0x002D4D20 - 0x002D4D56 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4D20(void)
{

loc_002D4D20: ;
    eax = MEM32(0x382EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33D95C);
    PUSH32(esp, 8);
    PUSH32(esp, 0x530FE8);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x53101C;
    PUSH32(esp, 0x002D4D4Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4D4A: ;
    PUSH32(esp, 0x2D7E60);
    PUSH32(esp, 0x002D4D54u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4D54: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4D60
 * Original: 0x002D4D60 - 0x002D4DA2 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4D60(void)
{

loc_002D4D60: ;
    eax = MEM32(0x382EC0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 8);
    PUSH32(esp, 0x53101C);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1FB200);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FB180);
    PUSH32(esp, 0x1FB1A0);
    PUSH32(esp, eax);
    ecx = 0x531050;
    PUSH32(esp, 0x002D4D96u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4D96: ;
    PUSH32(esp, 0x2D7E70);
    PUSH32(esp, 0x002D4DA0u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4DA0: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4DB0
 * Original: 0x002D4DB0 - 0x002D4DF5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4DB0(void)
{

loc_002D4DB0: ;
    eax = MEM32(0x382EC4);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x33D990);
    PUSH32(esp, 0x30);
    PUSH32(esp, 0x53101C);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1FB2B0);
    PUSH32(esp, 0x1FB230);
    PUSH32(esp, 0x1FB220);
    PUSH32(esp, 0x1FB250);
    PUSH32(esp, eax);
    ecx = 0x531084;
    PUSH32(esp, 0x002D4DE9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4DE9: ;
    PUSH32(esp, 0x2D7E80);
    PUSH32(esp, 0x002D4DF3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4DF3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4E00
 * Original: 0x002D4E00 - 0x002D4E36 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4E00(void)
{

loc_002D4E00: ;
    eax = MEM32(0x382EC8);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33D9DC);
    PUSH32(esp, 8);
    PUSH32(esp, 0x530F80);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5310B8;
    PUSH32(esp, 0x002D4E2Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4E2A: ;
    PUSH32(esp, 0x2D7E90);
    PUSH32(esp, 0x002D4E34u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4E34: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4E40
 * Original: 0x002D4E40 - 0x002D4E85 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4E40(void)
{

loc_002D4E40: ;
    eax = MEM32(0x382ECC);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33DA08);
    PUSH32(esp, 0xC);
    PUSH32(esp, 0x5310B8);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1FC5C0);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FC540);
    PUSH32(esp, 0x1FC560);
    PUSH32(esp, eax);
    ecx = 0x5310EC;
    PUSH32(esp, 0x002D4E79u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4E79: ;
    PUSH32(esp, 0x2D7EA0);
    PUSH32(esp, 0x002D4E83u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4E83: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4E90
 * Original: 0x002D4E90 - 0x002D4EC3 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4E90(void)
{

loc_002D4E90: ;
    eax = MEM32(0x382ED0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 4);
    PUSH32(esp, 0x530F80);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x531120;
    PUSH32(esp, 0x002D4EB7u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4EB7: ;
    PUSH32(esp, 0x2D7EB0);
    PUSH32(esp, 0x002D4EC1u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4EC1: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4ED0
 * Original: 0x002D4ED0 - 0x002D4F15 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4ED0(void)
{

loc_002D4ED0: ;
    eax = MEM32(0x382ED4);
    PUSH32(esp, 0);
    PUSH32(esp, 3);
    PUSH32(esp, 0x33DAA0);
    PUSH32(esp, 0x40);
    PUSH32(esp, 0x53101C);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1FDD50);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FDD30);
    PUSH32(esp, 0x1FDD80);
    PUSH32(esp, eax);
    ecx = 0x531154;
    PUSH32(esp, 0x002D4F09u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4F09: ;
    PUSH32(esp, 0x2D7EC0);
    PUSH32(esp, 0x002D4F13u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4F13: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4F20
 * Original: 0x002D4F20 - 0x002D4F68 (72 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4F20(void)
{

loc_002D4F20: ;
    eax = MEM32(0x382ED8);
    PUSH32(esp, 0);
    PUSH32(esp, 0xF);
    PUSH32(esp, 0x33DAE0);
    PUSH32(esp, 0xC0);
    PUSH32(esp, 0x531120);
    PUSH32(esp, 0x1FE170);
    PUSH32(esp, 0x1FDF40);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FDE60);
    PUSH32(esp, 0x1FDE00);
    PUSH32(esp, eax);
    ecx = 0x531188;
    PUSH32(esp, 0x002D4F5Cu); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4F5C: ;
    PUSH32(esp, 0x2D7ED0);
    PUSH32(esp, 0x002D4F66u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4F66: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4F70
 * Original: 0x002D4F70 - 0x002D4FB5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4F70(void)
{

loc_002D4F70: ;
    eax = MEM32(0x382EDC);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33DCBC);
    PUSH32(esp, 0x20);
    PUSH32(esp, 0x53101C);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1FE200);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FE180);
    PUSH32(esp, 0x1FE1A0);
    PUSH32(esp, eax);
    ecx = 0x5311BC;
    PUSH32(esp, 0x002D4FA9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4FA9: ;
    PUSH32(esp, 0x2D7EE0);
    PUSH32(esp, 0x002D4FB3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D4FB3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D4FC0
 * Original: 0x002D4FC0 - 0x002D5005 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D4FC0(void)
{

loc_002D4FC0: ;
    eax = MEM32(0x382EE0);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x33DCE0);
    PUSH32(esp, 0x1C);
    PUSH32(esp, 0x531120);
    PUSH32(esp, 0x1FE2F0);
    PUSH32(esp, 0x1FE2C0);
    PUSH32(esp, 0x1FE240);
    PUSH32(esp, 0x1FE230);
    PUSH32(esp, 0x1FE260);
    PUSH32(esp, eax);
    ecx = 0x5311F0;
    PUSH32(esp, 0x002D4FF9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D4FF9: ;
    PUSH32(esp, 0x2D7EF0);
    PUSH32(esp, 0x002D5003u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5003: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5010
 * Original: 0x002D5010 - 0x002D5055 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5010(void)
{

loc_002D5010: ;
    eax = MEM32(0x382EE4);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x33DD28);
    PUSH32(esp, 0x50);
    PUSH32(esp, 0x530F80);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x1FE3A0);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FE300);
    PUSH32(esp, 0x1FE340);
    PUSH32(esp, eax);
    ecx = 0x531224;
    PUSH32(esp, 0x002D5049u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5049: ;
    PUSH32(esp, 0x2D7F00);
    PUSH32(esp, 0x002D5053u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5053: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5060
 * Original: 0x002D5060 - 0x002D50A5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5060(void)
{

loc_002D5060: ;
    eax = MEM32(0x382EE8);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x33DD6C);
    PUSH32(esp, 0x20);
    PUSH32(esp, 0x53101C);
    PUSH32(esp, 0x1FE610);
    PUSH32(esp, 0x1FE550);
    PUSH32(esp, 0x1F8060);
    PUSH32(esp, 0x1FE4D0);
    PUSH32(esp, 0x1FE4F0);
    PUSH32(esp, eax);
    ecx = 0x531258;
    PUSH32(esp, 0x002D5099u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5099: ;
    PUSH32(esp, 0x2D7F10);
    PUSH32(esp, 0x002D50A3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D50A3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D50B0
 * Original: 0x002D50B0 - 0x002D50C6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D50B0(void)
{

loc_002D50B0: ;
    ecx = 0x531290;
    PUSH32(esp, 0x002D50BAu); RECOMP_ABI_CALL(0x00218DA0u, sub_00218DA0); /* call 0x00218DA0 */

loc_002D50BA: ;
    PUSH32(esp, 0x2D7F20);
    PUSH32(esp, 0x002D50C4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D50C4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D50D0
 * Original: 0x002D50D0 - 0x002D50DF (15 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D50D0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D50D0: ;
    fp_push(MEMD(0x33E830)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) fp_top() = recomp_x87_cos(fp_top()); /* fcos */
    MEMF(0x53129C) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D50E0
 * Original: 0x002D50E0 - 0x002D50EF (15 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D50E0(void)
{
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D50E0: ;
    fp_push(MEMD(0x33E830)); /* fld double */
    if (recomp_fp_trig_in_range(fp_top())) fp_top() = recomp_x87_cos(fp_top()); /* fcos */
    MEMF(0x5312A0) = (float)fp_top(); fp_pop(); /* fstp */
    esp += 4; return; /* ret */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D50F0
 * Original: 0x002D50F0 - 0x002D5126 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D50F0(void)
{

loc_002D50F0: ;
    eax = MEM32(0x382F10);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33ED2C);
    PUSH32(esp, 8);
    PUSH32(esp, 0x531374);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5312A4;
    PUSH32(esp, 0x002D511Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D511A: ;
    PUSH32(esp, 0x2D7F30);
    PUSH32(esp, 0x002D5124u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5124: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5130
 * Original: 0x002D5130 - 0x002D5166 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5130(void)
{

loc_002D5130: ;
    eax = MEM32(0x382F14);
    PUSH32(esp, 0);
    PUSH32(esp, 4);
    PUSH32(esp, 0x33ED50);
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5312D8;
    PUSH32(esp, 0x002D515Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D515A: ;
    PUSH32(esp, 0x2D7F40);
    PUSH32(esp, 0x002D5164u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5164: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5170
 * Original: 0x002D5170 - 0x002D51A6 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5170(void)
{

loc_002D5170: ;
    eax = MEM32(0x382F18);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x33EDC8);
    PUSH32(esp, 0x1C);
    PUSH32(esp, 0x5312D8);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x53130C;
    PUSH32(esp, 0x002D519Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D519A: ;
    PUSH32(esp, 0x2D7F50);
    PUSH32(esp, 0x002D51A4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D51A4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D51B0
 * Original: 0x002D51B0 - 0x002D51FB (75 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D51B0(void)
{

loc_002D51B0: ;
    eax = MEM32(0x382F1C);
    PUSH32(esp, 0x224240);
    PUSH32(esp, 0x19);
    PUSH32(esp, 0x33EEF0);
    PUSH32(esp, 0x90);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x22E9D0);
    PUSH32(esp, 0x22E9B0);
    PUSH32(esp, 0x22E9A0);
    PUSH32(esp, 0x22E940);
    PUSH32(esp, eax);
    ecx = 0x531340;
    PUSH32(esp, 0x002D51EFu); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D51EF: ;
    PUSH32(esp, 0x2D7F60);
    PUSH32(esp, 0x002D51F9u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D51F9: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5200
 * Original: 0x002D5200 - 0x002D5236 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5200(void)
{

loc_002D5200: ;
    eax = MEM32(0x382F20);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33F288);
    PUSH32(esp, 4);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x531374;
    PUSH32(esp, 0x002D522Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D522A: ;
    PUSH32(esp, 0x2D7F70);
    PUSH32(esp, 0x002D5234u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5234: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5240
 * Original: 0x002D5240 - 0x002D5276 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5240(void)
{

loc_002D5240: ;
    eax = MEM32(0x382F24);
    PUSH32(esp, 0);
    PUSH32(esp, 3);
    PUSH32(esp, 0x33F2A0);
    PUSH32(esp, 0xC);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5313A8;
    PUSH32(esp, 0x002D526Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D526A: ;
    PUSH32(esp, 0x2D7F80);
    PUSH32(esp, 0x002D5274u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5274: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5280
 * Original: 0x002D5280 - 0x002D52B3 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5280(void)
{

loc_002D5280: ;
    eax = MEM32(0x382F28);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x5312D8);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5313DC;
    PUSH32(esp, 0x002D52A7u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D52A7: ;
    PUSH32(esp, 0x2D7F90);
    PUSH32(esp, 0x002D52B1u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D52B1: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D52C0
 * Original: 0x002D52C0 - 0x002D5308 (72 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D52C0(void)
{

loc_002D52C0: ;
    eax = MEM32(0x382F2C);
    PUSH32(esp, 0);
    PUSH32(esp, 0xD);
    PUSH32(esp, 0x33F2F0);
    PUSH32(esp, 0xC0);
    PUSH32(esp, 0x53130C);
    PUSH32(esp, 0x22EAA0);
    PUSH32(esp, 0x22EA90);
    PUSH32(esp, 0x22EA10);
    PUSH32(esp, 0x22EA00);
    PUSH32(esp, 0x22EA30);
    PUSH32(esp, eax);
    ecx = 0x531410;
    PUSH32(esp, 0x002D52FCu); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D52FC: ;
    PUSH32(esp, 0x2D7FA0);
    PUSH32(esp, 0x002D5306u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5306: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5310
 * Original: 0x002D5310 - 0x002D5343 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5310(void)
{

loc_002D5310: ;
    eax = MEM32(0x382F30);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0xC);
    PUSH32(esp, 0x5313A8);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x531444;
    PUSH32(esp, 0x002D5337u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5337: ;
    PUSH32(esp, 0x2D7FB0);
    PUSH32(esp, 0x002D5341u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5341: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5350
 * Original: 0x002D5350 - 0x002D5398 (72 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5350(void)
{

loc_002D5350: ;
    eax = MEM32(0x382F34);
    PUSH32(esp, 0);
    PUSH32(esp, 0xC);
    PUSH32(esp, 0x33F4A8);
    PUSH32(esp, 0x90);
    PUSH32(esp, 0x531444);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x22EE10);
    PUSH32(esp, 0x22ED70);
    PUSH32(esp, 0x22ED60);
    PUSH32(esp, 0x22EDB0);
    PUSH32(esp, eax);
    ecx = 0x531478;
    PUSH32(esp, 0x002D538Cu); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D538C: ;
    PUSH32(esp, 0x2D7FC0);
    PUSH32(esp, 0x002D5396u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5396: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D53A0
 * Original: 0x002D53A0 - 0x002D53B6 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D53A0(void)
{

loc_002D53A0: ;
    ecx = 0x5314AC;
    PUSH32(esp, 0x002D53AAu); RECOMP_ABI_CALL(0x0022EE20u, sub_0022EE20); /* call 0x0022EE20 */

loc_002D53AA: ;
    PUSH32(esp, 0x2D7FD0);
    PUSH32(esp, 0x002D53B4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D53B4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D53C0
 * Original: 0x002D53C0 - 0x002D5408 (72 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D53C0(void)
{

loc_002D53C0: ;
    eax = MEM32(0x382F38);
    PUSH32(esp, 0);
    PUSH32(esp, 0xA);
    PUSH32(esp, 0x33F868);
    PUSH32(esp, 0x90);
    PUSH32(esp, 0x531444);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x231840);
    PUSH32(esp, 0x2317C0);
    PUSH32(esp, 0x2317B0);
    PUSH32(esp, 0x2317E0);
    PUSH32(esp, eax);
    ecx = 0x5314B4;
    PUSH32(esp, 0x002D53FCu); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D53FC: ;
    PUSH32(esp, 0x2D7FE0);
    PUSH32(esp, 0x002D5406u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5406: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5410
 * Original: 0x002D5410 - 0x002D5446 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5410(void)
{

loc_002D5410: ;
    eax = MEM32(0x382F3C);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x33F95C);
    PUSH32(esp, 0x60);
    PUSH32(esp, 0x5313DC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5314E8;
    PUSH32(esp, 0x002D543Au); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D543A: ;
    PUSH32(esp, 0x2D7FF0);
    PUSH32(esp, 0x002D5444u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5444: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5450
 * Original: 0x002D5450 - 0x002D5492 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5450(void)
{

loc_002D5450: ;
    eax = MEM32(0x382F40);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0x60);
    PUSH32(esp, 0x5314E8);
    PUSH32(esp, 0x22EAA0);
    PUSH32(esp, 0x231940);
    PUSH32(esp, 0x231920);
    PUSH32(esp, 0x231910);
    PUSH32(esp, 0x2318B0);
    PUSH32(esp, eax);
    ecx = 0x53151C;
    PUSH32(esp, 0x002D5486u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5486: ;
    PUSH32(esp, 0x2D8000);
    PUSH32(esp, 0x002D5490u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5490: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D54A0
 * Original: 0x002D54A0 - 0x002D54E5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D54A0(void)
{

loc_002D54A0: ;
    eax = MEM32(0x382F44);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x33F990);
    PUSH32(esp, 0x40);
    PUSH32(esp, 0x5313DC);
    PUSH32(esp, 0x22EAA0);
    PUSH32(esp, 0x231A20);
    PUSH32(esp, 0x231A00);
    PUSH32(esp, 0x2319F0);
    PUSH32(esp, 0x231990);
    PUSH32(esp, eax);
    ecx = 0x531550;
    PUSH32(esp, 0x002D54D9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D54D9: ;
    PUSH32(esp, 0x2D8010);
    PUSH32(esp, 0x002D54E3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D54E3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D54F0
 * Original: 0x002D54F0 - 0x002D5523 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D54F0(void)
{

loc_002D54F0: ;
    eax = MEM32(0x382F48);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x531588;
    PUSH32(esp, 0x002D5517u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5517: ;
    PUSH32(esp, 0x2D8020);
    PUSH32(esp, 0x002D5521u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5521: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5530
 * Original: 0x002D5530 - 0x002D5563 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5530(void)
{

loc_002D5530: ;
    eax = MEM32(0x382F4C);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x531588);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x5315BC;
    PUSH32(esp, 0x002D5557u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5557: ;
    PUSH32(esp, 0x2D8030);
    PUSH32(esp, 0x002D5561u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5561: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5570
 * Original: 0x002D5570 - 0x002D55B2 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5570(void)
{

loc_002D5570: ;
    eax = MEM32(0x382F50);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x5315BC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x232670);
    PUSH32(esp, eax);
    ecx = 0x5315F0;
    PUSH32(esp, 0x002D55A6u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D55A6: ;
    PUSH32(esp, 0x2D8040);
    PUSH32(esp, 0x002D55B0u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D55B0: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D55C0
 * Original: 0x002D55C0 - 0x002D5605 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D55C0(void)
{

loc_002D55C0: ;
    eax = MEM32(0x382F54);
    PUSH32(esp, 0);
    PUSH32(esp, 5);
    PUSH32(esp, 0x33FBA8);
    PUSH32(esp, 0x14);
    PUSH32(esp, 0x5315BC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x232730);
    PUSH32(esp, 0x2326B0);
    PUSH32(esp, 0x2326A0);
    PUSH32(esp, 0x2326D0);
    PUSH32(esp, eax);
    ecx = 0x531624;
    PUSH32(esp, 0x002D55F9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D55F9: ;
    PUSH32(esp, 0x2D8050);
    PUSH32(esp, 0x002D5603u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5603: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5610
 * Original: 0x002D5610 - 0x002D5625 (21 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5610(void)
{

loc_002D5610: ;
    eax = MEM32(0x530F08);
    MEM32(0x382FE8) = eax;
    MEM32(0x530F08) = 0x382FE4;
    esp += 4; return; /* ret */

}

/**
 * sub_002D5630
 * Original: 0x002D5630 - 0x002D5675 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5630(void)
{

loc_002D5630: ;
    eax = MEM32(0x382FF0);
    PUSH32(esp, 0);
    PUSH32(esp, 0xC);
    PUSH32(esp, 0x349DF0);
    PUSH32(esp, 0x60);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x25BFE0);
    PUSH32(esp, 0x25BFC0);
    PUSH32(esp, 0x25BFB0);
    PUSH32(esp, 0x25BF50);
    PUSH32(esp, eax);
    ecx = 0x532B60;
    PUSH32(esp, 0x002D5669u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5669: ;
    PUSH32(esp, 0x2D8060);
    PUSH32(esp, 0x002D5673u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5673: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5680
 * Original: 0x002D5680 - 0x002D5695 (21 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5680(void)
{

loc_002D5680: ;
    eax = MEM32(0x530F08);
    MEM32(0x382FF8) = eax;
    MEM32(0x530F08) = 0x382FF4;
    esp += 4; return; /* ret */

}

/**
 * sub_002D56A0
 * Original: 0x002D56A0 - 0x002D56D6 (54 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D56A0(void)
{

loc_002D56A0: ;
    eax = MEM32(0x383000);
    PUSH32(esp, 0);
    PUSH32(esp, 0xA);
    PUSH32(esp, 0x34A0F8);
    PUSH32(esp, 0x28);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x532B9C;
    PUSH32(esp, 0x002D56CAu); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D56CA: ;
    PUSH32(esp, 0x2D8070);
    PUSH32(esp, 0x002D56D4u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D56D4: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D56E0
 * Original: 0x002D56E0 - 0x002D5725 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D56E0(void)
{

loc_002D56E0: ;
    eax = MEM32(0x383004);
    PUSH32(esp, 0);
    PUSH32(esp, 5);
    PUSH32(esp, 0x34A1FC);
    PUSH32(esp, 0x30);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x2616D0);
    PUSH32(esp, 0x2616B0);
    PUSH32(esp, 0x2616A0);
    PUSH32(esp, 0x261640);
    PUSH32(esp, eax);
    ecx = 0x532BD0;
    PUSH32(esp, 0x002D5719u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5719: ;
    PUSH32(esp, 0x2D8080);
    PUSH32(esp, 0x002D5723u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5723: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5730
 * Original: 0x002D5730 - 0x002D5772 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5730(void)
{

loc_002D5730: ;
    eax = MEM32(0x383008);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x261710);
    PUSH32(esp, eax);
    ecx = 0x532C04;
    PUSH32(esp, 0x002D5766u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5766: ;
    PUSH32(esp, 0x2D8090);
    PUSH32(esp, 0x002D5770u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5770: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5780
 * Original: 0x002D5780 - 0x002D57C2 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5780(void)
{

loc_002D5780: ;
    eax = MEM32(0x38300C);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x261750);
    PUSH32(esp, eax);
    ecx = 0x532C38;
    PUSH32(esp, 0x002D57B6u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D57B6: ;
    PUSH32(esp, 0x2D80A0);
    PUSH32(esp, 0x002D57C0u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D57C0: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D57D0
 * Original: 0x002D57D0 - 0x002D5815 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D57D0(void)
{

loc_002D57D0: ;
    eax = MEM32(0x383010);
    PUSH32(esp, 0);
    PUSH32(esp, 4);
    PUSH32(esp, 0x34A2C4);
    PUSH32(esp, 0x10);
    PUSH32(esp, 0x532C38);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x261820);
    PUSH32(esp, 0x2617A0);
    PUSH32(esp, 0x261790);
    PUSH32(esp, 0x2617C0);
    PUSH32(esp, eax);
    ecx = 0x532C6C;
    PUSH32(esp, 0x002D5809u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5809: ;
    PUSH32(esp, 0x2D80B0);
    PUSH32(esp, 0x002D5813u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5813: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5820
 * Original: 0x002D5820 - 0x002D5865 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5820(void)
{

loc_002D5820: ;
    eax = MEM32(0x383014);
    PUSH32(esp, 0);
    PUSH32(esp, 0xA);
    PUSH32(esp, 0x34A350);
    PUSH32(esp, 0x58);
    PUSH32(esp, 0x532B9C);
    PUSH32(esp, 0x2618E0);
    PUSH32(esp, 0x2618D0);
    PUSH32(esp, 0x261850);
    PUSH32(esp, 0x261840);
    PUSH32(esp, 0x261870);
    PUSH32(esp, eax);
    ecx = 0x532CA0;
    PUSH32(esp, 0x002D5859u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5859: ;
    PUSH32(esp, 0x2D80C0);
    PUSH32(esp, 0x002D5863u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5863: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5870
 * Original: 0x002D5870 - 0x002D58A3 (51 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5870(void)
{

loc_002D5870: ;
    eax = MEM32(0x383018);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, eax);
    ecx = 0x532CD4;
    PUSH32(esp, 0x002D5897u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5897: ;
    PUSH32(esp, 0x2D80D0);
    PUSH32(esp, 0x002D58A1u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D58A1: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D58B0
 * Original: 0x002D58B0 - 0x002D58F5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D58B0(void)
{

loc_002D58B0: ;
    eax = MEM32(0x38301C);
    PUSH32(esp, 0);
    PUSH32(esp, 3);
    PUSH32(esp, 0x34A4E0);
    PUSH32(esp, 0xC);
    PUSH32(esp, 0x532CD4);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x261980);
    PUSH32(esp, 0x261900);
    PUSH32(esp, 0x2618F0);
    PUSH32(esp, 0x261920);
    PUSH32(esp, eax);
    ecx = 0x532D08;
    PUSH32(esp, 0x002D58E9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D58E9: ;
    PUSH32(esp, 0x2D80E0);
    PUSH32(esp, 0x002D58F3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D58F3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5900
 * Original: 0x002D5900 - 0x002D5945 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5900(void)
{

loc_002D5900: ;
    eax = MEM32(0x383020);
    PUSH32(esp, 0);
    PUSH32(esp, 5);
    PUSH32(esp, 0x34A574);
    PUSH32(esp, 0x20);
    PUSH32(esp, 0x532F10);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x261A60);
    PUSH32(esp, 0x2619E0);
    PUSH32(esp, 0x2619D0);
    PUSH32(esp, 0x261A00);
    PUSH32(esp, eax);
    ecx = 0x532D3C;
    PUSH32(esp, 0x002D5939u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5939: ;
    PUSH32(esp, 0x2D80F0);
    PUSH32(esp, 0x002D5943u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5943: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5950
 * Original: 0x002D5950 - 0x002D5995 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5950(void)
{

loc_002D5950: ;
    eax = MEM32(0x383024);
    PUSH32(esp, 0);
    PUSH32(esp, 3);
    PUSH32(esp, 0x34A628);
    PUSH32(esp, 0x48);
    PUSH32(esp, 0x532F44);
    PUSH32(esp, 0x262020);
    PUSH32(esp, 0x261FD0);
    PUSH32(esp, 0x261F50);
    PUSH32(esp, 0x261F40);
    PUSH32(esp, 0x261F70);
    PUSH32(esp, eax);
    ecx = 0x532D70;
    PUSH32(esp, 0x002D5989u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5989: ;
    PUSH32(esp, 0x2D8100);
    PUSH32(esp, 0x002D5993u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5993: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D59A0
 * Original: 0x002D59A0 - 0x002D59E5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D59A0(void)
{

loc_002D59A0: ;
    eax = MEM32(0x383028);
    PUSH32(esp, 0);
    PUSH32(esp, 4);
    PUSH32(esp, 0x34A6BC);
    PUSH32(esp, 0x2C);
    PUSH32(esp, 0x532F78);
    PUSH32(esp, 0x262280);
    PUSH32(esp, 0x262250);
    PUSH32(esp, 0x2621D0);
    PUSH32(esp, 0x2621C0);
    PUSH32(esp, 0x2621F0);
    PUSH32(esp, eax);
    ecx = 0x532DA4;
    PUSH32(esp, 0x002D59D9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D59D9: ;
    PUSH32(esp, 0x2D8110);
    PUSH32(esp, 0x002D59E3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D59E3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D59F0
 * Original: 0x002D59F0 - 0x002D5A35 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D59F0(void)
{

loc_002D59F0: ;
    eax = MEM32(0x38302C);
    PUSH32(esp, 0);
    PUSH32(esp, 7);
    PUSH32(esp, 0x34A780);
    PUSH32(esp, 0x30);
    PUSH32(esp, 0x532FAC);
    PUSH32(esp, 0x2624A0);
    PUSH32(esp, 0x262460);
    PUSH32(esp, 0x2623E0);
    PUSH32(esp, 0x2623D0);
    PUSH32(esp, 0x262400);
    PUSH32(esp, eax);
    ecx = 0x532DD8;
    PUSH32(esp, 0x002D5A29u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5A29: ;
    PUSH32(esp, 0x2D8120);
    PUSH32(esp, 0x002D5A33u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5A33: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5A40
 * Original: 0x002D5A40 - 0x002D5A82 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5A40(void)
{

loc_002D5A40: ;
    eax = MEM32(0x383030);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x2624C0);
    PUSH32(esp, eax);
    ecx = 0x532E0C;
    PUSH32(esp, 0x002D5A76u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5A76: ;
    PUSH32(esp, 0x2D8130);
    PUSH32(esp, 0x002D5A80u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5A80: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5A90
 * Original: 0x002D5A90 - 0x002D5AD5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5A90(void)
{

loc_002D5A90: ;
    eax = MEM32(0x383034);
    PUSH32(esp, 0);
    PUSH32(esp, 0xA);
    PUSH32(esp, 0x34A880);
    PUSH32(esp, 0x28);
    PUSH32(esp, 0x532E0C);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x262580);
    PUSH32(esp, 0x262500);
    PUSH32(esp, 0x2624F0);
    PUSH32(esp, 0x262520);
    PUSH32(esp, eax);
    ecx = 0x532E40;
    PUSH32(esp, 0x002D5AC9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5AC9: ;
    PUSH32(esp, 0x2D8140);
    PUSH32(esp, 0x002D5AD3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5AD3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5AE0
 * Original: 0x002D5AE0 - 0x002D5B25 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5AE0(void)
{

loc_002D5AE0: ;
    eax = MEM32(0x383038);
    PUSH32(esp, 0);
    PUSH32(esp, 3);
    PUSH32(esp, 0x34A9D4);
    PUSH32(esp, 0x18);
    PUSH32(esp, 0x532FE0);
    PUSH32(esp, 0x2627D0);
    PUSH32(esp, 0x2627B0);
    PUSH32(esp, 0x262730);
    PUSH32(esp, 0x262720);
    PUSH32(esp, 0x262750);
    PUSH32(esp, eax);
    ecx = 0x532E74;
    PUSH32(esp, 0x002D5B19u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5B19: ;
    PUSH32(esp, 0x2D8150);
    PUSH32(esp, 0x002D5B23u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5B23: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5B30
 * Original: 0x002D5B30 - 0x002D5B72 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5B30(void)
{

loc_002D5B30: ;
    eax = MEM32(0x38303C);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 8);
    PUSH32(esp, 0x533014);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x264080);
    PUSH32(esp, 0x262CC0);
    PUSH32(esp, 0x262CB0);
    PUSH32(esp, 0x262CE0);
    PUSH32(esp, eax);
    ecx = 0x532EA8;
    PUSH32(esp, 0x002D5B66u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5B66: ;
    PUSH32(esp, 0x2D8160);
    PUSH32(esp, 0x002D5B70u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5B70: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5B80
 * Original: 0x002D5B80 - 0x002D5BC2 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5B80(void)
{

loc_002D5B80: ;
    eax = MEM32(0x383040);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0x64);
    PUSH32(esp, 0x533048);
    PUSH32(esp, 0x263CE0);
    PUSH32(esp, 0x264130);
    PUSH32(esp, 0x263C40);
    PUSH32(esp, 0x263C30);
    PUSH32(esp, 0x263C80);
    PUSH32(esp, eax);
    ecx = 0x532EDC;
    PUSH32(esp, 0x002D5BB6u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5BB6: ;
    PUSH32(esp, 0x2D8170);
    PUSH32(esp, 0x002D5BC0u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5BC0: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5BD0
 * Original: 0x002D5BD0 - 0x002D5C12 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5BD0(void)
{

loc_002D5BD0: ;
    eax = MEM32(0x383044);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x263D00);
    PUSH32(esp, 0x263CF0);
    PUSH32(esp, 0x263D20);
    PUSH32(esp, eax);
    ecx = 0x532F10;
    PUSH32(esp, 0x002D5C06u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5C06: ;
    PUSH32(esp, 0x2D8180);
    PUSH32(esp, 0x002D5C10u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5C10: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5C20
 * Original: 0x002D5C20 - 0x002D5C65 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5C20(void)
{

loc_002D5C20: ;
    eax = MEM32(0x383048);
    PUSH32(esp, 0);
    PUSH32(esp, 3);
    PUSH32(esp, 0x34AAB0);
    PUSH32(esp, 0x24);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0x263E40);
    PUSH32(esp, 0x263E10);
    PUSH32(esp, 0x263D90);
    PUSH32(esp, 0x263D80);
    PUSH32(esp, 0x263DB0);
    PUSH32(esp, eax);
    ecx = 0x532F44;
    PUSH32(esp, 0x002D5C59u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5C59: ;
    PUSH32(esp, 0x2D8190);
    PUSH32(esp, 0x002D5C63u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5C63: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5C70
 * Original: 0x002D5C70 - 0x002D5CB5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5C70(void)
{

loc_002D5C70: ;
    eax = MEM32(0x38304C);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x34AB24);
    PUSH32(esp, 1);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x263FE0);
    PUSH32(esp, 0x263E50);
    PUSH32(esp, 0x263ED0);
    PUSH32(esp, 0x263E70);
    PUSH32(esp, eax);
    ecx = 0x532F78;
    PUSH32(esp, 0x002D5CA9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5CA9: ;
    PUSH32(esp, 0x2D81A0);
    PUSH32(esp, 0x002D5CB3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5CB3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5CC0
 * Original: 0x002D5CC0 - 0x002D5D05 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5CC0(void)
{

loc_002D5CC0: ;
    eax = MEM32(0x383050);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x34AB50);
    PUSH32(esp, 1);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x263FE0);
    PUSH32(esp, 0x263EE0);
    PUSH32(esp, 0x263ED0);
    PUSH32(esp, 0x263F00);
    PUSH32(esp, eax);
    ecx = 0x532FAC;
    PUSH32(esp, 0x002D5CF9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5CF9: ;
    PUSH32(esp, 0x2D81B0);
    PUSH32(esp, 0x002D5D03u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5D03: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5D10
 * Original: 0x002D5D10 - 0x002D5D55 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5D10(void)
{

loc_002D5D10: ;
    eax = MEM32(0x383054);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x34AB74);
    PUSH32(esp, 1);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x263FE0);
    PUSH32(esp, 0x263F60);
    PUSH32(esp, 0x263ED0);
    PUSH32(esp, 0x263F80);
    PUSH32(esp, eax);
    ecx = 0x532FE0;
    PUSH32(esp, 0x002D5D49u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5D49: ;
    PUSH32(esp, 0x2D81C0);
    PUSH32(esp, 0x002D5D53u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5D53: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5D60
 * Original: 0x002D5D60 - 0x002D5DA5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5D60(void)
{

loc_002D5D60: ;
    eax = MEM32(0x383058);
    PUSH32(esp, 0);
    PUSH32(esp, 2);
    PUSH32(esp, 0x34AB94);
    PUSH32(esp, 8);
    PUSH32(esp, 0x530EBC);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x264080);
    PUSH32(esp, 0x264000);
    PUSH32(esp, 0x263FF0);
    PUSH32(esp, 0x264020);
    PUSH32(esp, eax);
    ecx = 0x533014;
    PUSH32(esp, 0x002D5D99u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5D99: ;
    PUSH32(esp, 0x2D81D0);
    PUSH32(esp, 0x002D5DA3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5DA3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5DB0
 * Original: 0x002D5DB0 - 0x002D5DF5 (69 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5DB0(void)
{

loc_002D5DB0: ;
    eax = MEM32(0x38305C);
    PUSH32(esp, 0);
    PUSH32(esp, 9);
    PUSH32(esp, 0x34ABE0);
    PUSH32(esp, 0x64);
    PUSH32(esp, 0x532C04);
    PUSH32(esp, 0x264140);
    PUSH32(esp, 0x264130);
    PUSH32(esp, 0x2640B0);
    PUSH32(esp, 0x2640A0);
    PUSH32(esp, 0x2640D0);
    PUSH32(esp, eax);
    ecx = 0x533048;
    PUSH32(esp, 0x002D5DE9u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5DE9: ;
    PUSH32(esp, 0x2D81E0);
    PUSH32(esp, 0x002D5DF3u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5DF3: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5E00
 * Original: 0x002D5E00 - 0x002D5E17 (23 bytes, 7 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5E00(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D5E00: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0);
    PUSH32(esp, 0x323530);
    PUSH32(esp, 0x002D5E0Eu); RECOMP_ABI_CALL(0x002C9560u, sub_002C9560); /* call 0x002C9560 */

loc_002D5E0E: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(0x5332C4) = eax;
    esp += 4; return; /* ret */

}

/**
 * sub_002D5E20
 * Original: 0x002D5E20 - 0x002D5E33 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5E20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D5E20: ;
    MEM16(0x383248) = MEM16(0x383248) + 1;
    _fa = (uint32_t)(MEM16(0x383248)) & 0xFFFFu;
    _fas = (int32_t)(int16_t)(_fa); _fb = (_fa == 0x8000u); /* inc result/SF/OF; CF unchanged */
    PUSH32(esp, 0x2D81F0);
    PUSH32(esp, 0x002D5E31u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5E31: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5E40
 * Original: 0x002D5E40 - 0x002D5E56 (22 bytes, 6 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5E40(void)
{

loc_002D5E40: ;
    ecx = 0x534578;
    PUSH32(esp, 0x002D5E4Au); RECOMP_ABI_CALL(0x002841E0u, sub_002841E0); /* call 0x002841E0 */

loc_002D5E4A: ;
    PUSH32(esp, 0x2D8210);
    PUSH32(esp, 0x002D5E54u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5E54: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5E60
 * Original: 0x002D5E60 - 0x002D5E87 (39 bytes, 10 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5E60(void)
{

loc_002D5E60: ;
    PUSH32(esp, 0x277430);
    PUSH32(esp, 0x277420);
    PUSH32(esp, 0xB2);
    PUSH32(esp, 4);
    PUSH32(esp, 0x5345E8);
    PUSH32(esp, 0x002D5E7Bu); RECOMP_ABI_CALL(0x002C1AE6u, sub_002C1AE6); /* call 0x002C1AE6 */

loc_002D5E7B: ;
    PUSH32(esp, 0x2D8220);
    PUSH32(esp, 0x002D5E85u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5E85: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5E90
 * Original: 0x002D5E90 - 0x002D5EA3 (19 bytes, 5 insns)
 * Category: game_vtable
 * CC: thiscall, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5E90(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D5E90: ;
    MEM16(0x383248) = MEM16(0x383248) + 1;
    _fa = (uint32_t)(MEM16(0x383248)) & 0xFFFFu;
    _fas = (int32_t)(int16_t)(_fa); _fb = (_fa == 0x8000u); /* inc result/SF/OF; CF unchanged */
    PUSH32(esp, 0x2D8240);
    PUSH32(esp, 0x002D5EA1u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5EA1: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5EB0
 * Original: 0x002D5EB0 - 0x002D5EC5 (21 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5EB0(void)
{

loc_002D5EB0: ;
    eax = MEM32(0x530F08);
    MEM32(0x384794) = eax;
    MEM32(0x530F08) = 0x384790;
    esp += 4; return; /* ret */

}

/**
 * sub_002D5ED0
 * Original: 0x002D5ED0 - 0x002D5EE5 (21 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5ED0(void)
{

loc_002D5ED0: ;
    eax = MEM32(0x530F08);
    MEM32(0x3847A0) = eax;
    MEM32(0x530F08) = 0x38479C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D5EF0
 * Original: 0x002D5EF0 - 0x002D5F05 (21 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5EF0(void)
{

loc_002D5EF0: ;
    eax = MEM32(0x530F08);
    MEM32(0x3847AC) = eax;
    MEM32(0x530F08) = 0x3847A8;
    esp += 4; return; /* ret */

}

/**
 * sub_002D5F10
 * Original: 0x002D5F10 - 0x002D5F52 (66 bytes, 18 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5F10(void)
{

loc_002D5F10: ;
    eax = MEM32(0x3847B4);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 0);
    PUSH32(esp, 1);
    PUSH32(esp, 0x530F4C);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0xF23E0);
    PUSH32(esp, 0x2B2960);
    PUSH32(esp, eax);
    ecx = 0x535568;
    PUSH32(esp, 0x002D5F46u); RECOMP_ABI_CALL(0x001F6AC0u, sub_001F6AC0); /* call 0x001F6AC0 */

loc_002D5F46: ;
    PUSH32(esp, 0x2D8260);
    PUSH32(esp, 0x002D5F50u); RECOMP_ABI_CALL(0x002BE30Eu, sub_002BE30E); /* call 0x002BE30E */

loc_002D5F50: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5F60
 * Original: 0x002D5F60 - 0x002D5F6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5F60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D5F60: ;
    ecx = 0x3887D0;
    g_seh_ebp = ebp; sub_0015C5D0(); return; /* tail jmp 0x0015C5D0 */

}

/**
 * sub_002D5F70
 * Original: 0x002D5F70 - 0x002D5F7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5F70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D5F70: ;
    ecx = 0x389F60;
    g_seh_ebp = ebp; sub_001374D0(); return; /* tail jmp 0x001374D0 */

}

/**
 * sub_002D5F80
 * Original: 0x002D5F80 - 0x002D5F8A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5F80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D5F80: ;
    ecx = 0x389FD0;
    g_seh_ebp = ebp; sub_00014130(); return; /* tail jmp 0x00014130 */

}

/**
 * sub_002D5F90
 * Original: 0x002D5F90 - 0x002D5F91 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5F90(void)
{

loc_002D5F90: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D5FA0
 * Original: 0x002D5FA0 - 0x002D5FD3 (51 bytes, 17 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5FA0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D5FA0: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    ecx = 0x3883C0;
    PUSH32(esp, 0x002D5FACu); RECOMP_ABI_CALL(0x00082160u, sub_00082160); /* call 0x00082160 */

loc_002D5FAC: ;
    esi = 0x3877DC;
    edi = 4;
    goto loc_002D5FC0;

    /* nop */
    /* nop */

loc_002D5FC0: ;
    _fb = (uint32_t)(0x124) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esi = esi - 0x124;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    ecx = esi;
    PUSH32(esp, 0x002D5FCDu); RECOMP_ABI_CALL(0x00077FA0u, sub_00077FA0); /* call 0x00077FA0 */

loc_002D5FCD: ;
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D5FC0; /* jne: not equal / not zero */

loc_002D5FD0: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D5FE0
 * Original: 0x002D5FE0 - 0x002D5FEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5FE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D5FE0: ;
    ecx = 0x38DCC8;
    g_seh_ebp = ebp; sub_0001C150(); return; /* tail jmp 0x0001C150 */

}

/**
 * sub_002D5FF0
 * Original: 0x002D5FF0 - 0x002D5FF1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D5FF0(void)
{

loc_002D5FF0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6000
 * Original: 0x002D6000 - 0x002D604E (78 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6000(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6000: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x39FCF8;
    edi = 0x5FF;
    /* nop */

loc_002D6010: ;
    eax = MEM32(esi + -48);
    _fb = (uint32_t)(0x30) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esi = esi - 0x30;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6029; /* je: equal / zero */

loc_002D601A: ;
    edx = MEM32(eax);
    ecx = esi + -8;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, ecx (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D6029; /* jne: not equal / not zero */

loc_002D6023: ;
    MEM32(eax) = 0;

loc_002D6029: ;
    SET_LO8(eax, MEM8(esi + 0x24));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6034; /* je: equal / zero */

loc_002D6030: ;
    MEM8(esi + 0x24) = 0;

loc_002D6034: ;
    ecx = esi + -8;
    MEM32(ecx) = 0;
    MEM32(esi) = 0;
    PUSH32(esp, 0x002D6048u); RECOMP_ABI_CALL(0x00017300u, sub_00017300); /* call 0x00017300 */

loc_002D6048: ;
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D6010; /* jne: not equal / not zero */

loc_002D604B: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D6050
 * Original: 0x002D6050 - 0x002D6051 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6050(void)
{

loc_002D6050: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6060
 * Original: 0x002D6060 - 0x002D606A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6060(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6060: ;
    ecx = 0x3A0190;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D6070
 * Original: 0x002D6070 - 0x002D608A (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6070(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6070: ;
    SET_LO8(eax, MEM8(0x3A0170));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6089; /* je: equal / zero */

loc_002D6079: ;
    eax = MEM32(0x3A0160);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6089; /* je: equal / zero */

loc_002D6082: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6088u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D6088: ;
    POP32(esp, ecx);

loc_002D6089: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6090
 * Original: 0x002D6090 - 0x002D60AA (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6090(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6090: ;
    SET_LO8(eax, MEM8(0x3A0240));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D60A9; /* je: equal / zero */

loc_002D6099: ;
    eax = MEM32(0x3A0230);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D60A9; /* je: equal / zero */

loc_002D60A2: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D60A8u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D60A8: ;
    POP32(esp, ecx);

loc_002D60A9: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D60B0
 * Original: 0x002D60B0 - 0x002D60CA (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D60B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D60B0: ;
    SET_LO8(eax, MEM8(0x372E20));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D60C9; /* je: equal / zero */

loc_002D60B9: ;
    eax = MEM32(0x372E10);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D60C9; /* je: equal / zero */

loc_002D60C2: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D60C8u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D60C8: ;
    POP32(esp, ecx);

loc_002D60C9: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D60D0
 * Original: 0x002D60D0 - 0x002D60D1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D60D0(void)
{

loc_002D60D0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D60E0
 * Original: 0x002D60E0 - 0x002D6134 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D60E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D60E0: ;
    eax = MEM32(0x3A02E4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6123; /* je: equal / zero */

loc_002D60E9: ;
    eax = MEM32(0x3A02E0);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A02E0;
    PUSH32(esp, 0x002D60FCu); RECOMP_ABI_CALL(0x00036240u, sub_00036240); /* call 0x00036240 */

loc_002D60FC: ;
    eax = MEM32(0x3A02E0);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A02E0);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A02E0);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A02E4) = 0;

loc_002D6123: ;
    eax = MEM32(0x3A02E0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6133; /* je: equal / zero */

loc_002D612C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6132u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6132: ;
    POP32(esp, ecx);

loc_002D6133: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6140
 * Original: 0x002D6140 - 0x002D615A (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6140(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6140: ;
    SET_LO8(eax, MEM8(0x372E44));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6159; /* je: equal / zero */

loc_002D6149: ;
    eax = MEM32(0x372E34);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6159; /* je: equal / zero */

loc_002D6152: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6158u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D6158: ;
    POP32(esp, ecx);

loc_002D6159: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6160
 * Original: 0x002D6160 - 0x002D61B4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6160(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6160: ;
    eax = MEM32(0x3A0308);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D61A3; /* je: equal / zero */

loc_002D6169: ;
    eax = MEM32(0x3A0304);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A0304;
    PUSH32(esp, 0x002D617Cu); RECOMP_ABI_CALL(0x00037220u, sub_00037220); /* call 0x00037220 */

loc_002D617C: ;
    eax = MEM32(0x3A0304);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A0304);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A0304);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A0308) = 0;

loc_002D61A3: ;
    eax = MEM32(0x3A0304);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D61B3; /* je: equal / zero */

loc_002D61AC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D61B2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D61B2: ;
    POP32(esp, ecx);

loc_002D61B3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D61C0
 * Original: 0x002D61C0 - 0x002D6214 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D61C0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D61C0: ;
    eax = MEM32(0x3A0314);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6203; /* je: equal / zero */

loc_002D61C9: ;
    eax = MEM32(0x3A0310);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A0310;
    PUSH32(esp, 0x002D61DCu); RECOMP_ABI_CALL(0x00037260u, sub_00037260); /* call 0x00037260 */

loc_002D61DC: ;
    eax = MEM32(0x3A0310);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A0310);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A0310);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A0314) = 0;

loc_002D6203: ;
    eax = MEM32(0x3A0310);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6213; /* je: equal / zero */

loc_002D620C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6212u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6212: ;
    POP32(esp, ecx);

loc_002D6213: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6220
 * Original: 0x002D6220 - 0x002D6221 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6220(void)
{

loc_002D6220: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6230
 * Original: 0x002D6230 - 0x002D6231 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6230(void)
{

loc_002D6230: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6240
 * Original: 0x002D6240 - 0x002D625C (28 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6240(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6240: ;
    ecx = MEM32(0x3A0528);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6251; /* je: equal / zero */

loc_002D624A: ;
    PUSH32(esp, 3);
    PUSH32(esp, 0x002D6251u); RECOMP_ABI_CALL(0x00039AF0u, sub_00039AF0); /* call 0x00039AF0 */

loc_002D6251: ;
    MEM32(0x3A0528) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6260
 * Original: 0x002D6260 - 0x002D6271 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6260(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6260: ;
    eax = MEM32(0x3A656C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6270; /* je: equal / zero */

loc_002D6269: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D626Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D626F: ;
    POP32(esp, ecx);

loc_002D6270: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6280
 * Original: 0x002D6280 - 0x002D62D4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6280(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6280: ;
    eax = MEM32(0x3A658C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D62C3; /* je: equal / zero */

loc_002D6289: ;
    eax = MEM32(0x3A6588);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A6588;
    PUSH32(esp, 0x002D629Cu); RECOMP_ABI_CALL(0x0003C460u, sub_0003C460); /* call 0x0003C460 */

loc_002D629C: ;
    eax = MEM32(0x3A6588);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A6588);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A6588);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A658C) = 0;

loc_002D62C3: ;
    eax = MEM32(0x3A6588);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D62D3; /* je: equal / zero */

loc_002D62CC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D62D2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D62D2: ;
    POP32(esp, ecx);

loc_002D62D3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D62E0
 * Original: 0x002D62E0 - 0x002D6334 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D62E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D62E0: ;
    eax = MEM32(0x3A6580);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6323; /* je: equal / zero */

loc_002D62E9: ;
    eax = MEM32(0x3A657C);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A657C;
    PUSH32(esp, 0x002D62FCu); RECOMP_ABI_CALL(0x0003C460u, sub_0003C460); /* call 0x0003C460 */

loc_002D62FC: ;
    eax = MEM32(0x3A657C);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A657C);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A657C);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A6580) = 0;

loc_002D6323: ;
    eax = MEM32(0x3A657C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6333; /* je: equal / zero */

loc_002D632C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6332u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6332: ;
    POP32(esp, ecx);

loc_002D6333: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6340
 * Original: 0x002D6340 - 0x002D634A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6340(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6340: ;
    ecx = 0x3A65A8;
    g_seh_ebp = ebp; sub_00156800(); return; /* tail jmp 0x00156800 */

}

/**
 * sub_002D6350
 * Original: 0x002D6350 - 0x002D6361 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6350(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6350: ;
    eax = MEM32(0x3A6598);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6360; /* je: equal / zero */

loc_002D6359: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D635Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D635F: ;
    POP32(esp, ecx);

loc_002D6360: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6370
 * Original: 0x002D6370 - 0x002D637A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6370(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6370: ;
    ecx = 0x3A6670;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6380
 * Original: 0x002D6380 - 0x002D638A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6380(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6380: ;
    ecx = 0x3A6694;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6390
 * Original: 0x002D6390 - 0x002D639A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6390(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6390: ;
    ecx = 0x3A66B8;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D63A0
 * Original: 0x002D63A0 - 0x002D63AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D63A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D63A0: ;
    ecx = 0x3A66DC;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D63B0
 * Original: 0x002D63B0 - 0x002D63BA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D63B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D63B0: ;
    ecx = 0x3A6700;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D63C0
 * Original: 0x002D63C0 - 0x002D63CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D63C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D63C0: ;
    ecx = 0x3A6738;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D63D0
 * Original: 0x002D63D0 - 0x002D6424 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D63D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D63D0: ;
    eax = MEM32(0x3A6760);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6413; /* je: equal / zero */

loc_002D63D9: ;
    eax = MEM32(0x3A675C);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A675C;
    PUSH32(esp, 0x002D63ECu); RECOMP_ABI_CALL(0x0004F420u, sub_0004F420); /* call 0x0004F420 */

loc_002D63EC: ;
    eax = MEM32(0x3A675C);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A675C);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A675C);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A6760) = 0;

loc_002D6413: ;
    eax = MEM32(0x3A675C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6423; /* je: equal / zero */

loc_002D641C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6422u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6422: ;
    POP32(esp, ecx);

loc_002D6423: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6430
 * Original: 0x002D6430 - 0x002D643A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6430(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6430: ;
    ecx = 0x3A75BC;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6440
 * Original: 0x002D6440 - 0x002D6494 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6440(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6440: ;
    eax = MEM32(0x3A75EC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6483; /* je: equal / zero */

loc_002D6449: ;
    eax = MEM32(0x3A75E8);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A75E8;
    PUSH32(esp, 0x002D645Cu); RECOMP_ABI_CALL(0x00050E40u, sub_00050E40); /* call 0x00050E40 */

loc_002D645C: ;
    eax = MEM32(0x3A75E8);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A75E8);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A75E8);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A75EC) = 0;

loc_002D6483: ;
    eax = MEM32(0x3A75E8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6493; /* je: equal / zero */

loc_002D648C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6492u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6492: ;
    POP32(esp, ecx);

loc_002D6493: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D64A0
 * Original: 0x002D64A0 - 0x002D64AB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D64A0(void)
{

loc_002D64A0: ;
    MEM32(0x3A75FC) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D64B0
 * Original: 0x002D64B0 - 0x002D64BB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D64B0(void)
{

loc_002D64B0: ;
    MEM32(0x3A7628) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D64C0
 * Original: 0x002D64C0 - 0x002D64CB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D64C0(void)
{

loc_002D64C0: ;
    MEM32(0x3A7654) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D64D0
 * Original: 0x002D64D0 - 0x002D64DB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D64D0(void)
{

loc_002D64D0: ;
    MEM32(0x3A7680) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D64E0
 * Original: 0x002D64E0 - 0x002D64EB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D64E0(void)
{

loc_002D64E0: ;
    MEM32(0x3A76AC) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D64F0
 * Original: 0x002D64F0 - 0x002D64FB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D64F0(void)
{

loc_002D64F0: ;
    MEM32(0x3A76D8) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6500
 * Original: 0x002D6500 - 0x002D6514 (20 bytes, 3 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6500(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6500: ;
    MEM32(0x3A7708) = 0x3052C4;
    ecx = 0x3A7708;
    g_seh_ebp = ebp; sub_0005D6B0(); return; /* tail jmp 0x0005D6B0 */

}

/**
 * sub_002D6520
 * Original: 0x002D6520 - 0x002D652A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6520(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6520: ;
    ecx = 0x3A7828;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6530
 * Original: 0x002D6530 - 0x002D653A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6530(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6530: ;
    ecx = 0x3A784C;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6540
 * Original: 0x002D6540 - 0x002D654A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6540(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6540: ;
    ecx = 0x3A7878;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6550
 * Original: 0x002D6550 - 0x002D6561 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6550(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6550: ;
    eax = MEM32(0x3A78A4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6560; /* je: equal / zero */

loc_002D6559: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D655Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D655F: ;
    POP32(esp, ecx);

loc_002D6560: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6570
 * Original: 0x002D6570 - 0x002D6581 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6570(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6570: ;
    eax = MEM32(0x3A78B4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6580; /* je: equal / zero */

loc_002D6579: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D657Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D657F: ;
    POP32(esp, ecx);

loc_002D6580: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6590
 * Original: 0x002D6590 - 0x002D65E4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6590(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6590: ;
    eax = MEM32(0x3A78C8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D65D3; /* je: equal / zero */

loc_002D6599: ;
    eax = MEM32(0x3A78C4);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A78C4;
    PUSH32(esp, 0x002D65ACu); RECOMP_ABI_CALL(0x00063CF0u, sub_00063CF0); /* call 0x00063CF0 */

loc_002D65AC: ;
    eax = MEM32(0x3A78C4);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A78C4);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A78C4);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A78C8) = 0;

loc_002D65D3: ;
    eax = MEM32(0x3A78C4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D65E3; /* je: equal / zero */

loc_002D65DC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D65E2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D65E2: ;
    POP32(esp, ecx);

loc_002D65E3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D65F0
 * Original: 0x002D65F0 - 0x002D65FA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D65F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D65F0: ;
    ecx = 0x3A78D0;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D6600
 * Original: 0x002D6600 - 0x002D6601 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6600(void)
{

loc_002D6600: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6610
 * Original: 0x002D6610 - 0x002D6664 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6610(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6610: ;
    eax = MEM32(0x3A9C38);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6653; /* je: equal / zero */

loc_002D6619: ;
    eax = MEM32(0x3A9C34);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A9C34;
    PUSH32(esp, 0x002D662Cu); RECOMP_ABI_CALL(0x00067250u, sub_00067250); /* call 0x00067250 */

loc_002D662C: ;
    eax = MEM32(0x3A9C34);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A9C34);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A9C34);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A9C38) = 0;

loc_002D6653: ;
    eax = MEM32(0x3A9C34);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6663; /* je: equal / zero */

loc_002D665C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6662u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6662: ;
    POP32(esp, ecx);

loc_002D6663: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6670
 * Original: 0x002D6670 - 0x002D66C4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6670(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6670: ;
    eax = MEM32(0x3A9C5C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D66B3; /* je: equal / zero */

loc_002D6679: ;
    eax = MEM32(0x3A9C58);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A9C58;
    PUSH32(esp, 0x002D668Cu); RECOMP_ABI_CALL(0x00067E80u, sub_00067E80); /* call 0x00067E80 */

loc_002D668C: ;
    eax = MEM32(0x3A9C58);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A9C58);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A9C58);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A9C5C) = 0;

loc_002D66B3: ;
    eax = MEM32(0x3A9C58);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D66C3; /* je: equal / zero */

loc_002D66BC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D66C2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D66C2: ;
    POP32(esp, ecx);

loc_002D66C3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D66D0
 * Original: 0x002D66D0 - 0x002D6724 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D66D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D66D0: ;
    eax = MEM32(0x3A9C44);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6713; /* je: equal / zero */

loc_002D66D9: ;
    eax = MEM32(0x3A9C40);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A9C40;
    PUSH32(esp, 0x002D66ECu); RECOMP_ABI_CALL(0x00068030u, sub_00068030); /* call 0x00068030 */

loc_002D66EC: ;
    eax = MEM32(0x3A9C40);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A9C40);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A9C40);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A9C44) = 0;

loc_002D6713: ;
    eax = MEM32(0x3A9C40);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6723; /* je: equal / zero */

loc_002D671C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6722u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6722: ;
    POP32(esp, ecx);

loc_002D6723: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6730
 * Original: 0x002D6730 - 0x002D6784 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6730(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6730: ;
    eax = MEM32(0x3A9C50);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6773; /* je: equal / zero */

loc_002D6739: ;
    eax = MEM32(0x3A9C4C);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3A9C4C;
    PUSH32(esp, 0x002D674Cu); RECOMP_ABI_CALL(0x00068710u, sub_00068710); /* call 0x00068710 */

loc_002D674C: ;
    eax = MEM32(0x3A9C4C);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3A9C4C);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3A9C4C);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3A9C50) = 0;

loc_002D6773: ;
    eax = MEM32(0x3A9C4C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6783; /* je: equal / zero */

loc_002D677C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6782u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6782: ;
    POP32(esp, ecx);

loc_002D6783: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6790
 * Original: 0x002D6790 - 0x002D679A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6790(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6790: ;
    ecx = 0x3BC890;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D67A0
 * Original: 0x002D67A0 - 0x002D67AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D67A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D67A0: ;
    ecx = 0x3BC8B4;
    g_seh_ebp = ebp; sub_000659F0(); return; /* tail jmp 0x000659F0 */

}

/**
 * sub_002D67B0
 * Original: 0x002D67B0 - 0x002D67C1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D67B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D67B0: ;
    eax = MEM32(0x3BC8E0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D67C0; /* je: equal / zero */

loc_002D67B9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D67BFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D67BF: ;
    POP32(esp, ecx);

loc_002D67C0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D67D0
 * Original: 0x002D67D0 - 0x002D67E1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D67D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D67D0: ;
    eax = MEM32(0x3BC8F0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D67E0; /* je: equal / zero */

loc_002D67D9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D67DFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D67DF: ;
    POP32(esp, ecx);

loc_002D67E0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D67F0
 * Original: 0x002D67F0 - 0x002D6801 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D67F0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D67F0: ;
    eax = MEM32(0x3BC904);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6800; /* je: equal / zero */

loc_002D67F9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D67FFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D67FF: ;
    POP32(esp, ecx);

loc_002D6800: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6810
 * Original: 0x002D6810 - 0x002D6821 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6810(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6810: ;
    eax = MEM32(0x3BC918);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6820; /* je: equal / zero */

loc_002D6819: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D681Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D681F: ;
    POP32(esp, ecx);

loc_002D6820: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6830
 * Original: 0x002D6830 - 0x002D6841 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6830(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6830: ;
    eax = MEM32(0x3BC92C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6840; /* je: equal / zero */

loc_002D6839: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D683Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D683F: ;
    POP32(esp, ecx);

loc_002D6840: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6850
 * Original: 0x002D6850 - 0x002D6861 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6850(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6850: ;
    eax = MEM32(0x3BC940);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6860; /* je: equal / zero */

loc_002D6859: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D685Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D685F: ;
    POP32(esp, ecx);

loc_002D6860: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6870
 * Original: 0x002D6870 - 0x002D6881 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6870(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6870: ;
    eax = MEM32(0x3BC954);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6880; /* je: equal / zero */

loc_002D6879: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D687Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D687F: ;
    POP32(esp, ecx);

loc_002D6880: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6890
 * Original: 0x002D6890 - 0x002D68A1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6890(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6890: ;
    eax = MEM32(0x3BC964);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D68A0; /* je: equal / zero */

loc_002D6899: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D689Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D689F: ;
    POP32(esp, ecx);

loc_002D68A0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D68B0
 * Original: 0x002D68B0 - 0x002D68C1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D68B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D68B0: ;
    eax = MEM32(0x3BC974);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D68C0; /* je: equal / zero */

loc_002D68B9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D68BFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D68BF: ;
    POP32(esp, ecx);

loc_002D68C0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D68D0
 * Original: 0x002D68D0 - 0x002D68E1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D68D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D68D0: ;
    eax = MEM32(0x3BC984);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D68E0; /* je: equal / zero */

loc_002D68D9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D68DFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D68DF: ;
    POP32(esp, ecx);

loc_002D68E0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D68F0
 * Original: 0x002D68F0 - 0x002D6901 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D68F0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D68F0: ;
    eax = MEM32(0x3BC994);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6900; /* je: equal / zero */

loc_002D68F9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D68FFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D68FF: ;
    POP32(esp, ecx);

loc_002D6900: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6910
 * Original: 0x002D6910 - 0x002D6921 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6910(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6910: ;
    eax = MEM32(0x3BC9A4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6920; /* je: equal / zero */

loc_002D6919: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D691Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D691F: ;
    POP32(esp, ecx);

loc_002D6920: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6930
 * Original: 0x002D6930 - 0x002D6941 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6930(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6930: ;
    eax = MEM32(0x3BC9B4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6940; /* je: equal / zero */

loc_002D6939: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D693Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D693F: ;
    POP32(esp, ecx);

loc_002D6940: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6950
 * Original: 0x002D6950 - 0x002D6961 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6950(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6950: ;
    eax = MEM32(0x3BC9C4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6960; /* je: equal / zero */

loc_002D6959: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D695Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D695F: ;
    POP32(esp, ecx);

loc_002D6960: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6970
 * Original: 0x002D6970 - 0x002D6981 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6970(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6970: ;
    eax = MEM32(0x3BC9D4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6980; /* je: equal / zero */

loc_002D6979: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D697Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D697F: ;
    POP32(esp, ecx);

loc_002D6980: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6990
 * Original: 0x002D6990 - 0x002D69A1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6990(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6990: ;
    eax = MEM32(0x3BC9E4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D69A0; /* je: equal / zero */

loc_002D6999: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D699Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D699F: ;
    POP32(esp, ecx);

loc_002D69A0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D69B0
 * Original: 0x002D69B0 - 0x002D69B1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D69B0(void)
{

loc_002D69B0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D69C0
 * Original: 0x002D69C0 - 0x002D69C1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D69C0(void)
{

loc_002D69C0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D69D0
 * Original: 0x002D69D0 - 0x002D69DA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D69D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D69D0: ;
    ecx = 0x3BE9A0;
    g_seh_ebp = ebp; sub_000742F0(); return; /* tail jmp 0x000742F0 */

}

/**
 * sub_002D69E0
 * Original: 0x002D69E0 - 0x002D69E1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D69E0(void)
{

loc_002D69E0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D69F0
 * Original: 0x002D69F0 - 0x002D6A04 (20 bytes, 4 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D69F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D69F0: ;
    ecx = 0x3C2538;
    PUSH32(esp, 0x002D69FAu); RECOMP_ABI_CALL(0x000774B0u, sub_000774B0); /* call 0x000774B0 */

loc_002D69FA: ;
    ecx = 0x3C2470;
    g_seh_ebp = ebp; sub_001557F0(); return; /* tail jmp 0x001557F0 */

}

/**
 * sub_002D6A10
 * Original: 0x002D6A10 - 0x002D6A1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6A10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6A10: ;
    ecx = 0x3C2F40;
    g_seh_ebp = ebp; sub_00181E10(); return; /* tail jmp 0x00181E10 */

}

/**
 * sub_002D6A20
 * Original: 0x002D6A20 - 0x002D6A3E (30 bytes, 4 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6A20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6A20: ;
    MEM32(0x3C35B0) = 0x307AF8;
    MEM32(0x3C35B8) = 0x307AEC;
    ecx = 0x3C35B0;
    g_seh_ebp = ebp; sub_00130500(); return; /* tail jmp 0x00130500 */

}

/**
 * sub_002D6A40
 * Original: 0x002D6A40 - 0x002D6A4A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6A40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6A40: ;
    ecx = 0x3C36F0;
    g_seh_ebp = ebp; sub_00156800(); return; /* tail jmp 0x00156800 */

}

/**
 * sub_002D6A50
 * Original: 0x002D6A50 - 0x002D6A5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6A50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6A50: ;
    ecx = 0x3C3740;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6A60
 * Original: 0x002D6A60 - 0x002D6A6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6A60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6A60: ;
    ecx = 0x3C3794;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6A70
 * Original: 0x002D6A70 - 0x002D6AC4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6A70(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6A70: ;
    eax = MEM32(0x3C37C4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6AB3; /* je: equal / zero */

loc_002D6A79: ;
    eax = MEM32(0x3C37C0);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3C37C0;
    PUSH32(esp, 0x002D6A8Cu); RECOMP_ABI_CALL(0x0008AAD0u, sub_0008AAD0); /* call 0x0008AAD0 */

loc_002D6A8C: ;
    eax = MEM32(0x3C37C0);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3C37C0);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3C37C0);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3C37C4) = 0;

loc_002D6AB3: ;
    eax = MEM32(0x3C37C0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6AC3; /* je: equal / zero */

loc_002D6ABC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6AC2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6AC2: ;
    POP32(esp, ecx);

loc_002D6AC3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6AD0
 * Original: 0x002D6AD0 - 0x002D6ADA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6AD0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6AD0: ;
    ecx = 0x3C383C;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6AE0
 * Original: 0x002D6AE0 - 0x002D6AEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6AE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6AE0: ;
    ecx = 0x3C3858;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6AF0
 * Original: 0x002D6AF0 - 0x002D6AFA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6AF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6AF0: ;
    ecx = 0x3C388C;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B00
 * Original: 0x002D6B00 - 0x002D6B0A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B00: ;
    ecx = 0x3C38FC;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B10
 * Original: 0x002D6B10 - 0x002D6B1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B10: ;
    ecx = 0x3C392C;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B20
 * Original: 0x002D6B20 - 0x002D6B2A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B20: ;
    ecx = 0x3C3A2C;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B30
 * Original: 0x002D6B30 - 0x002D6B3A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B30: ;
    ecx = 0x3C3AC4;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B40
 * Original: 0x002D6B40 - 0x002D6B4A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B40: ;
    ecx = 0x3C3CA0;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B50
 * Original: 0x002D6B50 - 0x002D6B5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B50: ;
    ecx = 0x3C3CAC;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B60
 * Original: 0x002D6B60 - 0x002D6B6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B60: ;
    ecx = 0x3C3CB8;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B70
 * Original: 0x002D6B70 - 0x002D6B7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B70: ;
    ecx = 0x3C3D08;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B80
 * Original: 0x002D6B80 - 0x002D6B8A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6B80: ;
    ecx = 0x3C3D70;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D6B90
 * Original: 0x002D6B90 - 0x002D6BE4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6B90(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6B90: ;
    eax = MEM32(0x3C3E84);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6BD3; /* je: equal / zero */

loc_002D6B99: ;
    eax = MEM32(0x3C3E80);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3C3E80;
    PUSH32(esp, 0x002D6BACu); RECOMP_ABI_CALL(0x000A5290u, sub_000A5290); /* call 0x000A5290 */

loc_002D6BAC: ;
    eax = MEM32(0x3C3E80);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3C3E80);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3C3E80);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3C3E84) = 0;

loc_002D6BD3: ;
    eax = MEM32(0x3C3E80);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6BE3; /* je: equal / zero */

loc_002D6BDC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6BE2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6BE2: ;
    POP32(esp, ecx);

loc_002D6BE3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6BF0
 * Original: 0x002D6BF0 - 0x002D6C04 (20 bytes, 4 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6BF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6BF0: ;
    ecx = 0x3734F8;
    PUSH32(esp, 0x002D6BFAu); RECOMP_ABI_CALL(0x000A69E0u, sub_000A69E0); /* call 0x000A69E0 */

loc_002D6BFA: ;
    ecx = 0x373508;
    g_seh_ebp = ebp; sub_00156700(); return; /* tail jmp 0x00156700 */

}

/**
 * sub_002D6C10
 * Original: 0x002D6C10 - 0x002D6C11 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C10(void)
{

loc_002D6C10: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6C20
 * Original: 0x002D6C20 - 0x002D6C2A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6C20: ;
    ecx = 0x3C6088;
    g_seh_ebp = ebp; sub_001D0960(); return; /* tail jmp 0x001D0960 */

}

/**
 * sub_002D6C30
 * Original: 0x002D6C30 - 0x002D6C44 (20 bytes, 4 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6C30: ;
    ecx = 0x3735A4;
    PUSH32(esp, 0x002D6C3Au); RECOMP_ABI_CALL(0x000B9200u, sub_000B9200); /* call 0x000B9200 */

loc_002D6C3A: ;
    ecx = 0x3735B4;
    g_seh_ebp = ebp; sub_00156700(); return; /* tail jmp 0x00156700 */

}

/**
 * sub_002D6C50
 * Original: 0x002D6C50 - 0x002D6C5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6C50: ;
    ecx = 0x3C6184;
    g_seh_ebp = ebp; sub_00156800(); return; /* tail jmp 0x00156800 */

}

/**
 * sub_002D6C60
 * Original: 0x002D6C60 - 0x002D6C6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6C60: ;
    ecx = 0x3C61A0;
    g_seh_ebp = ebp; sub_00156800(); return; /* tail jmp 0x00156800 */

}

/**
 * sub_002D6C70
 * Original: 0x002D6C70 - 0x002D6C7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6C70: ;
    ecx = 0x3C6230;
    g_seh_ebp = ebp; sub_001CE560(); return; /* tail jmp 0x001CE560 */

}

/**
 * sub_002D6C80
 * Original: 0x002D6C80 - 0x002D6CA0 (32 bytes, 12 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6C80(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6C80: ;
    ecx = MEM32(0x3C62B8);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    PUSH32(esp, esi);
    esi = ecx;
    if (CMP_EQ(_fa, _fb)) goto loc_002D6C9E; /* je: equal / zero */

loc_002D6C8D: ;
    PUSH32(esp, 0x002D6C92u); RECOMP_ABI_CALL(0x001D2B50u, sub_001D2B50); /* call 0x001D2B50 */

loc_002D6C92: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x34);
    PUSH32(esp, esi);
    { uint32_t _icall_target = MEM32(0x37DB6C); PUSH32(esp, 0x002D6C9Bu); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002D6C95u); } /* indirect call */
    }

loc_002D6C9B: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D6C9E: ;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D6CA0
 * Original: 0x002D6CA0 - 0x002D6CF9 (89 bytes, 26 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6CA0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6CA0: ;
    ecx = MEM32(0x3C6424);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6CD2; /* je: equal / zero */

loc_002D6CAA: ;
    SET_LO8(eax, MEM8(0x3C6438));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6CC8; /* je: equal / zero */

loc_002D6CB3: ;
    PUSH32(esp, esi);
    esi = ecx;
    PUSH32(esp, 0x002D6CBBu); RECOMP_ABI_CALL(0x001CE560u, sub_001CE560); /* call 0x001CE560 */

loc_002D6CBB: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x4C);
    PUSH32(esp, esi);
    { uint32_t _icall_target = MEM32(0x37DB6C); PUSH32(esp, 0x002D6CC4u); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002D6CBEu); } /* indirect call */
    }

loc_002D6CC4: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, esi);

loc_002D6CC8: ;
    MEM32(0x3C6424) = 0;

loc_002D6CD2: ;
    eax = MEM32(0x3C6420);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6CF8; /* je: equal / zero */

loc_002D6CDB: ;
    SET_LO8(ecx, MEM8(0x3C6439));
    _fa = (uint32_t)(LO8(ecx)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(ecx), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6CEE; /* je: equal / zero */

loc_002D6CE5: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6CEBu); RECOMP_ABI_CALL(0x00152060u, sub_00152060); /* call 0x00152060 */

loc_002D6CEB: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D6CEE: ;
    MEM32(0x3C6420) = 0;

loc_002D6CF8: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6D00
 * Original: 0x002D6D00 - 0x002D6D0A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6D00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6D00: ;
    ecx = 0x3C64F8;
    g_seh_ebp = ebp; sub_001CE560(); return; /* tail jmp 0x001CE560 */

}

/**
 * sub_002D6D10
 * Original: 0x002D6D10 - 0x002D6D1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6D10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6D10: ;
    ecx = 0x3C6570;
    g_seh_ebp = ebp; sub_001CE560(); return; /* tail jmp 0x001CE560 */

}

/**
 * sub_002D6D20
 * Original: 0x002D6D20 - 0x002D6D39 (25 bytes, 5 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6D20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6D20: ;
    eax = 0x2FF0D4;
    MEM32(0x3C9690) = eax;
    MEM32(0x3C9500) = eax;
    ecx = 0x3C6600;
    g_seh_ebp = ebp; sub_000C51F0(); return; /* tail jmp 0x000C51F0 */

}

/**
 * sub_002D6D40
 * Original: 0x002D6D40 - 0x002D6D4B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6D40(void)
{

loc_002D6D40: ;
    MEM32(0x3DAF78) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6D50
 * Original: 0x002D6D50 - 0x002D6D5B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6D50(void)
{

loc_002D6D50: ;
    MEM32(0x3DAFA4) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6D60
 * Original: 0x002D6D60 - 0x002D6DB4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6D60(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6D60: ;
    eax = MEM32(0x3DAFF8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6DA3; /* je: equal / zero */

loc_002D6D69: ;
    eax = MEM32(0x3DAFF4);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3DAFF4;
    PUSH32(esp, 0x002D6D7Cu); RECOMP_ABI_CALL(0x000F0530u, sub_000F0530); /* call 0x000F0530 */

loc_002D6D7C: ;
    eax = MEM32(0x3DAFF4);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3DAFF4);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3DAFF4);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3DAFF8) = 0;

loc_002D6DA3: ;
    eax = MEM32(0x3DAFF4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6DB3; /* je: equal / zero */

loc_002D6DAC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6DB2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6DB2: ;
    POP32(esp, ecx);

loc_002D6DB3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6DC0
 * Original: 0x002D6DC0 - 0x002D6DF5 (53 bytes, 19 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6DC0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6DC0: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x3DB504;
    edi = 0x50;
    /* nop */

loc_002D6DD0: ;
    ecx = MEM32(esi + -16);
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esi = esi - 0x10;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    eax = esi + -4;
    MEM32(eax) = 0x2FEC40;
    if (CMP_EQ(_fa, _fb)) goto loc_002D6DE9; /* je: equal / zero */

loc_002D6DE3: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6DE9u); RECOMP_ABI_CALL(0x0012F650u, sub_0012F650); /* call 0x0012F650 */

loc_002D6DE9: ;
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(esi) = 0;
    if ((_fa != 0)) goto loc_002D6DD0; /* jne: not equal / not zero */

loc_002D6DF2: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D6E00
 * Original: 0x002D6E00 - 0x002D6E0B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6E00(void)
{

loc_002D6E00: ;
    MEM32(0x3DB624) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6E10
 * Original: 0x002D6E10 - 0x002D6E1B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6E10(void)
{

loc_002D6E10: ;
    MEM32(0x3DB65C) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6E20
 * Original: 0x002D6E20 - 0x002D6E2B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6E20(void)
{

loc_002D6E20: ;
    MEM32(0x3DB688) = 0x30466C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6E30
 * Original: 0x002D6E30 - 0x002D6E3B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6E30(void)
{

loc_002D6E30: ;
    MEM32(0x375E70) = 0x316ED8;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6E40
 * Original: 0x002D6E40 - 0x002D6E94 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6E40(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6E40: ;
    eax = MEM32(0x3DB8DC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6E83; /* je: equal / zero */

loc_002D6E49: ;
    eax = MEM32(0x3DB8D8);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3DB8D8;
    PUSH32(esp, 0x002D6E5Cu); RECOMP_ABI_CALL(0x000FC330u, sub_000FC330); /* call 0x000FC330 */

loc_002D6E5C: ;
    eax = MEM32(0x3DB8D8);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3DB8D8);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3DB8D8);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3DB8DC) = 0;

loc_002D6E83: ;
    eax = MEM32(0x3DB8D8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6E93; /* je: equal / zero */

loc_002D6E8C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6E92u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D6E92: ;
    POP32(esp, ecx);

loc_002D6E93: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6EA0
 * Original: 0x002D6EA0 - 0x002D6EAA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6EA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6EA0: ;
    ecx = 0x3DB900;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D6EB0
 * Original: 0x002D6EB0 - 0x002D6EBA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6EB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6EB0: ;
    ecx = 0x3DB930;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D6EC0
 * Original: 0x002D6EC0 - 0x002D6ECA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6EC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6EC0: ;
    ecx = 0x3DB960;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D6ED0
 * Original: 0x002D6ED0 - 0x002D6EDA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6ED0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6ED0: ;
    ecx = 0x3DE7E0;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D6EE0
 * Original: 0x002D6EE0 - 0x002D6EEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6EE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6EE0: ;
    ecx = 0x3DE810;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D6EF0
 * Original: 0x002D6EF0 - 0x002D6F0A (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6EF0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6EF0: ;
    SET_LO8(eax, MEM8(0x3DC470));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F09; /* je: equal / zero */

loc_002D6EF9: ;
    eax = MEM32(0x3DC460);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F09; /* je: equal / zero */

loc_002D6F02: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6F08u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D6F08: ;
    POP32(esp, ecx);

loc_002D6F09: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6F10
 * Original: 0x002D6F10 - 0x002D6F2A (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6F10(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6F10: ;
    SET_LO8(eax, MEM8(0x3DD8D0));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F29; /* je: equal / zero */

loc_002D6F19: ;
    eax = MEM32(0x3DD8C0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F29; /* je: equal / zero */

loc_002D6F22: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6F28u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D6F28: ;
    POP32(esp, ecx);

loc_002D6F29: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6F30
 * Original: 0x002D6F30 - 0x002D6F4A (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6F30(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6F30: ;
    SET_LO8(eax, MEM8(0x3DD930));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F49; /* je: equal / zero */

loc_002D6F39: ;
    eax = MEM32(0x3DD920);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F49; /* je: equal / zero */

loc_002D6F42: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6F48u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D6F48: ;
    POP32(esp, ecx);

loc_002D6F49: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6F50
 * Original: 0x002D6F50 - 0x002D6F6A (26 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6F50(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6F50: ;
    SET_LO8(eax, MEM8(0x3DE7D0));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F69; /* je: equal / zero */

loc_002D6F59: ;
    eax = MEM32(0x3DE7C0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6F69; /* je: equal / zero */

loc_002D6F62: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D6F68u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D6F68: ;
    POP32(esp, ecx);

loc_002D6F69: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6F70
 * Original: 0x002D6F70 - 0x002D6F7B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6F70(void)
{

loc_002D6F70: ;
    MEM32(0x375E88) = 0x318B18;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6F80
 * Original: 0x002D6F80 - 0x002D6F8B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6F80(void)
{

loc_002D6F80: ;
    MEM32(0x375E8C) = 0x318B18;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6F90
 * Original: 0x002D6F90 - 0x002D6F9B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6F90(void)
{

loc_002D6F90: ;
    MEM32(0x375E90) = 0x318B18;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6FA0
 * Original: 0x002D6FA0 - 0x002D6FA1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6FA0(void)
{

loc_002D6FA0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6FB0
 * Original: 0x002D6FB0 - 0x002D6FB1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6FB0(void)
{

loc_002D6FB0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D6FC0
 * Original: 0x002D6FC0 - 0x002D6FD4 (20 bytes, 4 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6FC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D6FC0: ;
    ecx = 0x3761F0;
    PUSH32(esp, 0x002D6FCAu); RECOMP_ABI_CALL(0x000EE550u, sub_000EE550); /* call 0x000EE550 */

loc_002D6FCA: ;
    ecx = 0x3761C8;
    g_seh_ebp = ebp; sub_000EE550(); return; /* tail jmp 0x000EE550 */

}

/**
 * sub_002D6FE0
 * Original: 0x002D6FE0 - 0x002D6FFF (31 bytes, 14 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D6FE0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D6FE0: ;
    eax = MEM32(0x3DEED8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D6FFE; /* je: equal / zero */

loc_002D6FE9: ;
    edx = MEM32(eax + 4);
    ecx = eax;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edx--;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    MEM32(eax) = edx;
    if (CMP_NE(_fa, _fb)) goto loc_002D6FFE; /* jne: not equal / not zero */

loc_002D6FF8: ;
    eax = MEM32(ecx);
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 1);
    { uint32_t _icall_target = MEM32(eax); PUSH32(esp, 0x002D6FFEu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D6FFCu); } /* indirect call */
    }

loc_002D6FFE: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7000
 * Original: 0x002D7000 - 0x002D700B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7000(void)
{

loc_002D7000: ;
    MEM32(0x376C58) = 0x31ABF8;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7010
 * Original: 0x002D7010 - 0x002D702F (31 bytes, 8 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7010(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7010: ;
    eax = 0x376C58;
    ecx = 8;
    /* nop */

loc_002D7020: ;
    _fb = (uint32_t)(0xA4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - 0xA4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(eax) = 0x31ABF8;
    if ((_fa != 0)) goto loc_002D7020; /* jne: not equal / not zero */

loc_002D702E: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7030
 * Original: 0x002D7030 - 0x002D703A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7030(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7030: ;
    ecx = 0x3E8B60;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D7040
 * Original: 0x002D7040 - 0x002D704A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7040(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7040: ;
    ecx = 0x3E8B90;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D7050
 * Original: 0x002D7050 - 0x002D705A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7050(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7050: ;
    ecx = 0x3E8BC0;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D7060
 * Original: 0x002D7060 - 0x002D706A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7060(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7060: ;
    ecx = 0x3E8BF0;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D7070
 * Original: 0x002D7070 - 0x002D707A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7070(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7070: ;
    ecx = 0x3E8C40;
    g_seh_ebp = ebp; sub_00132B00(); return; /* tail jmp 0x00132B00 */

}

/**
 * sub_002D7080
 * Original: 0x002D7080 - 0x002D709F (31 bytes, 5 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7080(void)
{

loc_002D7080: ;
    ecx = 0x376D40;
    MEM32(0x376D30) = 0x31B6FC;
    PUSH32(esp, 0x002D7094u); RECOMP_ABI_CALL(0x000EF420u, sub_000EF420); /* call 0x000EF420 */

loc_002D7094: ;
    MEM32(0x376D30) = 0x316ED8;
    esp += 4; return; /* ret */

}

/**
 * sub_002D70A0
 * Original: 0x002D70A0 - 0x002D70F4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D70A0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D70A0: ;
    eax = MEM32(0x3F2DFC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D70E3; /* je: equal / zero */

loc_002D70A9: ;
    eax = MEM32(0x3F2DF8);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x3F2DF8;
    PUSH32(esp, 0x002D70BCu); RECOMP_ABI_CALL(0x0013D580u, sub_0013D580); /* call 0x0013D580 */

loc_002D70BC: ;
    eax = MEM32(0x3F2DF8);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x3F2DF8);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x3F2DF8);
    MEM32(eax + 0xC) = eax;
    MEM32(0x3F2DFC) = 0;

loc_002D70E3: ;
    eax = MEM32(0x3F2DF8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D70F3; /* je: equal / zero */

loc_002D70EC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D70F2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D70F2: ;
    POP32(esp, ecx);

loc_002D70F3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7100
 * Original: 0x002D7100 - 0x002D710B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7100(void)
{

loc_002D7100: ;
    MEM32(0x376DDC) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7110
 * Original: 0x002D7110 - 0x002D711B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7110(void)
{

loc_002D7110: ;
    MEM32(0x376DE4) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7120
 * Original: 0x002D7120 - 0x002D712B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7120(void)
{

loc_002D7120: ;
    MEM32(0x376DEC) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7130
 * Original: 0x002D7130 - 0x002D713B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7130(void)
{

loc_002D7130: ;
    MEM32(0x376DF4) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7140
 * Original: 0x002D7140 - 0x002D714B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7140(void)
{

loc_002D7140: ;
    MEM32(0x376DFC) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7150
 * Original: 0x002D7150 - 0x002D715B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7150(void)
{

loc_002D7150: ;
    MEM32(0x376E04) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7160
 * Original: 0x002D7160 - 0x002D716B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7160(void)
{

loc_002D7160: ;
    MEM32(0x376E0C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7170
 * Original: 0x002D7170 - 0x002D717B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7170(void)
{

loc_002D7170: ;
    MEM32(0x376E14) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7180
 * Original: 0x002D7180 - 0x002D718B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7180(void)
{

loc_002D7180: ;
    MEM32(0x376E1C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7190
 * Original: 0x002D7190 - 0x002D719B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7190(void)
{

loc_002D7190: ;
    MEM32(0x376E24) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D71A0
 * Original: 0x002D71A0 - 0x002D71AB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D71A0(void)
{

loc_002D71A0: ;
    MEM32(0x376E2C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D71B0
 * Original: 0x002D71B0 - 0x002D71BB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D71B0(void)
{

loc_002D71B0: ;
    MEM32(0x376E34) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D71C0
 * Original: 0x002D71C0 - 0x002D71CB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D71C0(void)
{

loc_002D71C0: ;
    MEM32(0x376E3C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D71D0
 * Original: 0x002D71D0 - 0x002D71DB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D71D0(void)
{

loc_002D71D0: ;
    MEM32(0x376E44) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D71E0
 * Original: 0x002D71E0 - 0x002D71EB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D71E0(void)
{

loc_002D71E0: ;
    MEM32(0x376E4C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D71F0
 * Original: 0x002D71F0 - 0x002D71FB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D71F0(void)
{

loc_002D71F0: ;
    MEM32(0x376E54) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7200
 * Original: 0x002D7200 - 0x002D720B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7200(void)
{

loc_002D7200: ;
    MEM32(0x376E5C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7210
 * Original: 0x002D7210 - 0x002D721B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7210(void)
{

loc_002D7210: ;
    MEM32(0x376E64) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7220
 * Original: 0x002D7220 - 0x002D722B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7220(void)
{

loc_002D7220: ;
    MEM32(0x376E6C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7230
 * Original: 0x002D7230 - 0x002D723B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7230(void)
{

loc_002D7230: ;
    MEM32(0x376E74) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7240
 * Original: 0x002D7240 - 0x002D724B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7240(void)
{

loc_002D7240: ;
    MEM32(0x376E7C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7250
 * Original: 0x002D7250 - 0x002D725B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7250(void)
{

loc_002D7250: ;
    MEM32(0x376E84) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7260
 * Original: 0x002D7260 - 0x002D726B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7260(void)
{

loc_002D7260: ;
    MEM32(0x376E8C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7270
 * Original: 0x002D7270 - 0x002D727B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7270(void)
{

loc_002D7270: ;
    MEM32(0x376E94) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7280
 * Original: 0x002D7280 - 0x002D728B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7280(void)
{

loc_002D7280: ;
    MEM32(0x376E9C) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7290
 * Original: 0x002D7290 - 0x002D729B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7290(void)
{

loc_002D7290: ;
    MEM32(0x376EA4) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D72A0
 * Original: 0x002D72A0 - 0x002D72AB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D72A0(void)
{

loc_002D72A0: ;
    MEM32(0x376EAC) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D72B0
 * Original: 0x002D72B0 - 0x002D72BB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D72B0(void)
{

loc_002D72B0: ;
    MEM32(0x376EB4) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D72C0
 * Original: 0x002D72C0 - 0x002D72CB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D72C0(void)
{

loc_002D72C0: ;
    MEM32(0x376EBC) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D72D0
 * Original: 0x002D72D0 - 0x002D72DB (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D72D0(void)
{

loc_002D72D0: ;
    MEM32(0x376EC4) = 0x31BF2C;
    esp += 4; return; /* ret */

}

/**
 * sub_002D72E0
 * Original: 0x002D72E0 - 0x002D72F1 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D72E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D72E0: ;
    eax = MEM32(0x3F2E20);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D72F0; /* je: equal / zero */

loc_002D72E9: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D72EFu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D72EF: ;
    POP32(esp, ecx);

loc_002D72F0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7300
 * Original: 0x002D7300 - 0x002D7311 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7300(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7300: ;
    eax = MEM32(0x3F2E30);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7310; /* je: equal / zero */

loc_002D7309: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D730Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D730F: ;
    POP32(esp, ecx);

loc_002D7310: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7320
 * Original: 0x002D7320 - 0x002D7331 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7320(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7320: ;
    eax = MEM32(0x3F2E40);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7330; /* je: equal / zero */

loc_002D7329: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D732Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D732F: ;
    POP32(esp, ecx);

loc_002D7330: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7340
 * Original: 0x002D7340 - 0x002D7351 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7340(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7340: ;
    eax = MEM32(0x3F2E50);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7350; /* je: equal / zero */

loc_002D7349: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D734Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D734F: ;
    POP32(esp, ecx);

loc_002D7350: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7360
 * Original: 0x002D7360 - 0x002D7371 (17 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7360(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7360: ;
    eax = MEM32(0x3F2E60);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7370; /* je: equal / zero */

loc_002D7369: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D736Fu); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D736F: ;
    POP32(esp, ecx);

loc_002D7370: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7380
 * Original: 0x002D7380 - 0x002D738A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7380(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7380: ;
    ecx = 0x3F2E70;
    g_seh_ebp = ebp; sub_0014B3F0(); return; /* tail jmp 0x0014B3F0 */

}

/**
 * sub_002D7390
 * Original: 0x002D7390 - 0x002D739A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7390(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7390: ;
    ecx = 0x3F32B8;
    g_seh_ebp = ebp; sub_001AE740(); return; /* tail jmp 0x001AE740 */

}

/**
 * sub_002D73A0
 * Original: 0x002D73A0 - 0x002D73A1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D73A0(void)
{

loc_002D73A0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D73B0
 * Original: 0x002D73B0 - 0x002D73CD (29 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D73B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D73B0: ;
    eax = 0x3F49D0;
    ecx = 3;
    /* nop */

loc_002D73C0: ;
    _fb = (uint32_t)(0x60) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - 0x60;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(eax) = 0x2FF9D4;
    if ((_fa != 0)) goto loc_002D73C0; /* jne: not equal / not zero */

loc_002D73CC: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D73D0
 * Original: 0x002D73D0 - 0x002D7436 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D73D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D73D0: ;
    eax = MEM32(0x377420);
    edx = 0x37741C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D73FE; /* je: equal / zero */

loc_002D73DE: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D73E0: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x377418);
    MEM32(eax + 4) = esi;
    MEM32(0x377418) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D73E0; /* jne: not equal / not zero */

loc_002D73FD: ;
    POP32(esp, esi);

loc_002D73FE: ;
    SET_LO8(eax, MEM8(0x377428));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x377420) = edx;
    MEM32(0x37741C) = edx;
    MEM32(0x37740C) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D742B; /* je: equal / zero */

loc_002D741D: ;
    eax = MEM32(0x377414);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7428u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7428: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D742B: ;
    MEM32(0x377414) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7440
 * Original: 0x002D7440 - 0x002D74A6 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7440(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7440: ;
    eax = MEM32(0x377440);
    edx = 0x37743C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D746E; /* je: equal / zero */

loc_002D744E: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D7450: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x377438);
    MEM32(eax + 4) = esi;
    MEM32(0x377438) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D7450; /* jne: not equal / not zero */

loc_002D746D: ;
    POP32(esp, esi);

loc_002D746E: ;
    SET_LO8(eax, MEM8(0x377448));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x377440) = edx;
    MEM32(0x37743C) = edx;
    MEM32(0x37742C) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D749B; /* je: equal / zero */

loc_002D748D: ;
    eax = MEM32(0x377434);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7498u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7498: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D749B: ;
    MEM32(0x377434) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D74B0
 * Original: 0x002D74B0 - 0x002D7516 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D74B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D74B0: ;
    eax = MEM32(0x377460);
    edx = 0x37745C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D74DE; /* je: equal / zero */

loc_002D74BE: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D74C0: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x377458);
    MEM32(eax + 4) = esi;
    MEM32(0x377458) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D74C0; /* jne: not equal / not zero */

loc_002D74DD: ;
    POP32(esp, esi);

loc_002D74DE: ;
    SET_LO8(eax, MEM8(0x377468));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x377460) = edx;
    MEM32(0x37745C) = edx;
    MEM32(0x37744C) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D750B; /* je: equal / zero */

loc_002D74FD: ;
    eax = MEM32(0x377454);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7508u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7508: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D750B: ;
    MEM32(0x377454) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7520
 * Original: 0x002D7520 - 0x002D7586 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7520(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7520: ;
    eax = MEM32(0x377480);
    edx = 0x37747C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D754E; /* je: equal / zero */

loc_002D752E: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D7530: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x377478);
    MEM32(eax + 4) = esi;
    MEM32(0x377478) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D7530; /* jne: not equal / not zero */

loc_002D754D: ;
    POP32(esp, esi);

loc_002D754E: ;
    SET_LO8(eax, MEM8(0x377488));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x377480) = edx;
    MEM32(0x37747C) = edx;
    MEM32(0x37746C) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D757B; /* je: equal / zero */

loc_002D756D: ;
    eax = MEM32(0x377474);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7578u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7578: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D757B: ;
    MEM32(0x377474) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7590
 * Original: 0x002D7590 - 0x002D75F6 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7590(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7590: ;
    eax = MEM32(0x3774A0);
    edx = 0x37749C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D75BE; /* je: equal / zero */

loc_002D759E: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D75A0: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x377498);
    MEM32(eax + 4) = esi;
    MEM32(0x377498) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D75A0; /* jne: not equal / not zero */

loc_002D75BD: ;
    POP32(esp, esi);

loc_002D75BE: ;
    SET_LO8(eax, MEM8(0x3774A8));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x3774A0) = edx;
    MEM32(0x37749C) = edx;
    MEM32(0x37748C) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D75EB; /* je: equal / zero */

loc_002D75DD: ;
    eax = MEM32(0x377494);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D75E8u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D75E8: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D75EB: ;
    MEM32(0x377494) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7600
 * Original: 0x002D7600 - 0x002D7666 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7600(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7600: ;
    eax = MEM32(0x3774C0);
    edx = 0x3774BC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D762E; /* je: equal / zero */

loc_002D760E: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D7610: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x3774B8);
    MEM32(eax + 4) = esi;
    MEM32(0x3774B8) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D7610; /* jne: not equal / not zero */

loc_002D762D: ;
    POP32(esp, esi);

loc_002D762E: ;
    SET_LO8(eax, MEM8(0x3774C8));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x3774C0) = edx;
    MEM32(0x3774BC) = edx;
    MEM32(0x3774AC) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D765B; /* je: equal / zero */

loc_002D764D: ;
    eax = MEM32(0x3774B4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7658u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7658: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D765B: ;
    MEM32(0x3774B4) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7670
 * Original: 0x002D7670 - 0x002D76A6 (54 bytes, 12 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7670(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7670: ;
    ecx = 0x3F4830;
    PUSH32(esp, 0x002D767Au); RECOMP_ABI_CALL(0x001466E0u, sub_001466E0); /* call 0x001466E0 */

loc_002D767A: ;
    SET_LO8(eax, MEM8(0x3F48A0));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7691; /* je: equal / zero */

loc_002D7683: ;
    eax = MEM32(0x3F4838);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D768Eu); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D768E: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D7691: ;
    MEM32(0x3F4838) = 0;
    MEM32(0x3F4848) = 0x2FF9D4;
    esp += 4; return; /* ret */

}

/**
 * sub_002D76B0
 * Original: 0x002D76B0 - 0x002D76BA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D76B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D76B0: ;
    ecx = 0x3F3178;
    g_seh_ebp = ebp; sub_00146F70(); return; /* tail jmp 0x00146F70 */

}

/**
 * sub_002D76C0
 * Original: 0x002D76C0 - 0x002D76CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D76C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D76C0: ;
    ecx = 0x3F31F0;
    g_seh_ebp = ebp; sub_00146F00(); return; /* tail jmp 0x00146F00 */

}

/**
 * sub_002D76D0
 * Original: 0x002D76D0 - 0x002D76DA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D76D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D76D0: ;
    ecx = 0x4F4EA8;
    g_seh_ebp = ebp; sub_00140760(); return; /* tail jmp 0x00140760 */

}

/**
 * sub_002D76E0
 * Original: 0x002D76E0 - 0x002D76EA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D76E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D76E0: ;
    ecx = 0x4F52D0;
    g_seh_ebp = ebp; sub_0014ADE0(); return; /* tail jmp 0x0014ADE0 */

}

/**
 * sub_002D76F0
 * Original: 0x002D76F0 - 0x002D76FB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D76F0(void)
{

loc_002D76F0: ;
    MEM32(0x377510) = 0x2FF9D4;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7700
 * Original: 0x002D7700 - 0x002D770B (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7700(void)
{

loc_002D7700: ;
    MEM32(0x37755C) = 0x31A9D8;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7710
 * Original: 0x002D7710 - 0x002D771A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7710(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7710: ;
    ecx = 0x4F5DD8;
    g_seh_ebp = ebp; sub_001AE740(); return; /* tail jmp 0x001AE740 */

}

/**
 * sub_002D7720
 * Original: 0x002D7720 - 0x002D7721 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7720(void)
{

loc_002D7720: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7730
 * Original: 0x002D7730 - 0x002D7784 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7730(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7730: ;
    eax = MEM32(0x4F7288);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7773; /* je: equal / zero */

loc_002D7739: ;
    eax = MEM32(0x4F7284);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x4F7284;
    PUSH32(esp, 0x002D774Cu); RECOMP_ABI_CALL(0x0014BCC0u, sub_0014BCC0); /* call 0x0014BCC0 */

loc_002D774C: ;
    eax = MEM32(0x4F7284);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x4F7284);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x4F7284);
    MEM32(eax + 0xC) = eax;
    MEM32(0x4F7288) = 0;

loc_002D7773: ;
    eax = MEM32(0x4F7284);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7783; /* je: equal / zero */

loc_002D777C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7782u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D7782: ;
    POP32(esp, ecx);

loc_002D7783: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7790
 * Original: 0x002D7790 - 0x002D779A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7790(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7790: ;
    ecx = 0x4F72C0;
    g_seh_ebp = ebp; sub_00012A00(); return; /* tail jmp 0x00012A00 */

}

/**
 * sub_002D77A0
 * Original: 0x002D77A0 - 0x002D77F4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D77A0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D77A0: ;
    eax = MEM32(0x4F72B8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D77E3; /* je: equal / zero */

loc_002D77A9: ;
    eax = MEM32(0x4F72B4);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x4F72B4;
    PUSH32(esp, 0x002D77BCu); RECOMP_ABI_CALL(0x0014F140u, sub_0014F140); /* call 0x0014F140 */

loc_002D77BC: ;
    eax = MEM32(0x4F72B4);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x4F72B4);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x4F72B4);
    MEM32(eax + 0xC) = eax;
    MEM32(0x4F72B8) = 0;

loc_002D77E3: ;
    eax = MEM32(0x4F72B4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D77F3; /* je: equal / zero */

loc_002D77EC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D77F2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D77F2: ;
    POP32(esp, ecx);

loc_002D77F3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7800
 * Original: 0x002D7800 - 0x002D7854 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7800(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7800: ;
    eax = MEM32(0x4F73F8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7843; /* je: equal / zero */

loc_002D7809: ;
    eax = MEM32(0x4F73F4);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x4F73F4;
    PUSH32(esp, 0x002D781Cu); RECOMP_ABI_CALL(0x00150C40u, sub_00150C40); /* call 0x00150C40 */

loc_002D781C: ;
    eax = MEM32(0x4F73F4);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x4F73F4);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x4F73F4);
    MEM32(eax + 0xC) = eax;
    MEM32(0x4F73F8) = 0;

loc_002D7843: ;
    eax = MEM32(0x4F73F4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7853; /* je: equal / zero */

loc_002D784C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7852u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D7852: ;
    POP32(esp, ecx);

loc_002D7853: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7860
 * Original: 0x002D7860 - 0x002D786A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7860(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7860: ;
    ecx = 0x4F7400;
    g_seh_ebp = ebp; sub_00150DA0(); return; /* tail jmp 0x00150DA0 */

}

/**
 * sub_002D7870
 * Original: 0x002D7870 - 0x002D78C4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7870(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7870: ;
    eax = MEM32(0x4F7430);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D78B3; /* je: equal / zero */

loc_002D7879: ;
    eax = MEM32(0x4F742C);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x4F742C;
    PUSH32(esp, 0x002D788Cu); RECOMP_ABI_CALL(0x00151B80u, sub_00151B80); /* call 0x00151B80 */

loc_002D788C: ;
    eax = MEM32(0x4F742C);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x4F742C);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x4F742C);
    MEM32(eax + 0xC) = eax;
    MEM32(0x4F7430) = 0;

loc_002D78B3: ;
    eax = MEM32(0x4F742C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D78C3; /* je: equal / zero */

loc_002D78BC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D78C2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D78C2: ;
    POP32(esp, ecx);

loc_002D78C3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D78D0
 * Original: 0x002D78D0 - 0x002D7924 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D78D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D78D0: ;
    eax = MEM32(0x4F743C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7913; /* je: equal / zero */

loc_002D78D9: ;
    eax = MEM32(0x4F7438);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x4F7438;
    PUSH32(esp, 0x002D78ECu); RECOMP_ABI_CALL(0x00151BC0u, sub_00151BC0); /* call 0x00151BC0 */

loc_002D78EC: ;
    eax = MEM32(0x4F7438);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x4F7438);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x4F7438);
    MEM32(eax + 0xC) = eax;
    MEM32(0x4F743C) = 0;

loc_002D7913: ;
    eax = MEM32(0x4F7438);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7923; /* je: equal / zero */

loc_002D791C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7922u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D7922: ;
    POP32(esp, ecx);

loc_002D7923: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7930
 * Original: 0x002D7930 - 0x002D7935 (5 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7930(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7930: ;
    g_seh_ebp = ebp; sub_001BA436(); return; /* tail jmp 0x001BA436 */

}

/**
 * sub_002D7940
 * Original: 0x002D7940 - 0x002D7960 (32 bytes, 13 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7940(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7940: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    esi = 0x4F74DC;
    edi = 5;
    /* nop */

loc_002D7950: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esi = esi - 0x1C;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    ecx = esi;
    PUSH32(esp, 0x002D795Au); RECOMP_ABI_CALL(0x00155470u, sub_00155470); /* call 0x00155470 */

loc_002D795A: ;
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002D7950; /* jne: not equal / not zero */

loc_002D795D: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D7960
 * Original: 0x002D7960 - 0x002D79B4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7960(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7960: ;
    eax = MEM32(0x4F74E8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D79A3; /* je: equal / zero */

loc_002D7969: ;
    eax = MEM32(0x4F74E4);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x4F74E4;
    PUSH32(esp, 0x002D797Cu); RECOMP_ABI_CALL(0x00153660u, sub_00153660); /* call 0x00153660 */

loc_002D797C: ;
    eax = MEM32(0x4F74E4);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x4F74E4);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x4F74E4);
    MEM32(eax + 0xC) = eax;
    MEM32(0x4F74E8) = 0;

loc_002D79A3: ;
    eax = MEM32(0x4F74E4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D79B3; /* je: equal / zero */

loc_002D79AC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D79B2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D79B2: ;
    POP32(esp, ecx);

loc_002D79B3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D79C0
 * Original: 0x002D79C0 - 0x002D79C1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D79C0(void)
{

loc_002D79C0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D79D0
 * Original: 0x002D79D0 - 0x002D7A24 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D79D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D79D0: ;
    eax = MEM32(0x51D670);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7A13; /* je: equal / zero */

loc_002D79D9: ;
    eax = MEM32(0x51D66C);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x51D66C;
    PUSH32(esp, 0x002D79ECu); RECOMP_ABI_CALL(0x00159C00u, sub_00159C00); /* call 0x00159C00 */

loc_002D79EC: ;
    eax = MEM32(0x51D66C);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x51D66C);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x51D66C);
    MEM32(eax + 0xC) = eax;
    MEM32(0x51D670) = 0;

loc_002D7A13: ;
    eax = MEM32(0x51D66C);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7A23; /* je: equal / zero */

loc_002D7A1C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7A22u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D7A22: ;
    POP32(esp, ecx);

loc_002D7A23: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7A30
 * Original: 0x002D7A30 - 0x002D7A31 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7A30(void)
{

loc_002D7A30: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7A40
 * Original: 0x002D7A40 - 0x002D7AA6 (102 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7A40(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7A40: ;
    eax = MEM32(0x3785DC);
    edx = 0x3785D8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7A6E; /* je: equal / zero */

loc_002D7A4E: ;
    PUSH32(esp, esi);
    /* nop */

loc_002D7A50: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    MEM32(eax) = 0;
    esi = MEM32(0x3785D4);
    MEM32(eax + 4) = esi;
    MEM32(0x3785D4) = eax;
    eax = ecx;
    if (CMP_NE(_fa, _fb)) goto loc_002D7A50; /* jne: not equal / not zero */

loc_002D7A6D: ;
    POP32(esp, esi);

loc_002D7A6E: ;
    SET_LO8(eax, MEM8(0x378624));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(0x3785DC) = edx;
    MEM32(0x3785D8) = edx;
    MEM32(0x3785C8) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D7A9B; /* je: equal / zero */

loc_002D7A8D: ;
    eax = MEM32(0x3785D0);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7A98u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7A98: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D7A9B: ;
    MEM32(0x3785D0) = 0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7AB0
 * Original: 0x002D7AB0 - 0x002D7ABB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7AB0(void)
{

loc_002D7AB0: ;
    MEM32(0x3786B0) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7AC0
 * Original: 0x002D7AC0 - 0x002D7ACB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7AC0(void)
{

loc_002D7AC0: ;
    MEM32(0x3786E0) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7AD0
 * Original: 0x002D7AD0 - 0x002D7ADB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7AD0(void)
{

loc_002D7AD0: ;
    MEM32(0x378708) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7AE0
 * Original: 0x002D7AE0 - 0x002D7AEB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7AE0(void)
{

loc_002D7AE0: ;
    MEM32(0x37872C) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7AF0
 * Original: 0x002D7AF0 - 0x002D7AFB (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7AF0(void)
{

loc_002D7AF0: ;
    MEM32(0x378754) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7B00
 * Original: 0x002D7B00 - 0x002D7B0B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7B00(void)
{

loc_002D7B00: ;
    MEM32(0x37877C) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7B10
 * Original: 0x002D7B10 - 0x002D7B1B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7B10(void)
{

loc_002D7B10: ;
    MEM32(0x3787AC) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7B20
 * Original: 0x002D7B20 - 0x002D7B2B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7B20(void)
{

loc_002D7B20: ;
    MEM32(0x3787DC) = 0x31FC00;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7B30
 * Original: 0x002D7B30 - 0x002D7B84 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7B30(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7B30: ;
    eax = MEM32(0x51FAC4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7B73; /* je: equal / zero */

loc_002D7B39: ;
    eax = MEM32(0x51FAC0);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x51FAC0;
    PUSH32(esp, 0x002D7B4Cu); RECOMP_ABI_CALL(0x00170D60u, sub_00170D60); /* call 0x00170D60 */

loc_002D7B4C: ;
    eax = MEM32(0x51FAC0);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x51FAC0);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x51FAC0);
    MEM32(eax + 0xC) = eax;
    MEM32(0x51FAC4) = 0;

loc_002D7B73: ;
    eax = MEM32(0x51FAC0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7B83; /* je: equal / zero */

loc_002D7B7C: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7B82u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D7B82: ;
    POP32(esp, ecx);

loc_002D7B83: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7B90
 * Original: 0x002D7B90 - 0x002D7BE4 (84 bytes, 22 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7B90(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7B90: ;
    eax = MEM32(0x51FAD0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7BD3; /* je: equal / zero */

loc_002D7B99: ;
    eax = MEM32(0x51FACC);
    ecx = MEM32(eax + 4);
    PUSH32(esp, ecx);
    ecx = 0x51FACC;
    PUSH32(esp, 0x002D7BACu); RECOMP_ABI_CALL(0x00170DA0u, sub_00170DA0); /* call 0x00170DA0 */

loc_002D7BAC: ;
    eax = MEM32(0x51FACC);
    MEM32(eax + 8) = eax;
    edx = MEM32(0x51FACC);
    MEM32(edx + 4) = 0;
    eax = MEM32(0x51FACC);
    MEM32(eax + 0xC) = eax;
    MEM32(0x51FAD0) = 0;

loc_002D7BD3: ;
    eax = MEM32(0x51FACC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7BE3; /* je: equal / zero */

loc_002D7BDC: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7BE2u); RECOMP_ABI_CALL(0x001552D0u, sub_001552D0); /* call 0x001552D0 */

loc_002D7BE2: ;
    POP32(esp, ecx);

loc_002D7BE3: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7BF0
 * Original: 0x002D7BF0 - 0x002D7BF1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7BF0(void)
{

loc_002D7BF0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7C00
 * Original: 0x002D7C00 - 0x002D7C34 (52 bytes, 15 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C00(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7C00: ;
    SET_LO8(eax, MEM8(0x523410));
    PUSH32(esp, ebx);
    ebx = 0; /* xor self */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(LO8(ebx)) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), LO8(ebx) (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7C1A; /* je: equal / zero */

loc_002D7C0C: ;
    eax = MEM32(0x523400);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D7C17u); RECOMP_ABI_CALL(0x001551E0u, sub_001551E0); /* call 0x001551E0 */

loc_002D7C17: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D7C1A: ;
    MEM32(0x523400) = ebx;
    MEM32(0x523404) = ebx;
    MEM32(0x523408) = ebx;
    MEM32(0x52340C) = ebx;
    POP32(esp, ebx);
    esp += 4; return; /* ret */

}

/**
 * sub_002D7C40
 * Original: 0x002D7C40 - 0x002D7C4A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7C40: ;
    ecx = 0x523430;
    g_seh_ebp = ebp; sub_001D0960(); return; /* tail jmp 0x001D0960 */

}

/**
 * sub_002D7C50
 * Original: 0x002D7C50 - 0x002D7C5B (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C50(void)
{

loc_002D7C50: ;
    MEM32(0x3789A4) = 0x2FF0D4;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7C60
 * Original: 0x002D7C60 - 0x002D7C6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7C60: ;
    ecx = 0x523520;
    g_seh_ebp = ebp; sub_000EF420(); return; /* tail jmp 0x000EF420 */

}

/**
 * sub_002D7C70
 * Original: 0x002D7C70 - 0x002D7C7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7C70: ;
    ecx = 0x5235D8;
    g_seh_ebp = ebp; sub_001CE560(); return; /* tail jmp 0x001CE560 */

}

/**
 * sub_002D7C80
 * Original: 0x002D7C80 - 0x002D7C8A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7C80: ;
    ecx = 0x523650;
    g_seh_ebp = ebp; sub_001CF8A0(); return; /* tail jmp 0x001CF8A0 */

}

/**
 * sub_002D7C90
 * Original: 0x002D7C90 - 0x002D7C9A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7C90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7C90: ;
    ecx = 0x5236A0;
    g_seh_ebp = ebp; sub_001D0AE0(); return; /* tail jmp 0x001D0AE0 */

}

/**
 * sub_002D7CA0
 * Original: 0x002D7CA0 - 0x002D7CC0 (32 bytes, 12 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CA0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7CA0: ;
    ecx = MEM32(0x523624);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    PUSH32(esp, esi);
    esi = ecx;
    if (CMP_EQ(_fa, _fb)) goto loc_002D7CBE; /* je: equal / zero */

loc_002D7CAD: ;
    PUSH32(esp, 0x002D7CB2u); RECOMP_ABI_CALL(0x001D2B50u, sub_001D2B50); /* call 0x001D2B50 */

loc_002D7CB2: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0x34);
    PUSH32(esp, esi);
    { uint32_t _icall_target = MEM32(0x37DB6C); PUSH32(esp, 0x002D7CBBu); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002D7CB5u); } /* indirect call */
    }

loc_002D7CBB: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002D7CBE: ;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CC0
 * Original: 0x002D7CC0 - 0x002D7CC1 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CC0(void)
{

loc_002D7CC0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CC1
 * Original: 0x002D7CC1 - 0x002D7CC2 (1 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CC1(void)
{

loc_002D7CC1: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CC2
 * Original: 0x002D7CC2 - 0x002D7CCD (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CC2(void)
{

loc_002D7CC2: ;
    MEM32(0x5250B8) = 0x335514;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CCD
 * Original: 0x002D7CCD - 0x002D7CD8 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CCD(void)
{

loc_002D7CCD: ;
    MEM32(0x524BD8) = 0x335538;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CD8
 * Original: 0x002D7CD8 - 0x002D7CE3 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CD8(void)
{

loc_002D7CD8: ;
    MEM32(0x5255D8) = 0x335538;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CE3
 * Original: 0x002D7CE3 - 0x002D7CEE (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CE3(void)
{

loc_002D7CE3: ;
    MEM32(0x525140) = 0x335538;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7CF0
 * Original: 0x002D7CF0 - 0x002D7CFA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7CF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7CF0: ;
    ecx = 0x5286AC;
    g_seh_ebp = ebp; sub_001C1640(); return; /* tail jmp 0x001C1640 */

}

/**
 * sub_002D7D00
 * Original: 0x002D7D00 - 0x002D7D0A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7D00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7D00: ;
    ecx = 0x5286E8;
    g_seh_ebp = ebp; sub_001D2E10(); return; /* tail jmp 0x001D2E10 */

}

/**
 * sub_002D7D10
 * Original: 0x002D7D10 - 0x002D7D1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7D10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7D10: ;
    ecx = 0x5286C0;
    g_seh_ebp = ebp; sub_001D2CD0(); return; /* tail jmp 0x001D2CD0 */

}

/**
 * sub_002D7D20
 * Original: 0x002D7D20 - 0x002D7D2A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7D20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7D20: ;
    ecx = 0x528A68;
    g_seh_ebp = ebp; sub_001CF8A0(); return; /* tail jmp 0x001CF8A0 */

}

/**
 * sub_002D7D30
 * Original: 0x002D7D30 - 0x002D7D90 (96 bytes, 29 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7D30(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D7D30: ;
    SET_LO8(eax, MEM8(0x528ED8));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7D7D; /* je: equal / zero */

loc_002D7D39: ;
    PUSH32(esp, esi);
    { uint64_t _tsc = xbox_ReadTimeStampCounter();
      eax = (uint32_t)_tsc; edx = (uint32_t)(_tsc >> 32); }  /* rdtsc */
    ecx = MEM32(0x528EC8);
    edx = MEM32(0x528ED4);
    esi = MEM32(ecx + 0x110);
    _fb = (uint32_t)(edx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - edx;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fb = (uint32_t)(eax) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ecx + 0x110) = esi;
    eax = MEM32(0x528ECC);
    ecx = eax + 0x10;
    MEM8(0x528ED8) = 0;
    _fa = (uint32_t)(MEM8(ecx)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp MEM8(ecx), 0 (8-bit) */
    esi = eax;
    if (CMP_NE(_fa, _fb)) goto loc_002D7D7B; /* jne: not equal / not zero */

loc_002D7D6E: ;
    MEM32(0x37F0FC) = eax;
    { uint64_t _tsc = xbox_ReadTimeStampCounter();
      eax = (uint32_t)_tsc; edx = (uint32_t)(_tsc >> 32); }  /* rdtsc */
    MEM32(esi + 0xC) = eax;
    MEM8(ecx) = 1;

loc_002D7D7B: ;
    POP32(esp, esi);

loc_002D7D7C: ;
    esp += 4; return; /* ret */

loc_002D7D7D: ;
    eax = MEM32(0x528ED0);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D7D7C; /* je: equal / zero */

loc_002D7D86: ;
    ecx = MEM32(0x528ECC);
    MEM32(eax + 4) = ecx;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7D90
 * Original: 0x002D7D90 - 0x002D7D9A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7D90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7D90: ;
    ecx = 0x528DA0;
    g_seh_ebp = ebp; sub_001D5190(); return; /* tail jmp 0x001D5190 */

}

/**
 * sub_002D7DA0
 * Original: 0x002D7DA0 - 0x002D7DAA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7DA0: ;
    ecx = 0x528EE0;
    g_seh_ebp = ebp; sub_001D5190(); return; /* tail jmp 0x001D5190 */

}

/**
 * sub_002D7DB0
 * Original: 0x002D7DB0 - 0x002D7DBA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7DB0: ;
    ecx = 0x529C80;
    g_seh_ebp = ebp; sub_001D2B50(); return; /* tail jmp 0x001D2B50 */

}

/**
 * sub_002D7DC0
 * Original: 0x002D7DC0 - 0x002D7DCA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7DC0: ;
    ecx = 0x529CB4;
    g_seh_ebp = ebp; sub_001D2B50(); return; /* tail jmp 0x001D2B50 */

}

/**
 * sub_002D7DD0
 * Original: 0x002D7DD0 - 0x002D7DDA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DD0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7DD0: ;
    ecx = 0x529CE8;
    g_seh_ebp = ebp; sub_001D2B50(); return; /* tail jmp 0x001D2B50 */

}

/**
 * sub_002D7DE0
 * Original: 0x002D7DE0 - 0x002D7DEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7DE0: ;
    ecx = 0x529D1C;
    g_seh_ebp = ebp; sub_001D2B50(); return; /* tail jmp 0x001D2B50 */

}

/**
 * sub_002D7DEA
 * Original: 0x002D7DEA - 0x002D7DF5 (11 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DEA(void)
{

loc_002D7DEA: ;
    MEM32(0x37FC18) = 0x3390F0;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7DF5
 * Original: 0x002D7DF5 - 0x002D7E00 (11 bytes, 2 insns)
 * Category: game_vtable
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7DF5(void)
{

loc_002D7DF5: ;
    MEM32(0x37FC28) = 0x31A9D8;
    esp += 4; return; /* ret */

}

/**
 * sub_002D7E00
 * Original: 0x002D7E00 - 0x002D7E0A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E00: ;
    ecx = 0x530EBC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E10
 * Original: 0x002D7E10 - 0x002D7E1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E10: ;
    ecx = 0x530F18;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E20
 * Original: 0x002D7E20 - 0x002D7E2A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E20: ;
    ecx = 0x530F4C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E30
 * Original: 0x002D7E30 - 0x002D7E3A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E30: ;
    ecx = 0x530F80;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E40
 * Original: 0x002D7E40 - 0x002D7E4A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E40: ;
    ecx = 0x530FB4;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E50
 * Original: 0x002D7E50 - 0x002D7E5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E50: ;
    ecx = 0x530FE8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E60
 * Original: 0x002D7E60 - 0x002D7E6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E60: ;
    ecx = 0x53101C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E70
 * Original: 0x002D7E70 - 0x002D7E7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E70: ;
    ecx = 0x531050;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E80
 * Original: 0x002D7E80 - 0x002D7E8A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E80: ;
    ecx = 0x531084;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7E90
 * Original: 0x002D7E90 - 0x002D7E9A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7E90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7E90: ;
    ecx = 0x5310B8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7EA0
 * Original: 0x002D7EA0 - 0x002D7EAA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7EA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7EA0: ;
    ecx = 0x5310EC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7EB0
 * Original: 0x002D7EB0 - 0x002D7EBA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7EB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7EB0: ;
    ecx = 0x531120;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7EC0
 * Original: 0x002D7EC0 - 0x002D7ECA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7EC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7EC0: ;
    ecx = 0x531154;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7ED0
 * Original: 0x002D7ED0 - 0x002D7EDA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7ED0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7ED0: ;
    ecx = 0x531188;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7EE0
 * Original: 0x002D7EE0 - 0x002D7EEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7EE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7EE0: ;
    ecx = 0x5311BC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7EF0
 * Original: 0x002D7EF0 - 0x002D7EFA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7EF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7EF0: ;
    ecx = 0x5311F0;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F00
 * Original: 0x002D7F00 - 0x002D7F0A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F00: ;
    ecx = 0x531224;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F10
 * Original: 0x002D7F10 - 0x002D7F1A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F10(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F10: ;
    ecx = 0x531258;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F20
 * Original: 0x002D7F20 - 0x002D7F2A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F20: ;
    ecx = 0x531290;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F30
 * Original: 0x002D7F30 - 0x002D7F3A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F30(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F30: ;
    ecx = 0x5312A4;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F40
 * Original: 0x002D7F40 - 0x002D7F4A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F40: ;
    ecx = 0x5312D8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F50
 * Original: 0x002D7F50 - 0x002D7F5A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F50(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F50: ;
    ecx = 0x53130C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F60
 * Original: 0x002D7F60 - 0x002D7F6A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F60(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F60: ;
    ecx = 0x531340;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F70
 * Original: 0x002D7F70 - 0x002D7F7A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F70: ;
    ecx = 0x531374;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F80
 * Original: 0x002D7F80 - 0x002D7F8A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F80: ;
    ecx = 0x5313A8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7F90
 * Original: 0x002D7F90 - 0x002D7F9A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7F90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7F90: ;
    ecx = 0x5313DC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7FA0
 * Original: 0x002D7FA0 - 0x002D7FAA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7FA0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7FA0: ;
    ecx = 0x531410;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7FB0
 * Original: 0x002D7FB0 - 0x002D7FBA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7FB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7FB0: ;
    ecx = 0x531444;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7FC0
 * Original: 0x002D7FC0 - 0x002D7FCA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7FC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7FC0: ;
    ecx = 0x531478;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7FD0
 * Original: 0x002D7FD0 - 0x002D7FDA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7FD0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7FD0: ;
    ecx = 0x5314AC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7FE0
 * Original: 0x002D7FE0 - 0x002D7FEA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7FE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7FE0: ;
    ecx = 0x5314B4;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D7FF0
 * Original: 0x002D7FF0 - 0x002D7FFA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D7FF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D7FF0: ;
    ecx = 0x5314E8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8000
 * Original: 0x002D8000 - 0x002D800A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8000(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8000: ;
    ecx = 0x53151C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8010
 * Original: 0x002D8010 - 0x002D801A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8010(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8010: ;
    ecx = 0x531550;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8020
 * Original: 0x002D8020 - 0x002D802A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8020(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8020: ;
    ecx = 0x531588;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8030
 * Original: 0x002D8030 - 0x002D803A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8030(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8030: ;
    ecx = 0x5315BC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8040
 * Original: 0x002D8040 - 0x002D804A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8040(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8040: ;
    ecx = 0x5315F0;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8050
 * Original: 0x002D8050 - 0x002D805A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8050(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8050: ;
    ecx = 0x531624;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8060
 * Original: 0x002D8060 - 0x002D806A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8060(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8060: ;
    ecx = 0x532B60;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8070
 * Original: 0x002D8070 - 0x002D807A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8070(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8070: ;
    ecx = 0x532B9C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8080
 * Original: 0x002D8080 - 0x002D808A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8080(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8080: ;
    ecx = 0x532BD0;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8090
 * Original: 0x002D8090 - 0x002D809A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8090(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8090: ;
    ecx = 0x532C04;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D80A0
 * Original: 0x002D80A0 - 0x002D80AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D80A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D80A0: ;
    ecx = 0x532C38;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D80B0
 * Original: 0x002D80B0 - 0x002D80BA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D80B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D80B0: ;
    ecx = 0x532C6C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D80C0
 * Original: 0x002D80C0 - 0x002D80CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D80C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D80C0: ;
    ecx = 0x532CA0;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D80D0
 * Original: 0x002D80D0 - 0x002D80DA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D80D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D80D0: ;
    ecx = 0x532CD4;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D80E0
 * Original: 0x002D80E0 - 0x002D80EA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D80E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D80E0: ;
    ecx = 0x532D08;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D80F0
 * Original: 0x002D80F0 - 0x002D80FA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D80F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D80F0: ;
    ecx = 0x532D3C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8100
 * Original: 0x002D8100 - 0x002D810A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8100(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8100: ;
    ecx = 0x532D70;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8110
 * Original: 0x002D8110 - 0x002D811A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8110(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8110: ;
    ecx = 0x532DA4;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8120
 * Original: 0x002D8120 - 0x002D812A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8120(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8120: ;
    ecx = 0x532DD8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8130
 * Original: 0x002D8130 - 0x002D813A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8130(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8130: ;
    ecx = 0x532E0C;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8140
 * Original: 0x002D8140 - 0x002D814A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8140(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8140: ;
    ecx = 0x532E40;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8150
 * Original: 0x002D8150 - 0x002D815A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8150(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8150: ;
    ecx = 0x532E74;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8160
 * Original: 0x002D8160 - 0x002D816A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8160(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8160: ;
    ecx = 0x532EA8;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8170
 * Original: 0x002D8170 - 0x002D817A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8170(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8170: ;
    ecx = 0x532EDC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8180
 * Original: 0x002D8180 - 0x002D818A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8180(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8180: ;
    ecx = 0x532F10;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8190
 * Original: 0x002D8190 - 0x002D819A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8190(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8190: ;
    ecx = 0x532F44;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D81A0
 * Original: 0x002D81A0 - 0x002D81AA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D81A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D81A0: ;
    ecx = 0x532F78;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D81B0
 * Original: 0x002D81B0 - 0x002D81BA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D81B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D81B0: ;
    ecx = 0x532FAC;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D81C0
 * Original: 0x002D81C0 - 0x002D81CA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D81C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D81C0: ;
    ecx = 0x532FE0;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D81D0
 * Original: 0x002D81D0 - 0x002D81DA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D81D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D81D0: ;
    ecx = 0x533014;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D81E0
 * Original: 0x002D81E0 - 0x002D81EA (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D81E0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D81E0: ;
    ecx = 0x533048;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D81F0
 * Original: 0x002D81F0 - 0x002D8209 (25 bytes, 9 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D81F0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D81F0: ;
    eax = MEM32(0x3830F4);
    MEM16(eax) = MEM16(eax) - 1;
    _fa = (uint32_t)(MEM16(eax)) & 0xFFFFu;
    _fas = (int32_t)(int16_t)(_fa); _fb = (_fa == 0x7FFFu); /* dec result/SF/OF; CF unchanged */
    _fa = (uint32_t)(MEM16(eax)) & 0xFFFFu; _fb = (uint32_t)(0) & 0xFFFFu;
    _fas = (int32_t)(int16_t)(_fa); _fbs = (int32_t)(int16_t)(_fb); /* cmp MEM16(eax), 0 (16-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D8208; /* jne: not equal / not zero */

loc_002D81FE: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, eax);
    eax = MEM32(0x534574);
    { uint32_t _icall_target = MEM32(eax + 4); PUSH32(esp, 0x002D8207u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D8204u); } /* indirect call */
    }

loc_002D8207: ;
    POP32(esp, ecx);

loc_002D8208: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D8210
 * Original: 0x002D8210 - 0x002D821A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8210(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8210: ;
    ecx = 0x534578;
    g_seh_ebp = ebp; sub_00284210(); return; /* tail jmp 0x00284210 */

}

/**
 * sub_002D8220
 * Original: 0x002D8220 - 0x002D8237 (23 bytes, 6 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8220(void)
{

loc_002D8220: ;
    PUSH32(esp, 0x277430);
    PUSH32(esp, 0xB2);
    PUSH32(esp, 4);
    PUSH32(esp, 0x5345E8);
    PUSH32(esp, 0x002D8236u); RECOMP_ABI_CALL(0x002C1A86u, sub_002C1A86); /* call 0x002C1A86 */

loc_002D8236: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D8240
 * Original: 0x002D8240 - 0x002D8259 (25 bytes, 9 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8240(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D8240: ;
    eax = MEM32(0x383C28);
    MEM16(eax) = MEM16(eax) - 1;
    _fa = (uint32_t)(MEM16(eax)) & 0xFFFFu;
    _fas = (int32_t)(int16_t)(_fa); _fb = (_fa == 0x7FFFu); /* dec result/SF/OF; CF unchanged */
    _fa = (uint32_t)(MEM16(eax)) & 0xFFFFu; _fb = (uint32_t)(0) & 0xFFFFu;
    _fas = (int32_t)(int16_t)(_fa); _fbs = (int32_t)(int16_t)(_fb); /* cmp MEM16(eax), 0 (16-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D8258; /* jne: not equal / not zero */

loc_002D824E: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, eax);
    eax = MEM32(0x534574);
    { uint32_t _icall_target = MEM32(eax + 4); PUSH32(esp, 0x002D8257u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D8254u); } /* indirect call */
    }

loc_002D8257: ;
    POP32(esp, ecx);

loc_002D8258: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D8260
 * Original: 0x002D8260 - 0x002D826A (10 bytes, 2 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8260(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8260: ;
    ecx = 0x535568;
    g_seh_ebp = ebp; sub_00211DF0(); return; /* tail jmp 0x00211DF0 */

}

/**
 * sub_002D8280
 * Original: 0x002D8280 - 0x002D82F1 (113 bytes, 36 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8280(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8280: ;
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = MEM32(esp + 0x10);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi + 0x2478);
    edx = esi + 0x1C28;
    esi = MEM32(esi + 0x240C);
    esi = esi + esi * 2;
    esi = esi << 8;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, edi);
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = 0xC0;
    edi = ebp;
    esi = esi + edx + 0x1DC;
    ebx = 0; /* xor self */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _flags = ((_fa == 0)) ? 1 : 0; /* ZF in: a zero count keeps it */
    { int32_t _st = RECOMP_DF_STEP(4);
    while (ecx != 0) {
        _flags = (MEM32(esi) == MEM32(edi));
        esi += _st; edi += _st; ecx--;
        if (!_flags) break;
    } } /* repe cmpsd */
    if ((_flags != 0)) { g_seh_ebp = ebp; sub_002D82FC(); return; } /* je: equal / zero */

loc_002D82BD: ;
    ecx = eax + eax * 2;
    ecx = ecx << 8;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ebx = ecx + edx + 0x1DC;
    ecx = 0xC0;
    esi = ebp;
    edi = ebx;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    _fa = (uint32_t)(MEM8(esp + 0x14)) & 0xFFu; _fb = (uint32_t)(2) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(esp + 0x14), 2 (8-bit) */
    MEM32(edx + 0x7E4) = eax;
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002D82F1(); return; } /* je: equal / zero */

loc_002D82E2: ;
    PUSH32(esp, ebx);
    ecx = edx;
    PUSH32(esp, 0x002D82EAu); RECOMP_ABI_CALL(0x002DF42Eu, sub_002DF42E); /* call 0x002DF42E */

loc_002D82EA: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D8310
 * Original: 0x002D8310 - 0x002D833A (42 bytes, 13 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8310(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D8310: ;
    eax = MEM32(0x2E9548);
    ecx = MEM32(eax + 0x240C);
    PUSH32(esp, esi);
    ecx = ecx + ecx * 2;
    ecx = ecx << 8;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, edi);
    edi = MEM32(esp + 0xC);
    esi = ecx + eax + 0x1E04;
    ecx = 0xC0;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8470
 * Original: 0x002D8470 - 0x002D847F (15 bytes, 5 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8470(void)
{

loc_002D8470: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, 4);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D847Cu); RECOMP_ABI_CALL(0x002DE0C0u, sub_002DE0C0); /* call 0x002DE0C0 */

loc_002D847C: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8480
 * Original: 0x002D8480 - 0x002D84C1 (65 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8480(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8480: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    edx = eax;
    edx = edx >> 8;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    eax = eax & 0xFF;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    PUSH32(esp, esi);
    esi = MEM32(ecx + edx * 4 + 0x7D4);
    eax = eax << 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edx = MEM32(eax + esi + 0xC);
    _fb = (uint32_t)(esi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + esi;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFFFFFFu) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0xFFFFFFFFu (32-bit) */
    POP32(esp, esi);
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D84C1(); return; } /* jne: not equal / not zero */

loc_002D84AB: ;
    eax = MEM32(eax);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ecx + 0x2C)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(ecx + 0x2C) (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D84B9; /* jne: not equal / not zero */

loc_002D84B2: ;
    PUSH32(esp, 0);
    PUSH32(esp, 0x002D84B9u); RECOMP_ABI_CALL(0x002DE000u, sub_002DE000); /* call 0x002DE000 */

loc_002D84B9: ;
    eax = 0x88760828u;
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002D84F0
 * Original: 0x002D84F0 - 0x002D8503 (19 bytes, 4 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D84F0(void)
{

loc_002D84F0: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    MEM32(ecx + 0x1DB8) = eax;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8510
 * Original: 0x002D8510 - 0x002D8523 (19 bytes, 4 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8510(void)
{

loc_002D8510: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    MEM32(ecx + 0x1DB4) = eax;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8560
 * Original: 0x002D8560 - 0x002D859D (61 bytes, 18 insns)
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8560(void)
{

loc_002D8560: ;
    ecx = MEM32(0x2E9548);
    eax = MEM32(esp + 4);
    eax = eax + eax * 2;
    edx = ecx + eax * 8 + 0x1AC0;
    ecx = MEM32(edx);
    eax = MEM32(esp + 8);
    MEM32(eax) = ecx;
    ecx = MEM32(edx + 4);
    MEM32(eax + 4) = ecx;
    ecx = MEM32(edx + 8);
    MEM32(eax + 8) = ecx;
    ecx = MEM32(edx + 0xC);
    MEM32(eax + 0xC) = ecx;
    ecx = MEM32(edx + 0x10);
    MEM32(eax + 0x10) = ecx;
    edx = MEM32(edx + 0x14);
    MEM32(eax + 0x14) = edx;
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D85A0
 * Original: 0x002D85A0 - 0x002D85E2 (66 bytes, 18 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D85A0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D85A0: ;
    ecx = MEM32(0x2E8480);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    eax = MEM32(0x2E9548);
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    if (CMP_EQ(_fa, _fb)) goto loc_002D85BC; /* je: equal / zero */

loc_002D85B4: ;
    _fa = (uint32_t)(MEM32(0x2E8478)) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E8478), esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D85DE; /* je: equal / zero */

loc_002D85BC: ;
    eax = MEM32(eax + 0x1C28);
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0);
    PUSH32(esp, esi);
    PUSH32(esp, 0xB);
    PUSH32(esp, eax);
    { uint32_t _icall_target = MEM32(0x2FE768); PUSH32(esp, 0x002D85CEu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D85C8u); } /* indirect call */
    }

loc_002D85CE: ;
    MEM32(0x2E8480) = 1;
    MEM32(0x2E8478) = esi;

loc_002D85DE: ;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D85F0
 * Original: 0x002D85F0 - 0x002D8641 (81 bytes, 25 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D85F0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D85F0: ;
    ecx = MEM32(0x2E847C);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    eax = MEM32(0x2E9548);
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    if (CMP_EQ(_fa, _fb)) goto loc_002D8615; /* je: equal / zero */

loc_002D8604: ;
    edx = MEM32(0x2E8474);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    SET_LO8(ecx, (CMP_NE(_fa, _fb)) ? 1 : 0); /* setne */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, ecx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D863D; /* je: equal / zero */

loc_002D8615: ;
    edx = MEM32(eax + 0x1C28);
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0);
    PUSH32(esp, esi);
    PUSH32(esp, 0xE);
    PUSH32(esp, edx);
    { uint32_t _icall_target = MEM32(0x2FE768); PUSH32(esp, 0x002D8627u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D8621u); } /* indirect call */
    }

loc_002D8627: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    SET_LO8(eax, (CMP_NE(_fa, _fb)) ? 1 : 0); /* setne */
    MEM32(0x2E847C) = 1;
    MEM32(0x2E8474) = eax;

loc_002D863D: ;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8650
 * Original: 0x002D8650 - 0x002D8658 (8 bytes, 3 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8650(void)
{

loc_002D8650: ;
    PUSH32(esp, 0);
    PUSH32(esp, 0x002D8657u); RECOMP_ABI_CALL(0x002DE000u, sub_002DE000); /* call 0x002DE000 */

loc_002D8657: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002D8660
 * Original: 0x002D8660 - 0x002D869A (58 bytes, 20 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8660(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8660: ;
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    eax = MEM32(esi + 0x10);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D86B9(); return; } /* jne: not equal / not zero */

loc_002D866C: ;
    ecx = MEM32(esi + 0xC);
    eax = ZX8(MEM8(esi + 0xD));
    ecx = ecx >> 0x14;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx & 0xF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edx = 1;
    edx = edx << LO8(ecx);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xC) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xC (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D86B2(); return; } /* je: equal / zero */

loc_002D8685: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xD) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xD (32-bit) */
    if (CMP_LE(_fas, _fbs)) { g_seh_ebp = ebp; sub_002D869A(); return; } /* jle: less or equal (signed <=) */

loc_002D868A: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xF (32-bit) */
    if (CMP_G(_fas, _fbs)) { g_seh_ebp = ebp; sub_002D869A(); return; } /* jg: greater (signed >) */

loc_002D868F: ;
    eax = edx * 4;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D86D0
 * Original: 0x002D86D0 - 0x002D872E (94 bytes, 38 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D86D0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    int _cf = 0; /* carry flag */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D86D0: ;
    PUSH32(esp, ebx);
    PUSH32(esp, esi);
    esi = MEM32(esp + 0xC);
    eax = ZX8(MEM8(esi + 0xD));
    _cf = 0; /* xor clears CF */
    ebx = 0; /* xor self */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    SET_LO8(ebx, MEM8(eax + 0x2E7108));
    PUSH32(esp, edi);
    edi = MEM32(esi + 0x10);
    PUSH32(esp, eax);
    _cf = 0; /* logical op clears CF */
    ebx = ebx & 0x3C;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    PUSH32(esp, 0x002D86EFu); RECOMP_ABI_CALL(0x002E0E30u, sub_002E0E30); /* call 0x002E0E30 */

loc_002D86EF: ;
    _cf = (int)((LO8(eax)) != 0);
    SET_LO8(eax, (uint32_t)(0u - (uint32_t)(LO8(eax))));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fas = (int32_t)(int8_t)(_fa); /* neg result */
    eax = _cf ? 0xFFFFFFFF : 0; /* sbb self (CF extend) */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sbb result */
    _cf = 0; /* logical op clears CF */
    eax = eax & 2;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0 (32-bit) */
    _cf = 0; /* nothing borrows from zero */
    edx = eax;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D872E(); return; } /* jne: not equal / not zero */

loc_002D86FC: ;
    ecx = MEM32(esi + 0xC);
    eax = ecx;
    if (0x14) _cf = (int)(((eax) >> ((0x14) - 1)) & 1);
    eax = eax >> 0x14;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _cf = 0; /* logical op clears CF */
    eax = eax & 0xF;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, eax (32-bit) */
    _cf = (int)(_fa < _fb);
    if (CMP_BE(_fa, _fb)) goto loc_002D870D; /* jbe: below or equal (unsigned <=) */

loc_002D870B: ;
    eax = edx;

loc_002D870D: ;
    if (0x18) _cf = (int)(((ecx) >> ((0x18) - 1)) & 1);
    ecx = ecx >> 0x18;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _cf = 0; /* logical op clears CF */
    ecx = ecx & 0xF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, ecx (32-bit) */
    _cf = (int)(_fa < _fb);
    if (CMP_BE(_fa, _fb)) goto loc_002D8719; /* jbe: below or equal (unsigned <=) */

loc_002D8717: ;
    ecx = edx;

loc_002D8719: ;
    _fb = (uint32_t)(eax) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    _cf = (int)((((uint64_t)(ecx) + (uint64_t)(eax)) >> 32) & 1);
    ecx = ecx + eax;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = 1;
    if (LO8(ecx)) _cf = (int)(((eax) >> (32 - (LO8(ecx)))) & 1);
    eax = eax << LO8(ecx);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    POP32(esp, edi);
    POP32(esp, esi);
    eax = (uint32_t)((int32_t)eax * (int32_t)ebx);
    if (3) _cf = (int)(((eax) >> ((3) - 1)) & 1);
    eax = eax >> 3;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    POP32(esp, ebx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8750
 * Original: 0x002D8750 - 0x002D8799 (73 bytes, 28 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8750(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8750: ;
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(0x2E9548);
    PUSH32(esp, 0x002D875Fu); RECOMP_ABI_CALL(0x002DE3D0u, sub_002DE3D0); /* call 0x002DE3D0 */

loc_002D875F: ;
    ebp = edi + 0x1C28;

loc_002D8765: ;
    ecx = ebp;
    PUSH32(esp, 0x002D876Cu); RECOMP_ABI_CALL(0x002E1A30u, sub_002E1A30); /* call 0x002E1A30 */

loc_002D876C: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D8765; /* jne: not equal / not zero */

loc_002D8770: ;
    ecx = edi;
    PUSH32(esp, 0x002D8777u); RECOMP_ABI_CALL(0x002DFF90u, sub_002DFF90); /* call 0x002DFF90 */

loc_002D8777: ;
    esi = MEM32(esp + 0x14);
    PUSH32(esp, esi);
    ecx = edi;
    PUSH32(esp, 0x002D8783u); RECOMP_ABI_CALL(0x002E00C0u, sub_002E00C0); /* call 0x002E00C0 */

loc_002D8783: ;
    ebx = eax;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0 (32-bit) */
    if (CMP_GE(_fas, _fbs)) { g_seh_ebp = ebp; sub_002D8799(); return; } /* jge: greater or equal (signed >=) */

loc_002D8789: ;
    ecx = edi;
    PUSH32(esp, 0x002D8790u); RECOMP_ABI_CALL(0x002DFF90u, sub_002DFF90); /* call 0x002DFF90 */

loc_002D8790: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    eax = ebx;
    POP32(esp, ebx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8800
 * Original: 0x002D8800 - 0x002D88C8 (200 bytes, 65 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8800(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8800: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = MEM32(esp + 0x18);
    PUSH32(esp, esi);
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, esi (32-bit) */
    PUSH32(esp, edi);
    edi = MEM32(0x2E9548);
    if (CMP_NE(_fa, _fb)) goto loc_002D8823; /* jne: not equal / not zero */

loc_002D8817: ;
    eax = MEM32(edi + 0x1A04);
    MEM32(esp + 0x20) = eax;
    ebp = eax;

loc_002D8823: ;
    PUSH32(esp, ebp);
    PUSH32(esp, 0x002D8829u); RECOMP_ABI_CALL(0x002DE5E0u, sub_002DE5E0); /* call 0x002DE5E0 */

loc_002D8829: ;
    eax = MEM32(edi + 0x1A04);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D884E; /* je: equal / zero */

loc_002D8833: ;
    ecx = MEM32(eax + 0x14);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D883C; /* je: equal / zero */

loc_002D883A: ;
    eax = ecx;

loc_002D883C: ;
    ecx = MEM32(edi + 0x2C);
    MEM32(eax + 8) = ecx;
    edx = MEM32(edi + 0x1A04);
    PUSH32(esp, edx);
    PUSH32(esp, 0x002D884Eu); RECOMP_ABI_CALL(0x002DE810u, sub_002DE810); /* call 0x002DE810 */

loc_002D884E: ;
    eax = MEM32(edi + 0x1A08);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    MEM32(edi + 0x1A04) = ebp;
    if (CMP_EQ(_fa, _fb)) goto loc_002D8879; /* je: equal / zero */

loc_002D885E: ;
    ecx = MEM32(eax + 0x14);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D8867; /* je: equal / zero */

loc_002D8865: ;
    eax = ecx;

loc_002D8867: ;
    ecx = MEM32(edi + 0x2C);
    MEM32(eax + 8) = ecx;
    edx = MEM32(edi + 0x1A08);
    PUSH32(esp, edx);
    PUSH32(esp, 0x002D8879u); RECOMP_ABI_CALL(0x002DE810u, sub_002DE810); /* call 0x002DE810 */

loc_002D8879: ;
    ebx = MEM32(esp + 0x24);
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, esi (32-bit) */
    MEM32(edi + 0x1A08) = ebx;
    if (CMP_EQ(_fa, _fb)) goto loc_002D88A6; /* je: equal / zero */

loc_002D8887: ;
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002D888Du); RECOMP_ABI_CALL(0x002DE5E0u, sub_002DE5E0); /* call 0x002DE5E0 */

loc_002D888D: ;
    eax = edi + 0x948;
    PUSH32(esp, eax);
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002D889Au); RECOMP_ABI_CALL(0x002E0FE0u, sub_002E0FE0); /* call 0x002E0FE0 */

loc_002D889A: ;
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002D88A0u); RECOMP_ABI_CALL(0x002D8660u, sub_002D8660); /* call 0x002D8660 */

loc_002D88A0: ;
    MEM32(edi + 0x94C) = eax;

loc_002D88A6: ;
    eax = MEM32(edi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(edi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(edi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002D88B2; /* jb: below (unsigned <) */

loc_002D88AD: ;
    PUSH32(esp, 0x002D88B2u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002D88B2: ;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, esi (32-bit) */
    ecx = MEM32(ebp + 4);
    edx = eax;
    MEM32(esp + 0x18) = ecx;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D88C8(); return; } /* je: equal / zero */

loc_002D88BF: ;
    eax = MEM32(ebx + 4);
    MEM32(esp + 0x10) = eax;
    g_seh_ebp = ebp; sub_002D88CC(); return; /* tail jmp 0x002D88CC */

}

/**
 * sub_002D8A80
 * Original: 0x002D8A80 - 0x002D8AA8 (40 bytes, 12 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8A80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8A80: ;
    eax = MEM32(esp + 4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFFFFFFu) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xFFFFFFFFu (32-bit) */
    ecx = MEM32(0x2E9548);
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D8AA8(); return; } /* jne: not equal / not zero */

loc_002D8A8F: ;
    eax = 1;
    PUSH32(esp, esi);
    esi = MEM32(ecx + eax * 4 + 0x1A14);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002D8AA2u); RECOMP_ABI_CALL(0x002DE620u, sub_002DE620); /* call 0x002DE620 */

loc_002D8AA2: ;
    eax = esi;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D8AD0
 * Original: 0x002D8AD0 - 0x002D8B75 (165 bytes, 49 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8AD0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8AD0: ;
    _fb = (uint32_t)(0x34) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x34;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = MEM32(esp + 0x38);
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = ZX8(MEM8(eax + 0xD));
    SET_LO8(ebx, MEM8(ebp + 0x2E7108));
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    SET_LO8(ecx, LO8(ebx));
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    PUSH32(esp, eax);
    ecx = ecx >> 3;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx & 7;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esp + 0x1C) = ecx;
    PUSH32(esp, 0x002D8AF9u); RECOMP_ABI_CALL(0x002D8660u, sub_002D8660); /* call 0x002D8660 */

loc_002D8AF9: ;
    edx = MEM32(esp + 0x54);
    PUSH32(esp, edx);
    esi = eax;
    PUSH32(esp, 0x002D8B05u); RECOMP_ABI_CALL(0x002D8660u, sub_002D8660); /* call 0x002D8660 */

loc_002D8B05: ;
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 1 (8-bit) */
    edi = eax;
    if (TEST_NZ(_fa, _fb)) goto loc_002D8B1E; /* jne: not equal / not zero */

loc_002D8B0C: ;
    PUSH32(esp, ebp);
    PUSH32(esp, 0x002D8B12u); RECOMP_ABI_CALL(0x002E0E30u, sub_002E0E30); /* call 0x002E0E30 */

loc_002D8B12: ;
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(eax), 0 (8-bit) */
    MEM32(esp + 0x14) = 0;
    if (CMP_EQ(_fa, _fb)) goto loc_002D8B26; /* je: equal / zero */

loc_002D8B1E: ;
    MEM32(esp + 0x14) = 1;

loc_002D8B26: ;
    ebx = MEM32(0x2E9548);
    eax = MEM32(esp + 0x50);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    ebp = MEM32(ebx + 0x192C);
    MEM32(esp + 0x28) = ebx;
    if (CMP_NE(_fa, _fb)) goto loc_002D8B46; /* jne: not equal / not zero */

loc_002D8B3E: ;
    MEM32(esp + 0x50) = 1;

loc_002D8B46: ;
    eax = MEM32(esp + 0x14);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D8BA0(); return; } /* je: equal / zero */

loc_002D8B4E: ;
    eax = MEM32(esp + 0x48);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D8B58u); RECOMP_ABI_CALL(0x002D86D0u, sub_002D86D0); /* call 0x002D86D0 */

loc_002D8B58: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x1FC0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x1FC0 (32-bit) */
    if (CMP_A(_fa, _fb)) { g_seh_ebp = ebp; sub_002D8B75(); return; } /* ja: above (unsigned >) */

loc_002D8B5F: ;
    esi = eax + 0x3F;
    esi = esi & 0xFFFFFFC0u;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edi = esi;
    MEM32(esp + 0x10) = eax;
    MEM32(esp + 0x1C) = 1;
    g_seh_ebp = ebp; sub_002D8B87(); return; /* tail jmp 0x002D8B87 */

}

/**
 * sub_002D8E00
 * Original: 0x002D8E00 - 0x002D8E14 (20 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8E00(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8E00: ;
    eax = MEM32(0x2E9548);
    PUSH32(esp, esi);
    esi = MEM32(eax + 0x1A08);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D8E14(); return; } /* jne: not equal / not zero */

loc_002D8E10: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D8E20
 * Original: 0x002D8E20 - 0x002D8E51 (49 bytes, 13 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D8E20(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D8E20: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebp);
    ebp = MEM32(esp + 0x14);
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, 0 (32-bit) */
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D9013(); return; } /* je: equal / zero */

loc_002D8E37: ;
    eax = MEM32(esi + 0x1A04);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 0x1A14)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 0x1A14) (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D8E51(); return; } /* jne: not equal / not zero */

loc_002D8E45: ;
    ecx = MEM32(esi + 0x1A18);
    MEM32(esp + 8) = ecx;
    g_seh_ebp = ebp; sub_002D8E57(); return; /* tail jmp 0x002D8E57 */

}

/**
 * sub_002D9050
 * Original: 0x002D9050 - 0x002D90E9 (153 bytes, 45 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9050(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9050: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = MEM32(0x2E9548);
    PUSH32(esp, esi);
    esi = MEM32(esp + 0x18);
    eax = MEM32(ebp + esi * 4 + 0xF88);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(esp + 0xC) = ebp;
    MEM32(esp + 0x10) = eax;
    if (CMP_EQ(_fa, _fb)) goto loc_002D9093; /* je: equal / zero */

loc_002D9073: ;
    ecx = MEM32(ebp + 0x2C);
    edx = MEM32(eax);
    _fb = (uint32_t)(0xFFF80000u) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + 0xFFF80000u;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(eax + 8) = ecx;
    ecx = edx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x78FFFF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test ecx, 0x78FFFF (32-bit) */
    MEM32(eax) = edx;
    if (TEST_NZ(_fa, _fb)) goto loc_002D9093; /* jne: not equal / not zero */

loc_002D908D: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D9093u); RECOMP_ABI_CALL(0x002DE500u, sub_002DE500); /* call 0x002DE500 */

loc_002D9093: ;
    ebx = MEM32(esp + 0x1C);
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0 (32-bit) */
    MEM32(ebp + esi * 4 + 0xF88) = ebx;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D90E9(); return; } /* jne: not equal / not zero */

loc_002D90A2: ;
    eax = MEM32(ebp);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ebp + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(ebp + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002D90AF; /* jb: below (unsigned <) */

loc_002D90AA: ;
    PUSH32(esp, 0x002D90AFu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002D90AF: ;
    edx = esi;
    edx = edx << 6;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x41B0C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + 0x41B0C;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(eax) = edx;
    MEM32(eax + 4) = 0;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ebp) = eax;
    MEM32(ebp + esi * 4 + 0xC) = 0x80000000u;
    eax = MEM32(0x2E90A8);
    POP32(esp, esi);
    eax = eax | 0x4800;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    POP32(esp, ebp);
    MEM32(0x2E90A8) = eax;
    POP32(esp, ebx);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D9200
 * Original: 0x002D9200 - 0x002D928D (141 bytes, 48 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9200(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9200: ;
    PUSH32(esp, ebx);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x10);
    eax = MEM32(esi + edi * 4 + 0xF98);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D923F; /* je: equal / zero */

loc_002D9218: ;
    ecx = MEM32(esi + 0x2C);
    MEM32(eax + 8) = ecx;
    eax = MEM32(esi + edi * 4 + 0xF98);
    edx = MEM32(eax);
    _fb = (uint32_t)(0xFFF80000u) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + 0xFFF80000u;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx = edx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x78FFFF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test ecx, 0x78FFFF (32-bit) */
    MEM32(eax) = edx;
    if (TEST_NZ(_fa, _fb)) goto loc_002D923F; /* jne: not equal / not zero */

loc_002D9239: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D923Fu); RECOMP_ABI_CALL(0x002DE500u, sub_002DE500); /* call 0x002DE500 */

loc_002D923F: ;
    ebx = MEM32(esp + 0x14);
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0 (32-bit) */
    MEM32(esi + edi * 4 + 0xF98) = ebx;
    if (CMP_EQ(_fa, _fb)) goto loc_002D9287; /* je: equal / zero */

loc_002D924E: ;
    PUSH32(esp, ebp);
    ebp = MEM32(ebx);
    _fb = (uint32_t)(0x80000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ebp = ebp + 0x80000;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = ebp;
    eax = eax >> 0x1C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(ebx) = ebp;
    ecx = MEM32(esi + 4);
    ebp = eax;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002D926E; /* jb: below (unsigned <) */

loc_002D9269: ;
    PUSH32(esp, 0x002D926Eu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002D926E: ;
    ebx = MEM32(ebx + 4);
    edi = edi << 6;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ebx = ebx | ebp;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    _fb = (uint32_t)(0x41B20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + 0x41B20;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(eax) = edi;
    MEM32(eax + 4) = ebx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, ebp);

loc_002D9287: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebx);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D9290
 * Original: 0x002D9290 - 0x002D92B0 (32 bytes, 10 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9290(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9290: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0xC);
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D92B0(); return; } /* je: equal / zero */

loc_002D92A0: ;
    _fb = (uint32_t)(0x80000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    MEM32(edi) = MEM32(edi) + 0x80000;
    _fa = (uint32_t)(MEM32(edi)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = MEM32(edi + 4);
    MEM32(0x2E90A4) = eax;
    g_seh_ebp = ebp; sub_002D92BA(); return; /* tail jmp 0x002D92BA */

}

/**
 * sub_002D9350
 * Original: 0x002D9350 - 0x002D937B (43 bytes, 14 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9350(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D9350: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002D9363; /* jb: below (unsigned <) */

loc_002D935E: ;
    PUSH32(esp, 0x002D9363u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002D9363: ;
    MEM32(eax) = 0x817C8;
    ecx = 1;
    MEM32(eax + 4) = ecx;
    MEM32(eax + 8) = ecx;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D9380
 * Original: 0x002D9380 - 0x002D93BD (61 bytes, 20 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9380(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9380: ;
    PUSH32(esp, ebx);
    ebx = MEM32(0x2E9548);
    PUSH32(esp, esi);
    esi = MEM32(esp + 0xC);
    PUSH32(esp, edi);
    edi = esi;
    edi = edi >> 8;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    eax = MEM32(ebx + edi * 4 + 0x7D4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D93BD(); return; } /* jne: not equal / not zero */

loc_002D939D: ;
    PUSH32(esp, 0xA1800000u);
    PUSH32(esp, 0x1000);
    PUSH32(esp, 0x002D93ACu); RECOMP_ABI_CALL(0x001F093Cu, sub_001F093C); /* call 0x001F093C */

loc_002D93AC: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(ebx + edi * 4 + 0x7D4) = eax;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D93BD(); return; } /* jne: not equal / not zero */

loc_002D93B7: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D93F0
 * Original: 0x002D93F0 - 0x002D940A (26 bytes, 10 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D93F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D93F0: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002D93FBu); RECOMP_ABI_CALL(0x002D9380u, sub_002D9380); /* call 0x002D9380 */

loc_002D93FB: ;
    esi = eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D940A(); return; } /* jne: not equal / not zero */

loc_002D9401: ;
    eax = 0x8007000Eu;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D9450
 * Original: 0x002D9450 - 0x002D9477 (39 bytes, 12 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9450(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D9450: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002D9463; /* jb: below (unsigned <) */

loc_002D945E: ;
    PUSH32(esp, 0x002D9463u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002D9463: ;
    MEM32(eax) = 0x41710;
    MEM32(eax + 4) = 0;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002D9480
 * Original: 0x002D9480 - 0x002D9512 (146 bytes, 54 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9480(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9480: ;
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x1C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = MEM32(esp + 0x24);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    PUSH32(esp, ebx);
    ebx = MEM32(0x2E9548);
    PUSH32(esp, esi);
    MEM32(esp + 8) = ebx;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D9512(); return; } /* je: equal / zero */

loc_002D9497: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002D9512(); return; } /* je: equal / zero */

loc_002D949E: ;
    esi = MEM32(eax + 8);
    edx = MEM32(eax);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    MEM32(esp + 0x14) = esi;
    esi = MEM32(eax + 0xC);
    MEM32(esp + 0x18) = esi;
    esi = MEM32(eax + 0x10);
    eax = MEM32(eax + 0x14);
    if ((((uint32_t)((uint32_t)(_fas) - (uint32_t)(_fbs)) >> 31) != 0)) goto loc_002D94BC; /* js: sign (negative) */

loc_002D94B8: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */

loc_002D94BC: ;
    PUSH32(esp, ebp);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x30);
    ebp = edi + edi * 2;
    ebx = ebx + ebp * 8 + 0x1AC0;
    ebp = ebx;
    ebx = MEM32(esp + 0x1C);
    MEM32(ebp) = edx;
    MEM32(ebp + 4) = ecx;
    PUSH32(esp, eax);
    MEM32(ebp + 8) = ebx;
    ebx = MEM32(esp + 0x24);
    PUSH32(esp, esi);
    MEM32(ebp + 0xC) = ebx;
    PUSH32(esp, edx);
    MEM32(ebp + 0x10) = esi;
    PUSH32(esp, ebx);
    MEM32(ebp + 0x14) = eax;
    eax = MEM32(esp + 0x2C);
    ecx = ecx & 0xFFFFFFF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    PUSH32(esp, eax);
    PUSH32(esp, ecx);
    ecx = MEM32(esp + 0x28);
    PUSH32(esp, edi);
    _fb = (uint32_t)(0x1C28) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x1C28;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, 0x002D9508u); RECOMP_ABI_CALL(0x002E2C26u, sub_002E2C26); /* call 0x002E2C26 */

loc_002D9508: ;
    POP32(esp, edi);
    POP32(esp, ebp);
    POP32(esp, esi);
    POP32(esp, ebx);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x1C;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D9560
 * Original: 0x002D9560 - 0x002D956A (10 bytes, 2 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9560(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9560: ;
    PUSH32(esp, 0x002D9565u); RECOMP_ABI_CALL(0x002DE3D0u, sub_002DE3D0); /* call 0x002DE3D0 */

loc_002D9565: ;
    g_seh_ebp = ebp; sub_002D9480(); return; /* tail jmp 0x002D9480 */

}

/**
 * sub_002D98F0
 * Original: 0x002D98F0 - 0x002D9927 (55 bytes, 17 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D98F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D98F0: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebp);
    ebp = MEM32(0x2E9548);
    { uint32_t _icall_esp = g_esp;
    { uint32_t _icall_target = MEM32(0x2FE764); PUSH32(esp, 0x002D9900u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D98FAu); } /* indirect call */
    }

loc_002D9900: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D9913; /* je: equal / zero */

loc_002D9904: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, eax);
    { uint32_t _icall_target = MEM32(0x2FE5F0); PUSH32(esp, 0x002D990Bu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D9905u); } /* indirect call */
    }

loc_002D990B: ;
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, 0);
    { uint32_t _icall_target = MEM32(0x2FE770); PUSH32(esp, 0x002D9913u); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002D990Du); } /* indirect call */
    }

loc_002D9913: ;
    eax = MEM32(ebp + 0x938);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D9927(); return; } /* jne: not equal / not zero */

loc_002D991D: ;
    eax = 0x80004005u;
    POP32(esp, ebp);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002D9A20
 * Original: 0x002D9A20 - 0x002D9A69 (73 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9A20(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D9A20: ;
    fp_push(MEMF(esp + 4)); /* fld float */
    PUSH32(esp, esi);
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2E7088)); /* fadd dword ptr [0x2e7088] */
    esi = MEM32(0x2E9548);
    ecx = esi;
    MEMF(esi + 0xEF8) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push(MEMF(esp + 0xC)); /* fld float */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2E7088)); /* fadd dword ptr [0x2e7088] */
    MEMF(esi + 0xEFC) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002D9A4Eu); RECOMP_ABI_CALL(0x002DD2C0u, sub_002DD2C0); /* call 0x002DD2C0 */

loc_002D9A4E: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002D9A5A; /* jb: below (unsigned <) */

loc_002D9A55: ;
    PUSH32(esp, 0x002D9A5Au); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002D9A5A: ;
    edx = eax;
    ecx = esi;
    PUSH32(esp, 0x002D9A63u); RECOMP_ABI_CALL(0x002DA990u, sub_002DA990); /* call 0x002DA990 */

loc_002D9A63: ;
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002D9CC0
 * Original: 0x002D9CC0 - 0x002D9CD6 (22 bytes, 5 insns)
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9CC0(void)
{

loc_002D9CC0: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(esp + 8);
    MEM32(0x2EBCEC) = eax;
    MEM32(0x2EBCE8) = ecx;
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D9CE0
 * Original: 0x002D9CE0 - 0x002D9D73 (147 bytes, 39 insns)
 * Category: game_render
 * CC: cdecl, 6 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9CE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9CE0: ;
    eax = MEM32(0x2EBCEC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D9CF3; /* jne: not equal / not zero */

loc_002D9CE9: ;
    MEM32(0x2EBCEC) = 0x80000;

loc_002D9CF3: ;
    eax = MEM32(0x2EBCE8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002D9D06; /* jne: not equal / not zero */

loc_002D9CFC: ;
    MEM32(0x2EBCE8) = 0x8000;

loc_002D9D06: ;
    eax = MEM32(esp + 0x10);
    ecx = MEM32(esp + 0x14);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9558);
    PUSH32(esp, edi);
    eax = eax & 0x10;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edi = 0x2E9550;
    esi = esi | eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    PUSH32(esp, ecx);
    ecx = edi;
    MEM32(0x2E9548) = edi;
    MEM32(0x2E9E88) = 1;
    MEM32(0x2E9558) = esi;
    PUSH32(esp, 0x002D9D3Eu); RECOMP_ABI_CALL(0x002E0660u, sub_002E0660); /* call 0x002E0660 */

loc_002D9D3E: ;
    esi = eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_GE(_fas, _fbs)) { g_seh_ebp = ebp; sub_002D9D73(); return; } /* jge: greater or equal (signed >=) */

loc_002D9D44: ;
    ecx = edi;
    PUSH32(esp, 0x002D9D4Bu); RECOMP_ABI_CALL(0x002E0B30u, sub_002E0B30); /* call 0x002E0B30 */

loc_002D9D4B: ;
    eax = MEM32(esp + 0x20);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D9D59; /* je: equal / zero */

loc_002D9D53: ;
    MEM32(eax) = 0;

loc_002D9D59: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ecx = 0x928;
    { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4); for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = eax; edi += ecx * _st; }
    ecx = 0; /* rep stosd */
    POP32(esp, edi);
    eax = esi;
    MEM32(0x2E9548) = 0;
    POP32(esp, esi);
    esp += 28; return; /* ret 24 */

}

/**
 * sub_002D9D90
 * Original: 0x002D9D90 - 0x002D9DB2 (34 bytes, 6 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9D90(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002D9D90: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    MEM32(ecx + 0x790) = eax;
    MEM32(0x2E90A8) = MEM32(0x2E90A8) | 0x4000;
    _fa = (uint32_t)(MEM32(0x2E90A8)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(0x2E94D0) = eax;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002D9DC0
 * Original: 0x002D9DC0 - 0x002D9DDC (28 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9DC0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9DC0: ;
    eax = MEM32(0x2E9550);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(0x2E9554)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(0x2E9554) (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002D9DDC(); return; } /* jae: above or equal (unsigned >=) */

loc_002D9DD0: ;
    MEM32(0x2E9550) = eax;
    MEM32(eax + -8) = ecx;
    MEM32(eax + -4) = edx;
    esp += 4; return; /* ret */

}

/**
 * sub_002D9DF0
 * Original: 0x002D9DF0 - 0x002D9E19 (41 bytes, 13 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002D9DF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002D9DF0: ;
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0x5C) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0x5C (32-bit) */
    if (CMP_GE(_fas, _fbs)) { g_seh_ebp = ebp; sub_002D9E19(); return; } /* jge: greater or equal (signed >=) */

loc_002D9DFA: ;
    ecx = MEM32(esi * 4 + 0x311F48);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x10);
    edx = edi;
    PUSH32(esp, 0x002D9E0Du); RECOMP_ABI_CALL(0x002D9DC0u, sub_002D9DC0); /* call 0x002D9DC0 */

loc_002D9E0D: ;
    MEM32(esi * 4 + 0x2E92B0) = edi;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002D9E50
 * Original: 0x002D9E50 - 0x002D9F72 (290 bytes, 72 insns)
 * CC: cdecl, 2 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002D9E50(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002D9E50: ;
    eax = MEM32(0x2E9548);
    ecx = MEM32(eax + 0xEE0);
    fp_push((double)SMEM32(eax + 0xEE0)); /* fild */
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_GE(_fas, _fbs)) goto loc_002D9E6E; /* jge: greater or equal (signed >=) */

loc_002D9E68: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002D9E6E: ;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(eax + 0x95C)); /* fmul dword ptr [eax + 0x95c] */
    edx = MEM32(eax + 0xEE4);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(eax + 0xEF8)); /* fadd dword ptr [eax + 0xef8] */
    fp_push((double)SMEM32(eax + 0xEE4)); /* fild */
    if (CMP_GE(_fas, _fbs)) goto loc_002D9E90; /* jge: greater or equal (signed >=) */

loc_002D9E8A: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002D9E90: ;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(eax + 0x960)); /* fmul dword ptr [eax + 0x960] */
    edx = MEM32(eax + 8);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(HI8(edx)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp HI8(edx), 0 (8-bit) */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(eax + 0xEFC)); /* fadd dword ptr [eax + 0xefc] */
    if ((((uint8_t)((uint8_t)(_fa) - (uint8_t)(_fb)) >> 7) == 0)) goto loc_002D9EBD; /* jns: not sign (positive) */

loc_002D9EA5: ;
    _fa = (uint32_t)(MEM32(0x2E9510)) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E9510), ecx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002D9EBD; /* je: equal / zero */

loc_002D9EAD: ;
    { double _t = fp_top(); fp_top() = fp_st1(); fp_st1() = _t; } /* fxch st(1) */
    fp_top() = RECOMP_FP_PC(fp_top() - MEMF(0x2FE9A0)); /* fsub dword ptr [0x2fe9a0] */
    { double _t = fp_top(); fp_top() = fp_st1(); fp_st1() = _t; } /* fxch st(1) */
    fp_top() = RECOMP_FP_PC(fp_top() - MEMF(0x2FE9A0)); /* fsub dword ptr [0x2fe9a0] */

loc_002D9EBD: ;
    edx = MEM32(eax + 0xEE8);
    fp_push((double)SMEM32(eax + 0xEE8)); /* fild */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_GE(_fas, _fbs)) goto loc_002D9ED3; /* jge: greater or equal (signed >=) */

loc_002D9ECD: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002D9ED3: ;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(eax + 0x95C)); /* fmul dword ptr [eax + 0x95c] */
    edx = MEM32(eax + 0xEEC);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FE9A0)); /* fmul dword ptr [0x2fe9a0] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push((double)SMEM32(eax + 0xEEC)); /* fild */
    if (CMP_GE(_fas, _fbs)) goto loc_002D9EF8; /* jge: greater or equal (signed >=) */

loc_002D9EF2: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002D9EF8: ;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(eax + 0x960)); /* fmul dword ptr [eax + 0x960] */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x3075DC)); /* fmul dword ptr [0x3075dc] */
    MEMF(esp + 4) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push(MEMF(eax + 0xEF4)); /* fld float */
    fp_top() = RECOMP_FP_PC(fp_top() - MEMF(eax + 0xEF0)); /* fsub dword ptr [eax + 0xef0] */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(eax + 0x948)); /* fmul dword ptr [eax + 0x948] */
    MEMF(esp + 0xC) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push(MEMF(eax + 0xEF0)); /* fld float */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(eax + 0x948)); /* fmul dword ptr [eax + 0x948] */
    eax = MEM32(esp + 0x14);
    MEM32(eax + 0xC) = ecx;
    MEMF(esp + 8) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push(MEMF(esp)); /* fld float */
    edx = MEM32(esp + 8);
    fp_top() = RECOMP_FP_PC(fp_top() + g_fp_stack[(g_fp_top + 2) & 7]); /* fadd st(2) */
    MEM32(eax + 8) = edx;
    edx = MEM32(esp + 4);
    MEMF(eax) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push(MEMF(esp + 4)); /* fld float */
    fp_top() = -fp_top(); /* fchs */
    fp_top() = RECOMP_FP_PC(fp_top() + fp_st1()); /* fadd st(1) */
    MEMF(eax + 4) = (float)fp_top(); fp_pop(); /* fstp */
    eax = MEM32(esp + 0x18);
    MEM32(eax + 4) = edx;
    edx = MEM32(esp + 0xC);
    fp_pop(); /* fstp st(0) */
    fp_pop(); /* fstp st(0) */
    MEM32(eax + 8) = edx;
    fp_push(MEMF(esp)); /* fld float */
    MEM32(eax + 0xC) = ecx;
    MEMF(eax) = (float)fp_top(); fp_pop(); /* fstp */
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 12; return; /* ret 8 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002DA0C0
 * Original: 0x002DA0C0 - 0x002DA0F2 (50 bytes, 15 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA0C0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA0C0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA0D3; /* jb: below (unsigned <) */

loc_002DA0CE: ;
    PUSH32(esp, 0x002DA0D3u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA0D3: ;
    ecx = MEM32(esp + 8);
    MEM32(eax) = 0x80320;
    MEM32(eax + 4) = ecx;
    MEM32(eax + 8) = ecx;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E950C) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA100
 * Original: 0x002DA100 - 0x002DA135 (53 bytes, 15 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA100(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA100: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA113; /* jb: below (unsigned <) */

loc_002DA10E: ;
    PUSH32(esp, 0x002DA113u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA113: ;
    ecx = MEM32(esp + 8);
    MEM32(eax) = 0x41E6C;
    edx = ecx + -512;
    MEM32(eax + 4) = edx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E9520) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA140
 * Original: 0x002DA140 - 0x002DA18D (77 bytes, 24 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA140(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA140: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    PUSH32(esp, edi);
    if (CMP_B(_fa, _fb)) goto loc_002DA154; /* jb: below (unsigned <) */

loc_002DA14F: ;
    PUSH32(esp, 0x002DA154u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA154: ;
    ecx = MEM32(esp + 0xC);
    edx = ZX8(MEM8(esp + 0xE));
    edi = ecx;
    edi = edi & 0xFF;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edi = edi << 0x10;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edx = edx | edi;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    edi = ecx;
    edi = edi & 0xFF00FF00u;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(eax) = 0x402A8;
    edx = edx | edi;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(eax + 4) = edx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, edi);
    MEM32(0x2E94D8) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA190
 * Original: 0x002DA190 - 0x002DA1C3 (51 bytes, 16 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA190(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA190: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA1A3; /* jb: below (unsigned <) */

loc_002DA19E: ;
    PUSH32(esp, 0x002DA1A3u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA1A3: ;
    ecx = MEM32(esp + 8);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    MEM32(eax) = 0x40308;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DA1C3(); return; } /* jne: not equal / not zero */

loc_002DA1B1: ;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E94FC) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA200
 * Original: 0x002DA200 - 0x002DA23A (58 bytes, 16 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA200(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA200: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA213; /* jb: below (unsigned <) */

loc_002DA20E: ;
    PUSH32(esp, 0x002DA213u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA213: ;
    ecx = MEM32(esp + 8);
    MEM32(eax) = 0x403A0;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    eax = MEM32(0x2E94FC);
    MEM32(0x2E94F8) = ecx;
    POP32(esp, esi);
    MEM32(esp + 4) = eax;
    g_seh_ebp = ebp; sub_002DA190(); return; /* tail jmp 0x002DA190 */

}

/**
 * sub_002DA240
 * Original: 0x002DA240 - 0x002DA279 (57 bytes, 15 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA240(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA240: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA253; /* jb: below (unsigned <) */

loc_002DA24E: ;
    PUSH32(esp, 0x002DA253u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA253: ;
    ecx = MEM32(esp + 8);
    MEM32(eax) = 0x403A4;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E90A8) = MEM32(0x2E90A8) | 0x200;
    _fa = (uint32_t)(MEM32(0x2E90A8)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(0x2E94E8) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA280
 * Original: 0x002DA280 - 0x002DA2C4 (68 bytes, 22 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA280(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA280: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi + 0x784);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DA2C4(); return; } /* jne: not equal / not zero */

loc_002DA291: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA29D; /* jb: below (unsigned <) */

loc_002DA298: ;
    PUSH32(esp, 0x002DA29Du); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA29D: ;
    ecx = MEM32(esp + 8);
    MEM32(eax) = 0x400A60;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edx = 0x10;
    /* nop */

loc_002DA2B0: ;
    MEM32(eax) = ecx;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edx--;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002DA2B0; /* jne: not equal / not zero */

loc_002DA2B8: ;
    MEM32(esi) = eax;
    MEM32(0x2E9500) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA2E0
 * Original: 0x002DA2E0 - 0x002DA345 (101 bytes, 30 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA2E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002DA2E0: ;
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 8);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    MEM32(esp + 0xC) = ebx;
    fp_push(MEMF(esp + 0xC)); /* fld float */
    PUSH32(esp, edi);
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(esi + 0x964)); /* fmul dword ptr [esi + 0x964] */
    PUSH32(esp, ecx);
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x317728)); /* fmul dword ptr [0x317728] */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FE9A0)); /* fadd dword ptr [0x2fe9a0] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DA310u); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DA310: ;
    edi = eax;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0x1FF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0x1FF (32-bit) */
    if (CMP_BE(_fa, _fb)) goto loc_002DA31F; /* jbe: below or equal (unsigned <=) */

loc_002DA31A: ;
    edi = 0x1FF;

loc_002DA31F: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA32B; /* jb: below (unsigned <) */

loc_002DA326: ;
    PUSH32(esp, 0x002DA32Bu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA32B: ;
    MEM32(eax) = 0x40380;
    MEM32(eax + 4) = edi;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    MEM32(esi) = eax;
    POP32(esp, esi);
    MEM32(0x2E9524) = ebx;
    POP32(esp, ebx);
    esp += 8; return; /* ret 4 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002DA350
 * Original: 0x002DA350 - 0x002DA3C7 (119 bytes, 38 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA350(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA350: ;
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 8);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(0x2E9548);
    eax = MEM32(edi + 0x1A04);
    ecx = ZX8(MEM8(eax + 0xD));
    SET_LO8(edx, MEM8(ecx + 0x2E7108));
    SET_LO8(edx, LO8(edx) & 0x3C);
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fas = (int32_t)(int8_t)(_fa); /* and result */
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(0x20) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp LO8(edx), 0x20 (8-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DA379; /* jne: not equal / not zero */

loc_002DA377: ;
    esi = ebx;

loc_002DA379: ;
    eax = MEM32(edi + 8);
    ecx = eax;
    ecx = ecx & 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, ecx (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DA3BB; /* je: equal / zero */

loc_002DA385: ;
    ecx = MEM32(edi + 4);
    eax = eax ^ 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(edi + 8) = eax;
    eax = MEM32(edi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA399; /* jb: below (unsigned <) */

loc_002DA394: ;
    PUSH32(esp, 0x002DA399u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA399: ;
    MEM32(eax) = 0x40110;
    MEM32(eax + 4) = 0;
    esi = esi << 5;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(eax + 8) = 0x40100;
    esi = esi | 8;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(eax + 0xC) = esi;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x10;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(edi) = eax;

loc_002DA3BB: ;
    POP32(esp, edi);
    POP32(esp, esi);
    MEM32(0x2E952C) = ebx;
    POP32(esp, ebx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA3D0
 * Original: 0x002DA3D0 - 0x002DA444 (116 bytes, 41 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA3D0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)

loc_002DA3D0: ;
    PUSH32(esp, ecx);
    PUSH32(esp, esi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x10);
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0 (32-bit) */
    SET_LO8(eax, (CMP_NE(_fa, _fb)) ? 1 : 0); /* setne */
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0 (32-bit) */
    MEM32(esp + 0x10) = edi;
    fp_push((double)SMEM32(esp + 0x10)); /* fild */
    esi = eax;
    if (CMP_GE(_fas, _fbs)) goto loc_002DA3F2; /* jge: greater or equal (signed >=) */

loc_002DA3EC: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002DA3F2: ;
    fp_top() = -fp_top(); /* fchs */
    MEMF(esp + 0x10) = (float)fp_top(); /* fst */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x2FF224)); /* fmul dword ptr [0x2ff224] */
    MEMF(esp + 8) = (float)fp_top(); fp_pop(); /* fstp */
    ecx = MEM32(esp + 8);
    PUSH32(esp, ecx);
    PUSH32(esp, 0x4D);
    PUSH32(esp, 0x002DA40Eu); RECOMP_ABI_CALL(0x002D9DF0u, sub_002D9DF0); /* call 0x002D9DF0 */

loc_002DA40E: ;
    edx = MEM32(esp + 0x10);
    eax = edx;
    PUSH32(esp, eax);
    PUSH32(esp, 0x4E);
    MEM32(esp + 0x18) = edx;
    PUSH32(esp, 0x002DA420u); RECOMP_ABI_CALL(0x002D9DF0u, sub_002D9DF0); /* call 0x002D9DF0 */

loc_002DA420: ;
    PUSH32(esp, esi);
    PUSH32(esp, 0x4F);
    PUSH32(esp, 0x002DA428u); RECOMP_ABI_CALL(0x002D9DF0u, sub_002D9DF0); /* call 0x002D9DF0 */

loc_002DA428: ;
    PUSH32(esp, esi);
    PUSH32(esp, 0x50);
    PUSH32(esp, 0x002DA430u); RECOMP_ABI_CALL(0x002D9DF0u, sub_002D9DF0); /* call 0x002D9DF0 */

loc_002DA430: ;
    PUSH32(esp, esi);
    PUSH32(esp, 0x51);
    PUSH32(esp, 0x002DA438u); RECOMP_ABI_CALL(0x002D9DF0u, sub_002D9DF0); /* call 0x002D9DF0 */

loc_002DA438: ;
    MEM32(0x2E9504) = edi;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ecx);
    esp += 8; return; /* ret 4 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002DA450
 * Original: 0x002DA450 - 0x002DA483 (51 bytes, 16 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA450(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA450: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA463; /* jb: below (unsigned <) */

loc_002DA45E: ;
    PUSH32(esp, 0x002DA463u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA463: ;
    ecx = MEM32(esp + 8);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DA483(); return; } /* jne: not equal / not zero */

loc_002DA46B: ;
    MEM32(eax) = 0x417BC;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E9508) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA4B0
 * Original: 0x002DA4B0 - 0x002DA4F4 (68 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA4B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA4B0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA4C3; /* jb: below (unsigned <) */

loc_002DA4BE: ;
    PUSH32(esp, 0x002DA4C3u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA4C3: ;
    ecx = MEM32(0x2E94E4);
    edx = MEM32(0x2E94E0);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    ecx = MEM32(esp + 8);
    if (CMP_NE(_fa, _fb)) goto loc_002DA4D9; /* jne: not equal / not zero */

loc_002DA4D7: ;
    edx = ecx;

loc_002DA4D9: ;
    MEM32(eax) = 0x8038C;
    MEM32(eax + 4) = ecx;
    MEM32(eax + 8) = edx;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E94DC) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA500
 * Original: 0x002DA500 - 0x002DA551 (81 bytes, 24 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA500(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA500: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    MEM32(0x2E94E0) = eax;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    PUSH32(esp, edi);
    edi = MEM32(0x2E94DC);
    if (CMP_B(_fa, _fb)) goto loc_002DA523; /* jb: below (unsigned <) */

loc_002DA51E: ;
    PUSH32(esp, 0x002DA523u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA523: ;
    ecx = MEM32(0x2E94E4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    ecx = MEM32(0x2E94E0);
    if (CMP_NE(_fa, _fb)) goto loc_002DA535; /* jne: not equal / not zero */

loc_002DA533: ;
    ecx = edi;

loc_002DA535: ;
    MEM32(eax) = 0x8038C;
    MEM32(eax + 4) = edi;
    MEM32(eax + 8) = ecx;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E94DC) = edi;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA560
 * Original: 0x002DA560 - 0x002DA5E0 (128 bytes, 36 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA560(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA560: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    PUSH32(esp, edi);
    if (CMP_B(_fa, _fb)) goto loc_002DA574; /* jb: below (unsigned <) */

loc_002DA56F: ;
    PUSH32(esp, 0x002DA574u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA574: ;
    ecx = MEM32(esp + 0xC);
    MEM32(eax) = 0x417C4;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    MEM32(esi) = eax;
    if (CMP_EQ(_fa, _fb)) goto loc_002DA594; /* je: equal / zero */

loc_002DA58A: ;
    MEM32(0x2E90A8) = MEM32(0x2E90A8) | 0x9000;
    _fa = (uint32_t)(MEM32(0x2E90A8)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DA594: ;
    esi = MEM32(0x2E9548);
    edi = MEM32(0x2E94DC);
    MEM32(0x2E94E4) = ecx;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA5B2; /* jb: below (unsigned <) */

loc_002DA5AD: ;
    PUSH32(esp, 0x002DA5B2u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA5B2: ;
    ecx = MEM32(0x2E94E4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    ecx = MEM32(0x2E94E0);
    if (CMP_NE(_fa, _fb)) goto loc_002DA5C4; /* jne: not equal / not zero */

loc_002DA5C2: ;
    ecx = edi;

loc_002DA5C4: ;
    MEM32(eax) = 0x8038C;
    MEM32(eax + 4) = edi;
    MEM32(eax + 8) = ecx;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E94DC) = edi;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA5E0
 * Original: 0x002DA5E0 - 0x002DA621 (65 bytes, 17 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA5E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA5E0: ;
    edx = MEM32(0x2E90A8);
    edx = edx | 0x200;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    MEM32(0x2E90A8) = edx;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA605; /* jb: below (unsigned <) */

loc_002DA600: ;
    PUSH32(esp, 0x002DA605u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA605: ;
    ecx = MEM32(esp + 8);
    MEM32(eax) = 0x40328;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(0x2E94D4) = ecx;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DA630
 * Original: 0x002DA630 - 0x002DA6A8 (120 bytes, 35 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA630(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA630: ;
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 0xC);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x14);
    eax = edi;
    eax = eax << 7;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(eax + 0x2E9120) = ebx;
    eax = MEM32(esi);
    ecx = MEM32(esi + 4);
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    ebp = 0; /* xor self */
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    MEM32(esp + 0x14) = edx;
    MEM32(esp + 0x18) = ebx;
    if (CMP_B(_fa, _fb)) goto loc_002DA66B; /* jb: below (unsigned <) */

loc_002DA662: ;
    PUSH32(esp, 0x002DA667u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA667: ;
    edx = MEM32(esp + 0x14);

loc_002DA66B: ;
    ebx = ebx & 0xFFFF0000u;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = 1;
    if ((_fa == 0)) { g_seh_ebp = ebp; sub_002DA6C7(); return; } /* je: equal / zero */

loc_002DA678: ;
    ebp = edi * 4 + 0x41964;
    MEM32(eax) = ebp;
    MEM32(eax + 4) = 0xFF000000u;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x30000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0x30000 (32-bit) */
    MEM32(esp + 0x18) = edi;
    if (CMP_A(_fa, _fb)) { g_seh_ebp = ebp; sub_002DA6C2(); return; } /* ja: above (unsigned >) */

loc_002DA697: ;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DA6B5(); return; } /* je: equal / zero */

loc_002DA699: ;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x10000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0x10000 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DA6A8(); return; } /* je: equal / zero */

loc_002DA6A1: ;
    ebp = 0x2400;
    g_seh_ebp = ebp; sub_002DA6C7(); return; /* tail jmp 0x002DA6C7 */

}

/**
 * sub_002DA740
 * Original: 0x002DA740 - 0x002DA7A3 (99 bytes, 35 insns)
 * Category: game_render
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA740(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA740: ;
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    esi = MEM32(esp + 0x10);
    PUSH32(esp, edi);
    edi = MEM32(0x2E9548);
    eax = MEM32(edi + 0x784);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    ebx = esi;
    if (CMP_NE(_fa, _fb)) goto loc_002DA75D; /* jne: not equal / not zero */

loc_002DA75A: ;
    ebx = esi + 1;

loc_002DA75D: ;
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(3) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 3 (8-bit) */
    ebp = MEM32(esp + 0x1C);
    if (TEST_Z(_fa, _fb)) goto loc_002DA78C; /* je: equal / zero */

loc_002DA766: ;
    eax = MEM32(edi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(edi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(edi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA772; /* jb: below (unsigned <) */

loc_002DA76D: ;
    PUSH32(esp, 0x002DA772u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA772: ;
    ecx = MEM32(esp + 0x18);
    ebx = ebx << 4;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(ecx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ebx = ebx + ecx;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx = ebx * 4 + 0x41AD0;
    MEM32(eax) = ecx;
    MEM32(eax + 4) = ebp;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(edi) = eax;

loc_002DA78C: ;
    eax = MEM32(esp + 0x18);
    esi = esi << 5;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(eax) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    MEM32(esi * 4 + 0x2E90B0) = ebp;
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002DA7B0
 * Original: 0x002DA7B0 - 0x002DA7ED (61 bytes, 19 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA7B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA7B0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA7C3; /* jb: below (unsigned <) */

loc_002DA7BE: ;
    PUSH32(esp, 0x002DA7C3u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA7C3: ;
    ecx = MEM32(esp + 8);
    edx = ecx;
    edx = edx << 6;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x41B24) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + 0x41B24;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(eax) = edx;
    edx = MEM32(esp + 0xC);
    MEM32(eax + 4) = edx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    ecx = ecx << 7;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(ecx + 0x2E9124) = edx;
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DA7F0
 * Original: 0x002DA7F0 - 0x002DA829 (57 bytes, 17 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA7F0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DA7F0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DA803; /* jb: below (unsigned <) */

loc_002DA7FE: ;
    PUSH32(esp, 0x002DA803u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DA803: ;
    ecx = MEM32(esp + 8);
    edx = ecx * 4 + 0x40AE0;
    MEM32(eax) = edx;
    edx = MEM32(esp + 0xC);
    MEM32(eax + 4) = edx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    ecx = ecx << 7;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(ecx + 0x2E9128) = edx;
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DA830
 * Original: 0x002DA830 - 0x002DA867 (55 bytes, 16 insns)
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA830(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA830: ;
    eax = MEM32(esp + 8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xC) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xC (32-bit) */
    if (CMP_GE(_fas, _fbs)) { g_seh_ebp = ebp; sub_002DA867(); return; } /* jge: greater or equal (signed >=) */

loc_002DA839: ;
    ecx = MEM32(esp + 4);
    edx = 1;
    edx = edx << LO8(ecx);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, esi);
    esi = MEM32(0x2E90A8);
    ecx = ecx << 5;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    esi = esi | edx;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    _fb = (uint32_t)(eax) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + eax;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = MEM32(esp + 0x10);
    MEM32(0x2E90A8) = esi;
    MEM32(ecx * 4 + 0x2E90B0) = eax;
    POP32(esp, esi);
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002DA920
 * Original: 0x002DA920 - 0x002DA98A (106 bytes, 40 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DA920(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA920: ;
    PUSH32(esp, ebx);
    ebx = MEM32(ecx + 0x784);
    eax = edx;
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0 (32-bit) */
    SET_LO8(edx, (CMP_NE(_fa, _fb)) ? 1 : 0); /* setne */
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    ecx = 0x181B68;
    esi = edx;
    esi = esi << 7;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edx = eax + 4;
    _fb = (uint32_t)(0x2E9108) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 0x2E9108;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DA946: ;
    MEM32(eax) = ecx;
    edi = esi;
    ebp = MEM32(edi);
    ebx = edx;
    MEM32(ebx) = ebp;
    ebp = MEM32(edi + 4);
    MEM32(ebx + 4) = ebp;
    ebp = MEM32(edi + 8);
    MEM32(ebx + 8) = ebp;
    ebp = MEM32(edi + 0xC);
    MEM32(ebx + 0xC) = ebp;
    ebp = MEM32(edi + 0x10);
    MEM32(ebx + 0x10) = ebp;
    edi = MEM32(edi + 0x14);
    _fb = (uint32_t)(0x40) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x40;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x1C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + 0x1C;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fb = (uint32_t)(0x80) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 0x80;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x181BE8) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0x181BE8 (32-bit) */
    MEM32(ebx + 0x14) = edi;
    if (CMP_BE(_fa, _fb)) goto loc_002DA946; /* jbe: below or equal (unsigned <=) */

loc_002DA985: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 4; return; /* ret */

}

/**
 * sub_002DA990
 * Original: 0x002DA990 - 0x002DAA54 (196 bytes, 50 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns float_sse
 * Frame: fpo_leaf
 */
void sub_002DA990(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DA990: ;
    _fb = (uint32_t)(0x24) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x24;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, esi);
    esi = ecx;
    eax = MEM32(esi + 0x794);
    _fa = (uint32_t)(MEM8(eax + 4)) & 0xFFu; _fb = (uint32_t)(0x12) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(eax + 4), 0x12 (8-bit) */
    PUSH32(esp, edi);
    edi = edx;
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DAA7B(); return; } /* je: equal / zero */

loc_002DA9A9: ;
    ecx = esp + 0x1C;
    PUSH32(esp, ecx);
    edx = esp + 0x10;
    PUSH32(esp, edx);
    PUSH32(esp, 0x002DA9B8u); RECOMP_ABI_CALL(0x002D9E50u, sub_002D9E50); /* call 0x002D9E50 */

loc_002DA9B8: ;
    eax = MEM32(esi + 8);
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(2) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test HI8(eax), 2 (8-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DAA08; /* jne: not equal / not zero */

loc_002DA9C0: ;
    eax = MEM32(esp + 0xC);
    ecx = MEM32(esp + 0x10);
    edx = MEM32(esp + 0x14);
    MEM32(edi + 4) = eax;
    eax = MEM32(esp + 0x18);
    MEM32(edi + 8) = ecx;
    ecx = MEM32(esp + 0x1C);
    MEM32(edi + 0xC) = edx;
    edx = MEM32(esp + 0x20);
    MEM32(edi + 0x10) = eax;
    eax = MEM32(esp + 0x24);
    MEM32(edi) = 0x100A20;
    MEM32(edi + 0x18) = ecx;
    ecx = MEM32(esp + 0x28);
    MEM32(edi + 0x14) = 0x100AF0;
    MEM32(edi + 0x1C) = edx;
    MEM32(edi + 0x20) = eax;
    MEM32(edi + 0x24) = ecx;
    _fb = (uint32_t)(0x28) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + 0x28;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DAA08: ;
    SET_LO8(ecx, MEM8(esi + 0x1C18));
    eax = 2;
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(LO8(ecx)) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(eax), LO8(ecx) (8-bit) */
    if (TEST_NZ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DAA6A(); return; } /* jne: not equal / not zero */

loc_002DAA17: ;
    _fa = (uint32_t)(MEM32(0x2E94EC)) & 0xFFFFFFFFu; _fb = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94EC), eax (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DAA54(); return; } /* jne: not equal / not zero */

loc_002DAA1F: ;
    fp_push(MEMF(esi + 0x944)); /* fld float */
    edx = MEM32(esi + 0x948);
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(esi + 0x93C)); /* fmul dword ptr [esi + 0x93c] */
    MEM32(esi + 0x1C14) = edx;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(esi + 0x948)); /* fmul dword ptr [esi + 0x948] */
    MEMF(esi + 0x1C10) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push(MEMF(esi + 0x1C14)); /* fld float */
    fp_push(MEMF(esi + 0x1C10)); /* fld float */
    g_seh_ebp = ebp; sub_002DAB60(); return; /* tail jmp 0x002DAB60 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002DAB80
 * Original: 0x002DAB80 - 0x002DABD9 (89 bytes, 27 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DAB80(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DAB80: ;
    eax = MEM32(0x2E9530);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    PUSH32(esp, esi);
    esi = 0x100001;
    if (CMP_EQ(_fa, _fb)) goto loc_002DAB94; /* je: equal / zero */

loc_002DAB8F: ;
    esi = 0x10100001;

loc_002DAB94: ;
    _fa = (uint32_t)(MEM32(0x2E94EC)) & 0xFFFFFFFFu; _fb = (uint32_t)(2) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94EC), 2 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DABA3; /* jne: not equal / not zero */

loc_002DAB9D: ;
    esi = esi | 0x10000;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DABA3: ;
    eax = MEM32(ecx + 0x1A08);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DABCB; /* je: equal / zero */

loc_002DABAD: ;
    eax = ZX8(MEM8(eax + 0xD));
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x2D) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x2D (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DABC5; /* je: equal / zero */

loc_002DABB6: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x2B) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x2B (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DABC5; /* je: equal / zero */

loc_002DABBB: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x31) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x31 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DABC5; /* je: equal / zero */

loc_002DABC0: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x2F) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x2F (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DABCB; /* jne: not equal / not zero */

loc_002DABC5: ;
    esi = esi | 0x1000;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DABCB: ;
    MEM32(edx) = 0x40290;
    MEM32(edx + 4) = esi;
    eax = edx + 8;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002DABE0
 * Original: 0x002DABE0 - 0x002DACAE (206 bytes, 47 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DABE0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DABE0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    edx = MEM32(esi + 0x2428);
    edx = edx & 0xFFFFFFF7u;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esi + 0x2428) = edx;
    ecx = MEM32(0x2E9544);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    eax = edx;
    if (CMP_EQ(_fa, _fb)) goto loc_002DAC0B; /* je: equal / zero */

loc_002DAC02: ;
    eax = eax | 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(esi + 0x2428) = eax;

loc_002DAC0B: ;
    edx = MEM32(esi + 0x242C);
    edx = edx & 0xE7EFFFFFu;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esi + 0x242C) = edx;
    ecx = MEM32(0x2E953C);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    eax = edx;
    if (CMP_EQ(_fa, _fb)) goto loc_002DAC34; /* je: equal / zero */

loc_002DAC29: ;
    eax = eax | 0x100000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(esi + 0x242C) = eax;

loc_002DAC34: ;
    eax = MEM32(0x2E9540);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DAC47; /* je: equal / zero */

loc_002DAC3D: ;
    MEM32(esi + 0x242C) = MEM32(esi + 0x242C) | 0x8000000;
    _fa = (uint32_t)(MEM32(esi + 0x242C)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DAC47: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DAC53; /* jb: below (unsigned <) */

loc_002DAC4E: ;
    PUSH32(esp, 0x002DAC53u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DAC53: ;
    MEM32(eax) = 0x40110;
    MEM32(eax + 4) = 0;
    ecx = MEM32(esi + 0x2428);
    MEM32(eax + 8) = 0x81D8C;
    MEM32(eax + 0xC) = 0x400094;
    MEM32(eax + 0x10) = ecx;
    MEM32(eax + 0x14) = 0x40100;
    edx = 9;
    MEM32(eax + 0x18) = edx;
    ecx = MEM32(esi + 0x242C);
    MEM32(eax + 0x1C) = 0x81D8C;
    MEM32(eax + 0x20) = 0x400B80;
    MEM32(eax + 0x24) = ecx;
    MEM32(eax + 0x28) = 0x40100;
    MEM32(eax + 0x2C) = edx;
    _fb = (uint32_t)(0x30) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x30;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002DACB0
 * Original: 0x002DACB0 - 0x002DAD08 (88 bytes, 25 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DACB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DACB0: ;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x10;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    esi = ecx;
    ebx = MEM32(esi + 0x1A04);
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 0x1A14)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, MEM32(esi + 0x1A14) (32-bit) */
    PUSH32(esp, edi);
    MEM32(esp + 0x18) = edx;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DAE18(); return; } /* jne: not equal / not zero */

loc_002DACCF: ;
    ecx = MEM32(esi + 0x970);
    eax = MEM32(esi + 0x96C);
    ebp = MEM32(0x2E9518);
    MEM32(esp + 0x14) = ecx;
    ecx = MEM32(esi + 0x1A18);
    MEM32(esp + 0x10) = eax;
    eax = MEM32(ecx + 0x10);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DAD08(); return; } /* jne: not equal / not zero */

loc_002DACF6: ;
    ecx = MEM32(ecx + 0xC);
    ecx = ecx >> 0x14;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx & 0xF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    eax = 1;
    eax = eax << LO8(ecx);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    g_seh_ebp = ebp; sub_002DAD0E(); return; /* tail jmp 0x002DAD0E */

}

/**
 * sub_002DB010
 * Original: 0x002DB010 - 0x002DB03C (44 bytes, 14 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB010(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DB010: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB023; /* jb: below (unsigned <) */

loc_002DB01E: ;
    PUSH32(esp, 0x002DB023u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB023: ;
    edx = MEM32(esp + 8);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DB03C(); return; } /* je: equal / zero */

loc_002DB02B: ;
    ecx = MEM32(esi + 0x1A08);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DB03C(); return; } /* je: equal / zero */

loc_002DB035: ;
    ecx = 1;
    g_seh_ebp = ebp; sub_002DB03E(); return; /* tail jmp 0x002DB03E */

}

/**
 * sub_002DB0A0
 * Original: 0x002DB0A0 - 0x002DB122 (130 bytes, 38 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB0A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DB0A0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0xC);
    MEM32(0x2E94F0) = edi;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB0BE; /* jb: below (unsigned <) */

loc_002DB0B9: ;
    PUSH32(esp, 0x002DB0BEu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB0BE: ;
    edx = MEM32(0x2E9538);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB0CF; /* je: equal / zero */

loc_002DB0CA: ;
    ecx = 2;

loc_002DB0CF: ;
    edx = MEM32(0x2E9534);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB0F2; /* je: equal / zero */

loc_002DB0D9: ;
    edx = MEM32(0x2E94F0);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB0EF; /* je: equal / zero */

loc_002DB0E3: ;
    _fa = (uint32_t)(MEM32(0x2E94F4)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x1E00) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94F4), 0x1E00 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DB0F2; /* jne: not equal / not zero */

loc_002DB0EF: ;
    ecx = ecx | 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB0F2: ;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0 (32-bit) */
    MEM32(eax) = 0x41D84;
    MEM32(eax + 4) = ecx;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DB122(); return; } /* je: equal / zero */

loc_002DB0FF: ;
    ecx = MEM32(esi + 0x1A08);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DB122(); return; } /* je: equal / zero */

loc_002DB109: ;
    MEM32(eax + 8) = 0x4032C;
    ecx = 1;
    MEM32(eax + 0xC) = ecx;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x10;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB140
 * Original: 0x002DB140 - 0x002DB1AF (111 bytes, 32 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB140(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB140: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0xC);
    MEM32(0x2E94F4) = edi;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB15E; /* jb: below (unsigned <) */

loc_002DB159: ;
    PUSH32(esp, 0x002DB15Eu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB15E: ;
    edx = MEM32(0x2E9538);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB16F; /* je: equal / zero */

loc_002DB16A: ;
    ecx = 2;

loc_002DB16F: ;
    edx = MEM32(0x2E9534);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB192; /* je: equal / zero */

loc_002DB179: ;
    edx = MEM32(0x2E94F0);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB18F; /* je: equal / zero */

loc_002DB183: ;
    _fa = (uint32_t)(MEM32(0x2E94F4)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x1E00) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94F4), 0x1E00 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DB192; /* jne: not equal / not zero */

loc_002DB18F: ;
    ecx = ecx | 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB192: ;
    MEM32(eax) = 0x41D84;
    MEM32(eax + 4) = ecx;
    MEM32(eax + 8) = 0x40370;
    MEM32(eax + 0xC) = edi;
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x10;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB1B0
 * Original: 0x002DB1B0 - 0x002DB1DB (43 bytes, 14 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB1B0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB1B0: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    MEM32(0x2E9530) = eax;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB1CC; /* jb: below (unsigned <) */

loc_002DB1C7: ;
    PUSH32(esp, 0x002DB1CCu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB1CC: ;
    edx = eax;
    ecx = esi;
    PUSH32(esp, 0x002DB1D5u); RECOMP_ABI_CALL(0x002DAB80u, sub_002DAB80); /* call 0x002DAB80 */

loc_002DB1D5: ;
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB1E0
 * Original: 0x002DB1E0 - 0x002DB242 (98 bytes, 28 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB1E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB1E0: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    MEM32(0x2E9534) = eax;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB1FC; /* jb: below (unsigned <) */

loc_002DB1F7: ;
    PUSH32(esp, 0x002DB1FCu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB1FC: ;
    edx = MEM32(0x2E9538);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB20D; /* je: equal / zero */

loc_002DB208: ;
    ecx = 2;

loc_002DB20D: ;
    edx = MEM32(0x2E9534);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB230; /* je: equal / zero */

loc_002DB217: ;
    edx = MEM32(0x2E94F0);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB22D; /* je: equal / zero */

loc_002DB221: ;
    _fa = (uint32_t)(MEM32(0x2E94F4)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x1E00) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94F4), 0x1E00 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DB230; /* jne: not equal / not zero */

loc_002DB22D: ;
    ecx = ecx | 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB230: ;
    MEM32(eax) = 0x41D84;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB250
 * Original: 0x002DB250 - 0x002DB2B2 (98 bytes, 28 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB250(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB250: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    MEM32(0x2E9538) = eax;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB26C; /* jb: below (unsigned <) */

loc_002DB267: ;
    PUSH32(esp, 0x002DB26Cu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB26C: ;
    edx = MEM32(0x2E9538);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB27D; /* je: equal / zero */

loc_002DB278: ;
    ecx = 2;

loc_002DB27D: ;
    edx = MEM32(0x2E9534);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB2A0; /* je: equal / zero */

loc_002DB287: ;
    edx = MEM32(0x2E94F0);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB29D; /* je: equal / zero */

loc_002DB291: ;
    _fa = (uint32_t)(MEM32(0x2E94F4)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x1E00) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94F4), 0x1E00 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DB2A0; /* jne: not equal / not zero */

loc_002DB29D: ;
    ecx = ecx | 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB2A0: ;
    MEM32(eax) = 0x41D84;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB2C0
 * Original: 0x002DB2C0 - 0x002DB2D1 (17 bytes, 4 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB2C0(void)
{

loc_002DB2C0: ;
    eax = MEM32(esp + 4);
    MEM32(0x2E953C) = eax;
    PUSH32(esp, 0x002DB2CEu); RECOMP_ABI_CALL(0x002DABE0u, sub_002DABE0); /* call 0x002DABE0 */

loc_002DB2CE: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB2E0
 * Original: 0x002DB2E0 - 0x002DB2F1 (17 bytes, 4 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB2E0(void)
{

loc_002DB2E0: ;
    eax = MEM32(esp + 4);
    MEM32(0x2E9540) = eax;
    PUSH32(esp, 0x002DB2EEu); RECOMP_ABI_CALL(0x002DABE0u, sub_002DABE0); /* call 0x002DABE0 */

loc_002DB2EE: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB300
 * Original: 0x002DB300 - 0x002DB311 (17 bytes, 4 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB300(void)
{

loc_002DB300: ;
    eax = MEM32(esp + 4);
    MEM32(0x2E9544) = eax;
    PUSH32(esp, 0x002DB30Eu); RECOMP_ABI_CALL(0x002DABE0u, sub_002DABE0); /* call 0x002DABE0 */

loc_002DB30E: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB320
 * Original: 0x002DB320 - 0x002DB347 (39 bytes, 9 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB320(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB320: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    MEM32(0x2E9518) = eax;
    edx = MEM32(ecx + 0x1A04);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ecx + 0x1A14)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, MEM32(ecx + 0x1A14) (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DB344; /* jne: not equal / not zero */

loc_002DB33D: ;
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, 0x002DB344u); RECOMP_ABI_CALL(0x002DACB0u, sub_002DACB0); /* call 0x002DACB0 */

loc_002DB344: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB350
 * Original: 0x002DB350 - 0x002DB377 (39 bytes, 9 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB350(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB350: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    MEM32(0x2E951C) = eax;
    edx = MEM32(ecx + 0x1A04);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ecx + 0x1A14)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, MEM32(ecx + 0x1A14) (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB374; /* je: equal / zero */

loc_002DB36D: ;
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, 0x002DB374u); RECOMP_ABI_CALL(0x002DACB0u, sub_002DACB0); /* call 0x002DACB0 */

loc_002DB374: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB380
 * Original: 0x002DB380 - 0x002DB3F2 (114 bytes, 37 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB380(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB380: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    PUSH32(esp, edi);
    ecx = esi;
    MEM32(0x2E9510) = eax;
    PUSH32(esp, 0x002DB398u); RECOMP_ABI_CALL(0x002DD2C0u, sub_002DD2C0); /* call 0x002DD2C0 */

loc_002DB398: ;
    edi = MEM32(0x2E9514);
    ecx = MEM32(0x2E9528);
    eax = MEM32(esi + 8);
    edi = edi << 0x10;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edi = edi | ecx;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp HI8(eax), 0 (8-bit) */
    if ((((uint8_t)((uint8_t)(_fa) - (uint8_t)(_fb)) >> 7) == 0)) goto loc_002DB3BC; /* jns: not sign (positive) */

loc_002DB3B0: ;
    eax = MEM32(0x2E9510);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB3BC; /* je: equal / zero */

loc_002DB3B9: ;
    edi = edi | 1;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB3BC: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB3C8; /* jb: below (unsigned <) */

loc_002DB3C3: ;
    PUSH32(esp, 0x002DB3C8u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB3C8: ;
    MEM32(eax) = 0x41D7C;
    MEM32(eax + 4) = edi;
    ecx = MEM32(esi + 4);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    MEM32(esi) = eax;
    if (CMP_B(_fa, _fb)) goto loc_002DB3E2; /* jb: below (unsigned <) */

loc_002DB3DD: ;
    PUSH32(esp, 0x002DB3E2u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB3E2: ;
    edx = eax;
    ecx = esi;
    PUSH32(esp, 0x002DB3EBu); RECOMP_ABI_CALL(0x002DA990u, sub_002DA990); /* call 0x002DA990 */

loc_002DB3EB: ;
    POP32(esp, edi);
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB400
 * Original: 0x002DB400 - 0x002DB450 (80 bytes, 27 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB400(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB400: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9528);
    MEM32(0x2E9514) = eax;
    eax = eax << 0x10;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = eax | ecx;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    PUSH32(esp, edi);
    edi = eax;
    eax = MEM32(esi + 8);
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp HI8(eax), 0 (8-bit) */
    if ((((uint8_t)((uint8_t)(_fa) - (uint8_t)(_fb)) >> 7) == 0)) goto loc_002DB431; /* jns: not sign (positive) */

loc_002DB425: ;
    eax = MEM32(0x2E9510);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB431; /* je: equal / zero */

loc_002DB42E: ;
    edi = edi | 1;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB431: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB43D; /* jb: below (unsigned <) */

loc_002DB438: ;
    PUSH32(esp, 0x002DB43Du); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB43D: ;
    MEM32(eax) = 0x41D7C;
    MEM32(eax + 4) = edi;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    POP32(esp, edi);
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB450
 * Original: 0x002DB450 - 0x002DB49E (78 bytes, 26 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB450(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB450: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9514);
    esi = esi << 0x10;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, edi);
    edi = MEM32(0x2E9548);
    esi = esi | eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(0x2E9528) = eax;
    eax = MEM32(edi + 8);
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* cmp HI8(eax), 0 (8-bit) */
    if ((((uint8_t)((uint8_t)(_fa) - (uint8_t)(_fb)) >> 7) == 0)) goto loc_002DB47F; /* jns: not sign (positive) */

loc_002DB473: ;
    eax = MEM32(0x2E9510);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB47F; /* je: equal / zero */

loc_002DB47C: ;
    esi = esi | 1;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DB47F: ;
    eax = MEM32(edi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(edi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(edi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB48B; /* jb: below (unsigned <) */

loc_002DB486: ;
    PUSH32(esp, 0x002DB48Bu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB48B: ;
    MEM32(eax) = 0x41D7C;
    MEM32(eax + 4) = esi;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(edi) = eax;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DB4A0
 * Original: 0x002DB4A0 - 0x002DB4C7 (39 bytes, 11 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB4A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DB4A0: ;
    eax = MEM32(0x2E9548);
    ecx = MEM32(eax + 0x784);
    MEM32(edx) = ecx;
    eax = MEM32(eax + 0x798);
    MEM32(edx + 4) = eax;
    ecx = MEM32(0x2E9160);
    MEM32(edx + 8) = ecx;
    ecx = edx + 0x14;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, esi);
    g_seh_ebp = ebp; sub_002DB4D0(); return; /* tail jmp 0x002DB4D0 */

}

/**
 * sub_002DB720
 * Original: 0x002DB720 - 0x002DB837 (279 bytes, 75 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB720(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DB720: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(0x2E9548);
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    /* nop */

loc_002DB730: ;
    eax = MEM32(esi + 0x2E7268);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x5C) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x5C (32-bit) */
    ecx = MEM32(esi + 0x2E726C);
    if (CMP_GE(_fas, _fbs)) goto loc_002DB74D; /* jge: greater or equal (signed >=) */

loc_002DB741: ;
    edx = MEM32(0x2E9548);
    _fa = (uint32_t)(MEM8(edx + 8)) & 0xFFu; _fb = (uint32_t)(0x10) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(edx + 8), 0x10 (8-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DB756; /* jne: not equal / not zero */

loc_002DB74D: ;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(eax * 4 + 0x2E92B0)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, MEM32(eax * 4 + 0x2E92B0) (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB75D; /* je: equal / zero */

loc_002DB756: ;
    PUSH32(esp, ecx);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DB75Du); RECOMP_ABI_CALL(0x002D9DF0u, sub_002D9DF0); /* call 0x002D9DF0 */

loc_002DB75D: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 8;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0xA0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0xA0 (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB730; /* jb: below (unsigned <) */

loc_002DB768: ;
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    /* nop */

loc_002DB770: ;
    ecx = MEM32(esi + 0x2E7210);
    eax = MEM32(esi + 0x2E7214);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ecx * 4 + 0x2E90B0)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(ecx * 4 + 0x2E90B0) (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB78E; /* je: equal / zero */

loc_002DB785: ;
    PUSH32(esp, eax);
    PUSH32(esp, ecx);
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DB78Eu); RECOMP_ABI_CALL(0x002DA830u, sub_002DA830); /* call 0x002DA830 */

loc_002DB78E: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 8;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0x58) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0x58 (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB770; /* jb: below (unsigned <) */

loc_002DB796: ;
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DB79Du); RECOMP_ABI_CALL(0x002DD590u, sub_002DD590); /* call 0x002DD590 */

loc_002DB79D: ;
    esi = MEM32(0x2E94A8);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(0x2E90C0)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, MEM32(0x2E90C0) (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB7B5; /* je: equal / zero */

loc_002DB7AB: ;
    PUSH32(esp, esi);
    PUSH32(esp, 4);
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DB7B5u); RECOMP_ABI_CALL(0x002DA830u, sub_002DA830); /* call 0x002DA830 */

loc_002DB7B5: ;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(0x2E90BC)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, MEM32(0x2E90BC) (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB7C7; /* je: equal / zero */

loc_002DB7BD: ;
    PUSH32(esp, esi);
    PUSH32(esp, 3);
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DB7C7u); RECOMP_ABI_CALL(0x002DA830u, sub_002DA830); /* call 0x002DA830 */

loc_002DB7C7: ;
    _fa = (uint32_t)(MEM32(0x2E9160)) & 0xFFFFFFFFu; _fb = (uint32_t)(1) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E9160), 1 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DB7DB; /* je: equal / zero */

loc_002DB7D0: ;
    PUSH32(esp, 1);
    PUSH32(esp, 0xC);
    PUSH32(esp, 1);
    PUSH32(esp, 0x002DB7DBu); RECOMP_ABI_CALL(0x002DA830u, sub_002DA830); /* call 0x002DA830 */

loc_002DB7DB: ;
    PUSH32(esp, 0x002DB7E0u); RECOMP_ABI_CALL(0x002E4700u, sub_002E4700); /* call 0x002E4700 */

loc_002DB7E0: ;
    PUSH32(esp, 8);
    PUSH32(esp, 0x2E7308);
    PUSH32(esp, 0x002DB7ECu); RECOMP_ABI_CALL(0x002DD260u, sub_002DD260); /* call 0x002DD260 */

loc_002DB7EC: ;
    eax = MEM32(edi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(edi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(edi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DB7F8; /* jb: below (unsigned <) */

loc_002DB7F3: ;
    PUSH32(esp, 0x002DB7F8u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DB7F8: ;
    MEM32(eax) = 0x81E94;
    MEM32(eax + 4) = 6;
    MEM32(eax + 8) = 0;
    MEM32(eax + 0xC) = 0x41EA0;
    MEM32(eax + 0x10) = 0;
    MEM32(eax + 0x14) = 0x80394;
    MEM32(eax + 0x18) = 0;
    MEM32(eax + 0x1C) = 0x4B7FFFFF;
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x20;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(edi) = eax;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002DB9C0
 * Original: 0x002DB9C0 - 0x002DB9FA (58 bytes, 17 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DB9C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DB9C0: ;
    PUSH32(esp, ebx);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = eax;
    eax = MEM32(edi + 0x1A04);
    PUSH32(esp, eax);
    MEM32(edi + 0x1A90) = eax;
    PUSH32(esp, 0x002DB9D7u); RECOMP_ABI_CALL(0x002DE620u, sub_002DE620); /* call 0x002DE620 */

loc_002DB9D7: ;
    eax = MEM32(edi + 0x1A08);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(edi + 0x1A94) = eax;
    if (CMP_EQ(_fa, _fb)) goto loc_002DB9ED; /* je: equal / zero */

loc_002DB9E7: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DB9EDu); RECOMP_ABI_CALL(0x002DE620u, sub_002DE620); /* call 0x002DE620 */

loc_002DB9ED: ;
    esi = edi + 0x1A98;
    ebx = 4;
    g_seh_ebp = ebp; sub_002DBA00(); return; /* tail jmp 0x002DBA00 */

}

/**
 * sub_002DBC40
 * Original: 0x002DBC40 - 0x002DBD73 (307 bytes, 88 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DBC40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DBC40: ;
    _fb = (uint32_t)(0x170) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x170;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    SET_LO8(ebx, MEM8(esp + 0x178));
    PUSH32(esp, ebp);
    ebp = 0; /* xor self */
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(3) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 3 (8-bit) */
    PUSH32(esp, edi);
    edi = 0x40100;
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DBD91(); return; } /* je: equal / zero */

loc_002DBC60: ;
    _fa = (uint32_t)(MEM32(esi + 0x1A10)) & 0xFFFFFFFFu; _fb = (uint32_t)(3) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(esi + 0x1A10), 3 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DBC99; /* jne: not equal / not zero */

loc_002DBC69: ;
    eax = MEM32(esi + 0x1A18);
    ecx = MEM32(esi + 0x1A1C);
    ebx = MEM32(eax + 4);
    edx = MEM32(ecx + 4);
    edi = MEM32(ecx + 8);
    MEM32(ecx + 4) = ebx;
    ebx = MEM32(eax + 8);
    MEM32(ecx + 8) = ebx;
    SET_LO8(ebx, MEM8(esp + 0x180));
    MEM32(eax + 8) = edi;
    MEM32(eax + 4) = edx;
    edi = 0x40100;

loc_002DBC99: ;
    eax = esi;
    PUSH32(esp, 0x002DBCA0u); RECOMP_ABI_CALL(0x002DB9C0u, sub_002DB9C0); /* call 0x002DB9C0 */

loc_002DBCA0: ;
    eax = MEM32(esi + 0x1A18);
    PUSH32(esp, ebp);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DBCADu); RECOMP_ABI_CALL(0x002D8800u, sub_002D8800); /* call 0x002D8800 */

loc_002DBCAD: ;
    ecx = MEM32(esi + 0x1A14);
    PUSH32(esp, ecx);
    PUSH32(esp, ebp);
    PUSH32(esp, 0x002DBCBAu); RECOMP_ABI_CALL(0x002D9050u, sub_002D9050); /* call 0x002D9050 */

loc_002DBCBA: ;
    PUSH32(esp, ebp);
    PUSH32(esp, 1);
    PUSH32(esp, 0x002DBCC2u); RECOMP_ABI_CALL(0x002D9050u, sub_002D9050); /* call 0x002D9050 */

loc_002DBCC2: ;
    PUSH32(esp, ebp);
    PUSH32(esp, 2);
    PUSH32(esp, 0x002DBCCAu); RECOMP_ABI_CALL(0x002D9050u, sub_002D9050); /* call 0x002D9050 */

loc_002DBCCA: ;
    PUSH32(esp, ebp);
    PUSH32(esp, 3);
    PUSH32(esp, 0x002DBCD2u); RECOMP_ABI_CALL(0x002D9050u, sub_002D9050); /* call 0x002D9050 */

loc_002DBCD2: ;
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 1 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DBCE5; /* je: equal / zero */

loc_002DBCD7: ;
    edx = esp + 0xC;
    PUSH32(esp, 0x002DBCE0u); RECOMP_ABI_CALL(0x002DB4A0u, sub_002DB4A0); /* call 0x002DB4A0 */

loc_002DBCE0: ;
    PUSH32(esp, 0x002DBCE5u); RECOMP_ABI_CALL(0x002DB720u, sub_002DB720); /* call 0x002DB720 */

loc_002DBCE5: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DBCF1; /* jb: below (unsigned <) */

loc_002DBCEC: ;
    PUSH32(esp, 0x002DBCF1u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DBCF1: ;
    _fa = (uint32_t)(MEM32(esi + 0x1A10)) & 0xFFFFFFFFu; _fb = (uint32_t)(3) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(esi + 0x1A10), 3 (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DBD73(); return; } /* jae: above or equal (unsigned >=) */

loc_002DBCFA: ;
    _fa = (uint32_t)(MEM32(0x2E94AC)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x80000000u) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(0x2E94AC), 0x80000000u (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DBD12; /* je: equal / zero */

loc_002DBD06: ;
    MEM32(eax) = 0x40110;
    MEM32(eax + 4) = ebp;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DBD12: ;
    edx = MEM32(esi + 0x1A18);
    ecx = MEM32(edx + 4);
    edx = MEM32(0x2E94AC);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(ebp) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, ebp (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DBD2A; /* jne: not equal / not zero */

loc_002DBD25: ;
    edx = 1;

loc_002DBD2A: ;
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 1 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DBD32; /* je: equal / zero */

loc_002DBD2F: ;
    ecx = ecx | 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DBD32: ;
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(2) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 2 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DBD3A; /* je: equal / zero */

loc_002DBD37: ;
    ecx = ecx | 2;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DBD3A: ;
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(4) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 4 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DBD42; /* je: equal / zero */

loc_002DBD3F: ;
    ecx = ecx | 3;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DBD42: ;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if ((((uint32_t)((uint32_t)(_fa) - (uint32_t)(_fb)) >> 31) == 0)) goto loc_002DBD49; /* jns: not sign (positive) */

loc_002DBD46: ;
    ecx = ecx | 8;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */

loc_002DBD49: ;
    MEM32(eax) = edi;
    ecx = ecx << 5;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx | 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(eax + 4) = ecx;
    MEM32(eax + 8) = 0x4012C;
    MEM32(eax + 0xC) = ebp;
    MEM32(eax + 0x10) = edi;
    MEM32(eax + 0x14) = ebp;
    MEM32(eax + 0x18) = 0x40130;
    MEM32(eax + 0x1C) = ebp;
    _fb = (uint32_t)(0x20) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x20;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002DBD8F(); return; /* tail jmp 0x002DBD8F */

}

/**
 * sub_002DBF80
 * Original: 0x002DBF80 - 0x002DBFF5 (117 bytes, 38 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DBF80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DBF80: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi + 0x8D4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DBF9B; /* jne: not equal / not zero */

loc_002DBF91: ;
    eax = MEM32(esi + 0x8D8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DBFA0; /* je: equal / zero */

loc_002DBF9B: ;
    PUSH32(esp, 0x002DBFA0u); RECOMP_ABI_CALL(0x002E4970u, sub_002E4970); /* call 0x002E4970 */

loc_002DBFA0: ;
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 0xC);
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, 0 (32-bit) */
    PUSH32(esp, edi);
    if (CMP_NE(_fa, _fb)) goto loc_002DBFAF; /* jne: not equal / not zero */

loc_002DBFAA: ;
    ebx = 5;

loc_002DBFAF: ;
    eax = MEM32(esi + 8);
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0x40) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test HI8(eax), 0x40 (8-bit) */
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DBFF5(); return; } /* je: equal / zero */

loc_002DBFB7: ;
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(3) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 3 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DBFE6; /* je: equal / zero */

loc_002DBFBC: ;
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DBFC3u); RECOMP_ABI_CALL(0x002DE000u, sub_002DE000); /* call 0x002DE000 */

loc_002DBFC3: ;
    eax = MEM32(esi + 0x2478);
    eax--;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    eax = eax & 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    eax = MEM32(esi + eax * 4 + 0x1974);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DBFE0; /* je: equal / zero */

loc_002DBFD8: ;
    PUSH32(esp, 1);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DBFE0u); RECOMP_ABI_CALL(0x002DE0C0u, sub_002DE0C0); /* call 0x002DE0C0 */

loc_002DBFE0: ;
    MEM32(esi + 0x2478) = MEM32(esi + 0x2478) + 1;
    _fa = (uint32_t)(MEM32(esi + 0x2478)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x80000000u); /* inc result/SF/OF; CF unchanged */

loc_002DBFE6: ;
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002DBFECu); RECOMP_ABI_CALL(0x002DBC40u, sub_002DBC40); /* call 0x002DBC40 */

loc_002DBFEC: ;
    edi = ebx;
    edi = edi & 4;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    if ((_fa == 0)) { g_seh_ebp = ebp; sub_002DC030(); return; } /* je: equal / zero */

loc_002DBFF3: ;
    g_seh_ebp = ebp; sub_002DC02B(); return; /* tail jmp 0x002DC02B */

}

/**
 * sub_002DC070
 * Original: 0x002DC070 - 0x002DC117 (167 bytes, 47 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC070(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DC070: ;
    PUSH32(esp, ecx);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi + 0x196C);
    ecx = eax;
    ecx = ecx >> 4;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx & 0xF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    MEM32(esp + 4) = ecx;
    fp_push((double)SMEM32(esp + 4)); /* fild */
    if (CMP_GE(_fas, _fbs)) goto loc_002DC098; /* jge: greater or equal (signed >=) */

loc_002DC092: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002DC098: ;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(esp + 0xC)); /* fmul dword ptr [esp + 0xc] */
    eax = eax & 0xF;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(esp + 4) = eax;
    MEMF(esp + 0xC) = (float)fp_top(); fp_pop(); /* fstp */
    fp_push((double)SMEM32(esp + 4)); /* fild */
    if (CMP_GE(_fas, _fbs)) goto loc_002DC0B5; /* jge: greater or equal (signed >=) */

loc_002DC0AF: ;
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FEC08)); /* fadd dword ptr [0x2fec08] */

loc_002DC0B5: ;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(esp + 0x10)); /* fmul dword ptr [esp + 0x10] */
    eax = MEM32(esi + 0x1970);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(3) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 3 (32-bit) */
    MEMF(esp + 0x10) = (float)fp_top(); fp_pop(); /* fstp */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DC152(); return; } /* je: equal / zero */

loc_002DC0CC: ;
    fp_push(MEMF(0x2FE99C)); /* fld float */
    fp_push(MEMF(esp + 0xC)); /* fld float */
    g_fp_cmp = RECOMP_FCMP(fp_top(), fp_st1()); g_fp_cc = RECOMP_FCMP_CC(g_fp_cmp); fp_pop(); fp_pop(); /* fucompp  */
    eax = (eax & 0xFFFF0000u) | (uint32_t)(uint16_t)(((g_fp_top & 7u) << 11) | g_fp_cc); /* fnstsw ax <- fpu status */
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0x44) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test HI8(eax), 0x44 (8-bit) */
    if (RECOMP_PARITY8((_fa) & (_fb))) { g_seh_ebp = ebp; sub_002DC117(); return; } /* jp: parity */

loc_002DC0DF: ;
    fp_push(MEMF(0x2FE99C)); /* fld float */
    fp_push(MEMF(esp + 0x10)); /* fld float */
    g_fp_cmp = RECOMP_FCMP(fp_top(), fp_st1()); g_fp_cc = RECOMP_FCMP_CC(g_fp_cmp); fp_pop(); fp_pop(); /* fucompp  */
    eax = (eax & 0xFFFF0000u) | (uint32_t)(uint16_t)(((g_fp_top & 7u) << 11) | g_fp_cc); /* fnstsw ax <- fpu status */
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0x44) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test HI8(eax), 0x44 (8-bit) */
    if (RECOMP_PARITY8((_fa) & (_fb))) { g_seh_ebp = ebp; sub_002DC117(); return; } /* jp: parity */

loc_002DC0F2: ;
    eax = MEM32(esi + 0x1A18);
    ecx = MEM32(esi + 0x1A14);
    edx = MEM32(ecx + 0x10);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(eax + 0x10)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, MEM32(eax + 0x10) (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DC152(); return; } /* jne: not equal / not zero */

loc_002DC106: ;
    ecx = MEM32(ecx + 0xC);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(eax + 0xC)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, MEM32(eax + 0xC) (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DC152(); return; } /* jne: not equal / not zero */

loc_002DC10E: ;
    MEM32(esi + 8) = MEM32(esi + 8) & 0xFFFFBFFFu;
    _fa = (uint32_t)(MEM32(esi + 8)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    g_seh_ebp = ebp; sub_002DC152(); return; /* tail jmp 0x002DC152 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002DC240
 * Original: 0x002DC240 - 0x002DC2C6 (134 bytes, 49 insns)
 * Category: game_render
 * CC: cdecl, 7 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC240(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DC240: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    eax = esp + 0x20;
    PUSH32(esp, eax);
    eax = MEM32(esp + 0x28);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(4) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 4 (32-bit) */
    SET_LO8(edx, (CMP_EQ(_fa, _fb)) ? 1 : 0); /* sete */
    ecx = esp + 0x28;
    PUSH32(esp, ecx);
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(5) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 5 (32-bit) */
    eax = MEM32(esp + 0x20);
    SET_LO8(ecx, (CMP_EQ(_fa, _fb)) ? 1 : 0); /* sete */
    PUSH32(esp, edx);
    edx = MEM32(esp + 0x2C);
    PUSH32(esp, ecx);
    ecx = MEM32(esp + 0x24);
    PUSH32(esp, 0);
    PUSH32(esp, edx);
    edx = MEM32(esp + 0x28);
    PUSH32(esp, eax);
    eax = MEM32(esp + 0x28);
    PUSH32(esp, ecx);
    PUSH32(esp, edx);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DC282u); RECOMP_ABI_CALL(0x002E1530u, sub_002E1530); /* call 0x002E1530 */

loc_002DC282: ;
    edi = eax;
    _fa = (uint32_t)(MEM32(esp + 0x1C)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x10000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test MEM32(esp + 0x1C), 0x10000 (32-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DC293; /* je: equal / zero */

loc_002DC28E: ;
    MEM32(esp + 0x24) = MEM32(esp + 0x24) & 0xFFFFFFF7u;
    _fa = (uint32_t)(MEM32(esp + 0x24)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */

loc_002DC293: ;
    PUSH32(esp, 0x64800000);
    PUSH32(esp, 0x14);
    PUSH32(esp, 0x002DC29Fu); RECOMP_ABI_CALL(0x001F093Cu, sub_001F093C); /* call 0x001F093C */

loc_002DC29F: ;
    esi = eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DC2BF; /* je: equal / zero */

loc_002DC2A5: ;
    PUSH32(esp, 0xB7800000u);
    PUSH32(esp, edi);
    PUSH32(esp, 0x002DC2B0u); RECOMP_ABI_CALL(0x001F093Cu, sub_001F093C); /* call 0x001F093C */

loc_002DC2B0: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DC2C6(); return; } /* jne: not equal / not zero */

loc_002DC2B4: ;
    PUSH32(esp, 0x24800000);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DC2BFu); RECOMP_ABI_CALL(0x001F09DCu, sub_001F09DC); /* call 0x001F09DC */

loc_002DC2BF: ;
    POP32(esp, edi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    POP32(esp, esi);
    esp += 32; return; /* ret 28 */

}

/**
 * sub_002DC2F0
 * Original: 0x002DC2F0 - 0x002DC2F5 (5 bytes, 1 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC2F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DC2F0: ;
    g_seh_ebp = ebp; sub_002E11A0(); return; /* tail jmp 0x002E11A0 */

}

/**
 * sub_002DC300
 * Original: 0x002DC300 - 0x002DC34A (74 bytes, 29 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC300(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DC300: ;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, esi);
    esi = MEM32(esp + 0x14);
    eax = esp + 0x14;
    PUSH32(esp, eax);
    ecx = esp + 8;
    PUSH32(esp, ecx);
    edx = esp + 0x10;
    PUSH32(esp, edx);
    edx = MEM32(esp + 0x24);
    eax = esp + 0x18;
    PUSH32(esp, eax);
    ecx = esp + 0x28;
    PUSH32(esp, ecx);
    PUSH32(esp, edx);
    PUSH32(esp, 0);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DC32Eu); RECOMP_ABI_CALL(0x002E1260u, sub_002E1260); /* call 0x002E1260 */

loc_002DC32E: ;
    eax = MEM32(esp + 0x18);
    ecx = MEM32(esp + 0x14);
    edx = MEM32(esp + 4);
    PUSH32(esp, eax);
    PUSH32(esp, esi);
    PUSH32(esp, ecx);
    PUSH32(esp, edx);
    PUSH32(esp, 0x002DC343u); RECOMP_ABI_CALL(0x002DE880u, sub_002DE880); /* call 0x002DE880 */

loc_002DC343: ;
    POP32(esp, esi);
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0xC;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DC350
 * Original: 0x002DC350 - 0x002DC6EF (927 bytes, 264 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC350(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    #define fp_push(v) do { double _fp_value = (v); \
        g_fp_top = (g_fp_top + 7u) & 7u; \
        g_fp_stack[g_fp_top] = _fp_value; } while (0)
    #define fp_pop() (g_fp_top = (g_fp_top + 1u) & 7u)
    #define fp_top() g_fp_stack[g_fp_top]
    #define fp_st(i) g_fp_stack[(g_fp_top + (i)) & 7u]
    #define fp_st1() fp_st(1)
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DC350: ;
    _fb = (uint32_t)(0x38) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 0x38;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = MEM32(0x2E9548);
    ebx = MEM32(ebp + 0x1A08);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(ebp + 0x1A04);
    eax = ZX8(MEM8(edi + 0xD));
    SET_LO8(ecx, MEM8(eax + 0x2E7108));
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(LO8(ecx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ecx), 1 (8-bit) */
    MEM32(esp + 0x10) = esi;
    MEM32(esp + 0x20) = esi;
    if (TEST_Z(_fa, _fb)) goto loc_002DC3BB; /* je: equal / zero */

loc_002DC382: ;
    PUSH32(esp, ebx);
    PUSH32(esp, edi);
    PUSH32(esp, 0x002DC389u); RECOMP_ABI_CALL(0x002E0EC0u, sub_002E0EC0); /* call 0x002E0EC0 */

loc_002DC389: ;
    ecx = MEM32(ebp + 4);
    esi = eax;
    esi = esi & 0xFFFFFDFFu;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esp + 0x20) = eax;
    eax = MEM32(ebp);
    esi = esi | 0x100;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DC3AA; /* jb: below (unsigned <) */

loc_002DC3A5: ;
    PUSH32(esp, 0x002DC3AAu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DC3AA: ;
    MEM32(eax) = 0x40208;
    MEM32(eax + 4) = esi;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ebp) = eax;
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */

loc_002DC3BB: ;
    edx = MEM32(esp + 0x54);
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(0xF0) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 0xF0 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DC425; /* je: equal / zero */

loc_002DC3C4: ;
    eax = ZX8(MEM8(edi + 0xD));
    _fb = (uint32_t)(0xFFFFFFFDu) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xFFFFFFFDu;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x19) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x19 (32-bit) */
    if (CMP_A(_fa, _fb)) goto loc_002DC425; /* ja: above (unsigned >) */

loc_002DC3D0: ;
    ecx = ZX8(MEM8(eax + 0x2DC6FC));
    { uint32_t _jt = MEM32(ecx * 4 + 0x2DC6F0); /* switch: 3 entries, 3 targets */
    if (_jt == 0x002DC3DEu) goto loc_002DC3DE;
    if (_jt == 0x002DC3FBu) goto loc_002DC3FB;
    if (_jt == 0x002DC425u) goto loc_002DC425;
    g_seh_ebp = ebp; RECOMP_ITAIL(_jt); return; }

loc_002DC3DE: ;
    ecx = MEM32(esp + 0x58);
    eax = ecx;
    eax = eax >> 3;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edi = ecx;
    eax = eax & 0x1F0000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edi = edi & 0xFC00;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    eax = eax | edi;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    eax = eax >> 2;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    goto loc_002DC416;

loc_002DC3FB: ;
    ecx = MEM32(esp + 0x58);
    eax = ecx;
    eax = eax >> 3;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edi = ecx;
    eax = eax & 0x1F0000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edi = edi & 0xF800;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    eax = eax | edi;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    eax = eax >> 3;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */

loc_002DC416: ;
    ecx = ecx & 0xF8;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    eax = eax | ecx;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    eax = eax >> 3;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(esp + 0x58) = eax;

loc_002DC425: ;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebx, esi (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DC436; /* jne: not equal / not zero */

loc_002DC429: ;
    edx = edx & 0xFFFFFFFCu;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esp + 0x54) = edx;
    if ((_fa == 0)) goto loc_002DC6E5; /* je: equal / zero */

loc_002DC436: ;
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 1 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DC523; /* je: equal / zero */

loc_002DC43F: ;
    edx = ZX8(MEM8(ebx + 0xD));
    _fb = (uint32_t)(0x2A) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    edx = edx - 0x2A;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    { uint32_t _jt = MEM32(edx * 4 + 0x2DC718); /* switch: 8 entries, 4 targets */
    if (_jt == 0x002DC44Du) goto loc_002DC44D;
    if (_jt == 0x002DC47Fu) goto loc_002DC47F;
    if (_jt == 0x002DC4B1u) goto loc_002DC4B1;
    if (_jt == 0x002DC4E9u) goto loc_002DC4E9;
    g_seh_ebp = ebp; RECOMP_ITAIL(_jt); return; }

loc_002DC44D: ;
    fp_push(MEMF(esp + 0x5C)); /* fld float */
    PUSH32(esp, ecx);
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x305F94)); /* fmul dword ptr [0x305f94] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DC460u); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DC460: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xFFFF (32-bit) */
    if (CMP_LE(_fas, _fbs)) goto loc_002DC46C; /* jle: less or equal (signed <=) */

loc_002DC467: ;
    eax = 0xFFFF;

loc_002DC46C: ;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    SET_LO8(ecx, (CMP_L(_fas, _fbs)) ? 1 : 0); /* setl */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    ecx = ecx & eax;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esp + 0x10) = ecx;
    goto loc_002DC523;

loc_002DC47F: ;
    fp_push(MEMF(esp + 0x5C)); /* fld float */
    PUSH32(esp, ecx);
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(0x33CD90)); /* fmul dword ptr [0x33cd90] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DC492u); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DC492: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFFFF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0xFFFFFF (32-bit) */
    if (CMP_LE(_fas, _fbs)) goto loc_002DC49E; /* jle: less or equal (signed <=) */

loc_002DC499: ;
    eax = 0xFFFFFF;

loc_002DC49E: ;
    edx = 0; /* xor self */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    SET_LO8(edx, (CMP_L(_fas, _fbs)) ? 1 : 0); /* setl */
    edx--;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    edx = edx & eax;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edx = edx << 8;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(esp + 0x10) = edx;
    goto loc_002DC523;

loc_002DC4B1: ;
    fp_push(MEMF(0x3210B0)); /* fld float */
    fp_push(MEMF(esp + 0x5C)); /* fld float */
    g_fp_cmp = RECOMP_FCMP(fp_top(), fp_st1()); g_fp_cc = RECOMP_FCMP_CC(g_fp_cmp); fp_pop(); fp_pop(); /* fucompp  */
    eax = (eax & 0xFFFF0000u) | (uint32_t)(uint16_t)(((g_fp_top & 7u) << 11) | g_fp_cc); /* fnstsw ax <- fpu status */
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0x44) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test HI8(eax), 0x44 (8-bit) */
    if ((!RECOMP_PARITY8((_fa) & (_fb)))) goto loc_002DC51F; /* jnp: not parity */

loc_002DC4C4: ;
    fp_push(MEMF(esp + 0x5C)); /* fld float */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMD(0x33CD88)); /* fmul qword ptr [0x33cd88] */
    MEMD(esp + 0x30) = fp_top(); fp_pop(); /* fstp */
    eax = MEM32(esp + 0x34);
    eax = eax >> 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x8000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - 0x8000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    eax = eax & 0xFFFF;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(esp + 0x10) = eax;
    goto loc_002DC523;

loc_002DC4E9: ;
    fp_push(MEMF(0x3210B0)); /* fld float */
    fp_push(MEMF(esp + 0x5C)); /* fld float */
    g_fp_cmp = RECOMP_FCMP(fp_top(), fp_st1()); g_fp_cc = RECOMP_FCMP_CC(g_fp_cmp); fp_pop(); fp_pop(); /* fucompp  */
    eax = (eax & 0xFFFF0000u) | (uint32_t)(uint16_t)(((g_fp_top & 7u) << 11) | g_fp_cc); /* fnstsw ax <- fpu status */
    _fa = (uint32_t)(HI8(eax)) & 0xFFu; _fb = (uint32_t)(0x44) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test HI8(eax), 0x44 (8-bit) */
    if ((!RECOMP_PARITY8((_fa) & (_fb)))) goto loc_002DC51F; /* jnp: not parity */

loc_002DC4FC: ;
    fp_push(MEMF(esp + 0x5C)); /* fld float */
    fp_top() = RECOMP_FP_PC(fp_top() * MEMD(0x33CD80)); /* fmul qword ptr [0x33cd80] */
    MEMD(esp + 0x30) = fp_top(); fp_pop(); /* fstp */
    eax = MEM32(esp + 0x34);
    _fb = (uint32_t)(0xF8000000u) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xF8000000u;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = eax & 0xFFFFFFF0u;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    eax = eax << 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    MEM32(esp + 0x10) = eax;
    goto loc_002DC523;

loc_002DC51F: ;
    MEM32(esp + 0x10) = esi;

loc_002DC523: ;
    ebx = MEM32(ebp + 0xEE0);
    edi = MEM32(ebp + 0xEE4);
    edx = MEM32(ebp + 0xEE8);
    esi = MEM32(ebp + 0xEEC);
    eax = MEM32(esp + 0x4C);
    _fb = (uint32_t)(ebx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + ebx;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fb = (uint32_t)(edi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + edi;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(esp + 0x28) = ebx;
    MEM32(esp + 0x24) = edi;
    MEM32(esp + 0x30) = edx;
    MEM32(esp + 0x2C) = esi;
    if (CMP_NE(_fa, _fb)) goto loc_002DC579; /* jne: not equal / not zero */

loc_002DC557: ;
    ecx = esp + 0x38;
    MEM32(esp + 0x38) = ebx;
    MEM32(esp + 0x3C) = edi;
    MEM32(esp + 0x40) = edx;
    MEM32(esp + 0x44) = esi;
    MEM32(esp + 0x50) = ecx;
    MEM32(esp + 0x4C) = 1;
    goto loc_002DC583;

loc_002DC579: ;
    ecx = MEM32(esp + 0x50);
    goto loc_002DC583;

loc_002DC57F: ;
    edi = MEM32(esp + 0x24);

loc_002DC583: ;
    eax = MEM32(ecx);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ebx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ebx (32-bit) */
    MEM32(esp + 0x14) = eax;
    if (CMP_G(_fas, _fbs)) goto loc_002DC591; /* jg: greater (signed >) */

loc_002DC58D: ;
    MEM32(esp + 0x14) = ebx;

loc_002DC591: ;
    eax = MEM32(ecx + 4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edi (32-bit) */
    MEM32(esp + 0x5C) = eax;
    if (CMP_G(_fas, _fbs)) goto loc_002DC5A0; /* jg: greater (signed >) */

loc_002DC59C: ;
    MEM32(esp + 0x5C) = edi;

loc_002DC5A0: ;
    eax = MEM32(ecx + 8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    edi = eax;
    if (CMP_L(_fas, _fbs)) goto loc_002DC5AB; /* jl: less (signed <) */

loc_002DC5A9: ;
    edi = edx;

loc_002DC5AB: ;
    eax = MEM32(ecx + 0xC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, esi (32-bit) */
    MEM32(esp + 0x18) = edi;
    if (CMP_L(_fas, _fbs)) goto loc_002DC5B8; /* jl: less (signed <) */

loc_002DC5B6: ;
    eax = esi;

loc_002DC5B8: ;
    _fa = (uint32_t)(MEM32(esp + 0x14)) & 0xFFFFFFFFu; _fb = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(esp + 0x14), edi (32-bit) */
    MEM32(esp + 0x1C) = eax;
    if (CMP_GE(_fas, _fbs)) goto loc_002DC6AB; /* jge: greater or equal (signed >=) */

loc_002DC5C6: ;
    _fa = (uint32_t)(MEM32(esp + 0x5C)) & 0xFFFFFFFFu; _fb = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(esp + 0x5C), eax (32-bit) */
    if (CMP_GE(_fas, _fbs)) goto loc_002DC6AB; /* jge: greater or equal (signed >=) */

loc_002DC5D0: ;
    fp_push((double)SMEM32(esp + 0x14)); /* fild */
    PUSH32(esp, ecx);
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(ebp + 0x95C)); /* fmul dword ptr [ebp + 0x95c] */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FE9A0)); /* fadd dword ptr [0x2fe9a0] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DC5E9u); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DC5E9: ;
    fp_push((double)SMEM32(esp + 0x18)); /* fild */
    PUSH32(esp, ecx);
    ebx = eax;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(ebp + 0x95C)); /* fmul dword ptr [ebp + 0x95c] */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FE9A0)); /* fadd dword ptr [0x2fe9a0] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DC604u); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DC604: ;
    fp_push((double)SMEM32(esp + 0x5C)); /* fild */
    PUSH32(esp, ecx);
    esi = eax;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(ebp + 0x960)); /* fmul dword ptr [ebp + 0x960] */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FE9A0)); /* fadd dword ptr [0x2fe9a0] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DC61Fu); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DC61F: ;
    fp_push((double)SMEM32(esp + 0x1C)); /* fild */
    PUSH32(esp, ecx);
    MEM32(esp + 0x60) = eax;
    fp_top() = RECOMP_FP_PC(fp_top() * MEMF(ebp + 0x960)); /* fmul dword ptr [ebp + 0x960] */
    fp_top() = RECOMP_FP_PC(fp_top() + MEMF(0x2FE9A0)); /* fadd dword ptr [0x2fe9a0] */
    MEMF(esp) = (float)fp_top(); fp_pop(); /* fstp */
    PUSH32(esp, 0x002DC63Cu); RECOMP_ABI_CALL(0x002E0CE0u, sub_002E0CE0); /* call 0x002E0CE0 */

loc_002DC63C: ;
    ecx = MEM32(ebp + 4);
    edi = eax;
    eax = MEM32(ebp);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DC64D; /* jb: below (unsigned <) */

loc_002DC648: ;
    PUSH32(esp, 0x002DC64Du); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DC64D: ;
    edx = MEM32(esp + 0x60);
    ecx = MEM32(esp + 0x10);
    esi = esi << 0x10;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x10000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esi = esi - 0x10000;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    esi = esi | ebx;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    ebx = MEM32(esp + 0x28);
    MEM32(eax) = 0x81D98;
    MEM32(eax + 4) = esi;
    esi = MEM32(esp + 0x5C);
    edi = edi << 0x10;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x10000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    edi = edi - 0x10000;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    ecx = ecx | edx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    edx = MEM32(esp + 0x58);
    edi = edi | esi;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    esi = MEM32(esp + 0x2C);
    MEM32(eax + 8) = edi;
    MEM32(eax + 0xC) = 0xC1D8C;
    MEM32(eax + 0x10) = ecx;
    ecx = MEM32(esp + 0x54);
    MEM32(eax + 0x14) = edx;
    edx = MEM32(esp + 0x30);
    MEM32(eax + 0x18) = ecx;
    ecx = MEM32(esp + 0x50);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x1C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ebp) = eax;

loc_002DC6AB: ;
    eax = MEM32(esp + 0x4C);
    _fb = (uint32_t)(0x10) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x10;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax--;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(esp + 0x50) = ecx;
    MEM32(esp + 0x4C) = eax;
    if ((_fa != 0)) goto loc_002DC57F; /* jne: not equal / not zero */

loc_002DC6C1: ;
    esi = MEM32(esp + 0x20);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DC6E5; /* je: equal / zero */

loc_002DC6C9: ;
    eax = MEM32(ebp);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ebp + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(ebp + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DC6D6; /* jb: below (unsigned <) */

loc_002DC6D1: ;
    PUSH32(esp, 0x002DC6D6u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DC6D6: ;
    MEM32(eax) = 0x40208;
    MEM32(eax + 4) = esi;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ebp) = eax;

loc_002DC6E5: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    _fb = (uint32_t)(0x38) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 0x38;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 28; return; /* ret 24 */

    #undef fp_push
    #undef fp_pop
    #undef fp_top
    #undef fp_st
    #undef fp_st1
}

/**
 * sub_002DC880
 * Original: 0x002DC880 - 0x002DC8CC (76 bytes, 23 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC880(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DC880: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(esp + 8);
    edx = MEM32(0x2E9548);
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    _fb = (uint32_t)(0x114) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x114;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx = ecx << 4;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, esi);
    ecx = ecx + edx + 0x10A8;
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x14);
    MEM32(esp + 0x18) = ecx;
    /* nop */
    ecx = MEM32(eax);
    edx = ecx;
    edx = edx >> 0x12;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(1) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 1 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DC8CC(); return; } /* jne: not equal / not zero */

loc_002DC8BF: ;
    edi = MEM32(eax);
    edi = edi << 4;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x2E8490) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + 0x2E8490;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    g_seh_ebp = ebp; sub_002DC919(); return; /* tail jmp 0x002DC919 */

}

/**
 * sub_002DC930
 * Original: 0x002DC930 - 0x002DC998 (104 bytes, 38 insns)
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DC930(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DC930: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(esp + 0xC);
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    /* nop */

loc_002DC940: ;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x20) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0x20 (32-bit) */
    ebx = ecx;
    if (CMP_B(_fa, _fb)) goto loc_002DC94C; /* jb: below (unsigned <) */

loc_002DC947: ;
    ebx = 0x20;

loc_002DC94C: ;
    esi = MEM32(esp + 0x18);
    ecx = ebx;
    ecx = ecx << 0x12;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0xB00) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0xB00;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(eax) = ecx;
    edx = ebx * 4;
    ecx = edx;
    ebp = ecx;
    ecx = ecx >> 2;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edi = eax + 4;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    ecx = ebp;
    ecx = ecx & 3;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    { uint64_t _n = (uint64_t)ecx * 1u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM8(edi + _i*1u) = MEM8(esi + _i*1u); }
      esi += ecx * 1u; edi += ecx * 1u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(1);
      for (_i = 0; _i < ecx; _i++) MEM8(edi + _i*_st) = MEM8(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsb */
    esi = MEM32(esp + 0x18);
    ecx = MEM32(esp + 0x1C);
    _fb = (uint32_t)(edx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + edx;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fb = (uint32_t)(ebx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    ecx = ecx - ebx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    MEM32(esp + 0x18) = esi;
    eax = eax + edx + 4;
    MEM32(esp + 0x1C) = ecx;
    if ((_fa != 0)) goto loc_002DC940; /* jne: not equal / not zero */

loc_002DC991: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002DCB40
 * Original: 0x002DCB40 - 0x002DCC37 (247 bytes, 82 insns)
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCB40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DCB40: ;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebp);
    ebp = MEM32(esp + 0x14);
    PUSH32(esp, esi);
    esi = MEM32(esp + 0x14);
    ecx = MEM32(esi);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 4;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFFFFFFu) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0xFFFFFFFFu (32-bit) */
    PUSH32(esp, edi);
    edi = 0xDEADBEEFu;
    MEM32(esp + 0x1C) = eax;
    MEM32(esp + 0x18) = esi;
    if (CMP_EQ(_fa, _fb)) goto loc_002DCC2E; /* je: equal / zero */

loc_002DCB6B: ;
    PUSH32(esp, ebx);
    /* nop */

loc_002DCB70: ;
    edx = ecx;
    edx = edx & 0xE0000000u;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x80000000u) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0x80000000u (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DCC1B; /* jne: not equal / not zero */

loc_002DCB84: ;
    edx = ecx;
    edx = edx >> 0x19;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edx = edx & 0xF;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = ecx & 0xFF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    edi++;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x80000000u); /* inc result/SF/OF; CF unchanged */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edi (32-bit) */
    MEM32(esp + 0x10) = edx;
    if (CMP_EQ(_fa, _fb)) goto loc_002DCBB3; /* je: equal / zero */

loc_002DCB9B: ;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DCBAC; /* je: equal / zero */

loc_002DCB9F: ;
    MEM32(ebp) = 0x41EA4;
    MEM32(ebp + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ebp = ebp + 8;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DCBAC: ;
    _fb = (uint32_t)(2) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 2;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esp + 0x20) = eax;

loc_002DCBB3: ;
    MEM32(esp + 0x14) = ecx;

loc_002DCBB7: ;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(8) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 8 (32-bit) */
    ebx = edx;
    if (CMP_B(_fa, _fb)) goto loc_002DCBC3; /* jb: below (unsigned <) */

loc_002DCBBE: ;
    ebx = 8;

loc_002DCBC3: ;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DCBFC; /* je: equal / zero */

loc_002DCBC7: ;
    eax = ebx;
    eax = eax << 0x14;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0xB80) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xB80;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ebp) = eax;
    edx = ebx;
    edx = edx << 4;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = edx;
    eax = ecx;
    ecx = ecx >> 2;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ebp = ebp + 4;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edi = ebp;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    ecx = eax;
    eax = MEM32(esp + 0x20);
    ecx = ecx & 3;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    { uint64_t _n = (uint64_t)ecx * 1u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM8(edi + _i*1u) = MEM8(esi + _i*1u); }
      esi += ecx * 1u; edi += ecx * 1u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(1);
      for (_i = 0; _i < ecx; _i++) MEM8(edi + _i*_st) = MEM8(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsb */
    esi = MEM32(esp + 0x1C);
    _fb = (uint32_t)(edx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ebp = ebp + edx;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    edx = MEM32(esp + 0x10);

loc_002DCBFC: ;
    ecx = ebx;
    ecx = ecx << 4;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(ecx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + ecx;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = eax + ebx * 4 + 1;
    _fb = (uint32_t)(ebx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    edx = edx - ebx;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    MEM32(esp + 0x1C) = esi;
    MEM32(esp + 0x20) = eax;
    MEM32(esp + 0x10) = edx;
    if ((_fa != 0)) goto loc_002DCBB7; /* jne: not equal / not zero */

loc_002DCC17: ;
    edi = MEM32(esp + 0x14);

loc_002DCC1B: ;
    ecx = MEM32(esi);
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + 4;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFFFFFFu) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0xFFFFFFFFu (32-bit) */
    MEM32(esp + 0x1C) = esi;
    if (CMP_NE(_fa, _fb)) goto loc_002DCB70; /* jne: not equal / not zero */

loc_002DCC2D: ;
    POP32(esp, ebx);

loc_002DCC2E: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DCC40
 * Original: 0x002DCC40 - 0x002DCCAC (108 bytes, 41 insns)
 * Category: game_render
 * CC: cdecl, 4 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCC40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DCC40: ;
    PUSH32(esp, ecx);
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = MEM32(esp + 0x14);
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, 0 (32-bit) */
    PUSH32(esp, esi);
    if (CMP_EQ(_fa, _fb)) goto loc_002DCC5C; /* je: equal / zero */

loc_002DCC4C: ;
    eax = ZX16(MEM16(ebp));
    ecx = ZX16(MEM16(ebp + 2));
    MEM32(esp + 0xC) = eax;
    MEM32(esp + 0x18) = ecx;

loc_002DCC5C: ;
    esi = 0; /* xor self */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DCC72; /* je: equal / zero */

loc_002DCC62: ;
    eax = MEM32(esp + 0x18);
    eax = eax << 4;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edx = eax + 0x7F;
    edx = edx >> 7;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    esi = eax + edx * 4;

loc_002DCC72: ;
    ecx = MEM32(esp + 0x14);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DCC86; /* je: equal / zero */

loc_002DCC7C: ;
    PUSH32(esp, eax);
    PUSH32(esp, ecx);
    PUSH32(esp, 0x002DCC83u); RECOMP_ABI_CALL(0x002DCB40u, sub_002DCB40); /* call 0x002DCB40 */

loc_002DCC83: ;
    eax = eax << 2;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */

loc_002DCC86: ;
    ebx = eax + esi;
    PUSH32(esp, 0x24800000);
    eax = ebx + 0x118;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DCC9Au); RECOMP_ABI_CALL(0x001F093Cu, sub_001F093C); /* call 0x001F093C */

loc_002DCC9A: ;
    esi = eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DCCAC(); return; } /* jne: not equal / not zero */

loc_002DCCA0: ;
    POP32(esp, esi);
    POP32(esp, ebp);
    eax = 0x8007000Eu;
    POP32(esp, ebx);
    POP32(esp, ecx);
    esp += 20; return; /* ret 16 */

}

/**
 * sub_002DCD80
 * Original: 0x002DCD80 - 0x002DCDD4 (84 bytes, 25 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCD80(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DCD80: ;
    PUSH32(esp, ebx);
    eax = MEM32(0x2E9550);
    _fb = (uint32_t)(0x1C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x1C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(0x2E9554)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(0x2E9554) (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DCDD4(); return; } /* jae: above or equal (unsigned >=) */

loc_002DCD91: ;
    MEM32(0x2E9550) = eax;
    MEM32(eax + -28) = 0x41EA4;
    MEM32(eax + -24) = ecx;
    MEM32(eax + -20) = 0x100B80;
    ecx = ecx << 4;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx + 0x2E8490;
    ebx = MEM32(edx);
    MEM32(eax + -16) = ebx;
    MEM32(ecx) = ebx;
    ebx = MEM32(edx + 4);
    MEM32(eax + -12) = ebx;
    MEM32(ecx + 4) = ebx;
    ebx = MEM32(edx + 8);
    MEM32(eax + -8) = ebx;
    MEM32(ecx + 8) = ebx;
    ebx = MEM32(edx + 0xC);
    MEM32(eax + -4) = ebx;
    MEM32(ecx + 0xC) = ebx;
    POP32(esp, ebx);
    esp += 4; return; /* ret */

}

/**
 * sub_002DCDE0
 * Original: 0x002DCDE0 - 0x002DCE74 (148 bytes, 36 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCDE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DCDE0: ;
    eax = MEM32(0x2E9550);
    _fb = (uint32_t)(0x4C) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x4C;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(0x2E9554)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(0x2E9554) (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DCE74(); return; } /* jae: above or equal (unsigned >=) */

loc_002DCDF4: ;
    MEM32(0x2E9550) = eax;
    mm0 = MMX_MEM(edx); /* movq */
    mm1 = MMX_MEM(edx + 8); /* movq */
    mm2 = MMX_MEM(edx + 0x10); /* movq */
    mm3 = MMX_MEM(edx + 0x18); /* movq */
    mm4 = MMX_MEM(edx + 0x20); /* movq */
    mm5 = MMX_MEM(edx + 0x28); /* movq */
    mm6 = MMX_MEM(edx + 0x30); /* movq */
    mm7 = MMX_MEM(edx + 0x38); /* movq */
    MEM32(eax + -76) = 0x41EA4;
    MEM32(eax + -72) = ecx;
    ecx = ecx << 4;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx + 0x2E8490;
    MEM32(eax + -68) = 0x400B80;
    MMX_STORE(eax + -64, mm0); /* movq */
    MMX_STORE(ecx, mm0); /* movq */
    MMX_STORE(eax + -56, mm1); /* movq */
    MMX_STORE(ecx + 8, mm1); /* movq */
    MMX_STORE(eax + -48, mm2); /* movq */
    MMX_STORE(ecx + 0x10, mm2); /* movq */
    MMX_STORE(eax + -40, mm3); /* movq */
    MMX_STORE(ecx + 0x18, mm3); /* movq */
    MMX_STORE(eax + -32, mm4); /* movq */
    MMX_STORE(ecx + 0x20, mm4); /* movq */
    MMX_STORE(eax + -24, mm5); /* movq */
    MMX_STORE(ecx + 0x28, mm5); /* movq */
    MMX_STORE(eax + -16, mm6); /* movq */
    MMX_STORE(ecx + 0x30, mm6); /* movq */
    MMX_STORE(eax + -8, mm7); /* movq */
    MMX_STORE(ecx + 0x38, mm7); /* movq */
    (void)0; /* emms - empty MMX state */
    esp += 4; return; /* ret */

}

/**
 * sub_002DCE90
 * Original: 0x002DCE90 - 0x002DCEDA (74 bytes, 23 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCE90(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DCE90: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(0x2E9550);
    esi = edx;
    eax = MEM32(esp + 0xC);
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(0x2E9554)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, MEM32(0x2E9554) (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DCF50(); return; } /* jae: above or equal (unsigned >=) */

loc_002DCEAA: ;
    MEM32(edi) = 0x41EA4;
    MEM32(edi + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + 8;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x10) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x10 (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DCEDA(); return; } /* jae: above or equal (unsigned >=) */

loc_002DCEBB: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + 4;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx = eax;
    eax = eax << 0x12;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    eax = eax | 0xB80;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(edi + -4) = eax;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    MEM32(0x2E9550) = edi;
    (void)0; /* emms - empty MMX state */
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DCF70
 * Original: 0x002DCF70 - 0x002DCFA1 (49 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCF70(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DCF70: ;
    eax = ecx;
    _fa = (uint32_t)(MEM8(0x2E9558)) & 0xFFu; _fb = (uint32_t)(0x10) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(0x2E9558), 0x10 (8-bit) */
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 8);
    if (TEST_NZ(_fa, _fb)) goto loc_002DCF95; /* jne: not equal / not zero */

loc_002DCF80: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = eax;
    edi = edi << 4;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    _fb = (uint32_t)(0x2E8490) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + 0x2E8490;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx = ebx;
    esi = edx;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    POP32(esp, edi);
    POP32(esp, esi);

loc_002DCF95: ;
    PUSH32(esp, ebx);
    ecx = eax;
    PUSH32(esp, 0x002DCF9Du); RECOMP_ABI_CALL(0x002DCE90u, sub_002DCE90); /* call 0x002DCE90 */

loc_002DCF9D: ;
    POP32(esp, ebx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DCFB0
 * Original: 0x002DCFB0 - 0x002DD02E (126 bytes, 36 insns)
 * Category: game_render
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DCFB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DCFB0: ;
    ecx = MEM32(0x2E9548);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x10);
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DCFC6; /* je: equal / zero */

loc_002DCFC0: ;
    _fb = (uint32_t)(0x80000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    MEM32(edi) = MEM32(edi) + 0x80000;
    _fa = (uint32_t)(MEM32(edi)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DCFC6: ;
    eax = MEM32(esp + 0xC);
    esi = eax + eax * 2;
    esi = esi << 2;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    eax = MEM32(esi + 0x2EB9F8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DD000; /* je: equal / zero */

loc_002DCFDA: ;
    ecx = MEM32(ecx + 0x2C);
    MEM32(eax + 8) = ecx;
    eax = MEM32(esi + 0x2EB9F8);
    edx = MEM32(eax);
    _fb = (uint32_t)(0xFFF80000u) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + 0xFFF80000u;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    ecx = edx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x78FFFF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test ecx, 0x78FFFF (32-bit) */
    MEM32(eax) = edx;
    if (TEST_NZ(_fa, _fb)) goto loc_002DD000; /* jne: not equal / not zero */

loc_002DCFFA: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DD000u); RECOMP_ABI_CALL(0x002DE500u, sub_002DE500); /* call 0x002DE500 */

loc_002DD000: ;
    ecx = MEM32(esi + 0x2EB9F0);
    eax = MEM32(esp + 0x14);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ecx (32-bit) */
    ecx = MEM32(0x2E90A8);
    MEM32(esi + 0x2EB9F0) = eax;
    MEM32(esi + 0x2EB9F8) = edi;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD02E(); return; } /* jne: not equal / not zero */

loc_002DD020: ;
    ecx = ecx | 0x40;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    POP32(esp, edi);
    MEM32(0x2E90A8) = ecx;
    POP32(esp, esi);
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002DD040
 * Original: 0x002DD040 - 0x002DD094 (84 bytes, 32 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD040(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DD040: ;
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    ebp = MEM32(0x2E9548);
    SET_LO8(eax, MEM8(ebp + 8));
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0x14);
    edi--;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0x10) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(eax), 0x10 (8-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DD061; /* jne: not equal / not zero */

loc_002DD056: ;
    eax = MEM32(esp + 0x18);
    PUSH32(esp, eax);
    PUSH32(esp, edi);
    PUSH32(esp, 0x002DD061u); RECOMP_ABI_CALL(0x002DC880u, sub_002DC880); /* call 0x002DC880 */

loc_002DD061: ;
    esi = MEM32(edi + 0xC);
    ebx = esi + 2;
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002DD06Du); RECOMP_ABI_CALL(0x002DE380u, sub_002DE380); /* call 0x002DE380 */

loc_002DD06D: ;
    ecx = MEM32(esp + 0x18);
    MEM32(eax) = 0x41E9C;
    MEM32(eax + 4) = ecx;
    ecx = esi;
    esi = edi + 0x114;
    edi = eax + 8;
    { uint64_t _n = (uint64_t)ecx * 4u;
    if (!g_df && esi < 0xFD000000u && edi < 0xFD000000u && (uint64_t)esi + _n <= 0xFD000000u && (uint64_t)edi + _n <= 0xFD000000u) {
      uint8_t *_d = (uint8_t*)XBOX_PTR(edi), *_s = (uint8_t*)XBOX_PTR(esi);
      if ((uint64_t)edi + _n <= esi || (uint64_t)esi + _n <= edi) memcpy(_d, _s, (size_t)_n);
      else { uint32_t _i; for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*4u) = MEM32(esi + _i*4u); }
      esi += ecx * 4u; edi += ecx * 4u; }
    else { uint32_t _i; int32_t _st = RECOMP_DF_STEP(4);
      for (_i = 0; _i < ecx; _i++) MEM32(edi + _i*_st) = MEM32(esi + _i*_st);
      esi += ecx * _st; edi += ecx * _st; }
    ecx = 0; } /* rep movsd */
    POP32(esp, edi);
    edx = eax + ebx * 4;
    POP32(esp, esi);
    MEM32(ebp) = edx;
    POP32(esp, ebp);
    POP32(esp, ebx);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DD0A0
 * Original: 0x002DD0A0 - 0x002DD13C (156 bytes, 44 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD0A0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DD0A0: ;
    eax = MEM32(esp + 4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    if (CMP_EQ(_fa, _fb)) goto loc_002DD114; /* je: equal / zero */

loc_002DD0AF: ;
    ecx = MEM32(esi + 0x794);
    ecx = MEM32(ecx + 4);
    PUSH32(esp, edi);
    edi = eax + -1;
    MEM32(esi + 0x794) = edi;
    MEM32(esi + 0x798) = eax;
    MEM32(0x2E90A8) = MEM32(0x2E90A8) | 0x70;
    _fa = (uint32_t)(MEM32(0x2E90A8)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    edx = MEM32(edi + 4);
    edx = edx ^ ecx;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(0x13) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 0x13 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DD113; /* je: equal / zero */

loc_002DD0D9: ;
    MEM32(0x2E90A8) = MEM32(0x2E90A8) | 0x1000;
    _fa = (uint32_t)(MEM32(0x2E90A8)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DD0EF; /* jb: below (unsigned <) */

loc_002DD0EA: ;
    PUSH32(esp, 0x002DD0EFu); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DD0EF: ;
    edx = eax;
    ecx = esi;
    PUSH32(esp, 0x002DD0F8u); RECOMP_ABI_CALL(0x002DA990u, sub_002DA990); /* call 0x002DA990 */

loc_002DD0F8: ;
    ecx = MEM32(edi + 4);
    MEM32(eax) = 0x81E94;
    ecx = ecx & 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    MEM32(eax + 4) = 6;
    MEM32(eax + 8) = ecx;
    _fb = (uint32_t)(0xC) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0xC;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;

loc_002DD113: ;
    POP32(esp, edi);

loc_002DD114: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DD120; /* jb: below (unsigned <) */

loc_002DD11B: ;
    PUSH32(esp, 0x002DD120u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DD120: ;
    ecx = MEM32(esp + 0xC);
    MEM32(eax) = 0x41EA0;
    MEM32(eax + 4) = ecx;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    MEM32(esi + 0x79C) = ecx;
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DD140
 * Original: 0x002DD140 - 0x002DD15A (26 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD140(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DD140: ;
    eax = MEM32(esp + 4);
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0x10) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(eax), 0x10 (8-bit) */
    PUSH32(esp, ebx);
    ebx = MEM32(0x2E9548);
    ecx = MEM32(ebx + 8);
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD15A(); return; } /* je: equal / zero */

loc_002DD152: ;
    ecx = ecx | 0x200;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    g_seh_ebp = ebp; sub_002DD160(); return; /* tail jmp 0x002DD160 */

}

/**
 * sub_002DD260
 * Original: 0x002DD260 - 0x002DD299 (57 bytes, 18 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD260(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DD260: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DD273; /* jb: below (unsigned <) */

loc_002DD26E: ;
    PUSH32(esp, 0x002DD273u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DD273: ;
    ecx = MEM32(esp + 0xC);
    edx = MEM32(esp + 8);
    MEM32(eax) = 0x41E9C;
    PUSH32(esp, ecx);
    MEM32(eax + 4) = 0;
    PUSH32(esp, edx);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DD293u); RECOMP_ABI_CALL(0x002DC930u, sub_002DC930); /* call 0x002DC930 */

loc_002DD293: ;
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DD2A0
 * Original: 0x002DD2A0 - 0x002DD2BB (27 bytes, 10 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD2A0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DD2A0: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(eax + -1);
    eax--;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(eax) = ecx;
    if ((_fa != 0)) goto loc_002DD2B8; /* jne: not equal / not zero */

loc_002DD2AD: ;
    PUSH32(esp, 0x24800000);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DD2B8u); RECOMP_ABI_CALL(0x001F09DCu, sub_001F09DC); /* call 0x001F09DC */

loc_002DD2B8: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DD2C0
 * Original: 0x002DD2C0 - 0x002DD2E8 (40 bytes, 14 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD2C0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DD2C0: ;
    PUSH32(esp, esi);
    esi = ecx;
    eax = MEM32(esi + 0x794);
    _fa = (uint32_t)(MEM8(eax + 4)) & 0xFFu; _fb = (uint32_t)(2) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(eax + 4), 2 (8-bit) */
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD3AD(); return; } /* je: equal / zero */

loc_002DD2D3: ;
    eax = MEM32(0x2E9424);
    PUSH32(esp, ebx);
    ebx = 0; /* xor self */
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(ebx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, ebx (32-bit) */
    PUSH32(esp, ebp);
    PUSH32(esp, edi);
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD2E8(); return; } /* jne: not equal / not zero */

loc_002DD2E1: ;
    ebp = 0x2E7518;
    g_seh_ebp = ebp; sub_002DD2FF(); return; /* tail jmp 0x002DD2FF */

}

/**
 * sub_002DD3B0
 * Original: 0x002DD3B0 - 0x002DD3F6 (70 bytes, 30 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD3B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DD3B0: ;
    PUSH32(esp, ecx);
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 0xC);
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 1 (8-bit) */
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi + 0x794);
    ecx = MEM32(eax + 4);
    ebp = MEM32(eax + 0x10);
    PUSH32(esp, edi);
    MEM32(esp + 0x10) = ecx;
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD3F6(); return; } /* je: equal / zero */

loc_002DD3D4: ;
    SET_LO8(eax, MEM8(ebx + 3));
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(0x10) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(eax), 0x10 (8-bit) */
    edi = ebx + -1;
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD402(); return; } /* je: equal / zero */

loc_002DD3DE: ;
    ebp = 0; /* xor self */
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    PUSH32(esp, ebp);
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002DD3E7u); RECOMP_ABI_CALL(0x002DD040u, sub_002DD040); /* call 0x002DD040 */

loc_002DD3E7: ;
    PUSH32(esp, ebp);
    PUSH32(esp, ebx);
    PUSH32(esp, 0x002DD3EEu); RECOMP_ABI_CALL(0x002DD0A0u, sub_002DD0A0); /* call 0x002DD0A0 */

loc_002DD3EE: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    POP32(esp, ecx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DD520
 * Original: 0x002DD520 - 0x002DD53B (27 bytes, 7 insns)
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD520(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DD520: ;
    PUSH32(esp, 0x24800000);
    PUSH32(esp, 0xFC);
    PUSH32(esp, 0x002DD52Fu); RECOMP_ABI_CALL(0x001F093Cu, sub_001F093C); /* call 0x001F093C */

loc_002DD52F: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD53B(); return; } /* jne: not equal / not zero */

loc_002DD533: ;
    eax = 0x8007000Eu;
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DD570
 * Original: 0x002DD570 - 0x002DD58D (29 bytes, 10 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD570(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DD570: ;
    eax = MEM32(esp + 4);
    MEM32(eax) = MEM32(eax) - 1;
    _fa = (uint32_t)(MEM32(eax)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    if ((_fa != 0)) goto loc_002DD58A; /* jne: not equal / not zero */

loc_002DD578: ;
    ecx = MEM32(eax + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DD58A; /* je: equal / zero */

loc_002DD57F: ;
    PUSH32(esp, 0x24800000);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DD58Au); RECOMP_ABI_CALL(0x001F09DCu, sub_001F09DC); /* call 0x001F09DC */

loc_002DD58A: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DD590
 * Original: 0x002DD590 - 0x002DD610 (128 bytes, 35 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DD590(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DD590: ;
    PUSH32(esp, ecx);
    PUSH32(esp, ebx);
    ebx = MEM32(0x2E9548);
    eax = MEM32(ebx + 0x784);
    MEM32(esp + 4) = eax;
    eax = MEM32(esp + 0xC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(ebx + 0x784) = eax;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DD610(); return; } /* jne: not equal / not zero */

loc_002DD5B0: ;
    ecx = MEM32(0x2E90A8);
    ecx = ecx | 0x4800;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(0x2E90A8) = ecx;
    eax = MEM32(ebx + 0x788);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DD5D8; /* je: equal / zero */

loc_002DD5CC: ;
    eax = ecx;
    eax = eax | 0x2000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(0x2E90A8) = eax;

loc_002DD5D8: ;
    ecx = MEM32(0x2E9500);
    PUSH32(esp, ecx);
    PUSH32(esp, 0x002DD5E4u); RECOMP_ABI_CALL(0x002DA280u, sub_002DA280); /* call 0x002DA280 */

loc_002DD5E4: ;
    eax = MEM32(ebx);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(ebx + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(ebx + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DD5F0; /* jb: below (unsigned <) */

loc_002DD5EB: ;
    PUSH32(esp, 0x002DD5F0u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DD5F0: ;
    edx = eax;
    ecx = ebx;
    PUSH32(esp, 0x002DD5F9u); RECOMP_ABI_CALL(0x002DA920u, sub_002DA920); /* call 0x002DA920 */

loc_002DD5F9: ;
    MEM32(eax) = 0x41E78;
    MEM32(eax + 4) = 0x210000;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 8;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(ebx) = eax;
    POP32(esp, ebx);
    POP32(esp, ecx);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DD790
 * Original: 0x002DD790 - 0x002DD7C7 (55 bytes, 19 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: standard_frame
 */
void sub_002DD790(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* prologue saves caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DD790: ;
    PUSH32(esp, ebp);
    ebp = esp;
    g_ebp = ebp; /* publish frame for frameless callees */
    g_seh_ebp = ebp;
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    edx = MEM32(0x2E9548);
    eax = MEM32(edx + 0x784);
    ecx = MEM32(eax + 8);
    eax = MEM32(ebp + 0xC);
    MEM32(ebp + 0xC) = eax;
    eax = MEM32(ebp + 0x10);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    MEM32(ebp + -4) = edx;
    MEM32(ebp + -8) = ecx;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDA51(); return; } /* je: equal / zero */

loc_002DD7BC: ;
    PUSH32(esp, ebx);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(ebp + 8);
    MEM32(ebp + 0x10) = eax;
    g_seh_ebp = ebp; sub_002DD7D0(); return; /* tail jmp 0x002DD7D0 */

}

/**
 * sub_002DDA60
 * Original: 0x002DDA60 - 0x002DDA73 (19 bytes, 8 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDA60(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DDA60: ;
    PUSH32(esp, ecx);
    MEM32(esp) = 0x190;

loc_002DDA68: ;
    eax = MEM32(esp);
    eax--;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    MEM32(esp) = eax;
    if ((_fa != 0)) goto loc_002DDA68; /* jne: not equal / not zero */

loc_002DDA71: ;
    POP32(esp, ecx);
    esp += 4; return; /* ret */

}

/**
 * sub_002DDA80
 * Original: 0x002DDA80 - 0x002DDAAF (47 bytes, 21 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDA80(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DDA80: ;
    eax = MEM32(esp + 4);
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(ecx);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edi (32-bit) */
    esi = eax;
    if (CMP_A(_fa, _fb)) goto loc_002DDA93; /* ja: above (unsigned >) */

loc_002DDA8E: ;
    esi = MEM32(ecx + 0x44);
    _fb = (uint32_t)(eax) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esi = esi + eax;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DDA93: ;
    eax = MEM32(edx + 4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edi (32-bit) */
    if (CMP_A(_fa, _fb)) goto loc_002DDA9D; /* ja: above (unsigned >) */

loc_002DDA9A: ;
    _fb = (uint32_t)(MEM32(ecx + 0x44)) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + MEM32(ecx + 0x44);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DDA9D: ;
    _fb = (uint32_t)(esi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - esi;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    ecx = 0;
    SET_LO8(ecx, ((_fas < 0)) ? 1 : 0); /* sets */
    POP32(esp, edi);
    POP32(esp, esi);
    ecx--;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x7FFFFFFFu); /* dec result/SF/OF; CF unchanged */
    eax = eax & ecx;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DDAB0
 * Original: 0x002DDAB0 - 0x002DDB20 (112 bytes, 37 insns)
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDAB0(void)
{

loc_002DDAB0: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(esp + 8);
    MEM32(eax) = ecx;
    ecx = MEM32(esp + 0xC);
    edx = MEM32(ecx);
    MEM32(eax + 4) = edx;
    edx = MEM32(ecx + 0x10);
    MEM32(eax + 8) = edx;
    edx = MEM32(ecx + 0x20);
    MEM32(eax + 0xC) = edx;
    edx = MEM32(ecx + 0x30);
    MEM32(eax + 0x10) = edx;
    edx = MEM32(ecx + 4);
    MEM32(eax + 0x14) = edx;
    edx = MEM32(ecx + 0x14);
    MEM32(eax + 0x18) = edx;
    edx = MEM32(ecx + 0x24);
    MEM32(eax + 0x1C) = edx;
    edx = MEM32(ecx + 0x34);
    MEM32(eax + 0x20) = edx;
    edx = MEM32(ecx + 8);
    MEM32(eax + 0x24) = edx;
    edx = MEM32(ecx + 0x18);
    MEM32(eax + 0x28) = edx;
    edx = MEM32(ecx + 0x28);
    MEM32(eax + 0x2C) = edx;
    edx = MEM32(ecx + 0x38);
    MEM32(eax + 0x30) = edx;
    edx = MEM32(ecx + 0xC);
    MEM32(eax + 0x34) = edx;
    edx = MEM32(ecx + 0x1C);
    MEM32(eax + 0x38) = edx;
    edx = MEM32(ecx + 0x2C);
    MEM32(eax + 0x3C) = edx;
    ecx = MEM32(ecx + 0x3C);
    MEM32(eax + 0x40) = ecx;
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002DDBC0
 * Original: 0x002DDBC0 - 0x002DDBE9 (41 bytes, 16 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDBC0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DDBC0: ;
    PUSH32(esp, esi);
    esi = ecx;
    eax = MEM32(esi + 0x24);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DDBD5; /* je: equal / zero */

loc_002DDBCA: ;
    PUSH32(esp, 0xA1800000u);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DDBD5u); RECOMP_ABI_CALL(0x001F09DCu, sub_001F09DC); /* call 0x001F09DC */

loc_002DDBD5: ;
    esi = MEM32(esi + 0x48);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DDBE7; /* je: equal / zero */

loc_002DDBDC: ;
    PUSH32(esp, 0x24800000);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DDBE7u); RECOMP_ABI_CALL(0x001F09DCu, sub_001F09DC); /* call 0x001F09DC */

loc_002DDBE7: ;
    POP32(esp, esi);
    esp += 4; return; /* ret */

}

/**
 * sub_002DDBF0
 * Original: 0x002DDBF0 - 0x002DDC63 (115 bytes, 46 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDBF0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DDBF0: ;
    edx = MEM32(0x2E9548);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    esp = esp - 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    PUSH32(esp, ebp);
    PUSH32(esp, esi);
    esi = MEM32(edx + 0x2C);
    PUSH32(esp, edi);
    edi = eax;
    eax = esi;
    _fb = (uint32_t)(edi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - edi;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x80) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x80 (32-bit) */
    if (CMP_A(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDC63(); return; } /* ja: above (unsigned >) */

loc_002DDC0D: ;
    ecx = MEM32(esp + 0x14);
    edi = edi >> 1;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edi = edi & 0x3F;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFFFFFFu) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, 0xFFFFFFFFu (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDC8C(); return; } /* je: equal / zero */

loc_002DDC1B: ;
    ebp = MEM32(edx + edi * 8 + 0x68);
    ebx = MEM32(edx);
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(ebx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, ebx (32-bit) */
    eax = edx + edi * 8 + 0x64;
    if (CMP_A(_fa, _fb)) goto loc_002DDC2C; /* ja: above (unsigned >) */

loc_002DDC29: ;
    _fb = (uint32_t)(MEM32(edx + 0x44)) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ebp = ebp + MEM32(edx + 0x44);
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DDC2C: ;
    esi = esi >> 1;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = edi + 1;
    esi = esi & 0x3F;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = ecx & 0x3F;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, esi (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDCE6(); return; } /* je: equal / zero */

loc_002DDC3F: ;
    /* nop */

loc_002DDC40: ;
    edi = MEM32(edx + ecx * 8 + 0x68);
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(ebx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, ebx (32-bit) */
    if (CMP_A(_fa, _fb)) goto loc_002DDC4B; /* ja: above (unsigned >) */

loc_002DDC48: ;
    _fb = (uint32_t)(MEM32(edx + 0x44)) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edi = edi + MEM32(edx + 0x44);
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DDC4B: ;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(ebp) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, ebp (32-bit) */
    if (CMP_B(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDCE4(); return; } /* jb: below (unsigned <) */

loc_002DDC53: ;
    ecx++;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x80000000u); /* inc result/SF/OF; CF unchanged */
    ecx = ecx & 0x3F;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(esi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, esi (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DDC40; /* jne: not equal / not zero */

loc_002DDC5B: ;
    POP32(esp, edi);
    POP32(esp, esi);
    POP32(esp, ebp);
    POP32(esp, ebx);
    _fb = (uint32_t)(8) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 8;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 4; return; /* ret */

}

/**
 * sub_002DDD70
 * Original: 0x002DDD70 - 0x002DDD89 (25 bytes, 9 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDD70(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DDD70: ;
    eax = MEM32(esp + 8);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDDA3(); return; } /* je: equal / zero */

loc_002DDD7D: ;
    edx = MEM32(esi + 0x934);
    PUSH32(esp, edi);
    edi = MEM32(esi + 0x30);
    g_seh_ebp = ebp; sub_002DDD90(); return; /* tail jmp 0x002DDD90 */

}

/**
 * sub_002DDDF0
 * Original: 0x002DDDF0 - 0x002DDE1D (45 bytes, 9 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDDF0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DDDF0: ;
    eax = MEM32(0x2E9548);
    eax = MEM32(eax + 0x1C28);
    (void)0; /* sfence: cache/ordering hint, nothing to model */
    ecx = MEM32(eax + 0x100410);
    ecx = ecx | 0x10000;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    MEM32(eax + 0x100410) = ecx;

loc_002DDE10: ;
    _fa = (uint32_t)(MEM32(eax + 0x100410)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x10000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test MEM32(eax + 0x100410), 0x10000 (32-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DDE10; /* jne: not equal / not zero */

loc_002DDE1C: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002DDE20
 * Original: 0x002DDE20 - 0x002DDE3E (30 bytes, 11 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDE20(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    int _cf = 0; /* carry flag */

loc_002DDE20: ;
    eax = MEM32(0x2E9548);
    ecx = MEM32(eax + 0x30);
    eax = MEM32(eax + 0x2C);
    ecx = MEM32(ecx);
    edx = eax;
    _fb = (uint32_t)(ecx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    _cf = (int)((uint32_t)(edx) < (uint32_t)(ecx));
    edx = edx - ecx;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fb = (uint32_t)(MEM32(esp + 4)) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    _cf = (int)((uint32_t)(eax) < (uint32_t)(MEM32(esp + 4)));
    eax = eax - MEM32(esp + 4);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    _cf = (int)(_fa < _fb);
    eax = _cf ? 0xFFFFFFFF : 0; /* sbb self (CF extend) */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sbb result */
    _cf = (int)((eax) != 0);
    eax = (uint32_t)(0u - (uint32_t)(eax));
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* neg result */
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DDE40
 * Original: 0x002DDE40 - 0x002DDE86 (70 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 3 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDE40(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DDE40: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DDE53; /* jb: below (unsigned <) */

loc_002DDE4E: ;
    PUSH32(esp, 0x002DDE53u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DDE53: ;
    ecx = MEM32(esp + 0xC);
    edx = MEM32(esp + 0x10);
    MEM32(eax) = 0x81D8C;
    MEM32(eax + 4) = ecx;
    ecx = MEM32(esp + 8);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    MEM32(eax + 8) = edx;
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDE86(); return; } /* jne: not equal / not zero */

loc_002DDE6F: ;
    MEM32(eax + 0xC) = 0x40100;
    MEM32(eax + 0x10) = 6;
    _fb = (uint32_t)(0x14) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + 0x14;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi) = eax;
    POP32(esp, esi);
    esp += 16; return; /* ret 12 */

}

/**
 * sub_002DDEB0
 * Original: 0x002DDEB0 - 0x002DDECB (27 bytes, 7 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDEB0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DDEB0: ;
    ecx = MEM32(0x2E9548);
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DDEBDu); RECOMP_ABI_CALL(0x002E4780u, sub_002E4780); /* call 0x002E4780 */

loc_002DDEBD: ;
    eax = MEM32(esp + 4);
    eax++;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x80000000u); /* inc result/SF/OF; CF unchanged */
    MEM32(esp + 4) = eax;
    g_seh_ebp = ebp; sub_002DE380(); return; /* tail jmp 0x002DE380 */

}

/**
 * sub_002DDED0
 * Original: 0x002DDED0 - 0x002DDEDF (15 bytes, 4 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDED0(void)
{

loc_002DDED0: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(0x2E9548);
    MEM32(ecx) = eax;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DDEE0
 * Original: 0x002DDEE0 - 0x002DDEF2 (18 bytes, 7 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DDEE0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DDEE0: ;
    PUSH32(esp, esi);
    esi = ecx;
    eax = MEM32(esi + 8);
    _fa = (uint32_t)(LO8(eax)) & 0xFFu; _fb = (uint32_t)(4) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(eax), 4 (8-bit) */
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DDEF2(); return; } /* je: equal / zero */

loc_002DDEEA: ;
    edx = MEM32(esi + 0x770);
    g_seh_ebp = ebp; sub_002DDEF4(); return; /* tail jmp 0x002DDEF4 */

}

/**
 * sub_002DE000
 * Original: 0x002DE000 - 0x002DE0B8 (184 bytes, 58 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE000(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE000: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, MEM32(esi + 4) (32-bit) */
    PUSH32(esp, edi);
    if (CMP_B(_fa, _fb)) goto loc_002DE014; /* jb: below (unsigned <) */

loc_002DE00F: ;
    PUSH32(esp, 0x002DE014u); RECOMP_ABI_CALL(0x002DE370u, sub_002DE370); /* call 0x002DE370 */

loc_002DE014: ;
    edi = MEM32(esi + 0x2C);
    MEM32(eax) = 0x4A310;
    edx = edi;
    edx = edx & 0x1F;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = eax * 8;
    ecx = ecx | edx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    edx = MEM32(esi + 0x40);
    ecx = ecx << 2;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    edx = edx & 3;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ecx = ecx | edx;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    SET_LO8(edx, MEM8(esp + 0xC));
    MEM32(eax + 4) = ecx;
    MEM32(eax + 8) = 0x41D70;
    MEM32(eax + 0xC) = edi;
    ecx = 0x41D90;
    MEM32(eax + 0x10) = ecx;
    MEM32(eax + 0x14) = 0;
    MEM32(eax + 0x18) = ecx;
    MEM32(eax + 0x1C) = 0;
    ecx = eax + 0x20;
    MEM32(esi) = ecx;
    ecx = edi;
    ecx = ecx >> 1;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = ecx & 0x3F;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 1 (8-bit) */
    MEM32(esi + ecx * 8 + 0x64) = edi;
    MEM32(esi + ecx * 8 + 0x68) = eax;
    if (TEST_Z(_fa, _fb)) goto loc_002DE095; /* je: equal / zero */

loc_002DE079: ;
    ecx = MEM32(esi + 0x38);
    PUSH32(esp, ebp);
    ebp = MEM32(esi + 0x34);
    ebp++;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x80000000u); /* inc result/SF/OF; CF unchanged */
    ecx = ecx & ebp;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    ebp = MEM32(esi + 0x48);
    MEM32(esi + 0x34) = ecx;
    MEM32(ebp + ecx * 8) = edi;
    ebp = MEM32(esi + 0x48);
    MEM32(ebp + ecx * 8 + 4) = eax;
    POP32(esp, ebp);

loc_002DE095: ;
    ecx = MEM32(esi + 0x2C);
    _fb = (uint32_t)(2) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 2;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(LO8(edx)) & 0xFFu; _fb = (uint32_t)(2) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(edx), 2 (8-bit) */
    MEM32(esi + 0x3C) = 0;
    MEM32(esi + 0x2C) = ecx;
    if (TEST_NZ(_fa, _fb)) goto loc_002DE0B1; /* jne: not equal / not zero */

loc_002DE0AA: ;
    ecx = esi;
    PUSH32(esp, 0x002DE0B1u); RECOMP_ABI_CALL(0x002DDEE0u, sub_002DDEE0); /* call 0x002DDEE0 */

loc_002DE0B1: ;
    eax = edi;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE0C0
 * Original: 0x002DE0C0 - 0x002DE208 (328 bytes, 107 insns)
 * Category: game_render
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE0C0(void)
{
    extern void sub_002DE0C0_enter(void);
    sub_002DE0C0_enter();
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE0C0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    eax = MEM32(esi + 0x30);
    ecx = MEM32(eax);
    eax = MEM32(esi + 0x2C);
    edx = eax;
    _fb = (uint32_t)(ecx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    edx = edx - ecx;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, edi);
    edi = MEM32(esp + 0xC);
    ecx = eax;
    _fb = (uint32_t)(edi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    ecx = ecx - edi;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    if (CMP_AE(_fa, _fb)) goto loc_002DE203; /* jae: above or equal (unsigned >=) */

loc_002DE0E4: ;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fb = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edi, eax (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DE0EF; /* jne: not equal / not zero */

loc_002DE0E8: ;
    PUSH32(esp, 0);
    PUSH32(esp, 0x002DE0EFu); RECOMP_ABI_CALL(0x002DE000u, sub_002DE000); /* call 0x002DE000 */

loc_002DE0EF: ;
    PUSH32(esp, ebp);
    eax = edi;
    PUSH32(esp, 0x002DE0F7u); RECOMP_ABI_CALL(0x002DDBF0u, sub_002DDBF0); /* call 0x002DDBF0 */

loc_002DE0F7: ;
    ebp = eax;
    _fa = (uint32_t)(ebp) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ebp, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DE202; /* je: equal / zero */

loc_002DE101: ;
    PUSH32(esp, 0);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DE109u); RECOMP_ABI_CALL(0x002DDD70u, sub_002DDD70); /* call 0x002DDD70 */

loc_002DE109: ;
    edx = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edx (32-bit) */
    if (CMP_A(_fa, _fb)) goto loc_002DE112; /* ja: above (unsigned >) */

loc_002DE10F: ;
    _fb = (uint32_t)(MEM32(esi + 0x44)) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    eax = eax + MEM32(esi + 0x44);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DE112: ;
    ecx = MEM32(ebp + 4);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    if (CMP_A(_fa, _fb)) goto loc_002DE11C; /* ja: above (unsigned >) */

loc_002DE119: ;
    _fb = (uint32_t)(MEM32(esi + 0x44)) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + MEM32(esi + 0x44);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DE11C: ;
    _fb = (uint32_t)(eax) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    ecx = ecx - eax;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    PUSH32(esp, ebx);
    ebx = MEM32(esp + 0x18);
    if ((_fas < 0)) goto loc_002DE1CB; /* js: sign (negative) */

loc_002DE129: ;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x2400) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0x2400 (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DE1CB; /* jb: below (unsigned <) */

loc_002DE135: ;
    eax = MEM32(esi + 0x19FC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DE16A; /* je: equal / zero */

loc_002DE13F: ;
    (void)0; /* emms - empty MMX state */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, ebx);
    MEM32(esi + 0x1A00) = edi;
    { uint32_t _icall_target = MEM32(esi + 0x19FC); PUSH32(esp, 0x002DE14Eu); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002DE148u); } /* indirect call */
    }

loc_002DE14E: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    PUSH32(esp, 0);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DE159u); RECOMP_ABI_CALL(0x002DDD70u, sub_002DDD70); /* call 0x002DDD70 */

loc_002DE159: ;
    PUSH32(esp, eax);
    edx = ebp;
    ecx = esi;
    PUSH32(esp, 0x002DE163u); RECOMP_ABI_CALL(0x002DDA80u, sub_002DDA80); /* call 0x002DDA80 */

loc_002DE163: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x2000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x2000 (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DE1CB; /* jb: below (unsigned <) */

loc_002DE16A: ;
    edi = MEM32(ebp + 4);
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(LO8(ebx)) & 0xFFu; _fb = (uint32_t)(8) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test LO8(ebx), 8 (8-bit) */
    MEM32(esi + 0x1DD0) = eax;
    if (TEST_NZ(_fa, _fb)) goto loc_002DE184; /* jne: not equal / not zero */

loc_002DE17A: ;
    MEM32(edi + 0x10) = 0x40110;
    MEM32(edi + 0x14) = eax;

loc_002DE184: ;
    MEM32(edi + 0x18) = 0x40100;
    MEM32(edi + 0x1C) = 5;
    PUSH32(esp, 0x002DE197u); RECOMP_ABI_CALL(0x002DDDF0u, sub_002DDDF0); /* call 0x002DDDF0 */

loc_002DE197: ;
    PUSH32(esp, 1);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DE19Fu); RECOMP_ABI_CALL(0x002DDD70u, sub_002DDD70); /* call 0x002DDD70 */

loc_002DE19F: ;
    PUSH32(esp, eax);
    edx = ebp;
    ecx = esi;
    PUSH32(esp, 0x002DE1A9u); RECOMP_ABI_CALL(0x002DDA80u, sub_002DDA80); /* call 0x002DDA80 */

loc_002DE1A9: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x2000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x2000 (32-bit) */
    if (CMP_AE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE208(); return; } /* jae: above or equal (unsigned >=) */

loc_002DE1B0: ;
    eax = 0x40100;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    MEM32(edi + 0x10) = eax;
    MEM32(edi + 0x14) = ecx;
    MEM32(edi + 0x18) = eax;
    MEM32(edi + 0x1C) = ecx;
    PUSH32(esp, 0x002DE1C8u); RECOMP_ABI_CALL(0x002DDDF0u, sub_002DDDF0); /* call 0x002DDDF0 */

loc_002DE1C8: ;
    edi = MEM32(ebp);

loc_002DE1CB: ;
    eax = MEM32(esi + 0x19FC);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DE1ED; /* je: equal / zero */

loc_002DE1D5: ;
    (void)0; /* emms - empty MMX state */
    ebx = ebx | 0x80000000u;
    _fa = (uint32_t)(ebx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, ebx);
    MEM32(esi + 0x1A00) = edi;
    { uint32_t _icall_target = MEM32(esi + 0x19FC); PUSH32(esp, 0x002DE1EAu); RECOMP_ICALL_SAFE_AT_CC(_icall_target, _icall_esp, 0x002DE1E4u); } /* indirect call */
    }

loc_002DE1EA: ;
    _fb = (uint32_t)(4) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    esp = esp + 4;
    _fa = (uint32_t)(esp) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DE1ED: ;
    edx = MEM32(esi + 0x30);
    esi = MEM32(esi + 0x2C);
    eax = esi;
    _fb = (uint32_t)(edi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    eax = eax - edi;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */

loc_002DE1F7: ;
    ecx = MEM32(edx);
    edi = esi;
    _fb = (uint32_t)(ecx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    edi = edi - ecx;
    _fa = (uint32_t)(edi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(edi) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, edi (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DE1F7; /* jb: below (unsigned <) */

loc_002DE201: ;
    POP32(esp, ebx);

loc_002DE202: ;
    POP32(esp, ebp);

loc_002DE203: ;
    POP32(esp, edi);
    POP32(esp, esi);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DE230
 * Original: 0x002DE230 - 0x002DE265 (53 bytes, 19 insns)
 * CC: cdecl, 2 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE230(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE230: ;
    PUSH32(esp, ecx);
    PUSH32(esp, esi);
    esi = MEM32(0x2E9548);
    _fa = (uint32_t)(MEM8(esi + 8)) & 0xFFu; _fb = (uint32_t)(4) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(esi + 8), 4 (8-bit) */
    PUSH32(esp, edi);
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE265(); return; } /* je: equal / zero */

loc_002DE23F: ;
    eax = MEM32(esi + 0x764);
    edi = MEM32(eax + 4);
    ecx = MEM32(esi);
    edx = MEM32(esi + 0x768);
    _fb = (uint32_t)(edi) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* sub source, before the write */
    ecx = ecx - edi;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* sub result */
    _fb = (uint32_t)(ecx) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    edx = edx + ecx;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    MEM32(esi + 0x768) = edx;
    eax = MEM32(eax + 4);
    POP32(esp, edi);
    MEM32(esi) = eax;
    POP32(esp, esi);
    POP32(esp, ecx);
    esp += 12; return; /* ret 8 */

}

/**
 * sub_002DE370
 * Original: 0x002DE370 - 0x002DE37F (15 bytes, 6 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE370(void)
{
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DE370: ;
    eax = MEM32(0x2EBCE8);
    PUSH32(esp, eax);
    eax = eax >> 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE37Eu); RECOMP_ABI_CALL(0x002DE230u, sub_002DE230); /* call 0x002DE230 */

loc_002DE37E: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002DE380
 * Original: 0x002DE380 - 0x002DE3C4 (68 bytes, 24 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE380(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DE380: ;
    ecx = MEM32(0x2E9548);
    eax = MEM32(ecx);
    ecx = MEM32(ecx + 4);
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    edx = eax + esi * 4;
    _fb = (uint32_t)(0x200) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 0x200;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(ecx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, ecx (32-bit) */
    if (CMP_B(_fa, _fb)) goto loc_002DE3C0; /* jb: below (unsigned <) */

loc_002DE39D: ;
    eax = MEM32(0x2EBCE8);
    edx = eax;
    eax = eax >> 1;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* shift result */
    ecx = esi * 4 + 0x204;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(eax) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, eax (32-bit) */
    if (CMP_BE(_fa, _fb)) goto loc_002DE3B3; /* jbe: below or equal (unsigned <=) */

loc_002DE3B1: ;
    eax = ecx;

loc_002DE3B3: ;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, edx (32-bit) */
    if (CMP_BE(_fa, _fb)) goto loc_002DE3B9; /* jbe: below or equal (unsigned <=) */

loc_002DE3B7: ;
    edx = ecx;

loc_002DE3B9: ;
    PUSH32(esp, edx);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE3C0u); RECOMP_ABI_CALL(0x002DE230u, sub_002DE230); /* call 0x002DE230 */

loc_002DE3C0: ;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE3D0
 * Original: 0x002DE3D0 - 0x002DE3E1 (17 bytes, 6 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE3D0(void)
{

loc_002DE3D0: ;
    eax = MEM32(0x2E9548);
    ecx = MEM32(eax + 0x2C);
    PUSH32(esp, 2);
    PUSH32(esp, ecx);
    PUSH32(esp, 0x002DE3E0u); RECOMP_ABI_CALL(0x002DE0C0u, sub_002DE0C0); /* call 0x002DE0C0 */

loc_002DE3E0: ;
    esp += 4; return; /* ret */

}

/**
 * sub_002DE3F0
 * Original: 0x002DE3F0 - 0x002DE434 (68 bytes, 23 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE3F0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE3F0: ;
    eax = MEM32(0x2E9548);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE465(); return; } /* je: equal / zero */

loc_002DE3F9: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(eax);
    ecx = ecx & 0x70000;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0x50000 (32-bit) */
    PUSH32(esp, esi);
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE436(); return; } /* jne: not equal / not zero */

loc_002DE40E: ;
    esi = MEM32(eax + 0x14);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE436(); return; } /* je: equal / zero */

loc_002DE415: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE41Bu); RECOMP_ABI_CALL(0x002DE5A0u, sub_002DE5A0); /* call 0x002DE5A0 */

loc_002DE41B: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE434(); return; } /* je: equal / zero */

loc_002DE41F: ;
    edx = MEM32(0x2E9548);
    eax = MEM32(edx + 0x2C);
    PUSH32(esp, 2);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE430u); RECOMP_ABI_CALL(0x002DE0C0u, sub_002DE0C0); /* call 0x002DE0C0 */

loc_002DE430: ;
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE470
 * Original: 0x002DE470 - 0x002DE497 (39 bytes, 12 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE470(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE470: ;
    edx = MEM32(0x2E9548);
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp edx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE4A3(); return; } /* je: equal / zero */

loc_002DE47A: ;
    ecx = MEM32(esp + 4);
    eax = MEM32(ecx + 8);
    _fa = (uint32_t)(MEM32(ecx)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x780000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test MEM32(ecx), 0x780000 (32-bit) */
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE497(); return; } /* je: equal / zero */

loc_002DE489: ;
    eax = MEM32(edx + 0x2C);
    PUSH32(esp, 2);
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE494u); RECOMP_ABI_CALL(0x002DE0C0u, sub_002DE0C0); /* call 0x002DE0C0 */

loc_002DE494: ;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE4B0
 * Original: 0x002DE4B0 - 0x002DE4ED (61 bytes, 23 insns)
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE4B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE4B0: ;
    PUSH32(esp, esi);
    esi = MEM32(0x2EBCE0);
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0 (32-bit) */
    PUSH32(esp, edi);
    edi = 0x2EBCE0;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE4F6(); return; } /* je: equal / zero */

loc_002DE4C1: ;
    PUSH32(esp, ebp);
    ebp = MEM32(esp + 0x10);
    _fa = (uint32_t)(MEM32(esi + 4)) & 0xFFFFFFFFu; _fb = (uint32_t)(ebp) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(esi + 4), ebp (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE4ED(); return; } /* jne: not equal / not zero */

loc_002DE4CB: ;
    eax = MEM32(esi);
    MEM32(edi) = eax;
    _fa = (uint32_t)(MEM8(esi + 0x1C)) & 0xFFu; _fb = (uint32_t)(1) & 0xFFu;
    _fas = (int32_t)(int8_t)(_fa); _fbs = (int32_t)(int8_t)(_fb); /* test MEM8(esi + 0x1C), 1 (8-bit) */
    if (TEST_Z(_fa, _fb)) goto loc_002DE4DE; /* je: equal / zero */

loc_002DE4D5: ;
    eax = MEM32(esi + 0x20);
    ecx = MEM32(eax);
    { uint32_t _icall_esp = g_esp;
    PUSH32(esp, eax);
    { uint32_t _icall_target = MEM32(ecx + 8); PUSH32(esp, 0x002DE4DEu); RECOMP_ICALL_SAFE_AT(_icall_target, _icall_esp, 0x002DE4DBu); } /* indirect call */
    }

loc_002DE4DE: ;
    PUSH32(esp, 0x24800000);
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DE4E9u); RECOMP_ABI_CALL(0x001F09DCu, sub_001F09DC); /* call 0x001F09DC */

loc_002DE4E9: ;
    esi = MEM32(edi);
    g_seh_ebp = ebp; sub_002DE4F1(); return; /* tail jmp 0x002DE4F1 */

}

/**
 * sub_002DE500
 * Original: 0x002DE500 - 0x002DE545 (69 bytes, 23 insns)
 * Category: game_render
 * CC: cdecl, 0 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE500(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE500: ;
    PUSH32(esp, esi);
    PUSH32(esp, edi);
    edi = MEM32(esp + 0xC);
    eax = MEM32(edi);
    esi = eax;
    esi = esi & 0x70000;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0x50000 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DE51C; /* jne: not equal / not zero */

loc_002DE518: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if ((((uint32_t)((uint32_t)(_fa) - (uint32_t)(_fb)) >> 31) == 0)) goto loc_002DE522; /* jns: not sign (positive) */

loc_002DE51C: ;
    PUSH32(esp, edi);
    PUSH32(esp, 0x002DE522u); RECOMP_ABI_CALL(0x002DE3F0u, sub_002DE3F0); /* call 0x002DE3F0 */

loc_002DE522: ;
    PUSH32(esp, edi);
    PUSH32(esp, 0x002DE528u); RECOMP_ABI_CALL(0x002DE4B0u, sub_002DE4B0); /* call 0x002DE4B0 */

loc_002DE528: ;
    _fa = (uint32_t)(esi) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp esi, 0x50000 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE545(); return; } /* jne: not equal / not zero */

loc_002DE530: ;
    _fa = (uint32_t)(MEM32(edi)) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp MEM32(edi), 0 (32-bit) */
    if ((((uint32_t)((uint32_t)(_fa) - (uint32_t)(_fb)) >> 31) == 0)) { g_seh_ebp = ebp; sub_002DE581(); return; } /* jns: not sign (positive) */

loc_002DE535: ;
    eax = MEM32(edi + 4);
    PUSH32(esp, 0xA1800000u);
    eax = eax | 0x80000000u;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* or result */
    PUSH32(esp, eax);
    g_seh_ebp = ebp; sub_002DE57C(); return; /* tail jmp 0x002DE57C */

}

/**
 * sub_002DE5A0
 * Original: 0x002DE5A0 - 0x002DE5D0 (48 bytes, 14 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE5A0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE5A0: ;
    ecx = MEM32(esp + 4);
    eax = MEM32(ecx);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x780000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test eax, 0x780000 (32-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DE5C8; /* jne: not equal / not zero */

loc_002DE5AD: ;
    eax = eax & 0x70000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x50000 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE5D0(); return; } /* jne: not equal / not zero */

loc_002DE5B9: ;
    eax = MEM32(ecx + 0x14);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE5D0(); return; } /* je: equal / zero */

loc_002DE5C0: ;
    _fa = (uint32_t)(MEM32(eax)) & 0xFFFFFFFFu; _fb = (uint32_t)(0x780000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test MEM32(eax), 0x780000 (32-bit) */
    if (TEST_Z(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE5D0(); return; } /* je: equal / zero */

loc_002DE5C8: ;
    eax = 1;
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE5E0
 * Original: 0x002DE5E0 - 0x002DE612 (50 bytes, 13 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE5E0(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DE5E0: ;
    eax = MEM32(esp + 4);
    ecx = MEM32(eax);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x780000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test ecx, 0x780000 (32-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DE609; /* jne: not equal / not zero */

loc_002DE5EE: ;
    ecx = ecx & 0x70000;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0x50000 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DE609; /* jne: not equal / not zero */

loc_002DE5FC: ;
    ecx = MEM32(eax + 0x14);
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DE609; /* je: equal / zero */

loc_002DE603: ;
    _fb = (uint32_t)(0x80000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    MEM32(ecx) = MEM32(ecx) + 0x80000;
    _fa = (uint32_t)(MEM32(ecx)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */

loc_002DE609: ;
    _fb = (uint32_t)(0x80000) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    MEM32(eax) = MEM32(eax) + 0x80000;
    _fa = (uint32_t)(MEM32(eax)) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE620
 * Original: 0x002DE620 - 0x002DE657 (55 bytes, 20 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE620(void)
{
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;

loc_002DE620: ;
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0xFFFF) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test eax, 0xFFFF (32-bit) */
    if (TEST_NZ(_fa, _fb)) goto loc_002DE647; /* jne: not equal / not zero */

loc_002DE62E: ;
    eax = eax & 0x70000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x50000 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DE647; /* jne: not equal / not zero */

loc_002DE63A: ;
    eax = MEM32(esi + 0x14);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DE647; /* je: equal / zero */

loc_002DE641: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE647u); RECOMP_ABI_CALL(0x002DE620u, sub_002DE620); /* call 0x002DE620 */

loc_002DE647: ;
    edx = MEM32(esi);
    edx++;
    _fa = (uint32_t)(edx) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fb = (_fa == 0x80000000u); /* inc result/SF/OF; CF unchanged */
    eax = edx;
    MEM32(esi) = edx;
    eax = eax & 0xFFFF;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE660
 * Original: 0x002DE660 - 0x002DE6A2 (66 bytes, 23 insns)
 * Category: game_render
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE660(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE660: ;
    PUSH32(esp, esi);
    esi = MEM32(esp + 8);
    eax = MEM32(esi);
    ecx = eax;
    ecx = ecx & 0xFFFF;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fb = (uint32_t)(1) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp ecx, 1 (32-bit) */
    if (CMP_NE(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE6A2(); return; } /* jne: not equal / not zero */

loc_002DE674: ;
    eax = eax & 0x70000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x50000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x50000 (32-bit) */
    if (CMP_NE(_fa, _fb)) goto loc_002DE68D; /* jne: not equal / not zero */

loc_002DE680: ;
    eax = MEM32(esi + 0x14);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) goto loc_002DE68D; /* je: equal / zero */

loc_002DE687: ;
    PUSH32(esp, eax);
    PUSH32(esp, 0x002DE68Du); RECOMP_ABI_CALL(0x002DE660u, sub_002DE660); /* call 0x002DE660 */

loc_002DE68D: ;
    eax = MEM32(esi);
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x780000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* test eax, 0x780000 (32-bit) */
    if (TEST_NZ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE6A2(); return; } /* jne: not equal / not zero */

loc_002DE696: ;
    PUSH32(esp, esi);
    PUSH32(esp, 0x002DE69Cu); RECOMP_ABI_CALL(0x002DE500u, sub_002DE500); /* call 0x002DE500 */

loc_002DE69C: ;
    eax = 0; /* xor self */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    POP32(esp, esi);
    esp += 8; return; /* ret 4 */

}

/**
 * sub_002DE6B0
 * Original: 0x002DE6B0 - 0x002DE6DA (42 bytes, 14 insns)
 * CC: cdecl, 1 params, returns int_or_void
 * Frame: fpo_leaf
 */
void sub_002DE6B0(void)
{
    uint32_t ebp = 0;
    ebp = g_ebp;  /* frameless: caller's frame */
    int _flags = 0; /* fallback flag var */
    uint32_t _fa = 0, _fb = 0;
    int32_t _fas = 0, _fbs = 0;
    (void)_fa; (void)_fb; (void)_fas; (void)_fbs;
    ebp = g_seh_ebp; /* fpo_leaf: inherit caller's frame */

loc_002DE6B0: ;
    ecx = MEM32(esp + 4);
    eax = MEM32(ecx);
    eax = eax & 0x70000;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* and result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x30000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x30000 (32-bit) */
    if (CMP_A(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE6EA(); return; } /* ja: above (unsigned >) */

loc_002DE6C2: ;
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE6E2(); return; } /* je: equal / zero */

loc_002DE6C4: ;
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0 (32-bit) */
    if (CMP_EQ(_fa, _fb)) { g_seh_ebp = ebp; sub_002DE6DA(); return; } /* je: equal / zero */

loc_002DE6C8: ;
    ecx = 0; /* xor self */
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* xor result */
    _fa = (uint32_t)(eax) & 0xFFFFFFFFu; _fb = (uint32_t)(0x10000) & 0xFFFFFFFFu;
    _fas = (int32_t)(int32_t)(_fa); _fbs = (int32_t)(int32_t)(_fb); /* cmp eax, 0x10000 (32-bit) */
    SET_LO8(ecx, (CMP_NE(_fa, _fb)) ? 1 : 0); /* setne */
    _fb = (uint32_t)(7) & 0xFFFFFFFFu; _fbs = (int32_t)(int32_t)(_fb); /* add source, before the write */
    ecx = ecx + 7;
    _fa = (uint32_t)(ecx) & 0xFFFFFFFFu; _fas = (int32_t)(int32_t)(_fa); /* add result */
    eax = ecx;
    esp += 8; return; /* ret 4 */

}
